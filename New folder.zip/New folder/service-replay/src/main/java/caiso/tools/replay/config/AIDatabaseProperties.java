package caiso.tools.replay.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Holds properties for the AI Audit Database in both the "source" database we pull messages from and the
 * "destination" database we can use to verify messages were delivered to.
 */
@Component
@ConfigurationProperties(prefix = "AIDatabase")
public class AIDatabaseProperties {

    private SourceDBSQLProperties source;
    private DestinationDBSQLProperties destination;

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public SourceDBSQLProperties getSource() {
        return source;
    }

    public void setSource(SourceDBSQLProperties source) {
        this.source = source;
    }

    public DestinationDBSQLProperties getDestination() {
        return destination;
    }

    public void setDestination(DestinationDBSQLProperties destination) {
        this.destination = destination;
    }

    @Override
    public String toString() {
        return "AIDatabaseProperties{" +
                "source=" + source +
                ", destination=" + destination +
                '}';
    }
}
