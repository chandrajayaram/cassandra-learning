package caiso.tools.replay;

import caiso.tools.replay.config.AIDatabaseProperties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.actuate.endpoint.Endpoint;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AuditDBMetrics implements Endpoint {
    private static final Logger logger = LogManager.getLogger(AuditDBMetrics.class);

    private String startDateTimeString;
    private volatile Map<String, Object> sourceMetrics = new HashMap<>();
    private volatile Map<String, Object> destinationMetrics = new HashMap<>();
    private volatile List<String[]> failedConnectionList = new ArrayList<>();
    private volatile List<String[]> exceptionList = new ArrayList<>();
    private volatile Status a2a = new Status();
    private volatile Status b2b = new Status();
    private volatile int sourceReceivesCount;
    private volatile int destinationA2ABroadcastCount;
    private volatile int destinationB2BBroadcastCount;
    private volatile int destinationReceivesCount;
    @Resource
    private AIDatabaseProperties aiDatabaseProperties;
    @SuppressWarnings("SpringJavaAutowiringInspection")
    @Resource(name = "jdbcSource")
    private JdbcTemplate jdbcSource;
    @SuppressWarnings("SpringJavaAutowiringInspection")
    @Resource(name = "jdbcDestination")
    private JdbcTemplate jdbcDestination;

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public Map<String, Object> getSource() {
        sourceMetrics.put("db", aiDatabaseProperties.getSource().getUrl());
        HashMap<String, Integer> map = new HashMap<>();
        Status s;

        sourceMetrics.put("broadcast-a2a", map);
        s = this.a2a;
        map.put("count", s.count);
        map.put("processing", s.processing);
        map.put("sent", s.sent);

        map = new HashMap<>();
        sourceMetrics.put("broadcast-b2b", map);
        s = this.b2b;
        map.put("count", s.count);
        map.put("processing", s.processing);
        map.put("sent", s.sent);

        sourceMetrics.put("receivesCount", this.sourceReceivesCount);

        return sourceMetrics;
    }

    public Map<String, Object> getDestination() {
        destinationMetrics.put("db", aiDatabaseProperties.getDestination().getUrl());
        HashMap<String, Integer> map = new HashMap<>();

        destinationMetrics.put("broadcast-a2a", map);
        map.put("count", this.destinationA2ABroadcastCount);

        map = new HashMap<>();
        destinationMetrics.put("broadcast-b2b", map);
        map.put("count", this.destinationB2BBroadcastCount);

        destinationMetrics.put("receivesCount", this.destinationReceivesCount);

        return destinationMetrics;
    }

    public void incB2BBroadcastProcessing() {
        this.b2b.processing++;
    }

    public void decB2BBroadcastProcessing() {
        this.b2b.processing--;
    }

    public void incB2BBroadcastsSent() {
        this.b2b.sent++;
    }

    public void incA2ABroadcastProcessing() {
        this.a2a.processing++;
    }

    public void decA2ABroadcastProcessing() {
        this.a2a.processing--;
    }

    public void incA2ABroadcastsSent() {
        this.a2a.sent++;
    }

    public List<String[]> getExceptionList() {
        return exceptionList;
    }

    public String getStartDateTimeString() {
        return startDateTimeString;
    }

    public void setStartDateTimeString(String startDateTimeString) {
        this.startDateTimeString = startDateTimeString;
    }

    @Override
    public String getId() {
        return "AuditDBMetrics";
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public boolean isSensitive() {
        return false;
    }

    @Override
    public Object invoke() {
        updateMetrics();

        return this;
    }

    public void addFailedConnection(String failedURL, String reason) {
        failedConnectionList.add(new String[]{new Date().toString(), failedURL, reason});
    }

    public void addException(String description, Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        // exceptionList.add(new String[]{description, sw.toString()});
        exceptionList.add(new String[]{new Date().toString(), description, t.toString()});
    }

    public List<String[]> getFailedConnectionList() {
        return failedConnectionList;
    }

    private void updateMetrics() {
        StringBuilder sb = new StringBuilder();

        // source b2b count
        {
            sb.setLength(0);
            sb.append(aiDatabaseProperties.getSource().getB2bCountSQL());
            sb.append("  AND request.TIME_STAMP >= TO_TIMESTAMP(:startdatetime, 'YYYY-MM-DD\"T\"HH24:MI:SS\"-00:00\"')\n");

            logger.trace("Using SQL: \n{} \nwith {}", sb.toString(), getStartDateTimeString());
            this.b2b.count = jdbcSource.queryForObject(sb.toString(), new String[]{getStartDateTimeString()}, new RowMapper<Integer>() {

                // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                @Override
                public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return rs.getInt("COUNT");
                }
            });
        }
        // source a2a count
        {
            sb.setLength(0);
            sb.append(aiDatabaseProperties.getSource().getA2aCountSQL());
            sb.append("  AND request.TIME_STAMP >= TO_TIMESTAMP(:startdatetime, 'YYYY-MM-DD\"T\"HH24:MI:SS\"-00:00\"')\n");

            logger.trace("Using SQL: \n{} \nwith {}", sb.toString(), getStartDateTimeString());
            this.a2a.count = jdbcSource.queryForObject(sb.toString(), new String[]{getStartDateTimeString()}, new RowMapper<Integer>() {

                // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                @Override
                public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return rs.getInt("COUNT");
                }
            });
        }
        // source receives count
        {
            sb.setLength(0);
            sb.append(aiDatabaseProperties.getSource().getReceivesCountSQL());
            sb.append("  AND request.TIME_STAMP >= TO_TIMESTAMP(:startdatetime, 'YYYY-MM-DD\"T\"HH24:MI:SS\"-00:00\"')\n");

            logger.trace("Using SQL: \n{} \nwith {}", sb.toString(), getStartDateTimeString());
            this.sourceReceivesCount = jdbcSource.queryForObject(sb.toString(), new String[]{getStartDateTimeString()}, new RowMapper<Integer>() {

                // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                @Override
                public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return rs.getInt("COUNT");
                }
            });
        }

        // destination a2a count
        {
            sb.setLength(0);
            sb.append(aiDatabaseProperties.getDestination().getA2aCountSQL());
            sb.append("  AND request.RECEPTION_DATETIME >= TO_TIMESTAMP(:startdatetime, 'YYYY-MM-DD\"T\"HH24:MI:SS\"-00:00\"')\n");

            logger.trace("Using SQL: \n{} \nwith {}", sb.toString(), getStartDateTimeString());
            this.destinationA2ABroadcastCount = jdbcDestination.queryForObject(sb.toString(), new String[]{getStartDateTimeString()}, new RowMapper<Integer>() {
                // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                @Override
                public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return rs.getInt("COUNT");
                }
            });
        }
        // destination b2b count
        {
            sb.setLength(0);
            sb.append(aiDatabaseProperties.getDestination().getB2bCountSQL());
            sb.append("  AND request.RECEPTION_DATETIME >= TO_TIMESTAMP(:startdatetime, 'YYYY-MM-DD\"T\"HH24:MI:SS\"-00:00\"')\n");

            logger.trace("Using SQL: \n{} \nwith {}", sb.toString(), getStartDateTimeString());
            this.destinationB2BBroadcastCount = jdbcDestination.queryForObject(sb.toString(), new String[]{getStartDateTimeString()}, new RowMapper<Integer>() {
                // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                @Override
                public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return rs.getInt("COUNT");
                }
            });
        }
        // source receives count
        {
            sb.setLength(0);
            sb.append(aiDatabaseProperties.getDestination().getReceivesCountSQL());
            sb.append("  AND request.RECEPTION_DATETIME >= TO_TIMESTAMP(:startdatetime, 'YYYY-MM-DD\"T\"HH24:MI:SS\"-00:00\"')\n");

            logger.trace("Using SQL: \n{} \nwith {}", sb.toString(), getStartDateTimeString());
            this.destinationReceivesCount = jdbcDestination.queryForObject(sb.toString(), new String[]{getStartDateTimeString()}, new RowMapper<Integer>() {

                // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                @Override
                public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return rs.getInt("COUNT");
                }
            });
        }

    }

    private class Status {
        private int count;
        private int processing;
        private int sent;
    }

}


