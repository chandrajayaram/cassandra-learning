package caiso.tools.replay.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "services")
public class ServiceProperties {
    private List<ServiceConfig> operationMappings;
    private String broadcastAIBaseURL;
    private String caisoESBURL;

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public String getCaisoESBURL() {
        return caisoESBURL;
    }

    public void setCaisoESBURL(String caisoESBURL) {
        this.caisoESBURL = caisoESBURL;
    }

    public String getBroadcastAIBaseURL() {
        return broadcastAIBaseURL;
    }

    public void setBroadcastAIBaseURL(String broadcastAIBaseURL) {
        this.broadcastAIBaseURL = trimURL(broadcastAIBaseURL);
    }

    public List<ServiceConfig> getOperationMappings() {
        return operationMappings;
    }

    public void setOperationMappings(List<ServiceConfig> operationMappings) {
        this.operationMappings = operationMappings;
    }

    public ServiceConfig getOperationMapping(String operation) {
        for (ServiceConfig config : operationMappings) {
            if (config.getOperation().equals(operation)) return config;
        }
        return null;
    }

    @Override
    public String toString() {
        return "ServiceProperties{" +
                "operationMappings=" + operationMappings +
                ", broadcastAIBaseURL='" + broadcastAIBaseURL + '\'' +
                ", caisoESBURL='" + caisoESBURL + '\'' +
                '}';
    }

    private String trimURL(String url) {
        if (!url.endsWith("/"))
            url += "/";
        return url;
    }

    public static class ServiceConfig {
        private String operation;
        private String soapAction;

        // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        public String getOperation() {
            return operation;
        }

        public void setOperation(String operation) {
            this.operation = operation;
        }

        public String getSoapAction() {
            return soapAction;
        }

        public void setSoapAction(String soapAction) {
            this.soapAction = soapAction;
        }

        @Override
        public String toString() {
            return "ServiceConfig{" +
                    "operation='" + operation + '\'' +
                    ", soapAction='" + soapAction + '\'' +
                    '}';
        }
    }
}
