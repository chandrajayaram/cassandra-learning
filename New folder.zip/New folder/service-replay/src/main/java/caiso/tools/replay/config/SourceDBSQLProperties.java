package caiso.tools.replay.config;

/**
 * Source AI Audit DB properties.  The Source DB is where we query and pull (reconstruct) messages from
 */
public class SourceDBSQLProperties extends DatabaseConnectionProperties {
    private String a2ASQL;
    private String a2aCountSQL;
    private String b2BSQL;
    private String b2bCountSQL;
    private String receivesCountSQL;
    private Poll poll;


    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * Receives msg count
     *
     * @return
     */
    public String getReceivesCountSQL() {
        return receivesCountSQL;
    }

    /**
     * Receives msg count
     *
     * @param receivesCountSQL
     */
    public void setReceivesCountSQL(String receivesCountSQL) {
        this.receivesCountSQL = receivesCountSQL;
    }

    /**
     * A2A msg count
     *
     * @return
     */
    public String getA2aCountSQL() {
        return a2aCountSQL;
    }

    /**
     * A2A msg count
     *
     * @param a2aCountSQL
     */
    public void setA2aCountSQL(String a2aCountSQL) {
        this.a2aCountSQL = a2aCountSQL;
    }

    /**
     * B2B msg count
     *
     * @return
     */
    public String getB2bCountSQL() {
        return b2bCountSQL;
    }

    /**
     * B2B msg count
     *
     * @param b2bCountSQL
     */
    public void setB2bCountSQL(String b2bCountSQL) {
        this.b2bCountSQL = b2bCountSQL;
    }

    /**
     * Polling properties of DB
     *
     * @return
     */
    public Poll getPoll() {
        return poll;
    }

    /**
     * Polling properties of DB
     *
     * @param poll
     */
    public void setPoll(Poll poll) {
        this.poll = poll;
    }

    /**
     * B2B msg SQL used to retrieve msgs
     *
     * @return
     */
    public String getB2BSQL() {
        return b2BSQL;
    }

    /**
     * B2B msg SQL used to retrieve msgs
     *
     * @param b2BSQL
     */
    public void setB2BSQL(String b2BSQL) {
        this.b2BSQL = b2BSQL;
    }

    /**
     * A2A msg SQL used to retrieve msgs.  In the Audit DB, these are logged as Receives, so we actually select
     * a set of receives
     *
     * @return
     */
    public String getA2ASQL() {
        return a2ASQL;
    }

    /**
     * A2A msg SQL used to retrieve msgs.  In the Audit DB, these are logged as Receives, so we actually select
     * a set of receives
     *
     * @param a2ASQL
     */
    public void setA2ASQL(String a2ASQL) {
        this.a2ASQL = a2ASQL;
    }

    @Override
    public String toString() {
        return "SourceDBSQLProperties{" +
                "a2ASQL='" + a2ASQL + '\'' +
                ", a2aCountSQL='" + a2aCountSQL + '\'' +
                ", b2BSQL='" + b2BSQL + '\'' +
                ", b2bCountSQL='" + b2bCountSQL + '\'' +
                ", receivesCountSQL='" + receivesCountSQL + '\'' +
                ", poll=" + poll +
                "} " + super.toString();
    }

    /**
     * Wrapper to hold DB polling properies
     */
    public static class Poll {
        private boolean enabled;
        private int intervalSeconds;

        // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getIntervalSeconds() {
            return intervalSeconds;
        }

        public void setIntervalSeconds(int intervalSeconds) {
            this.intervalSeconds = intervalSeconds;
        }

        @Override
        public String toString() {
            return "Poll{" +
                    "enabled=" + enabled +
                    ", intervalSeconds=" + intervalSeconds +
                    '}';
        }
    }
}
