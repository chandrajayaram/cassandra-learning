package caiso.tools.replay;


import caiso.tools.replay.config.AIDatabaseProperties;
import caiso.tools.replay.config.ServiceProperties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.xml.soap.SOAPException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Similar to A2AAuditQuery, this reconstructs SOAP message in A2A AuditDB, but rather than broadcast messages, its
 * query looks at a certain set of B2B receive messages logged there and reconstructs them.  Then sends reconstructed
 * SOAP message (as if it came from original source) to the CAISO ESB (not the B2B broadcast AI).
 */
@Component
public class B2BAuditQuery {

    private static final Logger logger = LogManager.getLogger(B2BAuditQuery.class);
    private static final String TYPE = "B2B";

    private static final String AUDIT_REQUEST_PROCESSED_SQL = "SELECT\n" +
            "  SERVICE,\n" +
            "  INTERACTION,\n" +
            "  NODE,\n" +
            "  REQUEST_ID,\n" +
            "  TIME_STAMP\n" +
            "FROM ACT_REQUEST\n" +
            "WHERE instr(SERVICE, 'Receive') > 0\n" +
            "      AND time_stamp >= SYSDATE - 5 / (24 * 60)\n" +
            "ORDER BY TIME_STAMP DESC";
    private static final List<String> usedRequestList = new ArrayList<>();

    @SuppressWarnings("SpringJavaAutowiringInspection")
    @Resource(name = "jdbcSource")
    private JdbcTemplate jdbcTemplate;
    @Resource
    private AIDatabaseProperties aiDatabaseProperties;
    @Resource
    private ServiceProperties serviceProperties;
    @Resource
    private AuditDBMetrics dbMetrics;

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @SuppressWarnings("Duplicates")
    void runQuery() {
        logger.trace("Running query for {} audit events....", TYPE);

        StringBuilder sb = new StringBuilder();
        sb.append("SELECT * FROM (");
        sb.append(aiDatabaseProperties.getSource().getB2BSQL());
        sb.append(") ");
        if (usedRequestList.size() > 0) {
            sb.append("WHERE INTERACTION NOT IN (");
            for (int i = 0; i < usedRequestList.size(); i++) {
                sb.append("'").append(usedRequestList.get(i)).append("' ");
                if (i < (usedRequestList.size() - 1)) sb.append(",");
            }
            sb.append(")");
        }

        logger.trace("Using {}, SQL: \n{}", TYPE, sb.toString());
        jdbcTemplate.query(sb.toString(), new RowCallbackHandler() {

            // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            public void processRow(ResultSet rs) throws SQLException {
                String serviceGroup = null;
                String node = null;
                String serviceName = null;
                String operation = null;
                String requestData = null;
                int attachSize = -1;
                String attachType = null;
                String attachName = null;
                Blob attachBody = null;
                byte[] attachBodyBytes = null;
                try {
                    String interactionId = rs.getString("INTERACTION");
                    usedRequestList.add(interactionId);
                    // don't keep more than this many rows in a 5 min span
                    while (usedRequestList.size() > 500) {
                        usedRequestList.remove(0);
                    }
                    serviceGroup = rs.getString("SVC_GROUP");
                    node = rs.getString("NODE");
                    serviceName = rs.getString("SERVICE");
                    operation = rs.getString("OPERATION");
                    requestData = rs.getString("REQUEST_DATA");
                    /*
                    For these B2B messages, since we're pulling the receiveAI log messages from A2A Db, we need
                    to convert the receive to broadcast
                     */
                    requestData = requestData.replaceAll("receive", "broadcast");
                    //same transform for serviceName
                    serviceName = serviceName.replaceAll("Receive", "Broadcast");

                    attachSize = rs.getInt("ATTACH_SIZE");
                    attachType = rs.getString("ATTACH_TYPE");
                    attachName = rs.getString("ATTACH_NAME");
                    attachBody = rs.getBlob("ATTACH_BODY");
                    attachBodyBytes = null;
                    // support inline (no attach) messages
                    if (attachBody != null) {
                        try {
                            int attachBodyLength = (int) attachBody.length();
                            attachBodyBytes = attachBody.getBytes(1, attachBodyLength);
                        } finally {
                            //noinspection Since15
                            attachBody.free();
                        }
                    }

                /*
                For SOAPAction, we have two patterns for this - most of them will follow
                    http://www.caiso.com/soa/<operation>
                but some like TelemetryData_v20120401 uses
                    http://www.caiso.com/soa/<date>/operation

                A property can override the default
                 */
                    ServiceProperties.ServiceConfig serviceConfig = serviceProperties.getOperationMapping(operation);
                    String soapAction;
                    // the AI, seems to surround soapAction in quotes when it sends msg, so we'll do it here in case we
                    // bypass AI and go to our locally running ESB - then handling of headers can be same
                    if (serviceConfig != null) {
                        soapAction = "\"" + serviceConfig.getSoapAction() + "\"";
                    } else {
                        soapAction = "\"http://www.caiso.com/soa/" + operation + "\"";
                    }
                    //same transform receive->broadcast of these b2b msgs for soap action
                    soapAction = soapAction.replaceAll("receive", "broadcast");

                    logger.info("Processing {} service group {} [{}] for SOAPAction {} ", TYPE, serviceGroup, operation, soapAction);

                    // reconstruct and send SOAP message to server
                    SOAPClient soapClient = new SOAPClient();
                    // NB: send b2b msgs to ESB directly, not to broadcast AI
                    // String url = serviceProperties.getBroadcastAIBaseURL() + serviceName;
                    String url = serviceProperties.getCaisoESBURL();
                    soapClient.setEndpointURL(url);
                    soapClient.setSoapAction(soapAction);
                    soapClient.addHeader("replay.ai_interaction", interactionId);
                    soapClient.addHeader("replay.type", TYPE);
                    soapClient.setRequestData(requestData);
                    // support inline / non-attach msgs
                    if (attachBodyBytes != null) {
                        soapClient.setAttachment(attachType, attachName, attachBodyBytes);
                    }
                    try {
                        dbMetrics.incB2BBroadcastProcessing();
                        soapClient.sendMessage();
                        logger.trace("sent interaction {} for {}", interactionId, serviceName);
                        dbMetrics.incB2BBroadcastsSent();
                    } catch (IOException | SOAPException e) {
                        logger.error("Error connecting " + TYPE + " message to " + url + " for " + operation, e);
                        dbMetrics.addFailedConnection(url, e.getMessage());
                    } finally {
                        dbMetrics.decB2BBroadcastProcessing();
                    }
                } catch (Throwable e) {
                    logger.error("Error processing " + TYPE + " row from Audit DB :", e);
                    dbMetrics.addException("Error processing " + TYPE + " Audit DB row for " + operation, e);
                }
            }
        });
    }

    /**
     * mark any 'recent' requests as used/old so we will ignore in future request
     */
    void markUsedRequests() {
        logger.trace("Using SQL: \n{}", AUDIT_REQUEST_PROCESSED_SQL);
        jdbcTemplate.query(AUDIT_REQUEST_PROCESSED_SQL, new RowCallbackHandler() {

            // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            @Override
            public void processRow(ResultSet rs) throws SQLException {
                usedRequestList.add(rs.getString("INTERACTION"));
            }
        });
    }

}
