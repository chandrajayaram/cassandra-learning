package caiso.tools.replay.config;

import oracle.jdbc.pool.OracleDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.SQLException;

/**
 * Generic application configuration
 */
@Configuration
// @Configuration indicates that a class declares one or more methods and may be processed by the Spring container
// to generate bean definitions and service requests for those beans at runtim
@EnableAsync
@EnableScheduling
public class AppConfig {

    private static final Logger logger = LogManager.getLogger(AppConfig.class);
    @Resource
    private AIDatabaseProperties aiDatabaseProperties;
    @Resource(name = "destination")
    private DataSource destinationDB;

// public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * Source DB where messages are pulled/replayed from
     *
     * @return
     * @throws SQLException
     */
    @Bean(name = "source")
    @Primary
    public DataSource dataSource() throws SQLException {
        SourceDBSQLProperties sourceDB = aiDatabaseProperties.getSource();

        String userName = sourceDB.getUserName();
        String password = sourceDB.getPassword();
        String url = sourceDB.getUrl();

        OracleDataSource dataSource = new OracleDataSource();
        dataSource.setUser(userName);
        dataSource.setPassword(password);
        dataSource.setURL(url);
        dataSource.setImplicitCachingEnabled(true);
        dataSource.setFastConnectionFailoverEnabled(true);
        return dataSource;
    }

    @Bean(name = "jdbcSource")
    @Resource(name = "source")
    public JdbcTemplate sourceJdbcTemplate(DataSource sourceDB) {
        return new JdbcTemplate(sourceDB);
    }

    /**
     * Destination db where we can check/validate counts as source messages should be audited to with destination AI
     *
     * @return
     * @throws SQLException
     */
    @Bean(name = "destination")
    public DataSource dataDestination() throws SQLException {
        DestinationDBSQLProperties destinationDB = aiDatabaseProperties.getDestination();

        String userName = destinationDB.getUserName();
        String password = destinationDB.getPassword();
        String url = destinationDB.getUrl();

        OracleDataSource dataSource = new OracleDataSource();
        dataSource.setUser(userName);
        dataSource.setPassword(password);
        dataSource.setURL(url);
        dataSource.setImplicitCachingEnabled(true);
        dataSource.setFastConnectionFailoverEnabled(true);
        return dataSource;
    }

    @Bean(name = "jdbcDestination")
    public JdbcTemplate destinationJdbcTemplate() {
        return new JdbcTemplate(destinationDB);
    }

}
