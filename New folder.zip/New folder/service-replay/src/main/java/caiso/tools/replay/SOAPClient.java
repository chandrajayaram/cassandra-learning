package caiso.tools.replay;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.ws.transport.TransportConstants;

import javax.activation.DataHandler;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.nio.charset.Charset;
import java.util.Iterator;

public class SOAPClient {
    private static final Logger logger = LogManager.getLogger(SOAPClient.class);

    private String endpointURL;
    private String requestData;
    private String attachType;
    private String attachName;
    private byte[] attachBytes;
    private MimeHeaders mimeHeaders;

    public SOAPClient() {
        mimeHeaders = new MimeHeaders();
    }

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    public void setAttachment(String attachType, String attachName, byte[] attachmentBytes) {
        logger.trace("setAttachment {}, {}, {}", attachType, attachName, attachmentBytes.length);

        this.attachType = attachType;
        this.attachName = attachName;
        this.attachBytes = attachmentBytes;
    }

    public void setRequestData(String requestData) {
        logger.trace("setRequestData {}", requestData);

        this.requestData = requestData;
    }

    public void setEndpointURL(String endpointURL) {
        logger.trace("setEndpointURL {}", endpointURL);

        this.endpointURL = endpointURL;
    }

    public void setSoapAction(String soapAction) {
        logger.trace("setSoapAction {}", soapAction);

        // e.g., http://www.caiso.com/soa/2012-04-01/broadcastTelemetryData_v20120401
        addHeader("SOAPAction", soapAction);
    }

    public void addHeader(String key, String value) {
        logger.trace("addHeader {}, {}", key, value);

        mimeHeaders.addHeader(key, value);
    }

    public void sendMessage() throws IOException, SOAPException {
        final int TIMEOUT_SEC = 15; // max time we'll wait for connection response

        // Create SOAP Connection
        SOAPConnectionFactory soapConnectionFactory;
        SOAPConnection soapConnection;
        soapConnectionFactory = SOAPConnectionFactory.newInstance();
        soapConnection = soapConnectionFactory.createConnection();

        SOAPMessage soapMessage = createSOAPMessage();
        // e.g., http://www.caiso.com/soa/2012-04-01/broadcastTelemetryData_v20120401
        Iterator<MimeHeader> allHeaders = mimeHeaders.getAllHeaders();
        while (allHeaders.hasNext()) {
            MimeHeader mh = allHeaders.next();
            soapMessage.getMimeHeaders().addHeader(mh.getName(), mh.getValue());
        }

        // save changes made
        soapMessage.saveChanges();

        logSOAPMessage(soapMessage);

        // Send SOAP Message to broadcastAI
        SOAPMessage soapResponse = null;
        // Only ever need one URL
        URL endpoint = new URL(null, endpointURL, new URLStreamHandler() {
            protected URLConnection openConnection(URL url) throws IOException {
                logger.trace("Opening connection to {}", url.toString());
                // The url is the parent of this stream handler, so must create clone
                URL clone = new URL(url.toString());
                URLConnection connection = clone.openConnection();
                // If you cast to HttpURLConnection, you can set redirects
                // connection.setInstanceFollowRedirects (false); // no redirs
                connection.setConnectTimeout(TIMEOUT_SEC * 1000);
                connection.setReadTimeout(TIMEOUT_SEC * 1000);
                // Custom header
                // connection.addRequestProperty("Developer-Mood", "Happy");
                return connection;
            }
        });
        try {
            soapResponse = soapConnection.call(soapMessage, endpoint);
            logSOAPMessage(soapResponse);
        } finally {
            soapConnection.close();
        }
    }

    private SOAPMessage createSOAPMessage() throws SOAPException, IOException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(), new ByteArrayInputStream(requestData.getBytes(Charset.forName("UTF-8"))));

        if (this.attachBytes != null) {
            DataHandler dataHandler = new DataHandler(this.attachBytes, attachType);
            AttachmentPart attachmentPart = message.createAttachmentPart(dataHandler);
            attachmentPart.setContentId(attachName);
            attachmentPart.setMimeHeader(TransportConstants.HEADER_CONTENT_TRANSFER_ENCODING, "binary");
            message.addAttachmentPart(attachmentPart);
        }

        return message;
    }

    private void logSOAPMessage(SOAPMessage soapMsg) {
        final TransformerFactory transformerFactory = TransformerFactory.newInstance();
        StreamResult result = new StreamResult(new StringWriter());

        try {
            final Transformer transformer = transformerFactory.newTransformer();
            // format
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

            Source sourceContent = soapMsg.getSOAPPart().getContent();
            transformer.transform(sourceContent, result);
            logger.trace("Content: {}", result.getWriter().toString());

            Iterator attachments = soapMsg.getAttachments();
            while (attachments.hasNext()) {
                Object obj = attachments.next();
                AttachmentPart att = (AttachmentPart) obj;
                logger.trace("Attachment Name/Id:{} Type:{} Size:{}", att.getContentId(), att.getDataHandler().getContentType(), att.getSize());
            }

        } catch (TransformerException | SOAPException e) {
            logger.error("Logging error ", e);
        }

    }

}
