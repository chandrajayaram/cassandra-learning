package caiso.tools.replay;

import caiso.tools.replay.config.AIDatabaseProperties;
import caiso.tools.replay.config.SourceDBSQLProperties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Component
public class QueryExecutor implements Runnable {

    private static final Logger logger = LogManager.getLogger(QueryExecutor.class);
    private static final SimpleDateFormat sqlDTFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
    @Resource
    private AIDatabaseProperties aiDatabaseProperties;
    @Resource
    private A2AAuditQuery a2aQuery;
    @Resource
    private B2BAuditQuery b2bQuery;
    @Resource
    private AuditDBMetrics dbMetrics;
    private ScheduledExecutorService scheduler;

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @Override
    public void run() {
        try {
            logger.debug("Running queries....");
            a2aQuery.runQuery();
            b2bQuery.runQuery();

        } catch (Throwable t) {
            logger.error("Error running audit query", t);
        }
    }

    @PostConstruct
    private void init() {
        final long STARTUP_DELAY_SECONDS = 5;

        scheduler = Executors.newSingleThreadScheduledExecutor();

        // set start time to consider counts / tracking based on now
        String nowDT = sqlDTFormat.format(new Date());//"2016-09-06T07:00:00";
        dbMetrics.setStartDateTimeString(nowDT);

        // mark any 'current' requests as used/old
        a2aQuery.markUsedRequests();
        b2bQuery.markUsedRequests();

        SourceDBSQLProperties.Poll pollProperties = aiDatabaseProperties.getSource().getPoll();
        if (pollProperties.isEnabled() == false) {
            logger.info("Polling is disabled");
            scheduler.schedule(this, STARTUP_DELAY_SECONDS, TimeUnit.SECONDS);
        } else {
            scheduler.scheduleWithFixedDelay(this, STARTUP_DELAY_SECONDS,
                    pollProperties.getIntervalSeconds(), TimeUnit.SECONDS);
        }
    }

    @PreDestroy
    private void shutdown() throws InterruptedException {
        if (scheduler != null && scheduler.isShutdown() == false)
            if (scheduler.awaitTermination(1, TimeUnit.SECONDS) == false) {
                System.err.println("[Shutdown did not terminate]");
            }
        System.out.println(this.getClass().getName() + " shutdown.");
        scheduler.shutdownNow();
    }
}
