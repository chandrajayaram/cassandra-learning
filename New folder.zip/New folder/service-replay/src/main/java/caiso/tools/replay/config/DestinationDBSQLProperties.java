package caiso.tools.replay.config;

/**
 * Destination AI Audit DB Properties
 */
public class DestinationDBSQLProperties extends DatabaseConnectionProperties {
    private String a2aCountSQL;
    private String b2bCountSQL;
    private String receivesCountSQL;

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * A2A message count
     *
     * @return
     */
    public String getA2aCountSQL() {
        return a2aCountSQL;
    }

    /**
     * A2A message count
     *
     * @param a2aCountSQL
     */
    public void setA2aCountSQL(String a2aCountSQL) {
        this.a2aCountSQL = a2aCountSQL;
    }

    /**
     * b2b message count
     *
     * @return
     */
    public String getB2bCountSQL() {
        return b2bCountSQL;
    }

    /**
     * b2b message count
     *
     * @param b2bCountSQL
     */
    public void setB2bCountSQL(String b2bCountSQL) {
        this.b2bCountSQL = b2bCountSQL;
    }

    /**
     * Receives message count
     *
     * @return
     */
    public String getReceivesCountSQL() {
        return receivesCountSQL;
    }

    /**
     * Receives message count
     *
     * @param receivesCountSQL
     */
    public void setReceivesCountSQL(String receivesCountSQL) {
        this.receivesCountSQL = receivesCountSQL;
    }

    @Override
    public String toString() {
        return "DestinationDBSQLProperties{" +
                "a2aCountSQL='" + a2aCountSQL + '\'' +
                ", b2bCountSQL='" + b2bCountSQL + '\'' +
                ", receivesCountSQL='" + receivesCountSQL + '\'' +
                "} " + super.toString();
    }
}
