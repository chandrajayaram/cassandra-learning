# Service Replay

[Distribution docs: installation, configuration, running, etc.](src/main/resources)

[Confluence Wiki](http://dev-tools.ete.wepex.net/confluence/display/RER/Service+Replay)

