package caiso.jms.config;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.activemq.pool.PooledConnectionFactory;
import org.apache.camel.component.jms.JmsConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.autoconfigure.jms.activemq.ActiveMQProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * This configuration is tightly coupled with ActiveMQ and provides transaction support and connection pooling.
 */
@Configuration
public class ActiveMQConfiguration extends ActiveMQProperties {
    private static final Logger logger = LogManager.getLogger(ActiveMQConfiguration.class);

    @Bean(destroyMethod = "stop")
    PooledConnectionFactory pooledConnectionFactory() {

        ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory();
        activeMQConnectionFactory.setBrokerURL(getBrokerUrl());
        activeMQConnectionFactory.setUserName(getUser());
        activeMQConnectionFactory.setPassword(getPassword());

        PooledConnectionFactory pooledConnectionFactory = new PooledConnectionFactory();
        pooledConnectionFactory.setMaxConnections(8);
        pooledConnectionFactory.setConnectionFactory(activeMQConnectionFactory);

        return pooledConnectionFactory;
    }

    @Bean
    JmsTemplate jmsTemplate(PooledConnectionFactory connectionFactory) {
        JmsTemplate jmsTemplate = new JmsTemplate(connectionFactory);
        return jmsTemplate;
    }

    @Bean
    JmsConfiguration jmsConfiguration(PooledConnectionFactory pooledConnectionFactory) {
        JmsConfiguration jmsConfiguration = new JmsConfiguration();
        jmsConfiguration.setConnectionFactory(pooledConnectionFactory);
        jmsConfiguration.setConcurrentConsumers(10);

        return jmsConfiguration;
    }

    @Bean
    PlatformTransactionManager platformTransactionManager(PooledConnectionFactory pooledConnectionFactory) {
        JmsTransactionManager jmsTransactionManager = new JmsTransactionManager();
        jmsTransactionManager.setConnectionFactory(pooledConnectionFactory);

        return jmsTransactionManager;
    }

    @Bean
    ActiveMQComponent activeMQComponent(JmsConfiguration jmsConfiguration, PlatformTransactionManager platformTransactionManager) {
        ActiveMQComponent activeMQComponent = new ActiveMQComponent();
        activeMQComponent.setConfiguration(jmsConfiguration);
        activeMQComponent.setTransacted(true);

        activeMQComponent.setTransactionManager(platformTransactionManager);

        activeMQComponent.setCacheLevelName("CACHE_CONSUMER");

        return activeMQComponent;
    }

}
