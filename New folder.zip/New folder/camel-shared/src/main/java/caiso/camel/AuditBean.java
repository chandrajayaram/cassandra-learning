package caiso.camel;


import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

@Component
public class AuditBean {

    public void logTime(String header, Exchange exchange) {
        exchange.getIn().setHeader(header, System.currentTimeMillis());
    }

}
