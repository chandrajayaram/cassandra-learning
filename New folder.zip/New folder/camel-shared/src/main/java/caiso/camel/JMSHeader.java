package caiso.camel;

public enum JMSHeader {

    SOAP_ACTION("soapaction"), // this may change/be rewritten
    INBOUND_SOAP_ACTION("caiso.esb.inbound-soapaction"), // saved original inbound/sent SOAPAction
    SERVICE_NAME("caiso.esb.SERVICE_NAME"), // last part of soapAction, after trailing slash
    PAYLOAD_ID("caiso.esb.service.UUID"), // payload id to track
    SERVICE_ORDERED("caiso.esb.service.orderedProcessing"), // if must be processed in sequential order
    SERVICE_APP_CONFIG_TRANSPORT("caiso.esb.service.app.config.transport"), // one of [HTTP, JMS]
    SERVICE_APP_CONFIG_DESTINATION("caiso.esb.service.app.config.destination"), // app destination
    SERVICE_APP_CONFIG_RETRIES("caiso.esb.service.app.config.retries"); // app retries

    private String header;

    JMSHeader(String header) {
        this.header = header;
    }

// public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @Override
    public String toString() {
        return header;
    }
}
