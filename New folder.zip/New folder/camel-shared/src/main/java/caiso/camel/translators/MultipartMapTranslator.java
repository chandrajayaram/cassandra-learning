package caiso.camel.translators;

import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

/**
 * Component to translate/convert the Exchange message body from a Multipart message into a Map<String,String>
 *
 * @see #parseMultipartMessage(String)
 */
@Component
public class MultipartMapTranslator {
    private static final Logger logger = LogManager.getLogger(MultipartMapTranslator.class);

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * Translates passed Camel exchange's in.body to a Map.
     * <p>
     * The in.body is expected to be a raw byte[] representing an HTTP Multipart message.
     * <p>
     * The resulting exchange.out.body map has 2 keys for "body" and "attachment" that represents the corresponding
     * parts parsed from passed the exchange.in.body
     *
     * @param exchange
     * @throws IOException
     */
    public void translate(Exchange exchange) throws IOException {
        logger.trace("received msg body {}", exchange.getIn().getBody());

        // convenience method to copy all headers and such to out message
        exchange.setOut(exchange.getIn().copy());

        byte[] bytes = (byte[]) exchange.getIn().getBody();
        Map<String, String> mapMultiParts = parseMultipartMessage(new String(bytes));

        exchange.getOut().setBody(mapMultiParts);
    }

    /**
     * Takes a Multipart message and retuns a map of the multiple parts
     *
     * @param multiPartMessage must be in the format of an HTTP Multipart message
     * @return map has 2 keys for "body" and "attachment" that represents the corresponding
     * parts parsed from passed the exchange.in.body
     * @throws IOException
     */
    public Map<String, String> parseMultipartMessage(String multiPartMessage) throws IOException {
        final String bodyKey = "body";
        final String attachmentKey = "attachment";

        StringReader reader = new StringReader(multiPartMessage);
        HashMap<String, String> result = new HashMap<>();
        BufferedReader br = new BufferedReader(reader);

        boolean body = false, attachment = false;
        String line, partDelimiter = null;
        StringBuilder sb = new StringBuilder();
        while ((line = br.readLine()) != null) {
            // line 1 will be the delimiter as in ------=_Part_185_848251541.1470167284646
            if (partDelimiter == null) {
                partDelimiter = line;

            } else if (line.length() == 0) {
                logger.trace("skipping empty line{} ", line);

            } else if (line.contains("Content-")) {
                // if a Content-* header line in part
                logger.trace("skipping meta {} ", line);

            } else if (line.indexOf(partDelimiter) >= 0) {
                // if this is a delimiter line
                logger.trace("skipping part {} ", line);
                if (!body) {
                    body = true;
                    result.put(bodyKey, sb.toString());
                } else if (!attachment) {
                    attachment = true;
                    result.put(attachmentKey, sb.toString());
                } else {
                    throw new UnsupportedOperationException("More than body and attachment found!");
                }
                sb.setLength(0);

            } else {

                sb.append(line);
            }
        }

        return result;
    }
}
