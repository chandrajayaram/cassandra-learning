package caiso.camel.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ParseAICSV {

    private static final Logger logger = LogManager.getLogger(ParseAICSV.class);
    // map of broadcast service type to list of receive types
    private static HashMap<String, List<String>> broadcastReceiveListMap = new HashMap<>();
    private static StringBuilder ymlBuffer = new StringBuilder();
    private String currentBroadcast;

    public static void main(String[] args) throws IOException {

        // arg 1: csv file
        if (args.length != 1) {
            System.err.println("ERROR: Missing required arguments for [CSV file]");
            System.exit(-1);
        }
        String csvFile = args[0];

        ParseAICSV gen = new ParseAICSV();

        File outputDir = new File(csvFile).getParentFile();
        gen.readCSVFile(csvFile);
        String ymlPath = outputDir.getPath() + "/services.yml";
        logger.info("Wrote {}", ymlPath);
        gen.saveFile(new File(ymlPath), ymlBuffer.toString());
    }

    /**
     * OBE: was used previously to load camel route template to generate a camel route per service
     *
     * @param file
     * @return
     * @throws IOException
     * @deprecated
     */
    private static byte[] loadFileContents(File file) throws IOException {

        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
            int count;
            byte data[] = new byte[32 * 1024];
            try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                while ((count = bis.read(data, 0, data.length)) != -1) {
                    out.write(data, 0, count);
                }
                return out.toByteArray();
            }
        }
    }

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * Read / process CSV for list of services
     */
    private void readCSVFile(String csvFile) {

        int count = 0;
        try {
            FileReader reader = new FileReader(csvFile);
            BufferedReader br = new BufferedReader(reader);

            String csvLine;
            while ((csvLine = br.readLine()) != null) {
                process(++count, csvLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        logger.info(String.format("Read %s lines", count));
    }

    /**
     * Utility method to save string to file
     *
     * @param outputFile
     * @param content
     * @throws IOException
     */
    private void saveFile(File outputFile, String content) throws IOException {

        FileOutputStream fout = new FileOutputStream(outputFile);
        try (BufferedOutputStream bout = new BufferedOutputStream(fout)) {
            bout.write(content.getBytes());
        }
    }

    /**
     * Reads the wsdl form passed param, and returns the complete SOAPAction from the wsdl contents
     *
     * @param wsdlURL http URL to wsdl file
     * @return SOAP Action parsed from wsdl
     * @throws IOException If there's some problem reading WSDL
     */
    private String readSOAPAction(String wsdlURL) throws IOException {
        URL url = new URL(wsdlURL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        try (BufferedInputStream in = new BufferedInputStream(connection.getInputStream())) {
            byte[] data = new byte[1024];

            int bytesRead;
            StringBuilder sb = new StringBuilder();
            while ((bytesRead = in.read(data)) != -1) {
                sb.append(new String(data, 0, bytesRead));
            }
            String wsdl = sb.toString();
            final String key = "soapAction=\"";
            int startPos = wsdl.indexOf(key) + key.length();
            int endPos = wsdl.indexOf("\"", startPos);
            String soapAction = wsdl.substring(startPos, endPos);

            return soapAction;
        }
    }

    /**
     * Process a CSV line - parse/handle fields
     * <p>
     * Expected CSV file Format (name : example value)
     * <pre>
     * [0] SG_NAME:        SG_BroadcastMQSBaseScheduleTestResults_MQSv1
     * [1] Schema:         BaseScheduleTestResults_v1.xsd
     * [2] APP_GROUP:      app_broadcast
     * [3] SG_Description: Fall 2015
     * [4] SG_Type:        Broadcast_MQS
     * [5] WSDL:           http://flame1/mrtu/services/BaseScheduleTestResults/BaseScheduleTestResults_v1/20161001/broadcastMQSBaseScheduleTestResults_v1.wsdl
     * [6] Endpoint:       http://CAISOWSHOST:11111/broadcast
     * [7] OrderedQueue:   false
     * [8] ErrorRetries:   1
     * [9] TTL:            1000 (in seconds?)
     * [10] transport:     http
     * </pre>
     * <p>
     * then followed by N number of receives that get called when this broadcast is called
     *
     * @param lineCount what line we're on (for error/msgs)
     * @param csvLine   csv line
     * @throws IOException can't read wsdl or some other IO error
     */
    private void process(int lineCount, String csvLine) throws IOException {

        logger.trace("Processing line #{} : {}", lineCount, csvLine);
        if (csvLine.startsWith("#")) {
            logger.trace("....skipping comment line {}", csvLine);
            return;
        }

        final String[] fields = parseFields(csvLine);
        if (fields == null) return; // comment
        if (fields[0].isEmpty()) {
            // blank line
            currentBroadcast = null;
            return;
        }

        StringBuilder sb = new StringBuilder("csv input fields:\n");
        for (int i = 0; i < fields.length; i++) {
            String f = fields[i];
            sb.append("   [").append(i).append("] ").append(f).append("\n");
        }

        logger.trace("\n{}", sb.toString());
        if ("app_broadcast".equals(fields[2])) {
            /*
            Process a broadcast
             */
            String soapAction = readSOAPAction(fields[5]);
            currentBroadcast = soapAction;//.substring(soapAction.lastIndexOf("/") + 1);
            logger.debug("### processing broadcast {} ", currentBroadcast);
            ymlBuffer.append("\n");
            ymlBuffer.append("    - SOAPAction: \"").append(currentBroadcast).append("\"\n");
            /*
            TTL
             */
            if (!fields[9].isEmpty() && !fields[9].trim().matches("6000")) {
                ymlBuffer.append("      TTL: ").append(fields[9]).append("\n");
            }
            /*
            Ordered Processing
             */
            if (Boolean.valueOf(fields[7])) {
                ymlBuffer.append("      orderedProcessing: true\n");
            }
            /*
            CAISO app list
             */
            ymlBuffer.append("      appList:\n");
            List<String> receiveList = broadcastReceiveListMap.get(currentBroadcast);
            if (receiveList == null) {
                receiveList = new ArrayList<>();
                broadcastReceiveListMap.put(currentBroadcast, receiveList);
            }
        } else {
            /*
             Process a receive
              */
            // add to broadcast
            if (currentBroadcast == null) {
                /*
                This is a special case
                There's no broadcast line in CSV, so
                    - d/l wsdl to get soapaction and service
                 */
                String soapAction = readSOAPAction(fields[5]);
                currentBroadcast = soapAction;//.substring(soapAction.lastIndexOf("/") + 1);
                currentBroadcast = currentBroadcast.replaceFirst("receive", "broadcast");
                logger.debug("=== b2b broadcast {} ", currentBroadcast);
                ymlBuffer.append("\n    # b2b service\n");
                ymlBuffer.append("    - SOAPAction: \"").append(currentBroadcast).append("\"\n");
                /*
                TTL
                 */
                if (!fields[9].isEmpty() && !fields[9].trim().matches("6000")) {
                    ymlBuffer.append("      TTL: ").append(fields[9]).append("\n");
                }
                /*
                Ordered Processing
                 */
                if (Boolean.valueOf(fields[7].toLowerCase())) {
                    ymlBuffer.append("      orderedProcessing: true\n");
                }
                ymlBuffer.append("      appList:\n");
                List<String> receiveList = broadcastReceiveListMap.get(currentBroadcast);
                if (receiveList == null) {
                    receiveList = new ArrayList<>();
                    broadcastReceiveListMap.put(currentBroadcast, receiveList);
                }
            }
            List<String> receiveList = broadcastReceiveListMap.get(currentBroadcast);
            String serviceName = fields[0].substring(3);
            String ap = serviceName + "_AP";
            logger.debug("    adding receive {} ", ap);
            boolean appListStarted = false;
            boolean jms = false;
            /*
            TRANSPORT (default http ignored)
             */
            // http is default, only write if it's a non-default
            if (!fields[10].isEmpty() && !fields[10].trim().matches("http")) {
                ymlBuffer.append("        - transport: " + fields[10] + "\n");
                jms = true;
                appListStarted = true;
            }
            /*
            DESTINATION
             */
            if (!appListStarted) {
                ymlBuffer.append("        - ");
                appListStarted = true;
            } else {
                ymlBuffer.append("          ");
            }
            if (jms) {
                ymlBuffer.append("destination: \"").append(serviceName).append("\"\n");
            } else {
                ymlBuffer.append("destination: \"{{receiveAIBaseURL}}/").append(ap).append("\"\n");
            }
            /*
            RETRIES (default 1 ignored)
             */
            // 1 is default retries, only write if it's a non-default
            if (!fields[8].isEmpty() && !fields[8].trim().matches("1")) {
                if (!appListStarted) {
                    ymlBuffer.append("        - ");
                    appListStarted = true;
                } else {
                    ymlBuffer.append("          ");
                }
                ymlBuffer.append("retries: " + fields[8] + "\n");
            }

            receiveList.add(ap);
        }

    }

    /**
     * Parses CSV line with field values in double quotes
     *
     * @param csvLine CSV line
     * @return null if this is a comment line
     */
    private String[] parseFields(String csvLine) {
        // skip comment lines
        if (csvLine.startsWith("\"#") || csvLine.startsWith("#")) {
            return null;
        }

        // fancy split on the comma only if that comma has zero, or an even number of quotes ahead of it
        // limit of -1 ensures ",,,," is parsed correctly
        final String[] fields = csvLine.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1);//.split(",");
        //strip quotes
        for (int i = 0; i < fields.length; i++) {
            String s = fields[i];
            s = s.replaceAll("\"", "");
            fields[i] = s;
        }

        return fields;
    }


}
