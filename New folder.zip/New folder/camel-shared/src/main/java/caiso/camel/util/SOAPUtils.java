package caiso.camel.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.Iterator;

import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.camel.Exchange;

/**
 * Camel utility classes for soap messages
 * 
 * @author akarkala
 */
public class SOAPUtils {

    /**
     * Fetches the Message body from the camel exchange
     */
	public static String getMessageBody(Exchange exchange) throws SOAPException, IOException {
        SOAPMessage soapMsg= SOAPUtils.getSOAPMessage(exchange);
        return SOAPUtils.getSOAPBodyAsXml(soapMsg);
	}
	
    /**
     * Fetches the SOAP message from the camel exchange
     * 
     * @param exchange - camel exchange
     * @return message - soap message
     * 
     * @throws SOAPException 
     * @throws IOException 
     */
    public static SOAPMessage getSOAPMessage(Exchange exchange) throws SOAPException, IOException {
        InputStream inStream = exchange.getIn().getBody(InputStream.class);
        MimeHeaders mimeHeaders = getMimeHeaders(exchange);
        SOAPMessage message = MessageFactory.newInstance().createMessage(mimeHeaders, inStream);
        return message;
    }

    /**
     * Gets the MimeHeaders from the camel exchange
     * 
     * @param exchange - camel exchange
     * @return mimeHdrs - soap mime headers
     */
    public static MimeHeaders getMimeHeaders(Exchange exchange) {
        MimeHeaders headers = new MimeHeaders();
        headers.addHeader("Content-Type", (String) exchange.getIn().getHeader("Content-Type"));
        headers.addHeader("Content-Length", (String) exchange.getIn().getHeader("Content-Length"));
        headers.addHeader("Accept-Encoding", (String) exchange.getIn().getHeader("Accept-Encoding"));
        headers.addHeader("SOAPAction", (String) exchange.getIn().getHeader("SOAPAction"));
        return headers;
    }

    /**
     * Get soap Attachment as a stream
     * 
     * @param message
     * @return
     * @throws Exception
     */
	public static InputStream getAttachment(SOAPMessage message) throws SOAPException{
        Iterator<?> attachments = message.getAttachments();
        if (attachments !=null && attachments.hasNext()) {
            AttachmentPart attachmentPart = (AttachmentPart) attachments.next();
            return attachmentPart == null?null:(InputStream) attachmentPart.getContent();
        }
        return null;	 
	}
	
	public static int getAttachmentSize(SOAPMessage message) throws SOAPException{
        Iterator<?> attachments = message.getAttachments();
        if (attachments !=null && attachments.hasNext()) {
            AttachmentPart attachmentPart = (AttachmentPart) attachments.next();
            return attachmentPart.getSize();
        }
        return 0;	 
	}
	
	/**
	 * Returns soap message as a string
	 * 
	 * @param message
	 * @return message body as string
	 */
	public static String getSOAPBodyAsXml(SOAPMessage message){
        final StringWriter sw = new StringWriter();
        try {
            TransformerFactory.newInstance().newTransformer().transform(
                new DOMSource(message.getSOAPPart()),new StreamResult(sw));
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }
        return sw.toString();
	}
	
}
