package caiso.camel.util;

import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Utility component useful in Camel routes as in:
 * <p>
 * <pre>
 *     {@code
 *     <bean ref="camelDebugBean" method="noOp"/>
 *     }
 * </pre>
 * <p>
 * This allows setting a breakpoint in the "noOp" method and examining the exchange during camel route processing.
 */
@Component
public class CamelDebugBean {
    private static final Logger logger = LogManager.getLogger(CamelDebugBean.class);

    @Resource
    private ConfigurableApplicationContext applicationContext;

    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * No operations, useful for setting breakpoint and examining passed params from routes
     *
     * @param exchange
     */
    public void noOp(Exchange exchange) {
        // set breakpoint on below to debug
        logger.trace("noOp");
    }

    /**
     * Method throws a Runtime {@code IllegalStateException} excetoption.  Useful in testing transactions.
     */
    public void exception() {
        throw new IllegalStateException("forced exception");
    }

    /**
     * Simulates some delay/processing time on server
     *
     * @param seconds seconds to delay this thread
     */
    public void simulateDelay(int seconds) {
        long mili = seconds * 1000;
        int waitMili = 0;
        while (waitMili < mili) {
            final int cycle = 1000;
            try {
                Thread.sleep(cycle);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (waitMili % 10000 == 0) {
                logger.debug("{}s passed", (waitMili / 1000));
            }
            waitMili += cycle;
        }
    }

    /**
     * Simulate a system/JVM crash or abrupt shutdown.
     *
     * @param delay seconds from now to simulate crashing.  This is a non-blocking delay, parent thread / caller
     *              continues after this call.
     */
    public void simulateCrash(int delay) {
        logger.warn("Simulate crash in " + delay + "s");

        Runnable crasher = new Runnable() {
            // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            @Override
            public void run() {
                simulateDelay(delay);
                logger.warn("\n" +
                        "#############################################\n" +
                        "################ SIMULATE SYSTEM CRASH NOW !!\n" +
                        "#############################################");

                SpringApplication.exit(applicationContext, new ExitCodeGenerator() {
                    // public ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    @Override
                    public int getExitCode() {
                        return -1;
                    }
                });
                System.exit(-1);
            }
        };
        new Thread(crasher).start();
    }
}
