package caiso.camel;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;

public class AuditBeanTest extends CamelTestSupport{
	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		final AuditBean bean = new AuditBean(); 
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:A").process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						bean.logTime("casio.esb",exchange);
					}
				}).to("mock:endpoint");
			}
		};
	}
	@Test
	public void testMessageHeader() throws InterruptedException{
		template.sendBody("direct:A","Hello");
		Thread.sleep(1000);
		MockEndpoint endpoint = getMockEndpoint("mock:endpoint");
		List<Exchange> exchanges = endpoint.getExchanges();
	    Message messageOut = exchanges.get(0).getIn();
	    Object header =  messageOut.getHeader("casio.esb");
	    assertNotNull("Header was set by auditbean", header);
	}
}
