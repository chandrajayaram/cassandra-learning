package caiso.camel.translators;

import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;

/**
 * Component to translate/convert the Exchange message body from a Multipart
 * message into a Map<String,String>
 *
 * @see #parseMultipartMessage(String)
 */
public class MultipartMapTranslatorTest extends CamelTestSupport {
	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				//from("file://src/test/resources/testinput?noop=true").to("file://src/test/resources/testoutput");
				from("file://src/test/resources/testinput?noop=true").convertBodyTo(byte[].class).transform().method(MultipartMapTranslator.class).to("mock:endpoint");
			}
		};
	}
	
	@Test
	public void testConvertMultipartMessageToMap() throws Exception {
		Thread.sleep(2000);
		MockEndpoint endpoint = getMockEndpoint("mock:endpoint");
		List<Exchange> exchanges = endpoint.getExchanges();
	    Message messageOut = exchanges.get(0).getIn();
	    Map<String, String> mapMultiParts = (Map<String, String>) messageOut.getBody();
	    assertCollectionSize("Does not contain all headers", mapMultiParts.keySet(), 2);
	}

}
