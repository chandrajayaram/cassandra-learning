on local
1) use CQLSH and run audit_keypsace-local.cql
2) use CQLSH and audit_table.cql

on dev and other envs
1) use CQLSH run audit_keypsace.cql
2) use CQLSH audit_table.cql


