package caiso.esb.common.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cassandra.core.ConsistencyLevel;
import org.springframework.cassandra.core.RetryPolicy;
import org.springframework.cassandra.core.WriteOptions;
import org.springframework.data.cassandra.core.CassandraOperations;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;

import caiso.esb.common.entity.PayloadAttachment;

/**
 * @author akarkala
 */
@Repository
public class PayloadAttachmentDao {

	@Value("${cassandra.payload.ttl}")
    private int ttl;

	@Value("${cassandra.consistancylevel}")
    private ConsistencyLevel consistancyLevel;

	@Autowired
	private CassandraOperations cassandraOperations;
	
	public void insertPayloadData(PayloadAttachment entity){
		if(entity == null){
			throw new IllegalArgumentException("Entity PayloadAttachment cannot be null");
		}
		WriteOptions writeOptions=new WriteOptions(consistancyLevel,RetryPolicy.DEFAULT,ttl);
		cassandraOperations.insert(entity,writeOptions);
	}

	public PayloadAttachment findById(String payloadId){
		if(StringUtils.isEmpty(payloadId)){
			throw new IllegalArgumentException("ID cannot be null");
		}
		Select select = QueryBuilder.select().from("payload_attachment");
		select.where(QueryBuilder.eq("payload_id", payloadId));
		return cassandraOperations.selectOne(select, PayloadAttachment.class);
	}

}
