package caiso.esb.common.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.util.StringUtils;

/**
 * Utility class for static methods
 * 
 * @author akarkala
 */
public class PayloadUtils {

	/**
	 * Method to extract Servicename from SoapAction
	 */
	public static String getServiceNameFromSoapAction(String soapAction){
		if(StringUtils.isEmpty(soapAction)){
			return soapAction;
		}
		String serviceName=(soapAction.contains("/"))?
				soapAction.substring(soapAction.lastIndexOf("/") + 1) : soapAction;
		//return serviceName.replaceAll("[^a-zA-Z0-9]", "");
		return serviceName.replaceAll("\"", "");
	}


}
