package caiso.esb.common.entity;

/**
 * @author akarkala
 */
public enum ResponseStatus {	
	SUCCESS,FAILURE,PENDING, UNKNOWN;
	
	public static ResponseStatus fromString(String value){
		if(value == null){
			return null;
		}
		for(ResponseStatus status: ResponseStatus.values() ){
			if(value.equalsIgnoreCase(status.toString())){
				return status;
			}
		}
		return null;
	}
}
