package caiso.esb.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.cassandra.config.CassandraClusterFactoryBean;
import org.springframework.data.cassandra.config.java.AbstractCassandraConfiguration;
import org.springframework.util.StringUtils;

import com.datastax.driver.core.policies.DCAwareRoundRobinPolicy;

/**
 * Cassandra configuration
 */
@Configuration
public class CassandraConfiguration extends AbstractCassandraConfiguration {

	@Value("${cassandra.contact-points}")
	private String cassandraContactPoints ;

	@Value("${cassandra.port}")
	private String cassandraPort;

	@Value("${cassandra.keyspace}")
	private String cassandraKeyspace;

	@Value("${cassandra.default-datacenter}")
	private String cassandraDefaultDs;

	@Value("${cassandra.user:''}")
	private String cassandraUser;

	@Value("${cassandra.password:''}")
	private String cassandraPassword;

	@Bean
	public CassandraClusterFactoryBean cluster() {		  
		CassandraClusterFactoryBean cluster = new CassandraClusterFactoryBean();
		cluster.setContactPoints(cassandraContactPoints);
		cluster.setPort(Integer.parseInt(cassandraPort));
		if(!StringUtils.isEmpty(cassandraUser)){
			cluster.setUsername(cassandraUser);
		}
		if(!StringUtils.isEmpty(cassandraPassword)){
			cluster.setPassword(cassandraPassword);
		}
		
		cluster.setLoadBalancingPolicy(new DCAwareRoundRobinPolicy(cassandraDefaultDs,1));
		return cluster;
	}

	@Override
	protected String getKeyspaceName() {
		return cassandraKeyspace;
	}
	 
}
