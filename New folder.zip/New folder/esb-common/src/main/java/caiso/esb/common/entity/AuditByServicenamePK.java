package caiso.esb.common.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.cassandra.core.Ordering;
import org.springframework.cassandra.core.PrimaryKeyType;
import org.springframework.data.cassandra.mapping.PrimaryKeyClass;
import org.springframework.data.cassandra.mapping.PrimaryKeyColumn;

/**
 * @author akarkala
 */
@PrimaryKeyClass
public class AuditByServicenamePK implements Serializable{
	private static final long serialVersionUID = 1L;

	//Partition column. Date is partitioned by servicename
	@PrimaryKeyColumn(name = "service_name", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
	private String serviceName;

	//Date in the partition gets ordered based on create timestamp 
	@PrimaryKeyColumn(name = "create_ts", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
	private Date createTime;

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
}
