package caiso.esb.common.utils;


import java.util.Calendar;

/**
 * Feb 21, 2008 8:42:54 AM 2008
 */
public class TimeUtil {

    public static long SEC = 1000;
    public static long MIN = 60 * SEC;
    public static long HOUR = 60 * MIN;
    public static long DAY = 24 * HOUR;

    public static void main(String[] args) {
        Calendar start = Calendar.getInstance();
        Calendar end = Calendar.getInstance();
        end.add(Calendar.HOUR, 8);
        end.add(Calendar.DAY_OF_YEAR, 4);
        System.out.println(">> " + getElapsedTime(start.getTimeInMillis(), end.getTimeInMillis()));
    }

    /**
     * Returns a "pretty print" format of the elapsed time (e.g., 3h 13m 4s)
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static String getElapsedTime(long startTime, long endTime) {
        long diff = endTime - startTime;
        return formatTime(diff);
    }

    /**
     * Formats the passed miliseconds to something like "3d 7h 19m 22ms"
     *
     * @param mili
     * @return
     */
    public static String formatTime(long mili) {
        long d = mili / DAY;
        long h = (mili - (d * DAY)) / HOUR;
        long m = (mili - (d * DAY) - (h * HOUR)) / MIN;
        long s = (mili - (d * DAY) - (h * HOUR) - (m * MIN)) / SEC;
        long ms = mili - (d * DAY) - (h * HOUR) - (m * MIN) - (s * SEC);
        StringBuffer buf = new StringBuffer();

        if (d > 0) buf.append(d + "d ");
        if (h > 0) buf.append(h + "h ");
        if (m > 0) buf.append(m + "m ");
        if (s > 0) buf.append(s + "s ");
        if (ms > 0) buf.append(ms + "ms ");

        return buf.toString();
    }

    /**
     * Returns true if the current time is within the passed hour of the day.
     *
     * @param hourOfDay 0-23 hour of day
     * @return
     */
    public static boolean isNowInHour(int... hourOfDay) {
        for (int h : hourOfDay) {
            Calendar beginCal = Calendar.getInstance();
            beginCal.set(Calendar.HOUR_OF_DAY, h);
            beginCal.set(Calendar.MINUTE, 0);
            beginCal.set(Calendar.SECOND, 0);
            beginCal.set(Calendar.MILLISECOND, 0);

            Calendar endCal = Calendar.getInstance();
            endCal.set(Calendar.HOUR_OF_DAY, h + 1);
            endCal.set(Calendar.MINUTE, 0);
            endCal.set(Calendar.SECOND, 0);
            endCal.set(Calendar.MILLISECOND, 0);

            Calendar now = Calendar.getInstance();
            // now >= begin time AND now is before end time
            if (now.compareTo(beginCal) >= 0 && now.compareTo(endCal) < 0) {
                return true;
            }
        }
        return false;

    }

}
