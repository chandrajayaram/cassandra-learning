package caiso.esb.common.metrics;

import caiso.esb.config.ApplicationProperties;
import org.springframework.boot.actuate.endpoint.Endpoint;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 */
@Component
public class Version implements Endpoint {
    @Resource
    private ApplicationProperties applicationProperties;

    @Override
    public String getId() {
        return "Version";
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public boolean isSensitive() {
        return false;
    }

    @Override
    public Object invoke() {
        return applicationProperties;
    }
}
