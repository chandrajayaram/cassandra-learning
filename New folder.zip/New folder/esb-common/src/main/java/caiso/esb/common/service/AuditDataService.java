package caiso.esb.common.service;

import caiso.camel.JMSHeader;
import caiso.camel.util.SOAPUtils;
import caiso.esb.common.dao.AuditByServiceDao;
import caiso.esb.common.dao.PayloadAttachmentDao;
import caiso.esb.common.entity.AuditByServicename;
import caiso.esb.common.entity.AuditByServicenamePK;
import caiso.esb.common.entity.PayloadAttachment;
import caiso.esb.common.entity.ResponseStatus;
import caiso.esb.common.utils.PayloadUtils;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Service to save and retrieve payload Audit information.
 * 
 * @author akarkala
 */
@Service
@Transactional
public class AuditDataService {
    private static final Logger logger = LogManager.getLogger(AuditDataService.class);

	@Autowired
	private PayloadAttachmentDao payloadDataDao;

	@Autowired
	private AuditByServiceDao auditByServiceDao;
	
	public void auditRequestAndResponse(Exchange request,Exchange response,int processTime, boolean saveAttachment) 
			throws SOAPException,IOException{
		if(request == null || request.getIn() == null || 
				response == null || response.getIn() == null){
			throw new IllegalArgumentException("Request and response cannot be null");
		}
		ResponseStatus status=response.getException() == null?ResponseStatus.SUCCESS:ResponseStatus.FAILURE;
        SOAPMessage soapMsg= SOAPUtils.getSOAPMessage(response);
        String responseXml=SOAPUtils.getSOAPBodyAsXml(soapMsg);
        auditRequestAndResponse(request,responseXml,processTime,status,saveAttachment);
	}
	
	public void auditRequestAndResponse(Exchange request,String responseXml,int processTime,
			ResponseStatus status,boolean saveAttachment)
			throws SOAPException,IOException{
		if(request == null || request.getIn() == null || StringUtils.isEmpty(responseXml) 
				|| status == null){
			throw new IllegalArgumentException("Request and response cannot be null");
		}
		Message message = request.getIn();
	    String soapAction = (String) message.getHeader(JMSHeader.SOAP_ACTION.toString());
		String serviceName=PayloadUtils.getServiceNameFromSoapAction(soapAction);
		if(StringUtils.isEmpty(soapAction) || StringUtils.isEmpty(serviceName)){
			throw new IllegalArgumentException("Headers SOAPAction and servicename cannot be null");
		}
	    logger.info("Auditing payload with soapaction: "+soapAction);		
	    String payloadId=(String)message.getHeader(JMSHeader.PAYLOAD_ID.toString());
		if(StringUtils.isEmpty(payloadId)){
			throw new IllegalArgumentException("Header PayloadId cannot be null");
		}
		//Convert the message to a soap message and save payload in the audit table
        SOAPMessage soapMsg= SOAPUtils.getSOAPMessage(request);
        String requestBody=SOAPUtils.getSOAPBodyAsXml(soapMsg);
        String attachment=saveAttachment?this.getAttachment(soapMsg):null;
        int attachSize=SOAPUtils.getAttachmentSize(soapMsg);
        //Audit soap message
        insertAuditData(serviceName, payloadId, requestBody,responseXml,status,processTime,attachment,attachSize);
	}
	
	public List<AuditByServicename> findByServiceNamesAndCreateDate(List<String> serviceNames,Date start,Date end){
		if(serviceNames == null || serviceNames.size() == 0 || start == null || end == null){
			throw new IllegalArgumentException("servicenames, start and end dates parameters must be specified");
		}
		if(end.before(start)){
			throw new IllegalArgumentException("End date must be after startdate");
		}
		return auditByServiceDao.findByServiceNamesAndCreateDate(serviceNames, start, end);  
	}
	
	/**
	 * Retrieve all service names, search them for names that contains search string.
	 * Return all those service names
	 *    
	 */
	public List<String> searchServiceNames(String serviceName){
		//TODO moniter the performance of this query, because this is done every time we 
		//search for payloads. It looks good now, but if this become slower, then cache it  
		List<String> allServiceNames=auditByServiceDao.findAllServiceNames();
		List<String> serviceNames= new ArrayList<String>();
		//Return services that match the search string
		for(String service:allServiceNames ){
			if(service.toLowerCase().contains(serviceName.toLowerCase())){
				serviceNames.add(service);
			}
		}
		return serviceNames;
	}

	public PayloadAttachment findAttachment(String payloadId){		
		return payloadDataDao.findById(payloadId);  
	}
	

	public void insertAuditData(String serviceName,String payloadId,String requestXml,
			String responseXml,ResponseStatus status,int processTime,String attachment,int attachSize)
	throws UnsupportedEncodingException{
		if(StringUtils.isEmpty(payloadId) || StringUtils.isEmpty(serviceName) 
				|| StringUtils.isEmpty(requestXml) || StringUtils.isEmpty(responseXml)
				|| status == null){
			throw new IllegalArgumentException("Paramters PayloadId, Service name, request Xml, response Xml cannot be null");
		}		
		saveAttachment(payloadId,attachment);
		
		AuditByServicename auditData= new AuditByServicename();
		AuditByServicenamePK pk= new AuditByServicenamePK();
		pk.setServiceName(serviceName);
		pk.setCreateTime(new Date());
		auditData.setPk(pk);
		auditData.setPayloadId(payloadId);
		auditData.setRequestXml(ByteBuffer.wrap(requestXml.getBytes("UTF-8")));
		auditData.setResponseXml(ByteBuffer.wrap(responseXml.getBytes("UTF-8")));
		auditData.setAttachmentSize(attachSize);
		auditData.setResponseStatus(status);
		auditData.setProcessTime(processTime);
		auditByServiceDao.insertAuditByServiceName(auditData);
	}
	
	private void saveAttachment(String payloadId,String attachment)
			throws UnsupportedEncodingException{
		if(attachment !=null){
			PayloadAttachment payload= new PayloadAttachment();
			payload.setPayloadId(payloadId);
			payload.setAttachment(ByteBuffer.wrap(attachment.getBytes("UTF-8")));
			payloadDataDao.insertPayloadData(payload);
		}
	}

	private String getAttachment(SOAPMessage message) throws SOAPException,IOException{
		InputStream inputStream=SOAPUtils.getAttachment(message);
		return inputStream == null?null:IOUtils.toString(inputStream);
	}
	
}
