package caiso.esb.common.entity;

import java.nio.ByteBuffer;

import org.springframework.data.cassandra.mapping.Column;
import org.springframework.data.cassandra.mapping.PrimaryKey;
import org.springframework.data.cassandra.mapping.Table;

/**
 * @author akarkala
 */
@Table(value = "payload_attachment")
public class PayloadAttachment {

	@PrimaryKey(value = "payload_id")
	private String payloadId;

	@Column(value = "attachment")
	private ByteBuffer attachment;

	public String getPayloadId() {
		return payloadId;
	}

	public void setPayloadId(String payloadId) {
		this.payloadId = payloadId;
	}

	public ByteBuffer getAttachment() {
		return attachment;
	}

	public void setAttachment(ByteBuffer attachment) {
		this.attachment = attachment;
	}
		
}
