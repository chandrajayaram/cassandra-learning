package caiso.esb.common.entity;

import java.nio.ByteBuffer;

import org.springframework.data.cassandra.mapping.Column;
import org.springframework.data.cassandra.mapping.PrimaryKey;
import org.springframework.data.cassandra.mapping.Table;

/**
 * Entity class for audit_by_servicename
 * 
 * @author akarkala
 */
@Table(value = "audit_by_servicename")
public class AuditByServicename {

	@PrimaryKey
	private AuditByServicenamePK pk;

	@Column(value = "payload_id")
	private String payloadId;

	@Column(value = "request_xml")
	private ByteBuffer requestXml;

	@Column(value = "response_xml")
	private ByteBuffer responseXml;
	
	@Column(value = "attachment_size")
	private int attachmentSize;
		
	@Column(value = "process_time")
	private int processTime;

	@Column(value = "response_status")
	private String responseStatus;
	
	public AuditByServicenamePK getPk() {
		return pk;
	}

	public void setPk(AuditByServicenamePK pk) {
		this.pk = pk;
	}
	
	public String getPayloadId() {
		return payloadId;
	}

	public void setPayloadId(String payloadId) {
		this.payloadId = payloadId;
	}

	public ByteBuffer getRequestXml() {
		return requestXml;
	}

	public void setRequestXml(ByteBuffer requestXml) {
		this.requestXml = requestXml;
	}

	public ByteBuffer getResponseXml() {
		return responseXml;
	}

	public void setResponseXml(ByteBuffer responseXml) {
		this.responseXml = responseXml;
	}

	public int getAttachmentSize() {
		return attachmentSize;
	}

	public void setAttachmentSize(int attachmentSize) {
		this.attachmentSize = attachmentSize;
	}

	public int getProcessTime() {
		return processTime;
	}

	public void setProcessTime(int processTime) {
		this.processTime = processTime;
	}

	public ResponseStatus getResponseStatus() {
		ResponseStatus status=ResponseStatus.fromString(responseStatus.toString());
		return status == null?ResponseStatus.UNKNOWN:status;
	}

	public void setResponseStatus(ResponseStatus responseStatus) {
		this.responseStatus = responseStatus.toString();
	}


}
