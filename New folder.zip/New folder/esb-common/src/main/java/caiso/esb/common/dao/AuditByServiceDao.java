package caiso.esb.common.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cassandra.core.ConsistencyLevel;
import org.springframework.cassandra.core.RetryPolicy;
import org.springframework.cassandra.core.WriteOptions;
import org.springframework.data.cassandra.core.CassandraOperations;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import caiso.esb.common.entity.AuditByServicename;

/**
 * @author akarkala
 */
@Repository
public class AuditByServiceDao {

	private static final String SQL_FIND_BY_SERVICENAME="SELECT service_name,create_ts,attachment_size,payload_id,process_time, "
			+ "response_status FROM audit_ks.audit_by_servicename";

	private static final String SQL_FIND_ALL_SERVICENAME="select distinct service_name from audit_ks.audit_by_servicename";

	private static final SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	@Value("${cassandra.audit.ttl}")
    private int ttl;

	@Value("${cassandra.consistancylevel}")
    private ConsistencyLevel consistancyLevel;

	@Autowired
	private CassandraOperations cassandraOperations;
	
	public void insertAuditByServiceName(AuditByServicename entity){
		if(entity == null){
			throw new IllegalArgumentException("Entity AuditByServicename cannot be null");
		}
		WriteOptions writeOptions=new WriteOptions(consistancyLevel,RetryPolicy.DEFAULT,ttl);
		cassandraOperations.insert(entity,writeOptions);
	}
	
	public List<AuditByServicename> findByServiceNamesAndCreateDate(List<String> serviceNames,Date start,Date end){
		if(serviceNames == null || serviceNames.size() == 0 || start == null || end == null){
			throw new IllegalArgumentException("servicenames, start and end dates parameters must be specified");
		}
		String query=SQL_FIND_BY_SERVICENAME+" where service_name in(";		
		query+=StringUtils.collectionToDelimitedString(serviceNames, ",", "'", "'")+") ";
		query+="and create_ts >= '"+dateFormat.format(start)+"'"+" and create_ts <= '"+dateFormat.format(end)+"'"; 
		return cassandraOperations.select(query, AuditByServicename.class);  
	}
	
	public List<String> findAllServiceNames(){
		return cassandraOperations.queryForList(SQL_FIND_ALL_SERVICENAME, String.class);  
	}
	
	public List<AuditByServicename> findAll(){
		return cassandraOperations.select(SQL_FIND_BY_SERVICENAME, AuditByServicename.class);  
	}

}
