package caiso.esb.commom.payload;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringBufferInputStream;
import java.io.StringWriter;

import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

public class PayloadGenerator {
	
	public SOAPMessage getPayload() throws SOAPException{
		MessageFactory myMsgFct = MessageFactory.newInstance();
		SOAPMessage message = myMsgFct.createMessage();
		SOAPPart mySPart = message.getSOAPPart();
		SOAPEnvelope myEnvp = mySPart.getEnvelope();
		SOAPHeader soapHeader = myEnvp.getHeader();
		Name attachmentHash= myEnvp.createName("attachmentHash", "ns1",
				"http://www.caiso.com/mrtu/soa/schemas/2005/09/attachmenthash");
		Name attachmentHashValue= myEnvp.createName("hashValue", "ns1",
				"http://www.caiso.com/mrtu/soa/schemas/2005/09/attachmenthash");
		SOAPHeaderElement attachmentHashElem = soapHeader.addHeaderElement(attachmentHash);
		attachmentHashElem.setMustUnderstand(false);
		attachmentHashElem.setActor("http://schemas.xmlsoap.org/soap/actor/next");
		SOAPElement hashValue = attachmentHashElem.addChildElement(attachmentHashValue);
		hashValue.setValue("YbDYq6uB/7WmwQ1xeCOfwXtx85I=");
		
		Name standardAttachmentInfor = myEnvp.createName("standardAttachmentInfor","","http://www.caiso.com/soa/2006-06-13/StandardAttachmentInfor.xsd");
		SOAPElement standardAttachmentInfo = soapHeader.addChildElement(standardAttachmentInfor);
		SOAPElement attachment = standardAttachmentInfo.addChildElement("Attachment");
		SOAPElement attachmentId = attachment.addChildElement("id");
		attachmentId.setNodeValue("1");
		SOAPElement compressFlag = attachment.addChildElement("compressFlag");
		compressFlag.setNodeValue("yes");
		
		SOAPElement compressMethod = attachment.addChildElement("compressMethod");
		compressMethod.setNodeValue("gzip");
		
		SOAPBody body = myEnvp.getBody();
		Name bodyName = myEnvp.createName("broadcastActualSystemDemand_v2", "",
                "http://www.caiso.com/soa/broadcastActualSystemDemand_v2");
		SOAPBodyElement gltp = body.addBodyElement(bodyName);
	
		
		AttachmentPart attachmentPart = message.createAttachmentPart();
		String encoded = Base64.encodeFromFile("src/test/resources/payloads/broadcastActualSystemDemand.xml");
		attachmentPart.setContent(encoded.getBytes(), "application/octetstream");
		message.addAttachmentPart(attachmentPart);
		message.saveChanges();
		return message;
	}
	public static void main(String[] args) throws SOAPException, IOException {
		SOAPMessage message = new PayloadGenerator().getPayload();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		message.writeTo(out);
		ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
		MessageFactory myMsgFct = MessageFactory.newInstance();
		myMsgFct.createMessage(null,in).writeTo(System.out);	
	}
}	
