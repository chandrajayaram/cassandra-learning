package caiso.esb.common.dao;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import caiso.esb.common.BaseIntegrationTest;
import caiso.esb.common.dao.AuditByServiceDao;
import caiso.esb.common.entity.AuditByServicename;
import caiso.esb.common.entity.AuditByServicenamePK;

/**
 * @author akarkala
 */
public class AuditByServiceDaoTest extends BaseIntegrationTest{

	@Test
	public void testFindAllServiceNames(){		
		AuditByServiceDao dao=ctx.getBean(AuditByServiceDao.class);
		List<String> serviceNames=dao.findAllServiceNames();
		assertTrue(serviceNames.size() > 0);
	}
	
	@Test
	public void testAddAudit(){
		AuditByServiceDao dao=ctx.getBean(AuditByServiceDao.class);
		AuditByServicename audit= new AuditByServicename();
		AuditByServicenamePK pk= new AuditByServicenamePK();
		pk.setServiceName("testservice");
		pk.setCreateTime(new Date());
		audit.setPk(pk);
		audit.setPayloadId("payloadid1");
		dao.insertAuditByServiceName(audit);

		Calendar start = Calendar.getInstance();
		start.add(Calendar.HOUR, -4);     	    
		Calendar end = Calendar.getInstance();
		end.add(Calendar.HOUR, +4);     
		
		List<AuditByServicename> services=dao.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{"testservice"}),
				start.getTime(),end.getTime());
		assertTrue(services.size() == 1);
		assertTrue(services.get(0).getPk().getServiceName().equals("testservice"));
		assertTrue(services.get(0).getPayloadId().equals("payloadid1"));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testAddNullAudit(){
		AuditByServiceDao dao=ctx.getBean(AuditByServiceDao.class);
		dao.insertAuditByServiceName(null);
	}

	public void testFindByServiceNameInvalidArgs() {
		Calendar start = Calendar.getInstance();
		start.add(Calendar.HOUR, -4);     	    
		Calendar end = Calendar.getInstance();
		end.add(Calendar.HOUR, +4);     
		
		//Test data has inserted 5 rows. Test the select statements
		AuditByServiceDao dao=ctx.getBean(AuditByServiceDao.class);
		try{
			dao.findByServiceNamesAndCreateDate(null,
					start.getTime(),end.getTime());
			fail();
		}catch(Exception e){}
		try{
			dao.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{"testservice"}),
					null,end.getTime());
			fail();
		}catch(Exception e){}
		try{
			dao.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{"testservice"}),
					start.getTime(),null);
			fail();
		}catch(Exception e){}
	}

	@Test
	public void testFindByServiceName() {
		Calendar start = Calendar.getInstance();
		start.add(Calendar.HOUR, -4);     	    
		Calendar end = Calendar.getInstance();
		end.add(Calendar.HOUR, +4);     
		
		//Test data has inserted 5 rows. Test the select statements
		AuditByServiceDao dao=ctx.getBean(AuditByServiceDao.class);
		List<AuditByServicename> services=dao.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{"broadcastResourceAwards_RTMv4"}),
				start.getTime(),end.getTime());
		assertTrue(services.size() == 1);
		assertTrue(services.get(0).getPk().getServiceName().equals("broadcastResourceAwards_RTMv4"));
		List<AuditByServicename> all=dao.findAll();
		assertTrue(all.size() == 5);
	}
	
}
