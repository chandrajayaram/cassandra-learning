package caiso.esb.common.dao;

import static org.junit.Assert.*;

import java.nio.ByteBuffer;
import java.util.UUID;

import org.apache.cassandra.utils.UUIDGen;
import org.junit.Test;
import caiso.esb.common.BaseIntegrationTest;
import caiso.esb.common.entity.PayloadAttachment;

/**
 * @author akarkala
 */
public class PayloadAttachmentDaoTest extends BaseIntegrationTest{

	@Test
	public void testAddPayload() throws Exception{
		PayloadAttachmentDao dao=ctx.getBean(PayloadAttachmentDao.class);
		String payloadId="payloooooadid11";
		PayloadAttachment payloadData=new PayloadAttachment();
		payloadData.setPayloadId(payloadId);
		payloadData.setAttachment(ByteBuffer.wrap("<test.uue/>".getBytes("UTF-8")));
		dao.insertPayloadData(payloadData);
		
		PayloadAttachment paylodOutput=dao.findById(payloadId);
		String attachment = new String(paylodOutput.getAttachment().array(),"UTF-8");
		assertTrue(attachment.equals("<test.uue/>"));
		
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testNullPayload() throws Exception{
		PayloadAttachmentDao dao=ctx.getBean(PayloadAttachmentDao.class);
		dao.insertPayloadData(null);
	}

	@Test(expected=IllegalArgumentException.class)
	public void testInvalidFindById(){
		PayloadAttachmentDao dao=ctx.getBean(PayloadAttachmentDao.class);
		dao.findById(null);		
	}
}
