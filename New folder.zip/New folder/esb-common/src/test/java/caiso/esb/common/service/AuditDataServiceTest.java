package caiso.esb.common.service;

import static org.junit.Assert.*;

import java.io.InputStream;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Test;

import caiso.camel.JMSHeader;
import caiso.esb.common.BaseIntegrationTest;
import caiso.esb.common.dao.PayloadAttachmentDao;
import caiso.esb.common.entity.AuditByServicename;
import caiso.esb.common.entity.PayloadAttachment;
import caiso.esb.common.entity.ResponseStatus;

/**
 * @author akarkala
 */
public class AuditDataServiceTest extends BaseIntegrationTest{
	private static final String SERVICE_NAME="serviceName";
	private static final String PAYLOAD_ID="TestpayloadId";

	@Test
	public void testAuditRequestAndResponse() throws Exception{
		AuditDataService service=ctx.getBean(AuditDataService.class);

        Exchange exchange = new DefaultExchange(new DefaultCamelContext());
        Message message = new DefaultMessage();
        addHeaders(message);
        InputStream body = Thread.currentThread().getContextClassLoader().getResourceAsStream("payloads/incrementalContingency.soap");
        message.setBody(body);
        exchange.setIn(message);
        service.auditRequestAndResponse(exchange, "<response/>",100,ResponseStatus.SUCCESS, true);
        
		Calendar start = Calendar.getInstance();
		start.add(Calendar.HOUR, -4);     	    
		Calendar end = Calendar.getInstance();
		end.add(Calendar.HOUR, +4);     
		
		List<AuditByServicename> services=service.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{SERVICE_NAME}),
				start.getTime(),end.getTime());
		assertTrue(services.size() == 1);
		assertTrue(services.get(0).getPk().getServiceName().equals(SERVICE_NAME));
		assertTrue(services.get(0).getPayloadId().equals(PAYLOAD_ID));
		assertTrue(services.get(0).getProcessTime() == 100);
		assertTrue(services.get(0).getAttachmentSize() != 0);
		assertEquals(services.get(0).getResponseXml(),null);
		
		PayloadAttachmentDao payloadDao= ctx.getBean(PayloadAttachmentDao.class);
		PayloadAttachment payloadData=payloadDao.findById(PAYLOAD_ID);
		assertTrue(payloadData.getAttachment() !=null);
	}

	@Test
	public void testAuditRequestAndResponseWithTTL() throws Exception{
		AuditDataService service=ctx.getBean(AuditDataService.class);

        Exchange exchange = new DefaultExchange(new DefaultCamelContext());
        Message message = new DefaultMessage();
        addHeaders(message);
        InputStream body = Thread.currentThread().getContextClassLoader().getResourceAsStream("payloads/incrementalContingency.soap");
        message.setBody(body);
        exchange.setIn(message);
        service.auditRequestAndResponse(exchange, "<response/>",100,ResponseStatus.SUCCESS, true);
        
		Calendar start = Calendar.getInstance();
		start.add(Calendar.HOUR, -4);     	    
		Calendar end = Calendar.getInstance();
		end.add(Calendar.HOUR, +4);     
		
		List<AuditByServicename> services=service.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{SERVICE_NAME}),
				start.getTime(),end.getTime());
		assertTrue(services.size() == 1);
		assertTrue(services.get(0).getPk().getServiceName().equals(SERVICE_NAME));
		assertTrue(services.get(0).getPayloadId().equals(PAYLOAD_ID));
		
		//TTL expires in 5 seconds. So wait for 10 seconds and make sure data is deleted
		Thread.sleep(TimeUnit.SECONDS.toMillis(10));
		services=service.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{SERVICE_NAME}),
				start.getTime(),end.getTime());
		assertTrue(services.size() == 0);
	}

	@Test
	public void testAuditRequestAndResponseNoSaveAttachment() throws Exception{
		AuditDataService service=ctx.getBean(AuditDataService.class);

        Exchange exchange = new DefaultExchange(new DefaultCamelContext());
        Message message = new DefaultMessage();
        addHeaders(message);
        InputStream body = Thread.currentThread().getContextClassLoader().getResourceAsStream("payloads/incrementalContingency.soap");
        message.setBody(body);
        exchange.setIn(message);
        //If save attachment is false, then attachment should not get saved
        service.auditRequestAndResponse(exchange, "<response/>",100,ResponseStatus.SUCCESS, false);
        
		Calendar start = Calendar.getInstance();
		start.add(Calendar.HOUR, -4);     	    
		Calendar end = Calendar.getInstance();
		end.add(Calendar.HOUR, +4);     
		
		List<AuditByServicename> services=service.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{SERVICE_NAME}),
				start.getTime(),end.getTime());
		assertTrue(services.size() == 1);
		assertTrue(services.get(0).getPk().getServiceName().equals(SERVICE_NAME));
		assertTrue(services.get(0).getPayloadId().equals(PAYLOAD_ID));
		assertTrue(services.get(0).getAttachmentSize() != 0);
		
		PayloadAttachmentDao payloadDao= ctx.getBean(PayloadAttachmentDao.class);
		PayloadAttachment payloadData=payloadDao.findById(PAYLOAD_ID);
		//Make sure attachment is not saved
		assertTrue(payloadData == null);
		
	}

	@Test
	public void testAuditRequestAndResponseNoAttach() throws Exception{
		AuditDataService service=ctx.getBean(AuditDataService.class);

        Exchange exchange = new DefaultExchange(new DefaultCamelContext());
        Message message = new DefaultMessage();
        addHeaders(message);
        InputStream body = Thread.currentThread().getContextClassLoader().getResourceAsStream("payloads/incrementalContingency_no_attach.soap");
        message.setBody(body);
        exchange.setIn(message);
        service.auditRequestAndResponse(exchange, "<response/>",100,ResponseStatus.SUCCESS, true);
        
		Calendar start = Calendar.getInstance();
		start.add(Calendar.HOUR, -4);     	    
		Calendar end = Calendar.getInstance();
		end.add(Calendar.HOUR, +4);     
		
		List<AuditByServicename> services=service.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{SERVICE_NAME}),
				start.getTime(),end.getTime());
		assertTrue(services.size() == 1);
		assertTrue(services.get(0).getPk().getServiceName().equals(SERVICE_NAME));
		assertTrue(services.get(0).getPayloadId().equals(PAYLOAD_ID));
		assertTrue(services.get(0).getAttachmentSize() == 0);

		PayloadAttachmentDao payloadDao= ctx.getBean(PayloadAttachmentDao.class);
		PayloadAttachment payloadData=payloadDao.findById(PAYLOAD_ID);
		//Make sure no attachment
		assertTrue(payloadData == null);		
	}

	@Test
	public void testAuditRequestAndResponseValidations() throws Exception{
		AuditDataService service=ctx.getBean(AuditDataService.class);

        try{
        	//Null message
            service.auditRequestAndResponse(null, "<response/>",100,ResponseStatus.SUCCESS, true);
            fail();
        }catch(Exception e){}

        Exchange exchange = new DefaultExchange(new DefaultCamelContext());
        try{
        	//No body
            service.auditRequestAndResponse(exchange, "<response/>",100,ResponseStatus.SUCCESS, true);
            fail();
        }catch(Exception e){}
        
        InputStream body = Thread.currentThread().getContextClassLoader().getResourceAsStream("payloads/incrementalContingency_no_attach.soap");
        Message message = new DefaultMessage();
        addHeaders(message);
        message.setBody(body);
        exchange.setIn(message);
        try{
        	//No response
            service.auditRequestAndResponse(exchange, "",100,ResponseStatus.SUCCESS, true);
            fail();
        }catch(Exception e){}
        
        try{
        	//No response
            service.auditRequestAndResponse(exchange, "<response/>",100,null, true);
            fail();
        }catch(Exception e){}

        try{
        	//No soap action
            message.setHeader(JMSHeader.SOAP_ACTION.toString(), null);
            service.auditRequestAndResponse(exchange, "<response/>",100,ResponseStatus.SUCCESS, true);
            fail();
        }catch(Exception e){
        	assertTrue(e.getMessage().contains("SOAPAction"));
        }
        try{
        	//No payloadid
            addHeaders(message);
            message.setHeader(JMSHeader.PAYLOAD_ID.toString(), null);
            service.auditRequestAndResponse(exchange, "<response/>",100,ResponseStatus.SUCCESS, true);
            fail();
        }catch(Exception e){
        	assertTrue(e.getMessage().contains("PayloadId"));
        }
	}

	public void testFindAllServiceNames(){
		AuditDataService service=ctx.getBean(AuditDataService.class);
		List<String> serviceNames=service.searchServiceNames("ResourceAwards_RTMv4");
		assertEquals(serviceNames.size(),1);
		
		serviceNames=service.searchServiceNames("abcd");
		assertEquals(serviceNames.size(),0);

	}
	
	@Test
	public void testFindValidations(){
		AuditDataService service=ctx.getBean(AuditDataService.class);
		Calendar start = Calendar.getInstance();
		start.add(Calendar.HOUR, -4);     	    
		Calendar end = Calendar.getInstance();
		end.add(Calendar.HOUR, +4);     
		try{
			service.findByServiceNamesAndCreateDate(null,
					start.getTime(),end.getTime());
			fail();
		}catch(Exception e){}
		
		try{
			service.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{"testservice"}),
					null,end.getTime());
			fail();
		}catch(Exception e){}
		
		try{
			service.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{"testservice"}),
					start.getTime(),null);
			fail();
		}catch(Exception e){}

		try{
			service.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{"testservice"}),
					end.getTime(),start.getTime());
			fail();
		}catch(Exception e){}
		
	}

	@Test
	public void testAddAudit() throws Exception{
		AuditDataService service=ctx.getBean(AuditDataService.class);
		service.insertAuditData(SERVICE_NAME, "payloadid","<requestxml/>", "<responsexml/>",ResponseStatus.SUCCESS,100, "/test/test.uue",100);

		Calendar start = Calendar.getInstance();
		start.add(Calendar.HOUR, -4);     	    
		Calendar end = Calendar.getInstance();
		end.add(Calendar.HOUR, +4);     
		
		List<AuditByServicename> services=service.findByServiceNamesAndCreateDate(Arrays.asList(new String[]{SERVICE_NAME}),
				start.getTime(),end.getTime());
		assertTrue(services.size() == 1);
		assertTrue(services.get(0).getPk().getServiceName().equals(SERVICE_NAME));
		assertTrue(services.get(0).getPayloadId().equals("payloadid"));
		assertTrue(services.get(0).getResponseStatus().equals(ResponseStatus.SUCCESS));
		assertTrue(services.get(0).getProcessTime() == 100);
	}
	
	private void addHeaders(Message message){
        message.setHeader("Content-Type", "multipart/related; type=\"text/xml\"; start=\"<rootpart@soapui.org>\"; boundary=\"----=_Part_140_970107475.1446246864250\"");
        message.setHeader("Content-Length", "3327");
        message.setHeader("Accept-Encoding", "gzip,deflate");
        message.setHeader(JMSHeader.SOAP_ACTION.toString(), "\"http://www.caiso.com/soa/"+SERVICE_NAME+"\"");
        message.setHeader(JMSHeader.PAYLOAD_ID.toString(), PAYLOAD_ID);
		
	}
	
}
