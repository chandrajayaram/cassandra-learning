package caiso.esb.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.cassandra.config.CassandraClusterFactoryBean;
import org.springframework.data.cassandra.config.java.AbstractCassandraConfiguration;

/**
 * @author akarkala
 */
@Configuration
@PropertySource("classpath:esbcommon-test.properties")
@ComponentScan(basePackages = {"caiso.esb"},
	excludeFilters = {@ComponentScan.Filter(
	  type = FilterType.ASSIGNABLE_TYPE,
	  value = {CassandraConfiguration.class}
	)}
)
public class CommonTestConfiguration extends AbstractCassandraConfiguration{

	@Bean
	public CassandraClusterFactoryBean cluster() {		  
		CassandraClusterFactoryBean cluster = new CassandraClusterFactoryBean();
		cluster.setContactPoints("localhost");
		cluster.setPort(9142);
		return cluster;
	}

	@Override
	protected String getKeyspaceName() {
		return "audit_ks";
	}
}
