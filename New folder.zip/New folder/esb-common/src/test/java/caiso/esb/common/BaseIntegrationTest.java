package caiso.esb.common;

import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnit;
import org.cassandraunit.spring.CassandraUnitTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.TestExecutionListeners.MergeMode;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import caiso.esb.config.CommonTestConfiguration;


/**
 * Base class for integration tests
 * 
 * @author akarkala
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners(
  listeners = CassandraUnitTestExecutionListener.class,
  mergeMode = MergeMode.MERGE_WITH_DEFAULTS
)
@CassandraUnit
@CassandraDataSet(value = "cql/audit_cql.cql", keyspace = "audit_ks")
@EmbeddedCassandra
public abstract class BaseIntegrationTest {

	protected ApplicationContext ctx;

	@Before
	public void setup() throws Exception {
		ctx = new AnnotationConfigApplicationContext(CommonTestConfiguration.class);
	}

	@After
	public void tearDown() throws Exception {
		ctx=null;
	}

}
