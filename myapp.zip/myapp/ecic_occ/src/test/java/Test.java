import java.util.Calendar;
import java.util.Date;

public class Test {
public static void main(String[] args) {
	
	Calendar cal = Calendar.getInstance();
	cal.set(Calendar.DAY_OF_MONTH, 1);
	Date startDt = cal.getTime(); 
	cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
	Date endDt = cal.getTime();
	System.out.println(startDt);
	System.out.println(endDt);
	
}
}
