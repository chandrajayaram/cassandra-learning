package com.caiso.ecic.occ.montly.rlc.service;

import java.util.Calendar;
import java.util.Date;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.ecic.occ.service.ECICOCCApplicationConfig;
import com.caiso.ecic.occ.service.MonthlyRLCData;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={ECICOCCApplicationConfig.class})
public class MonthlyRLCDataIntegrationTest {
	
	@Autowired
	MonthlyRLCData service;
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Test
	public void testProcess() {
		
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		final Date startDt = cal.getTime(); 
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
		final Date endDt = cal.getTime();
		
	}

}
