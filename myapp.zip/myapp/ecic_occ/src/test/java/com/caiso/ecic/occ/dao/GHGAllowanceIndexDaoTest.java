package com.caiso.ecic.occ.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.ecic.occ.service.ECICOCCApplicationConfig;
import com.caiso.soa.rlcdata_v1.DailyRLCDataGHGAllowanceIndex;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={ECICOCCApplicationConfig.class})
public class GHGAllowanceIndexDaoTest {

	@Autowired
	GHGAllowanceIndexDao ghgAllowanceIndexDao;

	@Test
	public void test() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.set(Calendar.HOUR_OF_DAY,0);
		cal.set(Calendar.MINUTE,0);
		cal.set(Calendar.SECOND,0);

		final Date startDt = cal.getTime(); 
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
		cal.set(Calendar.HOUR_OF_DAY,23);
		cal.set(Calendar.MINUTE,59);
		cal.set(Calendar.SECOND,59);

		final Date endDt = cal.getTime();
		

		
		List<DailyRLCDataGHGAllowanceIndex> data = ghgAllowanceIndexDao.retrieveGHGAllowanceIndex(startDt, endDt);
		System.out.println(data.size());
		
	}
}
