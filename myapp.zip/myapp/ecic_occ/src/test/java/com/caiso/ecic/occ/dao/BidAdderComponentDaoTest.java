package com.caiso.ecic.occ.dao;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.ecic.occ.service.ECICOCCApplicationConfig;
import com.caiso.soa.rlcdata_v1.BidAdderComponent;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={ECICOCCApplicationConfig.class})
public class BidAdderComponentDaoTest {
	@Autowired
	BidAdderComponentDao bidAdderComponentDao;
	
	@Test
	public void test() {
		List<BidAdderComponent> data = bidAdderComponentDao.retrieveBidAdderComponentData();
		System.out.println(data.size());
	}

}
