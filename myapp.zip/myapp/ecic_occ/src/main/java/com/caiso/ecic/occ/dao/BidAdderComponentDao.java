package com.caiso.ecic.occ.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import com.caiso.ecic.occ.util.ECICOCCUtil;
import com.caiso.soa.rlcdata_v1.BidAdderCompDEBCurveData;
import com.caiso.soa.rlcdata_v1.BidAdderComponent;
import com.caiso.soa.rlcdata_v1.CostPerHour;
import com.caiso.soa.rlcdata_v1.DefaultBidCurveBidAdder;
import com.caiso.soa.rlcdata_v1.MarketType;

@Component
public class BidAdderComponentDao extends GenericDao {
	private static final String RECENT_BID_ADDER_COMP_DATA = 
	"SELECT  BID_ADDER_ID,TRADE_DT,START_EFFECT_DT,END_EFFECT_DT,"
	+"REGGEN_MRID,CONFIG_MRID,MARKETTYPE,MINLOADCOST_VALUE,MINLOADCOST_UNITS,"
    +"BIDTYPE,ADDERTYPE,LAST_MODIFIED,NAME,XAXISDATA,Y1AXISDATA FROM " 
    +"ECIC_MSTR.OUT_BID_ADDER "
    +"WHERE  MARKETTYPE IN ('RTM','DAM') AND BIDTYPE IN ('MINIMUM_LOAD_BID','STARTUP_BID') " 
    +"AND ADDERTYPE = 'MMA'  AND TRADE_DT =(SELECT MAX(TRADE_DT) FROM ECIC_MSTR.OUT_BID_ADDER) " 
    +"ORDER BY REGGEN_MRID,CONFIG_MRID,NAME ASC";


	public List<BidAdderComponent> retrieveBidAdderComponentData() {
		List<BidAdderComponent> bidAdderComponents = new ArrayList<>(); 
		SqlRowSet rowSet = jdbcTemplate.queryForRowSet(RECENT_BID_ADDER_COMP_DATA);
		
		BidAdderComponent bidAdderComponent;
		CostPerHour costPerHour;
		DefaultBidCurveBidAdder defaultBidCurve;
		BidAdderCompDEBCurveData data;
		while (rowSet.next()) {
			bidAdderComponent= new BidAdderComponent();
			bidAdderComponent.setMrid(rowSet.getString("REGGEN_MRID"));
			bidAdderComponent.setStartTime(ECICOCCUtil.getCalendar(rowSet.getObject("START_EFFECT_DT")));
			bidAdderComponent.setStopTime(ECICOCCUtil.getCalendar(rowSet.getObject("END_EFFECT_DT")));
			bidAdderComponent.setLastModified(ECICOCCUtil.getCalendar(rowSet.getObject("LAST_MODIFIED")));
			bidAdderComponent.setMarketType(MarketType.valueOf(rowSet.getString("MARKETTYPE")));
			costPerHour = new CostPerHour();
			if(rowSet.getBigDecimal("MINLOADCOST_VALUE")!=null)
				costPerHour.setValue(rowSet.getBigDecimal("MINLOADCOST_VALUE").floatValue());
			costPerHour.setUnits(rowSet.getString("MINLOADCOST_UNITS"));
			bidAdderComponent.setMinLoadCost(costPerHour);
			bidAdderComponent.setBidType(rowSet.getString("BIDTYPE"));
			bidAdderComponent.setAdderType(rowSet.getString("ADDERTYPE"));
			defaultBidCurve = new DefaultBidCurveBidAdder();
			data = new BidAdderCompDEBCurveData(); 
			defaultBidCurve.getDefaultBidCurveDatas().add(data);
			if(rowSet.getBigDecimal("XAXISDATA")!=null)
				data.setXAxisData(rowSet.getBigDecimal("XAXISDATA").floatValue());
			if(rowSet.getBigDecimal("Y1AXISDATA")!=null)
				data.setY1AxisData(rowSet.getBigDecimal("Y1AXISDATA").floatValue());
			data.setName(rowSet.getString("NAME"));
			bidAdderComponent.setDefaultBidCurve(defaultBidCurve);
			bidAdderComponents.add(bidAdderComponent);
		}
		return bidAdderComponents;
		
	}

}
