package com.caiso.ecic.occ.service;

import java.util.Date;

public class NaturalGPIHistoricalRLCData implements ECICOCCService{

	@Override
	public void process() {
		process(new Date());
		
	}

	@Override
	public void process(Date broadcastDt) {
		// TODO Auto-generated method stub
		
	}

}
