package com.caiso.ecic.occ.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

import com.caiso.ecic.occ.util.ECICOCCUtil;
import com.caiso.soa.rlcdata_v1.RLCFuelRegion;

@Component 
public class GasPriceIndexDao extends GenericDao {
	
	private static final String LAST_TRADING_MT_DATA = "SELECT FUEL_REGION_ID, GAS_PRICE_INDEX, START_EFFECT_DT, END_EFFECT_DT, LAST_MODIFIED FROM ECIC_MSTR.OUT_FUEL_REGION WHERE TRADE_DT BETWEEN ? AND ?"; 

	public List<RLCFuelRegion> retrieveGPI(final Date startDt, final Date endDt) {
		
        PreparedStatementCreator preparedStatementCreator = new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
                PreparedStatement ps = connection.prepareStatement(LAST_TRADING_MT_DATA);
                ps.setDate(1, new java.sql.Date(startDt.getTime()));
                ps.setDate(2, new java.sql.Date(endDt.getTime()));
				return ps;
            }
        };

        ResultSetExtractor<List<RLCFuelRegion>> resultSetExtractor = new ResultSetExtractor<List<RLCFuelRegion>>() {
            public List<RLCFuelRegion> extractData(ResultSet rs) throws SQLException,
            DataAccessException {
            	List<RLCFuelRegion> fuelRegionList = new ArrayList<>();
            	RLCFuelRegion fuelRegion;
                while (rs.next()) {
                	fuelRegion= new RLCFuelRegion();
        			fuelRegion.setMrid(rs.getString("FUEL_REGION_ID"));
        			fuelRegion.setStartEffectiveDate(ECICOCCUtil.getCalendar(rs.getTimestamp("START_EFFECT_DT")));
        			fuelRegion.setEndEffectiveDate(ECICOCCUtil.getCalendar(rs.getTimestamp("END_EFFECT_DT")));
        			fuelRegion.setLastModified(ECICOCCUtil.getCalendar(rs.getTimestamp("LAST_MODIFIED")));
        			fuelRegion.setGasPriceIndex(rs.getBigDecimal("GAS_PRICE_INDEX").floatValue());
        			fuelRegionList.add(fuelRegion);
                }
                return fuelRegionList;
            }
        };

        return jdbcTemplate.query(preparedStatementCreator, resultSetExtractor);
		
	}
	
}
