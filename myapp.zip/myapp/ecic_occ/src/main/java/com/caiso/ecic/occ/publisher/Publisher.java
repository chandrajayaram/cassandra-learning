package com.caiso.ecic.occ.publisher;

import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;

import com.caiso.soa.standardoutput_v1.EventLog;
import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;

public class Publisher {
	
	private Logger logger = LoggerFactory.getLogger(Publisher.class);
	
	private String attachmentName;
	private String uri;
	private String soapAction;
	private int retry;
	private int retryInterval;
	
	private JAXBContext jaxbContext;
	private WebServiceTemplate webServiceTemplate;
	
	public <T> String broadcast(final T data) {
		try {

			try {

				int tried = 0;
				Exception lastException = null;
				boolean status = false;
				while (tried <= retry) {
					if (tried > 0) {
						try {
							Thread.sleep(retryInterval);
						} catch (InterruptedException t) {
							logger.warn("An interrupted occured.  Woke up earlier than anticipated to retry broadcast.",
									t);
							Thread.currentThread().interrupt();
						}
					}
					logger.info("Publishing data ({}/{}) to [uri={}] with [attachmentId={}]", tried + 1, retry + 1, uri,
							MDC.get("txid"));
					try {
						status = webServiceTemplate.sendAndReceive(uri, new WebServiceMessageCallback() {
							@Override
							public void doWithMessage(WebServiceMessage message)
									throws IOException, TransformerException {
								try {
									SoapMessage soapMessage = (SoapMessage) message;
									new CaisoSoapMessage<>(soapAction, soapMessage, attachmentName,data, jaxbContext).constructSoapMessage();
								} catch (Exception e) {
									throw new TransformerException("Unable to convert message into mime attachment.",
											e);
								}
							}

						}, new WebServiceMessageCallback() {
							@Override
							public void doWithMessage(WebServiceMessage message)
									throws IOException, TransformerException {
								handleBroadCastResponseCallback(message);

							}
						});

					} catch (Exception t) {
						logger.warn("An exception occured while trying to broadcast data ({}/{})", tried + 1,
								retry + 1);
						lastException = t;
					}
					// break out of the loop once successfully processed.
					if (status) {
						break;
					}
					++tried;
				}
				// check to see if the data have been published succesfully.
				if (status) {
					return null;
				} else {
					if (lastException != null) {
						throw lastException;
					} else {
						throw new RuntimeException("Unable to broadcast the data to AI.");
					}
				}

			} catch (Exception t) {
				logger.error("Unable to broadcast the data to AI.", t);
				return "Unable to broadcast the data to AI.";
			}
		} catch (Exception t) {
			logger.error("Unable to marshall the message to publish to AI.", t);
			return "Unable to marshall the message to publish to AI.";
		}
	}
   
	private void handleBroadCastResponseCallback(WebServiceMessage message) {
        DOMSource domSource = (DOMSource) message.getPayloadSource();
        if (("OutputDataType").equalsIgnoreCase(domSource.getNode().getLocalName())) {
            // doc attachment.
            try {
            	Unmarshaller unMarshaller = jaxbContext.createUnmarshaller();
            	OutputDataType output = (OutputDataType) unMarshaller.unmarshal(domSource);
                for (EventLog event : output.getEventLogs()) {
                    MDC.put("eventId", event.getId());
                    break;
                }

            } catch (Exception e) {
                logger.warn("Unable to extract payload from response message.", e);
            }
        }
    }
	
	

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getSoapAction() {
		return soapAction;
	}

	public void setSoapAction(String soapAction) {
		this.soapAction = soapAction;
	}

	public int getRetry() {
		return retry;
	}

	public void setRetry(int retry) {
		this.retry = retry;
	}

	public int getRetryInterval() {
		return retryInterval;
	}

	public void setRetryInterval(int retryInterval) {
		this.retryInterval = retryInterval;
	}
	@Autowired
	public void setWebServiceTemplate(WebServiceTemplate webServiceTemplate) {
		this.webServiceTemplate = webServiceTemplate;
	}
	@Autowired
	public void setJaxbContext(JAXBContext jaxbContext) {
		this.jaxbContext = jaxbContext;
	}
}
