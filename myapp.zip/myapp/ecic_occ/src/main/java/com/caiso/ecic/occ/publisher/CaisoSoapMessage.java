package com.caiso.ecic.occ.publisher;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;
import java.util.zip.GZIPOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.MDC;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.xml.transform.StringSource;

import com.caiso.mrtu.soa.schemas._2005._09.attachmenthash.AttachmentHash;
import com.caiso.soa._2006_06_13.standardattachmentinfor.Attachment;
import com.caiso.soa._2006_06_13.standardattachmentinfor.CompressFlag;
import com.caiso.soa._2006_06_13.standardattachmentinfor.StandardAttachmentInfor;

public class CaisoSoapMessage<T> {
	private static final String MIME_ATTACHMENT_BODY = "<%s xmlns=\"%s\"><%s_attachment href=\"cid:%s\" /></%s>";
	
	private String soapAction;
	private SoapMessage soapMessage;
	private String attachmentName;
	private String serviceName;
	private JAXBContext jaxbContext;
	private T data;
		
	public CaisoSoapMessage(String soapAction, SoapMessage soapMessage, String attachmentName,T data,JAXBContext jaxbContext) {
		this.soapAction = soapAction;
		this.soapMessage = soapMessage;
		this.attachmentName= attachmentName;
		this.serviceName = soapAction.substring(soapAction.lastIndexOf("/") + 1);
		this.data = data;
		this.jaxbContext = jaxbContext;
	}

	public SoapMessage constructSoapMessage() throws TransformerException, JAXBException, IOException, NoSuchAlgorithmException {

		final byte[] compressedBytes = compressData();

		final String hashValue = getBas64SHA1Hash(compressedBytes);

		
		addMimeAttachmentToMessage(compressedBytes);

		addAttachmentHashToHeader(hashValue);
		addAttachmentInforToHeader();
		// modify the body
		SoapBody soapBody = soapMessage.getSoapBody();

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();

		String serviceInfor = attachmentName;
		if (serviceInfor == null) {
			serviceInfor = serviceName.replace("broadcast", "");
			if (serviceInfor.contains("_")) {
				serviceInfor = serviceInfor.substring(0, serviceInfor.indexOf("_"));
			}
		}
		String transactionId = MDC.get("txid");
		if (transactionId == null) {
			transactionId = UUID.randomUUID().toString();
		}
		String fileName = "txid-" + transactionId;

		String body = String.format(MIME_ATTACHMENT_BODY, serviceName, serviceName, serviceInfor, fileName,
				serviceName);
		StringSource s = new StringSource(body);
		
		transformer.transform(s, soapBody.getPayloadResult());

		soapMessage.setSoapAction(soapAction);

		return soapMessage;
	}

	private byte[] compressData() throws JAXBException, IOException {
		byte[] uncompressedBytes;

		if (data instanceof String) {
			uncompressedBytes = data.toString().getBytes(StandardCharsets.UTF_8);
		} else {
			ByteArrayOutputStream os = marshall(data);
			uncompressedBytes = os.toByteArray();
		}
		return compressBase64(uncompressedBytes);
	}



	private byte[] compressBase64(byte[] bytes) throws IOException {
		try (ByteArrayOutputStream os = new ByteArrayOutputStream();
				GZIPOutputStream gzos = new GZIPOutputStream(os);) {
			gzos.write(bytes);
			gzos.close();
			return Base64.encodeBase64(os.toByteArray(), true);
		}
	}

	private String getBas64SHA1Hash(byte[] bytes) throws IOException, NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("SHA1");
		md.update(bytes);
		return Base64.encodeBase64String(md.digest());
	}

	private void addAttachmentInforToHeader() throws TransformerException {
		StandardAttachmentInfor stdInfo = new StandardAttachmentInfor();
		Attachment attachment = new Attachment();
		attachment.setId("1");
		attachment.setCompressFlag(CompressFlag.YES);
		attachment.setCompressMethod("gzip");
		stdInfo.getAttachments().add(attachment);
		
		try {
			ByteArrayOutputStream os = marshall(stdInfo);
		
			TransformerFactory.newInstance().newTransformer().transform(
					new StreamSource(new ByteArrayInputStream(os.toByteArray())),
					soapMessage.getSoapHeader().getResult());

		} catch (Exception t) {
			throw new TransformerException(t.getMessage(), t);
		}
	}

	private void addMimeAttachmentToMessage(byte[] compressedBytes) {

		String transactionId = MDC.get("txid");
		if (transactionId == null) {
			transactionId = UUID.randomUUID().toString();
		}
		String fileName = "txid-" + transactionId;
		
		soapMessage.addAttachment(fileName, new ByteArrayResource(compressedBytes), "application/octetstream");

	}

	private void addAttachmentHashToHeader(String hashValue) throws TransformerException {
		AttachmentHash attachmentHash = new AttachmentHash();
		attachmentHash.setHashValue(hashValue);
		try {
			ByteArrayOutputStream os = marshall(attachmentHash);
			TransformerFactory.newInstance().newTransformer().transform(
					new StreamSource(new ByteArrayInputStream(os.toByteArray())),
					soapMessage.getSoapHeader().getResult());

			SoapHeaderElement attachmentQName = soapMessage.getSoapHeader()
					.examineHeaderElements(
							new QName("http://www.caiso.com/mrtu/soa/schemas/2005/09/attachmenthash", "attachmentHash"))
					.next();
			attachmentQName.setMustUnderstand(false);
			attachmentQName.setActorOrRole("http://schemas.xmlsoap.org/soap/actor/next");
		} catch (Exception e) {
			throw new TransformerException(e.getMessage(), e);
		}

	}
	public ByteArrayOutputStream marshall(Object data) throws JAXBException {
		Marshaller marshaller = jaxbContext.createMarshaller();
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		marshaller.marshal(data, os);
		return os;
	}
}
