package com.caiso.ecic.occ.util;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import oracle.sql.TIMESTAMP;



public class ECICOCCUtil {

	public static XMLGregorianCalendar getCalendar(Timestamp ts)  {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(ts);
		try {
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			throw new RuntimeException(e);
		}
	}
	public static XMLGregorianCalendar getCalendar(Object ts)  {
		TIMESTAMP orcts = null;
		if (ts instanceof TIMESTAMP) {
			orcts = (TIMESTAMP) ts;
			try {
				Timestamp timestamp = orcts.timestampValue();
				return getCalendar(timestamp);
				
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}
		return null;
	}
}
