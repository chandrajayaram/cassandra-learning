package com.caiso.ecic.occ.service;

import java.util.Date;

public interface ECICOCCService {
	void process();
	void process(Date broadcastDt);
}	
