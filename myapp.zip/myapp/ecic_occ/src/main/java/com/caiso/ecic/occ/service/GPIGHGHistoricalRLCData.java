package com.caiso.ecic.occ.service;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.ecic.occ.dao.GHGAllowanceIndexDao;
import com.caiso.ecic.occ.dao.GasPriceIndexDao;
import com.caiso.ecic.occ.publisher.Publisher;
import com.caiso.soa.rlcdata_v1.MessagePayload;
import com.caiso.soa.rlcdata_v1.RLCData;

public class GPIGHGHistoricalRLCData implements ECICOCCService{
	private GasPriceIndexDao gasPriceIndexDao;
	private GHGAllowanceIndexDao ghgAllowanceIndexDao; 
	private Publisher gpiGHGHistoricalDataPublisher; 
	
	
	@Override
	public void process() {
		process(new Date());
		
	}
	@Override
	public void process(Date broadcastDt) {
		RLCData payload= generatePayload(broadcastDt);
		gpiGHGHistoricalDataPublisher.broadcast(payload);
	}
	
	public RLCData generatePayload(Date broadcastDt) {
		Calendar cal = Calendar.getInstance();
		
		cal.setTime(broadcastDt);
		
		cal.add(Calendar.YEAR, -1);
		
		cal.set(Calendar.MONTH, 0);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.set(Calendar.HOUR_OF_DAY,0);
		cal.set(Calendar.MINUTE,0);
		cal.set(Calendar.SECOND,0);
		final Date startDt = cal.getTime();
		
		
		cal.set(Calendar.MONTH, 11);
		cal.set(Calendar.DAY_OF_MONTH, 31);
		cal.set(Calendar.HOUR_OF_DAY,23);
		cal.set(Calendar.MINUTE,59);
		cal.set(Calendar.SECOND,59);
		final Date endDt = cal.getTime();
		
		RLCData rlcData = new RLCData();
		MessagePayload messagePayload = new MessagePayload();
		
		messagePayload.getFuelRegions()
		 .addAll(gasPriceIndexDao.retrieveGPI(startDt, endDt));
		
		
		messagePayload.getGHGAllowanceIndices()
		 .addAll(ghgAllowanceIndexDao.retrieveGHGAllowanceIndex(startDt, endDt));
		
		return rlcData;
	}
	
	
	@Autowired
	public void setGasPriceIndexDao(GasPriceIndexDao gasPriceIndexDao) {
		this.gasPriceIndexDao = gasPriceIndexDao;
	}
	@Autowired
	public void setGhgAllowanceIndexDao(GHGAllowanceIndexDao ghgAllowanceIndexDao) {
		this.ghgAllowanceIndexDao = ghgAllowanceIndexDao;
	}
	
	@Autowired
	public void setGpiGHGHistoricalDataPublisher(Publisher gpiGHGHistoricalDataPublisher) {
		this.gpiGHGHistoricalDataPublisher = gpiGHGHistoricalDataPublisher;
	}

}
