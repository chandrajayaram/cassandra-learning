package com.caiso.ecic.occ.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

import com.caiso.ecic.occ.util.ECICOCCUtil;
import com.caiso.soa.rlcdata_v1.DailyRLCDataGHGAllowanceIndex;

@Component
public class GHGAllowanceIndexDao extends GenericDao{
	private static final String GHG_INDEX_DATA = "SELECT GHG_ALLOWANCE_INDEX,LAST_MODIFIED,START_EFFECT_DT,END_EFFECT_DT FROM ECIC_MSTR.OUT_GHG_ALLOWANCE_INDEX WHERE TRADE_DT BETWEEN ? AND ?"; 

	public List<DailyRLCDataGHGAllowanceIndex> retrieveGHGAllowanceIndex(final Date startDt, final Date endDt ) {
		  
		PreparedStatementCreator preparedStatementCreator = new PreparedStatementCreator() {
	            public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
	                PreparedStatement ps = connection.prepareStatement(GHG_INDEX_DATA);
	                ps.setDate(1, new java.sql.Date(startDt.getTime()));
	                ps.setDate(2, new java.sql.Date(endDt.getTime()));
					return ps;
	            }
	        };

	        ResultSetExtractor<List<DailyRLCDataGHGAllowanceIndex>> resultSetExtractor = new ResultSetExtractor<List<DailyRLCDataGHGAllowanceIndex>>() {
	            public List<DailyRLCDataGHGAllowanceIndex> extractData(ResultSet rs) throws SQLException,
	            DataAccessException {
	            	List<DailyRLCDataGHGAllowanceIndex> ghgAllowanceIndices = new ArrayList<>();
	            	DailyRLCDataGHGAllowanceIndex ghgAllowanceIndex;
	                while (rs.next()) {
	                	ghgAllowanceIndex = new DailyRLCDataGHGAllowanceIndex();
	                	if(rs.getBigDecimal("GHG_ALLOWANCE_INDEX")!=null)
	                		ghgAllowanceIndex.setGHGAllowanceIndexPrice(rs.getBigDecimal("GHG_ALLOWANCE_INDEX").floatValue());
	        			ghgAllowanceIndex.setStartEffectiveDate(ECICOCCUtil.getCalendar(rs.getObject("START_EFFECT_DT")));
	        			ghgAllowanceIndex.setEndEffectiveDate(ECICOCCUtil.getCalendar(rs.getObject("END_EFFECT_DT")));
	        			ghgAllowanceIndex.setLastModified(ECICOCCUtil.getCalendar(rs.getObject("LAST_MODIFIED")));
	        			ghgAllowanceIndices.add(ghgAllowanceIndex);
	                	
	                }
	                return ghgAllowanceIndices;
	            }
	        };

	        return jdbcTemplate.query(preparedStatementCreator, resultSetExtractor);

	}

}
