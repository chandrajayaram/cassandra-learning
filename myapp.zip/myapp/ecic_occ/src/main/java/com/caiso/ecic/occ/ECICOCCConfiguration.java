package com.caiso.ecic.occ;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ECICOCCConfiguration {
	
}
