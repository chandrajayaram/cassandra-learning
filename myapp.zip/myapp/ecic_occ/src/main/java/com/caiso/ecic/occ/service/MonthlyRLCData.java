package com.caiso.ecic.occ.service;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caiso.ecic.occ.dao.BidAdderComponentDao;
import com.caiso.ecic.occ.dao.GHGAllowanceIndexDao;
import com.caiso.ecic.occ.dao.GasPriceIndexDao;
import com.caiso.ecic.occ.publisher.Publisher;
import com.caiso.soa.rlcdata_v1.MessagePayload;
import com.caiso.soa.rlcdata_v1.RLCData;

@Service("broadcastMonthlyRLCData")
public class MonthlyRLCData implements ECICOCCService {

	private GasPriceIndexDao gasPriceIndexDao;
	private BidAdderComponentDao bidAdderComponentDao;
	private GHGAllowanceIndexDao ghgAllowanceIndexDao; 
	private Publisher monthlyRLCDataPublisher; 
	
	@Autowired
	public void setMonthlyRLCDataPublisher(Publisher monthlyRLCDataPublisher) {
		this.monthlyRLCDataPublisher = monthlyRLCDataPublisher;
	}

	public void process() {
		Date currentDate= new Date();
		process(currentDate);
	}
	
	private RLCData generatePayload(Date broadcastDt) {
		RLCData rlcData = new RLCData();
		MessagePayload messagePayload = new MessagePayload();
		
		rlcData.setMessagePayload(messagePayload);
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(broadcastDt);
		cal.set(Calendar.HOUR_OF_DAY,23);
		cal.set(Calendar.MINUTE,59);
		cal.set(Calendar.SECOND,59);
		final Date currentDt = cal.getTime();
		
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.set(Calendar.HOUR_OF_DAY,0);
		cal.set(Calendar.MINUTE,0);
		cal.set(Calendar.SECOND,0);
		final Date startDt = cal.getTime(); 
		
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
		cal.set(Calendar.HOUR_OF_DAY,23);
		cal.set(Calendar.MINUTE,59);
		cal.set(Calendar.SECOND,59);
		final Date endDt = cal.getTime();
		
		messagePayload.getFuelRegions()
					 .addAll(gasPriceIndexDao.retrieveGPI(startDt, endDt));
		
		
		messagePayload.getBidAdderComponents()
					 .addAll(bidAdderComponentDao.retrieveBidAdderComponentData());
		
		
		messagePayload.getGHGAllowanceIndices()
					 .addAll(ghgAllowanceIndexDao.retrieveGHGAllowanceIndex(startDt, currentDt));
		
		return rlcData;
	}
	
	public void process(Date broadcastDt) {
		RLCData payload= generatePayload(broadcastDt);
		monthlyRLCDataPublisher.broadcast(payload);
	}
	@Autowired
	public void setGasPriceIndexDao(GasPriceIndexDao gasPriceIndexDao) {
		this.gasPriceIndexDao = gasPriceIndexDao;
	}
	@Autowired
	public void setBidAdderComponentDao(BidAdderComponentDao bidAdderComponentDao) {
		this.bidAdderComponentDao = bidAdderComponentDao;
	}
	@Autowired
	public void setGhgAllowanceIndexDao(GHGAllowanceIndexDao ghgAllowanceIndexDao) {
		this.ghgAllowanceIndexDao = ghgAllowanceIndexDao;
	}

}
