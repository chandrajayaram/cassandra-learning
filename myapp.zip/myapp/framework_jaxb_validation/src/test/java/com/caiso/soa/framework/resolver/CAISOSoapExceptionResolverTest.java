package com.caiso.soa.framework.resolver;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.MethodEndpoint;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.soap.SoapFault;
import org.springframework.ws.soap.SoapFaultDetail;
import org.springframework.ws.soap.server.endpoint.annotation.SoapAction;
import org.springframework.xml.transform.StringResult;

import com.caiso.soa.framework.configuration.CAISOServiceConfiguration;
import com.caiso.soa.framework.configuration.ResponseType;
import com.caiso.soa.framework.payload.RawPayload;
import com.caiso.soa.framework.quartz.BroadcastType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CAISOServiceConfiguration.class)

public class CAISOSoapExceptionResolverTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private CAISOSoapExceptionResolver exceptionResolver = new CAISOSoapExceptionResolver();

    /**
     * Test case to ensure that the provided exception is converted into output
     * data type.
     * 
     * @throws NoSuchMethodException
     */
    @Test
    public void testCustomizeFaultReceive() throws NoSuchMethodException {
        Object endpoint = new MethodEndpoint(new TestEndPoint(), "testReceive", RawPayload.class);
        MessageContext messageContext = Mockito.mock(MessageContext.class);
        SoapFault soapFault = Mockito.mock(SoapFault.class);
        Exception ex = new RuntimeException();
        StringResult result = new StringResult();
        SoapFaultDetail faultDetail = Mockito.mock(SoapFaultDetail.class);
        Mockito.when(soapFault.getFaultDetail()).thenReturn(faultDetail);
        Mockito.when(faultDetail.getResult()).thenReturn(result);

        exceptionResolver.customizeFault(messageContext, endpoint, ex, soapFault);
        Assert.assertTrue("Result should contains the exception raised in this class.",
                result.toString().contains("outputDataType"));
        Assert.assertTrue(result.toString().contains(StatusCode.RECEIVE_CONNECTOR_FAILURE.getDescription()));
    }

    /**
     * Test case to ensure that the provided exception is converted into output
     * data type.
     * 
     * @throws NoSuchMethodException
     */
    @Test
    public void testCustomizeFaultRetrieve() throws NoSuchMethodException {
        Object endpoint = new MethodEndpoint(new TestEndPoint(), "testRetrieve", RawPayload.class);
        MessageContext messageContext = Mockito.mock(MessageContext.class);
        SoapFault soapFault = Mockito.mock(SoapFault.class);
        Exception ex = new RuntimeException();
        StringResult result = new StringResult();
        SoapFaultDetail faultDetail = Mockito.mock(SoapFaultDetail.class);
        Mockito.when(soapFault.getFaultDetail()).thenReturn(faultDetail);
        Mockito.when(faultDetail.getResult()).thenReturn(result);

        exceptionResolver.customizeFault(messageContext, endpoint, ex, soapFault);
        Assert.assertTrue("Result should contains the exception raised in this class.",
                result.toString().contains("outputDataType"));
        Assert.assertTrue(result.toString().contains(StatusCode.RETRIEVE_CONNECTOR_FAILURE.getDescription()));
    }

    /**
     * Test case to ensure that the provided exception is converted into output
     * data type.
     * 
     * @throws NoSuchMethodException
     */
    @Test
    public void testCustomizeFaultUnableToConvertToOutputDataType() throws NoSuchMethodException {
        Object endpoint = new MethodEndpoint(new TestEndPoint(), "testReceive", RawPayload.class);
        MessageContext messageContext = Mockito.mock(MessageContext.class);
        SoapFault soapFault = Mockito.mock(SoapFault.class);
        StringResult result = new StringResult();
        SoapFaultDetail faultDetail = Mockito.mock(SoapFaultDetail.class);
        Mockito.when(soapFault.getFaultDetail()).thenReturn(faultDetail);
        Mockito.when(faultDetail.getResult()).thenReturn(result);

        exceptionResolver.customizeFault(messageContext, endpoint, null, soapFault);
        Assert.assertTrue("Result should contains the exception raised in this class.", result.toString().isEmpty());

    }

    @Endpoint
    private static class TestEndPoint {

        @SoapAction("http://test/testAction")
        @ResponseBody
        public Boolean testReceive(@RequestPayload RawPayload elem) {
            return true;
        }

        @SoapAction("http://test/testAction")
        @ResponseBody
        @ResponseType(msgType = BroadcastType.INLINE, failStatus = StatusCode.RETRIEVE_CONNECTOR_FAILURE)
        public String testRetrieve(@RequestPayload RawPayload elem) {
            return "";
        }
    }

}
