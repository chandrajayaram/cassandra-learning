package com.caiso.soa.framework.quartz;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.hamcrest.core.StringContains;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.JobListener;
import org.quartz.ListenerManager;
import org.quartz.Matcher;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerListener;
import org.quartz.TriggerKey;
import org.quartz.TriggerListener;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;

import com.caiso.soa.framework.configuration.CAISOServiceConfiguration;
import com.caiso.soa.framework.domain.AdditionalJobs;
import com.caiso.soa.framework.domain.SchedulingJob;
import com.caiso.soa.framework.quartz.QuartzRestController;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CAISOServiceConfiguration.class)
public class QuartzRestControllerTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Mock
    private SchedulerFactoryBean schedulerBean;
    @Mock
    AutowireCapableBeanFactory factory;

    @Mock
    JdbcTemplate jdbcTemplate;

    @InjectMocks
    private QuartzRestController quartzController;

    @Before
    public void init() {
        // set default timezone if not already specified
        MockitoAnnotations.initMocks(this);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testIndexWithNoCusomUrl() throws SchedulerException {
        Scheduler mockedScheduler = Mockito.mock(Scheduler.class);
        Mockito.when(schedulerBean.getScheduler()).thenReturn(mockedScheduler);
        Set<JobKey> jobKeys = new HashSet<>();
        jobKeys.add(new JobKey("JOB1", "Group1"));
        Mockito.when(mockedScheduler.getJobKeys(Mockito.any(GroupMatcher.class))).thenReturn(jobKeys);
        List<SchedulingJob> jobs = quartzController.index();
        Assert.assertEquals(1, jobs.size());
        Assert.assertTrue(jobs.get(0).getBaseUrl().contains("JOB1"));
        Assert.assertNull(jobs.get(0).getCustom());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testIndexWithMultipleJobsAndOrdered() throws SchedulerException {
        Scheduler mockedScheduler = Mockito.mock(Scheduler.class);
        Mockito.when(schedulerBean.getScheduler()).thenReturn(mockedScheduler);
        Set<JobKey> jobKeys = new HashSet<>();
        jobKeys.add(new JobKey("JOB1", "Group1"));
        jobKeys.add(new JobKey("JOB2", "Group1"));
        Mockito.when(mockedScheduler.getJobKeys(Mockito.any(GroupMatcher.class))).thenReturn(jobKeys);
        List<SchedulingJob> jobs = quartzController.index();
        Assert.assertEquals(2, jobs.size());
        Assert.assertTrue(jobs.get(0).getBaseUrl().contains("JOB1"));
        Assert.assertTrue(jobs.get(1).getBaseUrl().contains("JOB2"));
        Assert.assertNull(jobs.get(0).getCustom());
        Assert.assertNull(jobs.get(1).getCustom());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testIndexWithWithCusomUrl() throws SchedulerException {
        Scheduler mockedScheduler = Mockito.mock(Scheduler.class);
        Mockito.when(schedulerBean.getScheduler()).thenReturn(mockedScheduler);
        Set<JobKey> jobKeys = new HashSet<>();
        jobKeys.add(new JobKey("JOB1", "Group1"));
        Mockito.when(mockedScheduler.getJobKeys(Mockito.any(GroupMatcher.class))).thenReturn(jobKeys);

        List<String> example1 = Arrays.asList("/JOB1?test=test", "/JOB1?test=test2");
        List<String> example2 = Arrays.asList("/JOB1?test2=test", "/JOB1?test2=test2");
        List<AdditionalJobs> additionalJobs = Arrays.asList(new AdditionalJobs("JOB1", "/JOB1?test=?", example1),
                new AdditionalJobs("JOB1", "/JOB1?test2=?", example2));

        Mockito.when(factory.getBean("additionalQuartzJobs")).thenReturn(additionalJobs);

        List<SchedulingJob> jobs = quartzController.index();
        Assert.assertEquals(1, jobs.size());
        Assert.assertTrue(jobs.get(0).getBaseUrl().contains("JOB1"));
        Assert.assertEquals(2, jobs.get(0).getCustom().size());
        Assert.assertEquals("/JOB1?test=?", jobs.get(0).getCustom().get(0).getUrl());
        Assert.assertEquals(example1, jobs.get(0).getCustom().get(0).getExample());
        Assert.assertEquals("/JOB1?test2=?", jobs.get(0).getCustom().get(1).getUrl());
        Assert.assertEquals(example2, jobs.get(0).getCustom().get(1).getExample());

    }

    @Test
    public void testExecuteJobNoDatasourceDefined() throws SchedulerException {
        thrown.expect(RuntimeException.class);
        thrown.expectMessage(StringContains.containsString("quartzDS datasource is not defined."));
        quartzController.executeJob("JOB1", new LinkedMultiValueMap<String, String>(), "USER", "PASSWORD");
    }

    @Test
    public void testExecuteJobInvalidCredential() throws SchedulerException {
        thrown.expect(UnsupportedOperationException.class);
        thrown.expectMessage(StringContains.containsString("Invalid user name and password."));

        DataSource quartzDS = Mockito.mock(DataSource.class);
        Mockito.when(factory.getBean("quartzDS")).thenReturn(quartzDS);
        SqlRowSet mockedRowSet = Mockito.mock(SqlRowSet.class);
        Mockito.when(jdbcTemplate.queryForRowSet(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(mockedRowSet);

        Mockito.when(mockedRowSet.next()).thenReturn(false);

        quartzController.setJdbcTemplate(jdbcTemplate);
        quartzController.executeJob("JOB1", new LinkedMultiValueMap<String, String>(), "USER", "PASSWORD");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteJobInvalidJob() throws SchedulerException {
        // mock user validation
        thrown.expect(RuntimeException.class);
        thrown.expectMessage(StringContains.containsString("Unable to find"));
        DataSource quartzDS = Mockito.mock(DataSource.class);
        Mockito.when(factory.getBean("quartzDS")).thenReturn(quartzDS);
        SqlRowSet mockedRowSet = Mockito.mock(SqlRowSet.class);
        Mockito.when(jdbcTemplate.queryForRowSet(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(mockedRowSet);
        Mockito.when(mockedRowSet.next()).thenReturn(true);

        // mock the job to execute
        Scheduler mockedScheduler = Mockito.mock(Scheduler.class);
        Mockito.when(schedulerBean.getScheduler()).thenReturn(mockedScheduler);
        Set<JobKey> jobKeys = new HashSet<>();
        jobKeys.add(new JobKey("JOB1", "Group1"));
        Mockito.when(mockedScheduler.getJobKeys(Mockito.any(GroupMatcher.class))).thenReturn(jobKeys);

        quartzController.setJdbcTemplate(jdbcTemplate);
        quartzController.executeJob("JOB2", new LinkedMultiValueMap<String, String>(), "USER", "PASSWORD");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteJobSuccess() throws SchedulerException {
        // mock user validation
        DataSource quartzDS = Mockito.mock(DataSource.class);
        Mockito.when(factory.getBean("quartzDS")).thenReturn(quartzDS);
        SqlRowSet mockedRowSet = Mockito.mock(SqlRowSet.class);
        Mockito.when(jdbcTemplate.queryForRowSet(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(mockedRowSet);
        Mockito.when(mockedRowSet.next()).thenReturn(true);

        // mock the job to execute
        Scheduler mockedScheduler = Mockito.mock(Scheduler.class);
        Mockito.when(schedulerBean.getScheduler()).thenReturn(mockedScheduler);
        Set<JobKey> jobKeys = new HashSet<>();
        jobKeys.add(new JobKey("JOB1", "Group1"));
        Mockito.when(mockedScheduler.getJobKeys(Mockito.any(GroupMatcher.class))).thenReturn(jobKeys);

        final MockedListenerManager listenerManager = new MockedListenerManager();
        Mockito.when(mockedScheduler.getListenerManager()).thenReturn(listenerManager);
        Mockito.doAnswer(new Answer<Void>() {

            @Override
            public Void answer(InvocationOnMock invocation) throws Throwable {
                // response with complete
                listenerManager.notifyOfComplete();
                return null;
            }
        }).when(mockedScheduler).triggerJob(Mockito.any(JobKey.class));

        quartzController.setJdbcTemplate(jdbcTemplate);
        String status = quartzController.executeJob("JOB1", new LinkedMultiValueMap<String, String>(), "USER",
                "PASSWORD");
        Assert.assertTrue(status.contains("is successfully processed"));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteJobFailed() throws SchedulerException {
        // mock user validation
        DataSource quartzDS = Mockito.mock(DataSource.class);
        Mockito.when(factory.getBean("quartzDS")).thenReturn(quartzDS);
        SqlRowSet mockedRowSet = Mockito.mock(SqlRowSet.class);
        Mockito.when(jdbcTemplate.queryForRowSet(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(mockedRowSet);
        Mockito.when(mockedRowSet.next()).thenReturn(true);

        // mock the job to execute
        Scheduler mockedScheduler = Mockito.mock(Scheduler.class);
        Mockito.when(schedulerBean.getScheduler()).thenReturn(mockedScheduler);
        Set<JobKey> jobKeys = new HashSet<>();
        jobKeys.add(new JobKey("JOB1", "Group1"));
        Mockito.when(mockedScheduler.getJobKeys(Mockito.any(GroupMatcher.class))).thenReturn(jobKeys);

        final MockedListenerManager listenerManager = new MockedListenerManager();
        Mockito.when(mockedScheduler.getListenerManager()).thenReturn(listenerManager);
        Mockito.doAnswer(new Answer<Void>() {

            @Override
            public Void answer(InvocationOnMock invocation) throws Throwable {
                // response with exception
                listenerManager.notifyOfException();
                return null;
            }
        }).when(mockedScheduler).triggerJob(Mockito.any(JobKey.class));

        quartzController.setJdbcTemplate(jdbcTemplate);
        String status = quartzController.executeJob("JOB1", new LinkedMultiValueMap<String, String>(), "USER",
                "PASSWORD");
        Assert.assertTrue(status.contains("failed to process."));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteNoStatus() throws SchedulerException {
        // mock user validation
        DataSource quartzDS = Mockito.mock(DataSource.class);
        Mockito.when(factory.getBean("quartzDS")).thenReturn(quartzDS);
        SqlRowSet mockedRowSet = Mockito.mock(SqlRowSet.class);
        Mockito.when(jdbcTemplate.queryForRowSet(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(mockedRowSet);
        Mockito.when(mockedRowSet.next()).thenReturn(true);

        // mock the job to execute
        Scheduler mockedScheduler = Mockito.mock(Scheduler.class);
        Mockito.when(schedulerBean.getScheduler()).thenReturn(mockedScheduler);
        Set<JobKey> jobKeys = new HashSet<>();
        jobKeys.add(new JobKey("JOB1", "Group1"));
        Mockito.when(mockedScheduler.getJobKeys(Mockito.any(GroupMatcher.class))).thenReturn(jobKeys);

        final MockedListenerManager listenerManager = new MockedListenerManager();
        Mockito.when(mockedScheduler.getListenerManager()).thenReturn(listenerManager);
        Mockito.doAnswer(new Answer<Void>() {

            @Override
            public Void answer(InvocationOnMock invocation) throws Throwable {
                // no response
                return null;
            }
        }).when(mockedScheduler).triggerJob(Mockito.any(JobKey.class));

        quartzController.setJdbcTemplate(jdbcTemplate);
        String status = quartzController.executeJob("JOB1", new LinkedMultiValueMap<String, String>(), "USER",
                "PASSWORD");
        Assert.assertTrue(status.contains("Unable to get the job status"));

    }

    private static class MockedListenerManager implements ListenerManager {

        private JobListener jobListener;

        @Override
        public boolean setTriggerListenerMatchers(String listenerName, List<Matcher<TriggerKey>> matchers) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean setJobListenerMatchers(String listenerName, List<Matcher<JobKey>> matchers) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean removeTriggerListenerMatcher(String listenerName, Matcher<TriggerKey> matcher) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean removeTriggerListener(String name) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean removeSchedulerListener(SchedulerListener schedulerListener) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean removeJobListenerMatcher(String listenerName, Matcher<JobKey> matcher) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean removeJobListener(String name) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public List<TriggerListener> getTriggerListeners() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public List<Matcher<TriggerKey>> getTriggerListenerMatchers(String listenerName) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public TriggerListener getTriggerListener(String name) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public List<SchedulerListener> getSchedulerListeners() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public List<JobListener> getJobListeners() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public List<Matcher<JobKey>> getJobListenerMatchers(String listenerName) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public JobListener getJobListener(String name) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public boolean addTriggerListenerMatcher(String listenerName, Matcher<TriggerKey> matcher) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public void addTriggerListener(TriggerListener triggerListener, List<Matcher<TriggerKey>> matchers) {
            // TODO Auto-generated method stub

        }

        @SuppressWarnings("unchecked")
        @Override
        public void addTriggerListener(TriggerListener triggerListener, Matcher<TriggerKey>... matchers) {
            // TODO Auto-generated method stub

        }

        @Override
        public void addTriggerListener(TriggerListener triggerListener, Matcher<TriggerKey> matcher) {
            // TODO Auto-generated method stub

        }

        @Override
        public void addTriggerListener(TriggerListener triggerListener) {
            // TODO Auto-generated method stub

        }

        @Override
        public void addSchedulerListener(SchedulerListener schedulerListener) {
            // TODO Auto-generated method stub

        }

        @Override
        public boolean addJobListenerMatcher(String listenerName, Matcher<JobKey> matcher) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public void addJobListener(JobListener jobListener, List<Matcher<JobKey>> matchers) {
            // TODO Auto-generated method stub

        }

        @SuppressWarnings("unchecked")
        @Override
        public void addJobListener(JobListener jobListener, Matcher<JobKey>... matchers) {
            // TODO Auto-generated method stub

        }

        @Override
        public void addJobListener(JobListener jobListener, Matcher<JobKey> matcher) {
            this.jobListener = jobListener;

        }

        @Override
        public void addJobListener(JobListener jobListener) {

        }

        public void notifyOfComplete() {
            this.jobListener.jobWasExecuted(null, null);
        }

        public void notifyOfException() {
            this.jobListener.jobWasExecuted(null, new JobExecutionException("Test Exception"));
        }
    }
}
