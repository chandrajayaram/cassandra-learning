package com.caiso.soa.framework.quartz;

import java.util.LinkedList;
import java.util.List;

import org.hamcrest.core.StringContains;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.caiso.soa.framework.configuration.CAISOServiceConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CAISOServiceConfiguration.class)
public class BoradCastJobTest {
    @Mock
    private WebServiceTemplate webServiceTemplate;

    @Mock
    private AutowireCapableBeanFactory factory;

    @InjectMocks
    private BroadCastJobConcrete broadCast;

    @InjectMocks
    private BroadCastJobConcreteDomainType broadCastDomain;

    @Bean
    public BroadCastJobConcrete getBean() {
        return new BroadCastJobConcrete();
    }

    @Bean
    public BroadCastJobConcreteDomainType getBeanDomain() {
        return new BroadCastJobConcreteDomainType();
    }

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private JobDataMap jobDataMap;

    private static java.util.List<String> data = new LinkedList<>();

    @Before
    public void init() {
        // set default timezone if not already specified
        MockitoAnnotations.initMocks(this);
        jobDataMap = new JobDataMap();
    }

    @Test
    public void testMissingEndPoint() throws JobExecutionException {
        thrown.expect(JobExecutionException.class);
        thrown.expectMessage(StringContains.containsString("End point is not specified"));
        test();
    }

    @Test
    public void testMissingSoapAction() throws JobExecutionException {
        thrown.expect(JobExecutionException.class);
        thrown.expectMessage(StringContains.containsString("Soap Action is not specified "));
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        test();
    }

    @Test
    public void testInvalidRetry() throws JobExecutionException {
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), "3e4");
        data.clear();
        test();
    }

    @Test
    public void testInvalidRetryInterval() throws JobExecutionException {
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY_INTERVAL.getVal(), "3e4");
        data.clear();
        test();
    }

    @Test
    public void testGetDataSuccessfullyProcessed() throws JobExecutionException {
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        data.clear();
        data.add("Testin 2");
        Mockito.when(webServiceTemplate.sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class)))
                .thenReturn(true);

        test();
    }

    @Test
    public void testGetDataSuccessRepublish() throws JobExecutionException {
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), 3);
        data.clear();
        data.add("Testin 2");

        Mockito.when(webServiceTemplate.sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class)))
                .thenReturn(false, false, true);

        test();
        Mockito.verify(webServiceTemplate, Mockito.times(3)).sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class));

    }

    @Test
    public void testGetDataSuccessRepublishMimeAttach() throws JobExecutionException {
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), 2);
        jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), BroadcastType.MIME_ATTACHMENT);
        data.add("Testin 2");

        Mockito.when(webServiceTemplate.sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class)))
                .thenReturn(true);

        test();
    }

    @Test
    public void testGetDataSuccessRepublishInline() throws JobExecutionException {
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), 2);
        jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), BroadcastType.INLINE);
        data.add("Testin 2");

        Mockito.when(webServiceTemplate.sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class)))
                .thenReturn(true);

        test();
    }

    @Test
    public void testGetDataSuccessRepublishDefault() throws JobExecutionException {
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), 2);
        jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), "");
        data.add("Testin 2");

        Mockito.when(webServiceTemplate.sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class)))
                .thenReturn(true);

        test();
    }

    @Test
    public void testGetDataSuccessRepublish2Payload() throws JobExecutionException {
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), 1);
        data.clear();
        data.add("Testin 1");
        data.add("Testin 2");

        Mockito.when(webServiceTemplate.sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class)))
                .thenReturn(true, true);

        test();

        Mockito.verify(webServiceTemplate, Mockito.times(2)).sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class));

    }

    @Test
    public void testGetDataSuccessRepublishInvalidBroadcastType() throws JobExecutionException {
        thrown.expect(JobExecutionException.class);
        thrown.expectMessage(StringContains.containsString("is not valid"));
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), 2);
        jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), "TEST");
        data.add("Testin 2");

        Mockito.when(webServiceTemplate.sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class)))
                .thenReturn(true);

        test();
    }

    @Test
    public void testGetDataSuccessFailedRepublish() throws JobExecutionException {
        thrown.expect(JobExecutionException.class);

        thrown.expectMessage(StringContains.containsString("Unable to broadcast"));
        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), 1);
        data.add("Testin 2");

        Mockito.when(webServiceTemplate.sendAndReceive(Mockito.anyString(),
                Mockito.any(WebServiceMessageCallback.class), Mockito.any(WebServiceMessageCallback.class)))
                .thenThrow(new RuntimeException("Testing failure"));

        test();
    }

    @Test
    public void testFailToConvertPayloadDocAttach() throws JobExecutionException {
        thrown.expect(JobExecutionException.class);

        thrown.expectMessage(StringContains.containsString("Unable to marshall the message"));

        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), 1);
        JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
        JobDetail jobDetail = Mockito.mock(JobDetail.class);

        Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
        Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
        Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("test"));
        broadCastDomain.executeInternal(jobContext);
    }

    @Test
    public void testFailToConvertPayloadMimeAttach() throws JobExecutionException {
        thrown.expect(JobExecutionException.class);

        thrown.expectMessage(StringContains.containsString("Unable to marshall the message"));

        jobDataMap.put(QuartzProperty.URI.getVal(), "test_uri");
        jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "test_soap_action");
        jobDataMap.put(QuartzProperty.RETRY.getVal(), 1);
        jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), BroadcastType.MIME_ATTACHMENT);
        JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
        JobDetail jobDetail = Mockito.mock(JobDetail.class);

        Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
        Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
        Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("test"));
        broadCastDomain.executeInternal(jobContext);
    }

    private void test() throws JobExecutionException {
        JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
        JobDetail jobDetail = Mockito.mock(JobDetail.class);

        Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
        Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
        Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("test"));
        broadCast.executeInternal(jobContext);
    }

    public static class BroadCastJobConcrete extends BroadcastJob<String> {

        @Override
        public String getData(JobDataMap jobData, String jobName) {
            if (data.isEmpty()) {
                return null;
            }
            return data.get(0);
        }

        /*
         * (non-Javadoc)
         * 
         * @see
         * com.caiso.soa.framework.quartz.BroadcastJob#getDataAsList(org.quartz.
         * JobDataMap, java.lang.String)
         */
        @Override
        public List<String> getDataAsList(JobDataMap jobData, String jobName) {
            if (data.size() <= 1) {
                return super.getDataAsList(jobData, jobName);
            } else {
                return data;
            }

        }

    }

    public static class BroadCastJobConcreteDomainType extends BroadcastJob<Double> {

        @Override
        public Double getData(JobDataMap jobData, String jobName) {
            return 10.0;
        }

    }

}
