package com.caiso.soa.framework.resolver;

import javax.annotation.PostConstruct;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPMessage;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.MethodEndpoint;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.soap.server.endpoint.annotation.SoapAction;

import com.caiso.soa.framework.configuration.CAISOServiceConfiguration;
import com.caiso.soa.framework.dao.ProcessLogEventDAO;
import com.caiso.soa.framework.domain.LogEvent;
import com.caiso.soa.framework.domain.LogEvent.EventType;
import com.caiso.soa.framework.payload.RawPayload;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CAISOServiceConfiguration.class)
public class CAISOEndpointInterceptorTest {
    @Autowired
    private AutowireCapableBeanFactory factory;
    private CAISOEndpointInterceptor interceptor;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @PostConstruct
    public void init() {
        // init interceptor with the factory
        interceptor = new CAISOEndpointInterceptor(factory);
    }

    /**
     * Test no default configuration for request handling, meaning no logging is
     * enabled.
     * 
     * @throws NoSuchMethodException
     * @throws Exception
     */
    @Test
    public void testHandleRequestNoLogging() throws NoSuchMethodException, Exception {
        boolean status = interceptor.handleRequest(null,
                new MethodEndpoint(new TestEndPoint(), "testAction", RawPayload.class));
        Assert.assertTrue("Interceptor is not able to handle the provided end point.", status);
        Assert.assertNotNull("Interceptor is not adding txid into MDC.", MDC.get("txid"));
        Assert.assertEquals("Interceptor is not adding serviceName into MDC.", "testAction", MDC.get("serviceName"));
        Assert.assertFalse("Interceptor is enabled logging", interceptor.getEnableLogging());
    }

    /**
     * Test no default configuration for response handling, meaning no logging
     * is enabled.
     * 
     * @throws NoSuchMethodException
     * @throws Exception
     */
    @Test
    public void testHandleResponseNoLogging() throws NoSuchMethodException, Exception {
        interceptor.handleResponse(null, new MethodEndpoint(new TestEndPoint(), "testAction", RawPayload.class));
        Assert.assertNull("Interceptor is enabled logging", interceptor.getEnableLogging());
    }

    /**
     * Test no default configuration for fault handling, meaning no logging is
     * enabled.
     * 
     * @throws NoSuchMethodException
     * @throws Exception
     */
    @Test
    public void testHandleFaultNoLogging() throws NoSuchMethodException, Exception {
        interceptor.handleFault(null, new MethodEndpoint(new TestEndPoint(), "testAction", RawPayload.class));
        Assert.assertNull("Interceptor is enabled logging", interceptor.getEnableLogging());
    }

    /**
     * Testing request handling with logging enabled. Ensures that it is logged
     * with appropriate event type.
     * 
     * @throws NoSuchMethodException
     * @throws Exception
     */
    @Test
    public void testHandleRequestLogging() throws NoSuchMethodException, Exception {
        ProcessLogEventDAO mockedLogEventDAO = Mockito.mock(ProcessLogEventDAO.class);
        ArgumentCaptor<LogEvent> captor = ArgumentCaptor.forClass(LogEvent.class);
        // add mock object to handle the get jdbc template and handle insertion
        // since we don't have an actual DB laye
        CAISOEndpointInterceptor mockedInterceptor = new CAISOEndpointInterceptor(enableLogging(mockedLogEventDAO));

        boolean status = mockedInterceptor.handleRequest(null,
                new MethodEndpoint(new TestEndPoint(), "testAction", RawPayload.class));

        Mockito.verify(mockedLogEventDAO).insert(captor.capture());

        Assert.assertTrue("Interceptor is not able to handle the provided end point.", status);
        Assert.assertNotNull("Interceptor is not adding txid into MDC.", MDC.get("txid"));
        Assert.assertEquals("Interceptor is not adding serviceName into MDC.", "testAction", MDC.get("serviceName"));
        Assert.assertTrue("Interceptor is not enabling logging", mockedInterceptor.getEnableLogging());
        Assert.assertEquals(EventType.PROCESS_RECEIVE, captor.getValue().getEventType());
    }

    /**
     * Testing response handling with logging enabled. Ensures that it is logged
     * with appropriate event type.
     * 
     * @throws NoSuchMethodException
     * @throws Exception
     */
    @Test
    public void testHandleResponseLogging() throws NoSuchMethodException, Exception {
        ProcessLogEventDAO mockedLogEventDAO = Mockito.mock(ProcessLogEventDAO.class);

        CAISOEndpointInterceptor mockedInterceptor = new CAISOEndpointInterceptor(enableLogging(mockedLogEventDAO));
        // need to call handle request to init the logging.
        ArgumentCaptor<LogEvent> captor = ArgumentCaptor.forClass(LogEvent.class);
        mockedInterceptor.handleRequest(null, new MethodEndpoint(new TestEndPoint(), "testAction", RawPayload.class));
        Mockito.verify(mockedLogEventDAO).insert(captor.capture());

        mockedInterceptor.handleResponse(null, new MethodEndpoint(new TestEndPoint(), "testAction", RawPayload.class));
        Mockito.verify(mockedLogEventDAO, Mockito.times(2)).insert(captor.capture());

        Assert.assertEquals(EventType.PROCESS_COMPLETE, captor.getValue().getEventType());
    }

    /**
     * Testing fault handling with logging enabled. Ensures that it is logged
     * with appropriate event type.
     * 
     * @throws NoSuchMethodException
     * @throws Exception
     */
    @Test
    public void testHandleFaultLogging() throws NoSuchMethodException, Exception {
        ProcessLogEventDAO mockedLogEventDAO = Mockito.mock(ProcessLogEventDAO.class);

        CAISOEndpointInterceptor mockedInterceptor = new CAISOEndpointInterceptor(enableLogging(mockedLogEventDAO));
        // need to call handle request to init the logging.
        ArgumentCaptor<LogEvent> captor = ArgumentCaptor.forClass(LogEvent.class);
        mockedInterceptor.handleRequest(null, new MethodEndpoint(new TestEndPoint(), "testAction", RawPayload.class));
        Mockito.verify(mockedLogEventDAO).insert(captor.capture());

        mockedInterceptor.handleFault(null, new MethodEndpoint(new TestEndPoint(), "testAction", RawPayload.class));
        Mockito.verify(mockedLogEventDAO, Mockito.times(2)).insert(captor.capture());

        Assert.assertEquals(EventType.PROCESS_EXCEPTION, captor.getValue().getEventType());
    }

    @Test
    public void testCaptureInteraction() throws NoSuchMethodException, Exception {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/has_interaction.xml").getInputStream());
        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        interceptor.handleRequest(msgContext, new MethodEndpoint(new TestEndPoint(), "testAction", RawPayload.class));

        Assert.assertEquals("rBlCHmu6iCsnR08B9QsAAA==", MDC.get("interactionId"));
    }

    /**
     * Helper method to create a mock factory to enable logging.
     * 
     * @param mockedLogEventDAO
     * @return
     * @throws Exception
     * @throws NoSuchMethodException
     */
    private AutowireCapableBeanFactory enableLogging(ProcessLogEventDAO mockedLogEventDAO)
            throws Exception, NoSuchMethodException {
        AutowireCapableBeanFactory mockedFactory = Mockito.mock(AutowireCapableBeanFactory.class);
        Mockito.when(mockedFactory.getBean("logEventJdbcTemplate")).thenReturn(new JdbcTemplate());

        Mockito.when(mockedFactory.createBean(ProcessLogEventDAO.class)).thenReturn(mockedLogEventDAO);
        Mockito.when(mockedLogEventDAO.insert(Mockito.any(LogEvent.class))).thenReturn(true);

        return mockedFactory;

    }

    @Endpoint
    private static class TestEndPoint {

        @SoapAction("http://test/testAction")
        @ResponseBody
        public Boolean testAction(@RequestPayload RawPayload elem) {
            return true;
        }
    }
}
