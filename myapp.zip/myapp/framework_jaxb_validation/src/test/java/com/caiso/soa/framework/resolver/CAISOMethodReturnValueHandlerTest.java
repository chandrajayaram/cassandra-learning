package com.caiso.soa.framework.resolver;

import java.lang.reflect.Method;
import java.util.Scanner;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerFactory;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.core.MethodParameter;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.soap.server.endpoint.annotation.SoapAction;
import org.springframework.xml.transform.StringResult;

import com.caiso.soa.framework.configuration.CAISOServiceConfiguration;
import com.caiso.soa.framework.configuration.ResponseType;
import com.caiso.soa.framework.quartz.BroadcastType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CAISOServiceConfiguration.class)
public class CAISOMethodReturnValueHandlerTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private CAISOMethodReturnValueHandler methodReturnResolver = new CAISOMethodReturnValueHandler();

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testSupportingBooleanReturnType() throws NoSuchMethodException, SecurityException {
        Method method = this.getClass().getMethod("responseInlineSuccess");
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Mockito.when(parameter.getParameterType()).thenReturn((Class) Boolean.class);
        Mockito.when(parameter.getMethod()).thenReturn(method);
        boolean supported = methodReturnResolver.supportsReturnType(parameter);
        Assert.assertTrue("Should support Boolean.", supported);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testSupportingResponseTypeAnnotation() throws NoSuchMethodException, SecurityException {
        Method method = this.getClass().getMethod("responseInlineAsString");
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Mockito.when(parameter.getParameterType()).thenReturn((Class) String.class);
        Mockito.when(parameter.getMethod()).thenReturn(method);
        boolean supported = methodReturnResolver.supportsReturnType(parameter);
        Assert.assertTrue("Should support method with the ResponseType annotation.", supported);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testHandleReturnValueAsBoolean() throws Exception {
        Method method = this.getClass().getMethod("responseInlineSuccess");
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage();
        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        MessageContext msgContext = Mockito.mock(MessageContext.class);

        Mockito.when(parameter.getParameterType()).thenReturn((Class) Boolean.class);
        Mockito.when(parameter.getMethod()).thenReturn(method);
        Mockito.when(msgContext.getResponse()).thenReturn(soapMessage);

        methodReturnResolver.handleReturnValue(msgContext, parameter, true);
        StringResult stringResult = new StringResult();
        TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSoapBody().getPayloadSource(),
                stringResult);
        Assert.assertTrue(stringResult.toString().contains("outputDataType"));

    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testHandleReturnValueAsStringInline() throws Exception {
        Method method = this.getClass().getMethod("responseInlineAsString");
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        try (Scanner scanner = new Scanner((new ClassPathResource("payload/response_payload.xml").getFile()))) {
            String returnedValue = scanner.useDelimiter("\\Z").next();
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage();
            SaajSoapMessage soapMessage = new SaajSoapMessage(message);
            MessageContext msgContext = Mockito.mock(MessageContext.class);

            Mockito.when(parameter.getParameterType()).thenReturn((Class) String.class);
            Mockito.when(parameter.getMethod()).thenReturn(method);
            Mockito.when(msgContext.getResponse()).thenReturn(soapMessage);

            methodReturnResolver.handleReturnValue(msgContext, parameter, returnedValue);
            StringResult stringResult = new StringResult();
            TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSoapBody().getPayloadSource(),
                    stringResult);
            Assert.assertTrue(stringResult.toString().contains("LoadForecastData"));
        }

    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testHandleReturnValueAsStringDocAttach() throws Exception {
        Method method = this.getClass().getMethod("responseDocAttachAsString");
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        try (Scanner scanner = new Scanner((new ClassPathResource("payload/response_payload.xml").getFile()))) {
            String returnedValue = scanner.useDelimiter("\\Z").next();
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage();
            SaajSoapMessage soapMessage = new SaajSoapMessage(message);
            MessageContext msgContext = Mockito.mock(MessageContext.class);

            Mockito.when(parameter.getParameterType()).thenReturn((Class) String.class);
            Mockito.when(parameter.getMethod()).thenReturn(method);
            Mockito.when(msgContext.getResponse()).thenReturn(soapMessage);

            methodReturnResolver.handleReturnValue(msgContext, parameter, returnedValue);
            StringResult stringResult = new StringResult();
            TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSoapBody().getPayloadSource(),
                    stringResult);
            Assert.assertTrue(stringResult.toString().contains("AttachmentValue"));
        }

    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testHandleReturnValueAsStringMimeAttach() throws Exception {
        Method method = this.getClass().getMethod("responseMimeAttachAsString");
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        try (Scanner scanner = new Scanner((new ClassPathResource("payload/response_payload.xml").getFile()))) {
            String returnedValue = scanner.useDelimiter("\\Z").next();
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage();
            SaajSoapMessage soapMessage = new SaajSoapMessage(message);
            MessageContext msgContext = Mockito.mock(MessageContext.class);

            Mockito.when(parameter.getParameterType()).thenReturn((Class) String.class);
            Mockito.when(parameter.getMethod()).thenReturn(method);
            Mockito.when(msgContext.getResponse()).thenReturn(soapMessage);

            methodReturnResolver.handleReturnValue(msgContext, parameter, returnedValue);
            StringResult stringResult = new StringResult();
            TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSoapBody().getPayloadSource(),
                    stringResult);
            Assert.assertTrue(stringResult.toString().contains("_attachment"));
            Assert.assertTrue(soapMessage.getAttachments().hasNext());

            StringResult headerResult = new StringResult();
            TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSoapHeader().getSource(),
                    headerResult);
            Assert.assertTrue(headerResult.toString().contains("hashValue"));
        }

    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testHandleReturnValueAsStringMimeAttachMissingServiceNS() throws Exception {
        thrown.expect(RuntimeException.class);
        thrown.expectMessage(
                "serviceName and serviceNS is required for response type of MIME_ATTACHMENT..  Update the @ResponseType annotation to include the serviceName and seviceNS.");
        Method method = this.getClass().getMethod("responseMimeAttachAsStringMissingServiceNS");
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        try (Scanner scanner = new Scanner((new ClassPathResource("payload/response_payload.xml").getFile()))) {
            String returnedValue = scanner.useDelimiter("\\Z").next();
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage();
            SaajSoapMessage soapMessage = new SaajSoapMessage(message);
            MessageContext msgContext = Mockito.mock(MessageContext.class);

            Mockito.when(parameter.getParameterType()).thenReturn((Class) String.class);
            Mockito.when(parameter.getMethod()).thenReturn(method);
            Mockito.when(msgContext.getResponse()).thenReturn(soapMessage);

            methodReturnResolver.handleReturnValue(msgContext, parameter, returnedValue);

        }

    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testHandleReturnValueAsStringMimeAttachMissingServiceName() throws Exception {
        thrown.expect(RuntimeException.class);
        thrown.expectMessage(
                "serviceName and serviceNS is required for response type of MIME_ATTACHMENT..  Update the @ResponseType annotation to include the serviceName and seviceNS.");
        Method method = this.getClass().getMethod("responseMimeAttachAsStringMissingServiceName");
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        try (Scanner scanner = new Scanner((new ClassPathResource("payload/response_payload.xml").getFile()))) {
            String returnedValue = scanner.useDelimiter("\\Z").next();
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage();
            SaajSoapMessage soapMessage = new SaajSoapMessage(message);
            MessageContext msgContext = Mockito.mock(MessageContext.class);

            Mockito.when(parameter.getParameterType()).thenReturn((Class) String.class);
            Mockito.when(parameter.getMethod()).thenReturn(method);
            Mockito.when(msgContext.getResponse()).thenReturn(soapMessage);

            methodReturnResolver.handleReturnValue(msgContext, parameter, returnedValue);

        }

    }

    @SoapAction("test_soap_action")
    @ResponseBody
    @ResponseType(msgType = BroadcastType.INLINE, serviceName = "testServiceName", serviceNS = "testServiceNamespace")
    public String responseInlineAsString() {
        return "";
    }

    @SoapAction("test_soap_action")
    @ResponseBody
    @ResponseType(msgType = BroadcastType.DOC_ATTACHMENT, serviceName = "testServiceName", serviceNS = "testServiceNamespace")
    public String responseDocAttachAsString() {
        return "";
    }

    @SoapAction("test_soap_action")
    @ResponseBody
    @ResponseType(msgType = BroadcastType.MIME_ATTACHMENT, serviceName = "testServiceName", serviceNS = "testServiceNamespace")
    public String responseMimeAttachAsString() {
        return "";
    }

    @SoapAction("test_soap_action")
    @ResponseBody
    @ResponseType(msgType = BroadcastType.MIME_ATTACHMENT, serviceName = "testServiceName")
    public String responseMimeAttachAsStringMissingServiceNS() {
        return "";
    }

    @SoapAction("test_soap_action")
    @ResponseBody
    @ResponseType(msgType = BroadcastType.MIME_ATTACHMENT, serviceNS = "testServiceNamespace")
    public String responseMimeAttachAsStringMissingServiceName() {
        return "";
    }

    @SoapAction("test_soap_action")
    public Boolean responseInlineSuccess() {
        return true;
    }
}
