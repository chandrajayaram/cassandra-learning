package com.caiso.soa.framework.utils;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;
import com.caiso.soa.framework.configuration.CAISOServiceConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CAISOServiceConfiguration.class)
@Rollback
@Transactional
public class SOAPUtilsTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void testgetPayloadAsDocAttachmentFromJaxbElem() throws Exception {
        OutputDataType output = CAISOUtils.generateSuccessfullResponse("test");
        ByteArrayOutputStream stream = SOAPUtils.getPayloadAsDocAttachment(output);
        Assert.assertNotNull(stream);
    }

    @Test
    public void testgetPayloadAsDocAttachmentFromString() throws Exception {
        OutputDataType output = CAISOUtils.generateSuccessfullResponse("test");
        ByteArrayOutputStream outputStream = SOAPUtils.marshal(output);
        String outputXml = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
        ByteArrayOutputStream stream = SOAPUtils.getPayloadAsDocAttachment(outputXml);
        Assert.assertNotNull(stream);
    }

    @Test
    public void testgetPayloadAsDocAttachmentFromNonJaxbElem() throws Exception {
        List<Integer> output = Arrays.asList(12, 31);
        // expecting the JAXBException to be throwned since the List is not
        // JaxbElem.
        thrown.expect(JAXBException.class);
        SOAPUtils.getPayloadAsDocAttachment(output);
    }

}
