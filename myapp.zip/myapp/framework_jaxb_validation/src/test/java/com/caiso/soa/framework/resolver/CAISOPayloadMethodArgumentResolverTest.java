package com.caiso.soa.framework.resolver;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.core.MethodParameter;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.caiso.soa.framework.configuration.CAISOServiceConfiguration;
import com.caiso.soa.framework.payload.DomainPayload;
import com.caiso.soa.framework.payload.RawPayload;
import com.caiso.soa.framework.test.pojo.LoadForecastData;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CAISOServiceConfiguration.class)
public class CAISOPayloadMethodArgumentResolverTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private CAISOPayloadMethodArgumentResolver methodArgumentResolver = new CAISOPayloadMethodArgumentResolver();

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testSupportingRawPayload() {
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Class rawPayloadClass = RawPayload.class;
        Mockito.when(parameter.getParameterType()).thenReturn(rawPayloadClass);
        boolean supported = methodArgumentResolver.supportsParameter(parameter);
        Assert.assertTrue("Should support RawPayload.", supported);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testSupportingDomainPayload() {
        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Class domainPayloadClasss = DomainPayload.class;
        Mockito.when(parameter.getParameterType()).thenReturn(domainPayloadClasss);
        boolean supported = methodArgumentResolver.supportsParameter(parameter);
        Assert.assertTrue("Should support DomainPayload.", supported);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentRawPayloadInlineNoHeader() throws SOAPException, IOException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/inline.xml").getInputStream());
        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Class rawPayloadClass = RawPayload.class;
        Mockito.when(parameter.getParameterType()).thenReturn(rawPayloadClass);
        Object payload = methodArgumentResolver.resolveArgument(msgContext, parameter);
        Assert.assertEquals(RawPayload.class, payload.getClass());
        RawPayload rawPayload = (RawPayload) payload;
        Assert.assertTrue(new String(rawPayload.getXml().toByteArray()).contains("LoadForecastData"));
        Assert.assertNull(rawPayload.getCaisoWSHeader());
        Assert.assertNull(rawPayload.getHeader());

    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentRawPayloadDocAttach() throws SOAPException, IOException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/doc_attach.xml").getInputStream());
        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Mockito.when(parameter.getParameterType()).thenReturn((Class) RawPayload.class);
        Object payload = methodArgumentResolver.resolveArgument(msgContext, parameter);
        Assert.assertEquals(RawPayload.class, payload.getClass());
        RawPayload rawPayload = (RawPayload) payload;
        Assert.assertTrue(new String(rawPayload.getXml().toByteArray()).contains("LoadForecastData"));
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentRawPayloadMimeAttach() throws SOAPException, IOException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/mime_attach.xml").getInputStream());

        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        soapMessage.addAttachment("testAttachment.uue",
                new FileSystemResource(new ClassPathResource("payload/testAttachment.uue").getFile()),
                "application/octetstream");
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Class rawPayloadClass = RawPayload.class;
        Mockito.when(parameter.getParameterType()).thenReturn(rawPayloadClass);
        Object payload = methodArgumentResolver.resolveArgument(msgContext, parameter);
        Assert.assertEquals(RawPayload.class, payload.getClass());
        RawPayload rawPayload = (RawPayload) payload;
        Assert.assertTrue(new String(rawPayload.getXml().toByteArray()).contains("LoadForecastData"));
        Assert.assertEquals(rawPayload.getCaisoWSHeader().getCAISOUsernameToken().getUsername(), "ptester4");
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentDomainPayloadInlineRPC() throws SOAPException, IOException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/inline_rpc.xml").getInputStream());
        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Mockito.when(parameter.getParameterType()).thenReturn((Class) TestWrapper.class);
        Object payload = methodArgumentResolver.resolveArgument(msgContext, parameter);
        Assert.assertEquals(TestWrapper.class, payload.getClass());
        TestWrapper thePayload = (TestWrapper) payload;
        Assert.assertEquals(thePayload.getDomainObject().getMessagePayload().getLoadForecasts().size(), 1);

    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentDomainPayloadInlineNoHeader() throws SOAPException, IOException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/inline.xml").getInputStream());
        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);
        MethodParameter parameter = Mockito.mock(MethodParameter.class);

        Mockito.when(parameter.getParameterType()).thenReturn((Class) TestWrapper.class);
        Object payload = methodArgumentResolver.resolveArgument(msgContext, parameter);

        Assert.assertEquals(TestWrapper.class, payload.getClass());
        TestWrapper thePayload = (TestWrapper) payload;
        Assert.assertEquals(thePayload.getDomainObject().getMessagePayload().getLoadForecasts().size(), 1);
        Assert.assertNull(thePayload.getCaisoWSHeader());
        Assert.assertNull(thePayload.getHeader());

    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentDomainPayloadDocAttach() throws SOAPException, IOException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/doc_attach.xml").getInputStream());
        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        MethodParameter parameter = Mockito.mock(MethodParameter.class);

        Mockito.when(parameter.getParameterType()).thenReturn((Class) TestWrapper.class);

        Object payload = methodArgumentResolver.resolveArgument(msgContext, parameter);

        Assert.assertEquals(TestWrapper.class, payload.getClass());
        TestWrapper thePayload = (TestWrapper) payload;

        Assert.assertEquals(thePayload.getDomainObject().getMessagePayload().getLoadForecasts().size(), 1);
        Assert.assertEquals(thePayload.getCaisoWSHeader().getCAISOUsernameToken().getUsername(), "ptester4");
        Assert.assertNull(thePayload.getHeader());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentDomainPayloadMimeAttach() throws SOAPException, IOException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/mime_attach.xml").getInputStream());

        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        soapMessage.addAttachment("testAttachment.uue",
                new FileSystemResource(new ClassPathResource("payload/testAttachment.uue").getFile()),
                "application/octetstream");
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Mockito.when(parameter.getParameterType()).thenReturn((Class) TestWrapper.class);
        Object payload = methodArgumentResolver.resolveArgument(msgContext, parameter);
        Assert.assertEquals(TestWrapper.class, payload.getClass());
        TestWrapper thePayload = (TestWrapper) payload;

        Assert.assertEquals(thePayload.getDomainObject().getMessagePayload().getLoadForecasts().size(), 1);
        Assert.assertEquals(thePayload.getCaisoWSHeader().getCAISOUsernameToken().getUsername(), "ptester4");
        Assert.assertEquals(thePayload.getCaisoWSHeader().getCAISOUsernameToken().getUsername(), "ptester4");
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentDomainPayloadMimeAttachBadHashValue() throws SOAPException, IOException {
        thrown.expect(SOAPException.class);
        thrown.expectMessage("Attachment Hash is not valid, cannot continue!");

        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/mime_attach_bad_hash.xml").getInputStream());

        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        soapMessage.addAttachment("testAttachment.uue",
                new FileSystemResource(new ClassPathResource("payload/testAttachment.uue").getFile()),
                "application/octetstream");
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Mockito.when(parameter.getParameterType()).thenReturn((Class) TestWrapper.class);
        methodArgumentResolver.resolveArgument(msgContext, parameter);

    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentDomainPayloadMimeAttachBadAttachment() throws SOAPException, IOException {
        thrown.expect(SOAPException.class);
        thrown.expectMessage("Attachment is not valid, cannot continue!");

        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/mime_attach_bad_hash.xml").getInputStream());

        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        soapMessage.addAttachment("testAttachment.uue",
                new FileSystemResource(new ClassPathResource("payload/testAttachment_bad.uue").getFile()),
                "application/octetstream");
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Mockito.when(parameter.getParameterType()).thenReturn((Class) TestWrapper.class);
        methodArgumentResolver.resolveArgument(msgContext, parameter);

    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testResolveArgumentDomainPayloadMimeAttachNoHeader() throws SOAPException, IOException {
        thrown.expect(SOAPException.class);
        thrown.expectMessage("Attachment Hash header property does not exist in message, cannot continue!");

        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/mime_attach_no_header.xml").getInputStream());

        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        soapMessage.addAttachment("testAttachment.uue",
                new FileSystemResource(new ClassPathResource("payload/testAttachment.uue").getFile()),
                "application/octetstream");
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);

        MethodParameter parameter = Mockito.mock(MethodParameter.class);
        Mockito.when(parameter.getParameterType()).thenReturn((Class) TestWrapper.class);
        methodArgumentResolver.resolveArgument(msgContext, parameter);

    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testCustomMarhsallerNoPayload() throws IOException, SOAPException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/inline.xml").getInputStream());
        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);
        MethodParameter parameter = Mockito.mock(MethodParameter.class);

        Mockito.when(parameter.getParameterType()).thenReturn((Class) TestCustomMarshallerWrapperWithoutPayload.class);
        Object payload = methodArgumentResolver.resolveArgument(msgContext, parameter);

        Assert.assertEquals(TestCustomMarshallerWrapperWithoutPayload.class, payload.getClass());
        TestCustomMarshallerWrapperWithoutPayload thePayload = (TestCustomMarshallerWrapperWithoutPayload) payload;
        Assert.assertNull(thePayload.getDomainObject());
        Assert.assertNull(thePayload.getCaisoWSHeader());
        Assert.assertNull(thePayload.getHeader());
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testCustomMarhsallerWithPayload() throws IOException, SOAPException {
        MessageFactory factory = MessageFactory.newInstance();
        SOAPMessage message = factory.createMessage(new MimeHeaders(),
                new ClassPathResource("payload/inline.xml").getInputStream());
        SaajSoapMessage soapMessage = new SaajSoapMessage(message);
        MessageContext msgContext = Mockito.mock(MessageContext.class);
        Mockito.when(msgContext.getRequest()).thenReturn(soapMessage);
        MethodParameter parameter = Mockito.mock(MethodParameter.class);

        Mockito.when(parameter.getParameterType()).thenReturn((Class) TestCustomMarshallerWrapperWithPayload.class);
        Object payload = methodArgumentResolver.resolveArgument(msgContext, parameter);

        Assert.assertEquals(TestCustomMarshallerWrapperWithPayload.class, payload.getClass());
        TestCustomMarshallerWrapperWithPayload thePayload = (TestCustomMarshallerWrapperWithPayload) payload;
        Assert.assertEquals(TestCustomMarshallerWrapperWithPayload.lfd, thePayload.getDomainObject());
        Assert.assertNull(thePayload.getCaisoWSHeader());
        Assert.assertNull(thePayload.getHeader());
    }

    public static class TestWrapper extends DomainPayload<LoadForecastData> {

    }

    public static class TestCustomMarshallerWrapperWithoutPayload extends DomainPayload<LoadForecastData> {

        @Override
        public LoadForecastData customUnMarshaller(ByteArrayOutputStream os) {
            // TODO Auto-generated method stub
            return null;
        }

    }

    public static class TestCustomMarshallerWrapperWithPayload extends DomainPayload<LoadForecastData> {
        public static LoadForecastData lfd = new LoadForecastData();

        @Override
        public LoadForecastData customUnMarshaller(ByteArrayOutputStream os) {
            return lfd;
        }

    }

}
