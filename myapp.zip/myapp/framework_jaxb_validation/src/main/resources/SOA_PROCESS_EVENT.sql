
create table SOA_PROCESS_EVENT (
  "ID" number not null ENABLE,
  "EVENT_TIME" date not null enable, 
  "EVENT_TYPE" varchar2(25) not null enable,
  "SOURCE_HOST" varchar2(256) not null enable, 
  "SERVICE_NAME" varchar2(256) not null enable, 
   "TRANSACTIONID" varchar2(256) not null enable, 
   "INTERACTIONID" varchar2(256) not null enable,
   "COMMENTS" VARCHAR2(512 CHAR),
   "PAYLOAD" CLOB,
   
   CONSTRAINT "PI_BROADCAST_TAG_MAPPING_PK" PRIMARY KEY ("ID"),
   
);
create sequence SOA_PROCESS_EVENT_SQ start with 1 increment by 1;

CREATE INDEX SOA_PROCESS_EVENT_INDX ON SOA_PROCESS_EVENT(EVENT_TIME);