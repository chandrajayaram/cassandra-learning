create table REST_CONTROL_USER (
  "ID" Number Not Null Enable,
  "USER_NAME" Varchar(125) Not Null Enable,
  "PASSWORD" varchar2(254) not null enable
);