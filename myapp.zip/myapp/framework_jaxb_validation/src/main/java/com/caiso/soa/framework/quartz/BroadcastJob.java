package com.caiso.soa.framework.quartz;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import javax.xml.XMLConstants;
import javax.xml.bind.Marshaller;
import javax.xml.bind.util.JAXBSource;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.xml.transform.StringSource;
import org.xml.sax.SAXException;

import com.caiso.soa._2006_06_13.standardoutput.EventLog;
import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;
import com.caiso.soa.framework.dao.ProcessLogEventDAO;
import com.caiso.soa.framework.domain.LogEvent;
import com.caiso.soa.framework.domain.LogEvent.EventType;
import com.caiso.soa.framework.utils.CAISOUtils;
import com.caiso.soa.framework.utils.SOAPUtils;

public abstract class BroadcastJob<T> extends QuartzJobBean {
    private static UnsupportedOperationException unsupportedException = new UnsupportedOperationException();
    private static UnsupportedOperationException unsupportedBroadastType = new UnsupportedOperationException(
            "Unsupport broadcast type.");
    private static RuntimeException unableToBroadCast = new RuntimeException("Unable to broadcast the data to AI.");;
    private Logger logger = LoggerFactory.getLogger(BroadcastJob.class);
    private static final int broadcastRetry = 1;
    private static final int retryInterval = 1000;

    @Autowired
    private WebServiceTemplate webServiceTemplate;

    @Autowired
    private AutowireCapableBeanFactory factory;
    
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.scheduling.quartz.QuartzJobBean#executeInternal(org.
     * quartz.JobExecutionContext)
     */
    @Override
    final public void executeInternal(JobExecutionContext context) throws JobExecutionException {
        MDC.put("startTime", String.valueOf(System.currentTimeMillis()));
        JobDataMap jobData = context.getJobDetail().getJobDataMap();
        String jobName = context.getJobDetail().getKey().getName();
        String txId = MDC.get("txid");
        if (txId == null) {
            txId = UUID.randomUUID().toString();
        }
        MDC.put("txid", txId);
        Object serviceName = jobData.get(QuartzProperty.SERVICE_NAME);
        if (serviceName == null) {
            MDC.put("serviceName", jobName);
        } else {
            MDC.put("serviceName", serviceName.toString());
        }

        log(new LogEvent(EventType.PROCESS_PUBLISH, null));

        try {
            // validate that all the property is defined.
            String uri = getUri(jobData);
            BroadcastType broadcastType = getBroadCastType(jobData);
            String soapAction = getSoapAction(jobData);

            List<T> allData = extractDataFromAdapter(jobData, jobName);

            List<JobExecutionException> exceptions = new LinkedList<>();
            if (allData == null || allData.isEmpty()) {
                logger.warn("There is no data returned by adapter to publish.");
                log(new LogEvent(EventType.PROCESS_WARNING, "No data to publish."));
                notifyOfCompletion(jobData, jobName, allData);
                return;
            }
            Boolean validateSchema = false;
            String strValidateSchema =(String) jobData.get(QuartzProperty.VALIDTA_AGAINST_SCHEMA.getVal());
            if(strValidateSchema != null){
            	validateSchema = Boolean.valueOf(strValidateSchema);
            }
            	
            boolean validationFailed = false;
            if(validateSchema!=null && validateSchema == true){
                SchemaFactory sf=  SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            	String schemaFile =(String) jobData.get(QuartzProperty.SCHEMA_FILE.getVal());
            	if(schemaFile == null){
            		logger.warn("There is no schema file specified for the job to validate.");
                    log(new LogEvent(EventType.PROCESS_WARNING, "No schema file specified for the job to validate."));
                    notifyOfFailure(jobData, jobName, exceptions,allData);
                    return;
            	}
            	
            	InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(schemaFile);
            	Source source = new StreamSource(inputStream);
            	Schema schema = sf.newSchema(source);
    			Validator validator = schema.newValidator();
            	
            	for (T data : allData) {
                    if (data == null) {
                        continue;
                    }
                    try{
                    	SOAPUtils.validateJaxbData(validator, data);
                    }catch(SAXException e){
                    	 validationFailed = true;
                    	 exceptions.add(new JobExecutionException("[txid=" + txId + "] " + "validationFailed -> "+ e.getMessage()));
                    	 logger.error(e.getMessage());
                    	 e.printStackTrace();
                    }
            	}
            }
            if (validationFailed){
            	logger.warn("Validation failed data will not be published.");
                log(new LogEvent(EventType.PROCESS_WARNING, "Data will not be published due to validation failure."));
                notifyOfFailure(jobData, jobName, exceptions,allData);
                return;
            }
            
            // iterate over the list of data and publish.
            for (T data : allData) {
                if (data == null) {
                    continue;
                }
                String status;
                switch (broadcastType) {
                case INLINE:
                    status = inlineBroadcast(jobData, uri, soapAction, data, broadcastType);
                    break;
                case DOC_ATTACHMENT:
                    status = docAttachmentBroadcast(jobData, uri, soapAction, data, broadcastType);
                    break;
                case MIME_ATTACHMENT:
                    status = mineAttachmentBroadcast(jobData, uri, soapAction, data, broadcastType);
                    break;
                default:
                    throw unsupportedBroadastType;
                }

                if (status == null) {
                    notifyOfCompletion(jobData, jobName, data);
                } else {
                    notifyOfFailure(jobData, jobName, status,data);
                    // add exception to the list so we can display
                    // later
                    exceptions.add(new JobExecutionException("[txid=" + txId + "] " + status));
                }

            }
            // if there is no exception which mean it is successfully broadcast.
            // Otherwise just throw the first excpetion will bel good.
            if (exceptions.isEmpty()) {
            	notifyOfCompletion(jobData, jobName, allData);
            	log(new LogEvent(EventType.PROCESS_COMPLETE, null));
            } else {
                log(new LogEvent(exceptions.get(0)));
                notifyOfFailure(jobData, jobName, exceptions ,allData);
                throw exceptions.get(0);
            }

        } catch (JobExecutionException e) {
            throw e;
        } catch (Exception e) {
            throw new JobExecutionException(e);
        } finally {
            String startTimeObject = MDC.get("startTime");
            if (startTimeObject != null) {
                try {
                    long startTime = Long.parseLong(startTimeObject);
                    long ms = System.currentTimeMillis() - startTime;
                    logger.info("It took [ms={}] or [second={}] to process the payload.", ms, ms / 1000.0);
                } catch (Exception e) {
                    logger.info("Unable to get the start time to calculate the message processing time.", e);
                }
            }
            MDC.remove("txid");
            MDC.remove("serviceName");
            MDC.remove("eventId");
        }

    }

    private void notifyOfFailure(JobDataMap jobData, String jobName, String status,T data) {
        log(new LogEvent(EventType.PROCESS_ERROR, status));
        try {
            logger.info("Failed to broadcast data. Callback onError method.");
            onError(jobData, jobName, data);
        } catch (Exception t) {
            logger.error("Adapter " + getClass() + " throws an exception in the onError method.", t);

        }
        logger.error("Failed to broadcast message with error: {}", status);
    }

    private void notifyOfCompletion(JobDataMap jobData, String jobName, T data) {
        // notify that it is completed
        log(new LogEvent(EventType.PROCESS_INFO, "Published."));
        try {
            logger.info("Successfully broadcast data. Callback onSuccess method.");
            onSuccess(jobData, jobName, data);
        } catch (Exception t) {
            logger.error("Adapter " + getClass() + " throws an exception in the onSuccess method.", t);
        }
    }
    
    private void notifyOfFailure(JobDataMap jobData, String jobName, List<JobExecutionException> exceptions ,List<T> allData) {
        log(new LogEvent(EventType.PROCESS_ERROR, "Failed to process all elements in list"));
        try {
            logger.info("Failed to broadcast data. Callback onError method for list.");
            onError(jobData, jobName, allData);
        } catch (Exception t) {
            logger.error("Adapter " + getClass() + " throws an exception in the onError method for list.", t);

        }
        logger.error("Failed to broadcast list of messages with error: {}", exceptions.toString());
    }

    private void notifyOfCompletion(JobDataMap jobData, String jobName, List<T> data) {
        // notify that it is completed
        log(new LogEvent(EventType.PROCESS_INFO, "Published."));
        try {
            logger.info("Successfully broadcast data. Callback onSuccess method for list.");
            onSuccess(jobData, jobName, data);
        } catch (Exception t) {
            logger.error("Adapter " + getClass() + " throws an exception in the onSuccess method for list.", t);
        }
    }

    private List<T> extractDataFromAdapter(JobDataMap jobData, String jobName) {
        // catch exception if the adapter throws exception from retrieving
        // the data.
        List<T> allData = null;
        try {
            logger.debug("Retrieving data from the adapter.");
            // try to call get data as list in case the job wishes to
            // publish multiple payloads.
            try {
                allData = getDataAsList(jobData, jobName);
                if (allData == null) {
                    allData = new LinkedList<>();
                }
                logger.info("There are {} results returned.  There will be {} payload to publish.", allData.size(),
                        allData.size());
            } catch (UnsupportedOperationException e) {
                // The adapter didn't override the getDataAsList so it must
                // be single payload publishing.
                logger.debug("The adata did not override the getDataAsList method so calling the get data method.", e);
                T data = getData(jobData, jobName);
                allData = new LinkedList<>();
                if (data != null) {
                    allData.add(data);
                }
            }

        } catch (Exception t) {
            logger.error("Adapter " + getClass() + " throws an exception while trying to get the data to publish.", t);
            log(new LogEvent(t));
            throw t;
        }

        return allData;
    }

    /**
     * Helper method to log the log event. It only log if the log event jdbc
     * template is defined.
     * 
     * @param event
     */
    private void log(LogEvent event) {
        try {
            Object logEventJDBC = factory.getBean("logEventJdbcTemplate");
            if (logEventJDBC != null) {
                ProcessLogEventDAO logEventDAO = factory.createBean(ProcessLogEventDAO.class);
                logEventDAO.insert(event);
            }
        } catch (Exception e) {
            // best effort
            logger.warn("Unable to save the LogEvent into the database.");
            logger.debug("Error from trying to save log event", e);
        }
    }

    /**
     * Helper method to broadcast the data as mime attachment message.
     * 
     * @param jobData
     *            This is used to notify on success of failure only
     * @param jobName
     *            This is used to notify on success of failure only
     * @param uri
     * @param soapAction
     * @param broadcastType
     * @param data
     * @param packageName
     * @return null if success or message to indicate failure reason.
     */
    private String mineAttachmentBroadcast(final JobDataMap jobData, String uri, final String soapAction, final T data,
            BroadcastType broadcastType) {
        try {
            // mime attachment requires the service name and the service
            // namespace. Rerturn text status not found if unable to find it

            String attachmentNameTmp = null;
            Object attachmentNameObject = jobData.get(QuartzProperty.ATTACHMENT_NAME.getVal());
            if (attachmentNameObject != null) {
                attachmentNameTmp = attachmentNameObject.toString();
            }
            final String attachmentName = attachmentNameTmp;
            byte[] uncompressedBytes;
            // if string type it is already in xml.

            if (data instanceof String) {
                uncompressedBytes = data.toString().getBytes(StandardCharsets.UTF_8);
            } else {
                ByteArrayOutputStream os = SOAPUtils.marshal(data);
                uncompressedBytes = os.toByteArray();
            }

            final byte[] compressedBytes = CAISOUtils.compressBase64(uncompressedBytes);
            final String hashValue = CAISOUtils.getBas64SHA1Hash(compressedBytes);
            try {
                int retry = getRetry(jobData);
                int interval = getRetryInterval(jobData);
                int tried = 0;
                Exception lastException = null;
                boolean status = false;
                while (tried <= retry) {
                    // add delay between retry if it failed previously.
                    if (tried > 0) {
                        try {
                            Thread.sleep(interval);
                        } catch (InterruptedException t) {
                            // null since the thread interrupted will be ok
                            // since we will continue to process.
                            logger.warn("An interrupted occured.  Woke up earlier than anticipated to retry broadcast.",
                                    t);
                            Thread.currentThread().interrupt();
                        }
                    }
                    logger.info(
                            "Publishing data ({}/{}) to [uri={}] as [broadcastType={}] with [attachmentId={}] and [hashValue={}]",
                            tried + 1, retry + 1, uri, broadcastType, MDC.get("txid"), hashValue);
                    try {
                        status = webServiceTemplate.sendAndReceive(uri, new WebServiceMessageCallback() {
                            @Override
                            public void doWithMessage(WebServiceMessage message)
                                    throws IOException, TransformerException {
                                try {
                                    // extract the operation name
                                    String serviceName = soapAction.substring(soapAction.lastIndexOf("/") + 1);
                                    SOAPUtils.addMimeAttachmentToMessage(message, data, serviceName, attachmentName,
                                            soapAction);

                                    ((SoapMessage) message).setSoapAction(soapAction);
                                } catch (Exception e) {
                                    throw new TransformerException("Unable to convert message into mime attachment.",
                                            e);
                                }
                            }

                        }, new WebServiceMessageCallback() {
                            @Override
                            public void doWithMessage(WebServiceMessage message)
                                    throws IOException, TransformerException {
                                handleBroadCastResponseCallback(message);

                            }
                        });

                    } catch (Exception t) {
                        logger.warn("An exception occured while trying to broadcast data ({}/{})", tried + 1,
                                retry + 1);
                        lastException = t;
                    }
                    // break out of the loop once successfully processed.
                    if (status) {
                        break;
                    }
                    ++tried;
                }
                // check to see if the data have been published succesfully.
                if (status) {
                    return null;
                } else {
                    if (lastException != null) {
                        throw lastException;
                    } else {
                        throw unableToBroadCast;
                    }
                }

            } catch (Exception t) {
                logger.error("Unable to broadcast the data to AI.", t);
                return "Unable to broadcast the data to AI.";
            }
        } catch (Exception t) {
            logger.error("Unable to marshall the message to publish to AI.", t);
            return "Unable to marshall the message to publish to AI.";
        }
    }

    /**
     * Helper method to broadcast the data as inline message.
     * 
     * @param jobData
     *            This is used to notify on success of failure only
     * @param jobName
     *            This is used to notify on success of failure only
     * @param uri
     * @param broadcastType
     * @param data
     * @param packageName
     * @return null if success or message to indicate failure reason.
     */
    private String inlineBroadcast(JobDataMap jobData, String uri, final String soapAction, T data,
            BroadcastType broadcastType) {
        try {
            Source source;
            // if string type it is already in xml.
            if (data instanceof String) {
                source = new StringSource((String) data);
            } else {
                Marshaller marhsaller = SOAPUtils.getMarshaller(data);
                source = new JAXBSource(marhsaller, data);
            }
            try {
                int retry = getRetry(jobData);
                int interval = getRetryInterval(jobData);
                int tried = 0;
                Exception lastException = null;
                boolean status = false;
                final Source sourceToPublish = source;
                while (tried <= retry) {
                    // add delay between retry if it failed previously.
                    if (tried > 0) {
                        try {
                            Thread.sleep(interval);
                        } catch (InterruptedException t) {
                            // null since the thread interrupted will be ok
                            // since we will continue to process.
                            logger.warn("An interrupted occured.  Woke up earlier than anticipated to retry broadcast.",
                                    t);
                            Thread.currentThread().interrupt();
                        }
                    }
                    logger.info("Publishing data ({}/{})  to [uri={}] as [broadcastType={}] [soapAction={}]", tried + 1,
                            retry + 1, uri, broadcastType, soapAction);
                    try {
                        status = webServiceTemplate.sendAndReceive(uri, new WebServiceMessageCallback() {

                            @Override
                            public void doWithMessage(WebServiceMessage message)
                                    throws IOException, TransformerException {
                                TransformerFactory.newInstance().newTransformer().transform(sourceToPublish,
                                        message.getPayloadResult());
                                ((SoapMessage) message).setSoapAction(soapAction);

                            }
                        }, new WebServiceMessageCallback() {
                            @Override
                            public void doWithMessage(WebServiceMessage message)
                                    throws IOException, TransformerException {
                                handleBroadCastResponseCallback(message);
                            }
                        });
                    } catch (Exception t) {
                        logger.warn("An exception occured while trying to broadcast data ({}/{})", tried + 1,
                                retry + 1);
                        lastException = t;
                    }
                    // if successful, we will break out of the loop.
                    if (status) {
                        break;
                    }
                    ++tried;
                }
                // check to see if the data have been published succesfully.
                if (status) {
                    return null;
                } else {
                    if (lastException != null) {
                        throw lastException;
                    } else {
                        throw unableToBroadCast;
                    }
                }

            } catch (Exception t) {
                logger.error("Unable to broadcast the data to AI.", t);
                return "Unable to broadcast the data to AI.";
            }
        } catch (Exception t) {
            logger.error("Unable to marshall the message to publish to AI.", t);
            return "Unable to marshall the message to publish to AI.";
        }

    }

    /**
     * Helper method to broadcast the data as inline message.
     * 
     * @param jobData
     *            This is used to notify on success of failure only
     * @param jobName
     *            This is used to notify on success of failure only
     * @param uri
     * @param broadcastType
     * @param data
     * @param packageName
     * @return null if success or message to indicate failure reason.
     */
    private String docAttachmentBroadcast(JobDataMap jobData, String uri, final String soapAction, T data,
            BroadcastType broadcastType) {
        try {
            final ByteArrayOutputStream os = SOAPUtils.getPayloadAsDocAttachment(data);
            try {
                int retry = getRetry(jobData);
                int interval = getRetryInterval(jobData);
                int tried = 0;
                Exception lastException = null;
                boolean status = false;
                while (tried <= retry) {
                    // add delay between retry if it failed previously.
                    if (tried > 0) {
                        try {
                            Thread.sleep(interval);
                        } catch (InterruptedException t) {
                            // null since the thread interrupted will be ok
                            // since we will continue to process.
                            logger.warn("An interrupted occured.  Woke up earlier than anticipated to retry broadcast.",
                                    t);
                            Thread.currentThread().interrupt();
                        }
                    }
                    logger.info("Publishing data ({}/{})  to [uri={}] as [broadcastType={}]", tried + 1, retry + 1, uri,
                            broadcastType);
                    try {
                        status = webServiceTemplate.sendAndReceive(uri, new WebServiceMessageCallback() {

                            @Override
                            public void doWithMessage(WebServiceMessage message)
                                    throws IOException, TransformerException {
                                TransformerFactory.newInstance().newTransformer().transform(
                                        new StreamSource(new ByteArrayInputStream(os.toByteArray())),
                                        message.getPayloadResult());
                                ((SoapMessage) message).setSoapAction(soapAction);
                            }
                        }, new WebServiceMessageCallback() {

                            @Override
                            public void doWithMessage(WebServiceMessage message)
                                    throws IOException, TransformerException {
                                handleBroadCastResponseCallback(message);

                            }
                        });

                    } catch (Exception t) {
                        logger.warn("An acception occured while trying to broadcast data ({}/{})", tried + 1,
                                retry + 1);
                        lastException = t;
                    }
                    // if successful, we will break out of the loop.
                    if (status) {
                        break;
                    }
                    ++tried;

                }
                // check to see if the data have been published succesfully.
                if (status) {
                    return null;
                } else {
                    if (lastException != null) {
                        throw lastException;
                    } else {
                        throw unableToBroadCast;
                    }
                }

            } catch (Exception t) {
                logger.error("Unable to broadcast the data to AI.", t);
                return "Unable to broadcast the data to AI.";
            }
        } catch (Exception t) {
            logger.error("Unable to marshall the message to publish to AI.", t);
            return "Unable to marshall the message to publish to AI.";
        }

    }

    /**
     * Helper method to extract the event id and place into MDC if the response
     * type is of OutputDataType.
     * 
     * @param message
     */
    private void handleBroadCastResponseCallback(WebServiceMessage message) {
        DOMSource domSource = (DOMSource) message.getPayloadSource();
        if (("OutputDataType").equalsIgnoreCase(domSource.getNode().getLocalName())) {
            // doc attachment.
            try {
                OutputDataType output = (OutputDataType) SOAPUtils
                        .unmarshal(OutputDataType.class.getPackage().getName(), domSource);
                for (EventLog event : output.getEventLog()) {
                    MDC.put("eventId", event.getId());
                    break;
                }

            } catch (Exception e) {
                logger.warn("Unable to extract payload from response message.", e);
            }
        }
    }

    /**
     * Helper method to get number of broadcast to be retried if failed to
     * broadcast.
     * 
     * @param jobData
     *            The quartz job configuration.
     * @return The number to retry broadcast if defined in quartz job or
     *         default.
     */
    private int getRetry(JobDataMap jobData) {
        int retry = broadcastRetry;
        Object retryObj = jobData.get(QuartzProperty.RETRY.getVal());
        if (retryObj != null) {
            try {
                retry = Integer.parseInt(retryObj.toString().trim());
            } catch (Exception e) {
                logger.error("Retry is not a valid number.  Using defaul retry value.", e);
            }
        }
        return retry;
    }

    /**
     * Helper method to get the retry interval if broadcast needed to retry.
     * 
     * @param jobData
     * @return
     */
    private int getRetryInterval(JobDataMap jobData) {
        int interval = retryInterval;
        Object retryIntervalObj = jobData.get(QuartzProperty.RETRY_INTERVAL.getVal());
        if (retryIntervalObj != null) {
            try {
                interval = Integer.parseInt(retryIntervalObj.toString().trim());
            } catch (Exception e) {
                logger.error("Retry is not a valid number.  Using defaul retry interval value.", e);
            }
        }
        return interval;
    }

    /**
     * <p>
     * Helper method to extract the broadcast type for the job. Default value to
     * be {@link cam.caiso.soa.framework.quartz.ResponseType.DOC_ATTACHMENT
     * BroadcastType.DOC_ATTACHMENT}
     * </p>
     * 
     * @param jobData
     * @return The broadcast type defined in quartz job or default value
     *         {@link cam.caiso.soa.framework.quartz.ResponseType.DOC_ATTACHMENT
     *         BroadcastType.DOC_ATTACHMENT}
     * @throws JobExecutionException
     *             If the value is defined and it is not in the known type.
     */
    private BroadcastType getBroadCastType(JobDataMap jobData) throws JobExecutionException {
        BroadcastType broadCastType = BroadcastType.DOC_ATTACHMENT;
        Object broadCastTypeObj = jobData.get(QuartzProperty.BROADCAST_TYPE.getVal());

        if (broadCastTypeObj == null) {
            logger.warn(
                    "[{}] is not defined in the quartz job detail table in the job_data column.  It is defaulted to {}.",
                    QuartzProperty.BROADCAST_TYPE.getVal(), broadCastType);
        } else {
            String broadCastTypeString = broadCastTypeObj.toString().trim();
            if (broadCastTypeString.isEmpty()) {
                logger.warn(
                        "[{}] is not defined in the quartz job detail table in the job_data column.  It is defaulted to {}.",
                        QuartzProperty.BROADCAST_TYPE.getVal(), broadCastType);
            } else {
                try {
                    broadCastType = BroadcastType.valueOf(broadCastTypeString);
                } catch (Exception t) {
                    logger.error("[{}={}] is not valid.  Possible values {}", QuartzProperty.BROADCAST_TYPE.getVal(),
                            broadCastTypeString, Arrays.toString(BroadcastType.values()));
                    throw new JobExecutionException("[txid=" + MDC.get("txid") + "] ["
                            + QuartzProperty.BROADCAST_TYPE.getVal() + "=" + broadCastTypeString
                            + " is not valid.  Possible values " + Arrays.toString(BroadcastType.values()), t);
                }
            }
        }
        return broadCastType;
    }

    /**
     * <p>
     * Helper method to extract required URI field from the job_data column.
     * </p>
     * 
     * @param jobData
     * @return The uri to publish data.
     * @throws JobExecutionException
     *             If the value is not defined.
     */
    private String getUri(JobDataMap jobData) throws JobExecutionException {
        String uri = null;
        Object uriObj = jobData.get(QuartzProperty.URI.getVal());
        if (uriObj != null) {
            uri = uriObj.toString().trim();

        }
        if (uri == null || uri.isEmpty()) {
            logger.error(
                    "End point is not specified in the quartz job detail table in the job_data column.  The [{}] is required.",
                    QuartzProperty.URI.getVal());
            throw new JobExecutionException("[txid=" + MDC.get("txid")
                    + "] End point is not specified in the quartz job detail table in the job_data column.  The ["
                    + QuartzProperty.URI.getVal() + "] is required.");
        }
        return uri;

    }

    /**
     * <p>
     * Helper method to extract required SOAP Action field from the job_data
     * column.
     * </p>
     * 
     * @param jobData
     * @return The soap action to add to the header.
     * @throws JobExecutionException
     *             If the value is not defined.
     */
    private String getSoapAction(JobDataMap jobData) throws JobExecutionException {
        String soaAction = null;
        Object soapActionObject = jobData.get(QuartzProperty.SOAP_ACTION.getVal());
        if (soapActionObject != null) {
            soaAction = soapActionObject.toString().trim();

        }
        if (soaAction == null || soaAction.isEmpty()) {
            logger.error(
                    "Soap Action is not specified in the quartz job detail table in the job_data column.  The [{}] is required.",
                    QuartzProperty.SOAP_ACTION.getVal());
            throw new JobExecutionException("[txid=" + MDC.get("txid")
                    + "] Soap Action is not specified in the quartz job detail table in the job_data column.  The ["
                    + QuartzProperty.SOAP_ACTION.getVal() + "] is required.");
        }
        return soaAction;

    }

    /**
     * This method is called to retrieve the data that is going to be used to
     * broadcast.
     * 
     * @param jobData
     *            The data associated the with the job that defined in the
     *            quartz job details table. It is a key value pair type.
     * @param jobName
     *            The name of the job as defined in the quart job detail table.
     * @return The data that is used to publish to the AI or
     *         <strong>null</strong> if not applicable.
     */
    public abstract T getData(JobDataMap jobData, String jobName);

    /**
     * Ability to allow each job to publish more than 1 payload per job.
     * 
     * @param jobData
     * @param jobName
     * @return
     */
    public List<T> getDataAsList(JobDataMap jobData, String jobName) {
        throw unsupportedException;
    }

    /**
     * <p>
     * Call back to notify that the data have been successfully published to the
     * AI. This API can be implemented to update the record to indicate that the
     * data have been broadcasted and transaction needed to be committed.
     * </p>
     * 
     * @param jobData
     *            The data associated the with the job that defined in the
     *            quartz job details table. It is a key value pair type.
     * @param jobName
     *            The name of the job as defined in the quart job detail table.
     * @param data
     *            The data that is used to published to the AI.
     */
    public void onSuccess(JobDataMap jobData, String jobName, T data) {
    };

    /**
     * <p>
     * Call back to notify that we are not able to publish to the AI. This API
     * can be implemented to update the record to indicate the publishing to the
     * AI failed and either rollback or commit the transaction.
     * </p>
     * 
     * @param jobData
     *            The data associated the with the job that defined in the
     *            quartz job details table. It is a key value pair type.
     * @param jobName
     *            The name of the job as defined in the quart job detail table.
     * @param data
     *            The data that is used to published to the AI.
     *            <strong>null</strong> if the
     *            {@link #getData(JobDataMap, String)} throws an exception or
     *            returns <strong>null</strong>.
     */
    public void onError(JobDataMap jobData, String jobName, T data) {
    };
    
    /**
     * <p>
     * Call back to notify that the data have been successfully published to the
     * AI. This API can be implemented to update the record to indicate that the
     * data have been broadcasted and transaction needed to be committed.
     * </p>
     * 
     * @param jobData
     *            The data associated the with the job that defined in the
     *            quartz job details table. It is a key value pair type.
     * @param jobName
     *            The name of the job as defined in the quart job detail table.
     * @param data
     *            The data that is used to published to the AI.
     */
    public void onSuccess(JobDataMap jobData, String jobName, List<T> data) {
    };

    /**
     * <p>
     * Call back to notify that we are not able to publish to the AI. This API
     * can be implemented to update the record to indicate the publishing to the
     * AI failed and either rollback or commit the transaction.
     * </p>
     * 
     * @param jobData
     *            The data associated the with the job that defined in the
     *            quartz job details table. It is a key value pair type.
     * @param jobName
     *            The name of the job as defined in the quart job detail table.
     * @param data
     *            The data that is used to published to the AI.
     *            <strong>null</strong> if the
     *            {@link #getData(JobDataMap, String)} throws an exception or
     *            returns <strong>null</strong>.
     */
    public void onError(JobDataMap jobData, String jobName, List<T> data) {
    };

}
