package com.caiso.soa.framework.domain;

import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class SchedulingJob implements Comparable<SchedulingJob> {
    private String baseUrl;
    private List<BaseAdditionalJob> custom = new LinkedList<>();

    public SchedulingJob(String name) {
        this.baseUrl = "/" + name;
    }

    /**
     * @return the baseUrl
     */
    public String getBaseUrl() {
        return baseUrl;
    }

    @Override
    public int compareTo(SchedulingJob o) {
        return baseUrl.compareTo(o.getBaseUrl());
    }

    /**
     * @return the custom
     */
    public List<BaseAdditionalJob> getCustom() {
        return custom;
    }

    /**
     * @param custom
     *            the custom to set
     */
    public void setCustom(List<BaseAdditionalJob> custom) {
        this.custom = custom;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        // TODO Auto-generated method stub
        if (obj instanceof SchedulingJob) {
            return baseUrl.equals(((SchedulingJob) obj).getBaseUrl());
        }
        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return baseUrl.hashCode();
    }

}
