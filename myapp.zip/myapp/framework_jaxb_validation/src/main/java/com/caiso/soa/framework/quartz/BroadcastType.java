package com.caiso.soa.framework.quartz;

/**
 * The broadcast type that framework is supporting.
 * 
 * @author tta
 *
 */
public enum BroadcastType {
                           INLINE,
                           DOC_ATTACHMENT,
                           MIME_ATTACHMENT;

}
