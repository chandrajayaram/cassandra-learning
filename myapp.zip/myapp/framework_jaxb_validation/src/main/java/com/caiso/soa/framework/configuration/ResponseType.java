package com.caiso.soa.framework.configuration;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;
import com.caiso.soa.framework.quartz.BroadcastType;
import com.caiso.soa.framework.resolver.StatusCode;
import com.caiso.soa.standardoutput_v1.StandardOutput;

/**
 * <p>
 * Annotation to indicate the response type of the retrieve end point. If the
 * {@link #msgType()} is dfined as MIME_ATTACHMENT then the
 * {@link #serviceName()} and {@link serviceNS} is required.
 * </p>
 * 
 * The following snippet shows an example of supported declarations.
 * 
 * <pre>
 * <code>
 * //Indicates that the response type will be of inline attachment message. 
 *&#64;SoapAction("http://www.caiso.com/soa/retrieveVERMeasurements_v1_DocAttach")
 *&#64;ResponsePayload
 *&#64;ResponseType(msgType = BroadcastType.DOC_ATTACHMENT)
 *public MeterMeasurements retrieveVERMeasurements_v1_DocAttach(@RequestPayload RequestVERMeasurementsWrapper elem) {
 * 
 * }
 * 
 * //Indicates that the response type will be of inline message. 
 *&#64;SoapAction("http://www.caiso.com/soa/retrieveVERMeasurements_v1")
 *&#64;ResponsePayload
 *&#64;ResponseType(msgType = BroadcastType.INLINE)
 *public MeterMeasurements retrieveVERMeasurements_v1_DocAttach(@RequestPayload RequestVERMeasurementsWrapper elem) {
 * 
 * }
 * 
 * //Indicates that the response type will be of mime attachment message. 
 *&#64;SoapAction("http://www.caiso.com/soa/retrieveVERMeasurements_v1_MimeAttach")
 *&#64;ResponsePayload
 *&#64;ResponseType(msgType = BroadcastType.MIME_ATTACHMENT, serviceName = "retrieveVERMeasurements_v1", serviceNS = "http://www.caiso.com/soa/retrieveVERMeasurements_v1")
 *public MeterMeasurements retrieveVERMeasurements_v1_DocAttach(@RequestPayload RequestVERMeasurementsWrapper elem) {
 * 
 * }
 * </code>
 * </pre>
 * 
 * @author tta
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Documented
public @interface ResponseType {

    /**
     * Signifies the type of message to be response.
     *
     */
    BroadcastType msgType();

    /**
     * The service name to be place into the body if the response type is of
     * mime attachment. It is only required if it the broadcast type is of mime
     * attachment.
     * 
     */
    String serviceName() default "";

    /**
     * The service namespace to be place into the body if the response type is
     * of mime attachment. It is only required if it the broadcast type is of
     * mime attachment.
     * 
     */

    String serviceNS() default "";

    /**
     * The response standard response to send back to the client. We have
     * multiple version of response message
     * <ol>
     * <li>{@link OutputDataType} The standard response
     * <li>{@link StandardOutput} The new standard response defined on 03/2016
     * <li>{@link com.caiso.soa._2006_06_13.submitstandardoutput.OutputDataType}
     * The standard response from submit. Currently not supported.
     * </ol>
     * 
     * @return
     */
    Class<?> responseType() default OutputDataType.class;

    /**
     * Default value to indicate successful message.
     * 
     * @return
     */
    StatusCode successStatus() default StatusCode.RECEIVE_SERVICE_SUCCESS;

    /**
     * Default value to indicate failure message.
     * 
     * @return
     */
    StatusCode failStatus() default StatusCode.RECEIVE_CONNECTOR_FAILURE;

    /**
     * <p>
     * This flag indicates that the end point is returning the batch id as
     * string.
     * </p>
     * <p>
     * If the flag is set and the response type is of {@link StandardOutput},
     * the framework will construct the standard output object and using the
     * returned string as batch id.
     * </p>
     * <p>
     * If the flag is not set, and the response type is of
     * {@link StandardOutput}, the framework will use the transaction id as the
     * batch id.
     * </p>
     * 
     * 
     * @return
     */
    boolean batchIdIsReturned() default false;

}
