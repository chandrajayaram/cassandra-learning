package com.caiso.soa.framework.resolver;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.core.Ordered;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.MethodEndpoint;
import org.springframework.ws.soap.SoapFault;
import org.springframework.ws.soap.server.endpoint.SimpleSoapExceptionResolver;
import org.springframework.ws.soap.server.endpoint.annotation.SoapAction;

import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;
import com.caiso.soa.framework.configuration.ResponseType;
import com.caiso.soa.framework.utils.CAISOUtils;
import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.standardoutput_v1.StandardOutput;

/**
 * <p>
 * This custom resolver is used to injected into the spring-ws to catch all
 * exception raised by the end point and converted into the standard CAISO SOAP
 * response message.
 * </p>
 * The following shows how it is being used by define definding the bean in the
 * class that extends
 * {@link org.springframework.ws.config.annotation.WsConfigurerAdapter
 * WsConfigurerAdapter}.
 * 
 * <pre>
 * <code> 
 * &#64;Bean
 * public SimpleSoapExceptionResolver simpleSoapExceptionResolver() {
 *	CAISOSoapExceptionResolver exceptionResolver = new CAISOSoapExceptionResolver();
 *	return exceptionResolver;
 *}
 * </code>
 * </pre>
 * 
 * @author tta
 *
 */
public class CAISOSoapExceptionResolver extends SimpleSoapExceptionResolver {

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    private AutowireCapableBeanFactory factory;

    public CAISOSoapExceptionResolver() {
        super.setOrder(Ordered.LOWEST_PRECEDENCE);
    }

    /**
     * Intercept all exceptions and convert into the standard CAISO fault
     * response message.
     */
    @Override
    protected void customizeFault(MessageContext messageContext, Object endpoint, Exception ex, SoapFault fault) {
        MethodEndpoint ep = (MethodEndpoint) endpoint;

        SoapAction soapAction = ep.getMethod().getAnnotation(SoapAction.class);

        ResponseType responseTypeAnnotation = ep.getMethod().getAnnotation(ResponseType.class);

        String actionName = soapAction.value().replaceFirst(".*/([^/?]+).*", "$1");
        // adding the CAISO output data type into fault details.
        StatusCode statusCode = StatusCode.RECEIVE_CONNECTOR_FAILURE;
        Class<?> responseType = OutputDataType.class;
        if (responseTypeAnnotation != null) {
            statusCode = responseTypeAnnotation.failStatus();
            responseType = responseTypeAnnotation.responseType();
        }
        if (responseType.equals(OutputDataType.class)) {
            try {
                OutputDataType outputDataType = CAISOUtils.generateResponse(actionName, ex, statusCode);
                ByteArrayOutputStream os = SOAPUtils.marshal(outputDataType);
                fault.addFaultDetail();
                // add the output data type into the fault detail.
                TransformerFactory.newInstance().newTransformer().transform(
                        new StreamSource(new ByteArrayInputStream(os.toByteArray())),
                        fault.getFaultDetail().getResult());

            } catch (Exception e) {
                // best effort to add the fault details
                logger.error("Unable to marshall exception into standard caiso fault message.", e);
            }
        } else if (responseType.equals(StandardOutput.class)) {
            try {
                String source = null;
                try {
                    Object sourceObject = factory.getBean("AppName");
                    if (sourceObject instanceof String) {
                        source = (String) sourceObject;
                    }
                } catch (Exception e) {
                    logger.info("Unable to get bean [AppName].");
                    logger.debug("Error trying to bet the app name.", e);
                }
                if (source == null) {
                    logger.info(
                            "Bean [AppName] is not define.  The application name is unknow.  Set source in the repsonse message to be CAISO.");
                    source = "CAISO";
                }
                StandardOutput standardOutput = CAISOUtils.generateStandardOuputResponse(source, actionName, ex,
                        statusCode);

                ByteArrayOutputStream os = SOAPUtils.marshal(standardOutput);
                fault.addFaultDetail();
                // add the output data type into the fault detail.
                TransformerFactory.newInstance().newTransformer().transform(
                        new StreamSource(new ByteArrayInputStream(os.toByteArray())),
                        fault.getFaultDetail().getResult());
            } catch (Exception e) {
                // best effort.
                logger.error("Unable to marshall exception into standard caiso fault message.", e);
            }
        } else {
            logger.error("The response type {} is not supported.", responseType);

        }

        logger.error("An exception occured while processing the " + actionName, ex);
        super.customizeFault(messageContext, endpoint, ex, fault);
    }

}
