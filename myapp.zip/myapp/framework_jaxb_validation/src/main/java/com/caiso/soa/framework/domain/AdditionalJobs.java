package com.caiso.soa.framework.domain;

import java.util.List;

public class AdditionalJobs {

    private final String name;
    private final String url;
    private final List<String> example;

    /**
     * Additional jobs to be displayed by the rest controller.
     * 
     * @param name
     *            The name of the job as defined in quartz
     * @param url
     *            The URL with including the request param such as
     *            /testurl?param1=?&pram2=?.
     * @param example
     *            The example url which include the actual request param so user
     *            would know the format for instance
     *            /testurl?startDate=2016-01-01
     */
    public AdditionalJobs(String name, String url, List<String> example) {
        this.name = name;
        this.url = url;
        this.example = example;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @return the example
     */
    public List<String> getExample() {
        return example;
    }

}
