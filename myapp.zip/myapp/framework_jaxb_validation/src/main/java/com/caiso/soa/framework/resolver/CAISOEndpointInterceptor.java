package com.caiso.soa.framework.resolver;

import java.util.Iterator;
import java.util.UUID;

import javax.xml.namespace.QName;
import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.server.endpoint.MethodEndpoint;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.server.endpoint.annotation.SoapAction;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.caiso.soa.framework.dao.ProcessLogEventDAO;
import com.caiso.soa.framework.domain.LogEvent;
import com.caiso.soa.framework.domain.LogEvent.EventType;

public class CAISOEndpointInterceptor implements EndpointInterceptor {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private Boolean enableLogging = null;
    private ProcessLogEventDAO logEventDAO = null;
    private AutowireCapableBeanFactory factory;

    public CAISOEndpointInterceptor(AutowireCapableBeanFactory factory) {
        this.factory = factory;
    }

    @Override
    public boolean handleResponse(MessageContext messageContext, Object endpoint) throws Exception {
        try {
            if (enableLogging != null && enableLogging && logEventDAO != null) {
                LogEvent event = new LogEvent(EventType.PROCESS_COMPLETE, null);
                logger.debug("Inserting an event into event table to indicate successful to process message for {}.",
                        event.getServiceName());
                logEventDAO.insert(event);
            }
        } catch (Exception e) {
            // best effort.
            logger.warn("Unable to save the LogEvent into the database.");
            logger.debug("Exception while trying to save log event into the database.", e);
        }
        return true;
    }

    @Override
    public boolean handleRequest(MessageContext messageContext, Object endpoint) throws Exception {
        if (endpoint instanceof MethodEndpoint) {
            MethodEndpoint ep = (MethodEndpoint) endpoint;
            SoapAction soapActionAnnotation = ep.getMethod().getAnnotation(SoapAction.class);
            String serviceName = soapActionAnnotation.value().replaceFirst(".*/([^/?]+).*", "$1");
            String txId = UUID.randomUUID().toString();
            String interactionId = extractInteractionId(messageContext);
            MDC.put("txid", txId);
            MDC.put("serviceName", serviceName);
            MDC.put("interactionId", interactionId);
            MDC.put("startTime", String.valueOf(System.currentTimeMillis()));
            checkForLogging();
            try {
                if (enableLogging && logEventDAO != null) {
                    LogEvent event = new LogEvent(EventType.PROCESS_RECEIVE, null);
                    logger.debug(
                            "Inserting an event into event table to indicate that the message have been receieve for {}.",
                            serviceName);
                    logEventDAO.insert(event);
                }
            } catch (Exception e) {
                // best effort.
                logger.warn("Unable to save the LogEvent into the database.");
                logger.debug("Exception while trying to save log event into the database.", e);
            }

        }
        return true;

    }

    /**
     * Helper method try to see if the logging is enabled.
     */
    private void checkForLogging() {
        // if the enable logging ds is defined we will save this into the
        // log event table.
        if (enableLogging == null) {
            enableLogging = false;
            try {
                Object logEventJDBC = factory.getBean("logEventJdbcTemplate");
                if (logEventJDBC != null) {
                    logEventDAO = factory.createBean(ProcessLogEventDAO.class);
                    enableLogging = true;
                    logger.info("Logging event is enabled.");
                }
            } catch (Exception e) {
                logger.info("Logging event is disabled.");
                logger.debug("Exception while trying to get log event DAO database.", e);
            }
        }
    }

    @Override
    public boolean handleFault(MessageContext messageContext, Object endpoint) throws Exception {
        try {
            if (enableLogging != null && enableLogging && logEventDAO != null) {
                LogEvent event;
                if (messageContext != null) {
                    event = new LogEvent(EventType.PROCESS_EXCEPTION,
                            ((SoapMessage) messageContext.getResponse()).getFaultReason());
                } else {
                    event = new LogEvent(EventType.PROCESS_EXCEPTION, null);
                }
                logger.debug("Inserting an event into event table to indicate failure to process message for {}.",
                        event.getServiceName());
                logEventDAO.insert(event);
            }
        } catch (Exception e) {
            // best effort.
            logger.warn("Unable to save the LogEvent into the database.");
            logger.debug("Exception while trying to save log event into the database.", e);
        }
        return true;
    }

    @Override
    public void afterCompletion(MessageContext messageContext, Object endpoint, Exception ex) throws Exception {
        String startTimeObject = MDC.get("startTime");
        if (startTimeObject != null) {
            try {
                long startTime = Long.parseLong(startTimeObject);
                long ms = System.currentTimeMillis() - startTime;
                logger.info("It took [ms={}] or [second={}] to process the payload.", ms, ms / 1000.0);
            } catch (Exception e) {
                logger.info("Unable to get the start time to calculate the message processing time.");
            }
        }

        MDC.remove("txid");
        MDC.remove("serviceName");
        MDC.remove("interactionId");

    }

    private String extractInteractionId(MessageContext messageContext) {
        String interactionId = "Unknown";
        try {
            if (messageContext != null) {
                SoapMessage request = (SoapMessage) messageContext.getRequest();
                Iterator<SoapHeaderElement> interactionItr = request.getSoapHeader()
                        .examineHeaderElements(new QName("http://lg.actional.com/2003", "Manifest"));
                while (interactionItr.hasNext()) {
                    SoapHeaderElement interaction = interactionItr.next();
                    NodeList childNode = ((DOMSource) interaction.getSource()).getNode().getChildNodes();
                    for (int i = 0; i < childNode.getLength(); i++) {
                        Node node = childNode.item(i);
                        if ("Interaction".equalsIgnoreCase(node.getNodeName())) {
                            interactionId = node.getTextContent().trim();
                        }
                    }
                }
            }

        } catch (Exception t) {
            // null best effort.
            logger.warn("Unable to capture interaction id.");
            logger.debug("Exception occured while trying to get the interaction id.", t);
        }
        return interactionId;

    }

    /**
     * @return the enableLogging
     */
    public Boolean getEnableLogging() {
        return enableLogging;
    }

}
