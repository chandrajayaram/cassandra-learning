package com.caiso.soa.framework.quartz;

import java.util.Arrays;
import java.util.concurrent.BlockingQueue;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.util.MultiValueMap;

public class CustomJobListener implements JobListener {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String txId;
    private BlockingQueue<Object> status;
    private MultiValueMap<String, String> params;
    private String jobName;
    private Scheduler scheduler;

    public CustomJobListener(String txId, BlockingQueue<Object> status, MultiValueMap<String, String> params,
            String jobName, Scheduler scheduler) {
        this.txId = txId;
        this.status = status;
        this.params = params;
        this.jobName = jobName;
        this.scheduler = scheduler;
    }

    @Override
    public void jobWasExecuted(JobExecutionContext context, JobExecutionException jobException) {
        if (jobException == null) {
            // indicates that job is successfully processed
            try {
                status.put(Boolean.TRUE);
            } catch (InterruptedException e) {
                logger.error("Unable to add the exception to queue to indicate job have been completed successfully.",
                        e);
                Thread.currentThread().interrupt();
            }
        } else {
            // add exception to the status to indicate that job
            // failed to process
            try {
                status.put(jobException);
            } catch (InterruptedException e) {
                logger.error("Unable to add the exception to queue to indicate a job failure.", e);
                Thread.currentThread().interrupt();
            }
        }
        try {
            if (scheduler != null) {
                boolean jobStatus = scheduler.getListenerManager().removeJobListener(getName());
                logger.info("{} removed the manual job listener.", jobStatus ? "Successfully" : "Unsuccessfully");
            }
        } catch (SchedulerException e) {
            logger.warn("Unable to remove the manual job listener.", e);
        }
        MDC.remove("txid");
    }

    @Override
    public void jobToBeExecuted(JobExecutionContext context) {
        // add the params to the map so it can forward to the
        // class that implements the job.
        if (params != null && !params.isEmpty()) {
            // put txid into the context so we can use it after the job have
            // been executed.
            context.put("txid", txId);
            MDC.put("txid", txId);
            JobDataMap dataMap = context.getJobDetail().getJobDataMap();
            for (String key : params.keySet()) {
                if (params.get(key) != null && !params.get(key).isEmpty()) {

                    if (params.get(key).size() == 1) {
                        logger.info("Adding param {}={} to the quartz job map.", key, params.get(key).get(0));
                        dataMap.put(key, params.get(key).get(0));
                    } else {
                        logger.info("Adding param {}={} to the quartz job map.", key,
                                Arrays.toString(params.get(key).toArray()));
                        dataMap.put(key, params.get(key));
                    }
                }
            }
            // set params to null so the next job won't get get pick up by this.
            params = null;
        }

    }

    @Override
    public void jobExecutionVetoed(JobExecutionContext context) {
        // NULL

    }

    @Override
    public String getName() {
        return jobName + txId;
    }

}
