package com.caiso.soa.framework.domain;

import java.util.List;

public class BaseAdditionalJob {

    private String url;
    private List<String> example;

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url
     *            the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * @return the example
     */
    public List<String> getExample() {
        return example;
    }

    /**
     * @param example
     *            the example to set
     */
    public void setExample(List<String> example) {
        this.example = example;
    }

}
