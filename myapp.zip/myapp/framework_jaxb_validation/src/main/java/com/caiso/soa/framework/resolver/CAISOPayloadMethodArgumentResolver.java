package com.caiso.soa.framework.resolver;

import com.caiso.mrtu.soa.schemas._2005._09.attachmenthash.AttachmentHash;
import com.caiso.soa._2006_06_13.standardattachmentinfor.StandardAttachmentInfor;
import com.caiso.soa._2006_09_30.caisowsheader.CAISOWSHeaderType;
import com.caiso.soa._2006_10_26.isoattachment.ISOAttachment;
import com.caiso.soa.framework.payload.DomainPayload;
import com.caiso.soa.framework.payload.RawPayload;
import com.caiso.soa.framework.utils.CAISOUtils;
import com.caiso.soa.framework.utils.SOAPUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.MethodParameter;
import org.springframework.util.Assert;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.mime.Attachment;
import org.springframework.ws.server.endpoint.adapter.method.MethodArgumentResolver;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.SOAPException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

/**
 * <p>
 * Implementation of
 * {@link org.springframework.ws.server.endpoint.adapter.method.MethodArgumentResolver
 * MethodArgumentResolver} that supports resolving
 * {@link com.caiso.soa.framework.payload.RawPayload RawPayload} or
 * {@link com.caiso.soa.framework.payload.DomainPayload DomainPayload}
 * parameters. It is not recommended to use the
 * {@link com.caiso.soa.framework.payload.RawPayload RawPayload}.
 * </p>
 * The following snippet shows an example of supported declarations.
 * 
 * <pre>
 * <code>
 * &#64;SoapAction("http://www.caiso.com/soa/receiveALFSActuals_v2")
 * &#64;ResponsePayload
 * public OutputDataType receiveALFSActuals_v2(@RequestPayload MeterMeasurementsWrapper elem) {
 * 
 * }
 * </code>
 * </pre>
 * 
 * @author tta
 */
public class CAISOPayloadMethodArgumentResolver implements MethodArgumentResolver {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Supporting either raw payload or domain payload.
     */
    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        Class<?> parameterType = parameter.getParameterType();
        return RawPayload.class.equals(parameterType) || DomainPayload.class.isAssignableFrom(parameterType);

    }

    @Override
    public Object resolveArgument(MessageContext messageContext, MethodParameter parameter) throws SOAPException {
        Assert.isInstanceOf(SoapMessage.class, messageContext.getRequest());
        // output stream that contains the payload.
        ByteArrayOutputStream os;

        SoapMessage request = (SoapMessage) messageContext.getRequest();
        StandardAttachmentInfor headerInfo = getHeaderInfor(request);
        CAISOWSHeaderType caisoWSHeader = getCAISOWSHeader(request);

        // if there is a mime attachment then we are assumed that it is caiso
        // doc attachment and try to extract it.
        if (request.getAttachments().hasNext()) {
            logger.debug("Message has attachment.  Validating attachment with hash code..");
            Attachment attachment = request.getAttachments().next();
            os = extractPayload(request, attachment);
        } else {
            // there is no attachment and the header info is null which mean
            // that this is an inline message.
            // do we have the doc attachment?
            SoapBody soapBody = request.getSoapBody();
            DOMSource domSource = (DOMSource) soapBody.getPayloadSource();
            if ("ISOAttachment".equalsIgnoreCase(domSource.getNode().getLocalName())) {
                // doc attachment.
                try {
                    ISOAttachment attachment = (ISOAttachment) SOAPUtils.unmarshal(ISOAttachment.class.getPackage().getName(), domSource);
                    String values = attachment.getAttachmentValue();
                    os = CAISOUtils.decompressBase64(values.getBytes(StandardCharsets.UTF_8));
                } catch (Exception e) {
                    throw new SOAPException("Unable to extract payload from the message.", e);
                }
            } else {
                os = new ByteArrayOutputStream();
                StreamResult bodyResult = new StreamResult(os);

                try {
                    TransformerFactory.newInstance().newTransformer().transform(soapBody.getPayloadSource(), bodyResult);
                } catch (Exception e) {
                    throw new SOAPException("Unable to extract payload from the message.", e);
                }

            }

        }
        // log the payload as debug for those who interested in the payload.
        // We are not using the slf4j syntax since we have to convert the output
        // stream into string so instead we are checking the log level
        // explicitly so we are not wasting resource converting the output
        // stream into string.
        if (logger.isDebugEnabled()) {
            logger.debug("Payload \n" + new String(os.toByteArray(), StandardCharsets.UTF_8));
        }

        Class<?> parameterType = parameter.getParameterType();
        // check to see which type of object are we supposed to return
        if (DomainPayload.class.isAssignableFrom(parameterType)) {
            try {
                @SuppressWarnings("unchecked")
                DomainPayload<Object> payload = (DomainPayload<Object>) parameterType.newInstance();

                Object payloadObject = null;
                boolean payloadValid = true;
                try {
                    payloadObject = payload.customUnMarshaller(os);
                    logger.info("Custom marshaller is provided to process the payload.");
                    if (payloadObject == null) {
                        logger.info("Custom marshaller returns null, indicating that the payload is not of interest.");
                    }
                } catch (UnsupportedOperationException e) {
                    logger.trace("An exception occured while trying to get custom marshaller.", e);
                    logger.debug("There is no custom marshaller defined.");
                    // no custom marshaller is implemented.
                    // trying to get the package for the domain object so we can
                    // serialize it.
                    Type mySuperclass = payload.getClass().getGenericSuperclass();
                    Type tType = ((ParameterizedType) mySuperclass).getActualTypeArguments()[0];
                    // we can't just extract the package name from Type so we
                    // are using regex to remove the class from fully qualified
                    // class name.
                    // String fullyQualifiedClassName = tType.getTypeName();
                    // not fun with java 7. Use above for java 8.
                    String fullyQualifiedClassName = tType.toString().split(" ")[1];
                    String packageName = fullyQualifiedClassName.replaceAll("\\.[^.]*$", "");
                    // caching the jaxb context so we can re-use it instead of
                    // init it every time.
                    logger.debug("Listener is interested in domain object {} from received message.", fullyQualifiedClassName);

                    try {

                        // if it is unmarshalled successfully, we can call the
                        // validation method. it is backward but we don't know
                        // whether the request is rpc style or not so we are
                        // using the unmarhsalled first.
                        if (payload.isValidationRequired()) {
                            logger.info("Domain object indicate validation is required.");
                            payloadValid = payload.validate(new String(os.toByteArray(), StandardCharsets.UTF_8));
                            logger.info("he  payload is {}", payloadValid);
                        }

                        payloadObject = SOAPUtils.unmarshal(packageName, new StreamSource(new ByteArrayInputStream(os.toByteArray())));

                    } catch (Exception ex) {
                        try {
                            // maybe this is rpc style? if so we are trying to
                            // try
                            // get the request data object
                            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                            docFactory.setNamespaceAware(true);
                            Element node = docFactory.newDocumentBuilder().parse(new ByteArrayInputStream(os.toByteArray())).getDocumentElement();
                            NodeList childNodes = node.getChildNodes();
                            for (int i = 0; i < childNodes.getLength(); i++) {
                                Node child = childNodes.item(i);
                                // check if this is rpc style
                                if (child.getNodeType() == Node.ELEMENT_NODE) {
                                    logger.info("The message is of RPC type.");
                                    // try to find the name space
                                    NodeList dataNodes = child.getChildNodes();
                                    Node messageHeader = null;
                                    Node messagePayload = null;
                                    String namespace = "";
                                    for (int j = 0; j < dataNodes.getLength(); j++) {
                                        Node data = dataNodes.item(j);
                                        if (data.getNodeType() != Node.ELEMENT_NODE) {
                                            continue;
                                        }
                                        // now we got the header
                                        if ("MessageHeader".equalsIgnoreCase(data.getLocalName())) {
                                            messageHeader = data;
                                            namespace = data.getNamespaceURI();
                                        } else if ("MessagePayload".equalsIgnoreCase(data.getLocalName())) {
                                            messagePayload = data;
                                        }
                                    }
                                    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

                                    String elementName = payload.getElementName();
                                    if (elementName == null || elementName.isEmpty()) {
                                        elementName = fullyQualifiedClassName.substring(fullyQualifiedClassName.lastIndexOf(".") + 1).trim();
                                    }

                                    Element elem = doc.createElementNS(namespace, elementName);
                                    elem.appendChild(doc.importNode(messageHeader, true));
                                    elem.appendChild(doc.importNode(messagePayload, true));

                                    Transformer tf = TransformerFactory.newInstance().newTransformer();
                                    tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
                                    tf.setOutputProperty(OutputKeys.INDENT, "no");
                                    Writer out = new StringWriter();
                                    tf.transform(new DOMSource(elem), new StreamResult(out));
                                    String raw = null;
                                    if (payload.isValidationRequired()) {
                                        logger.info("Domain object indicate validation is required.");
                                        raw = out.toString();
                                        payloadValid = payload.validate(raw);
                                        logger.info("The  payload is {}", payloadValid);
                                    }

                                    payloadObject = SOAPUtils.unmarshal(packageName,
                                            new StreamSource(new ByteArrayInputStream(out.toString().getBytes(StandardCharsets.UTF_8))));

                                    break;
                                }
                            }
                        } catch (Exception innerException) {
                            // catch exception from this so that the original
                            // exception are being raised.
                            logger.info("Maybe the message is not of RPC type.", innerException);
                        }
                        if (payloadObject == null) {
                            throw ex;
                        }

                    }
                }
                if (!payloadValid) {
                    throw new SOAPException("The Payload is not valid.");
                }
                payload.setDomainObject(payloadObject);
                payload.setHeader(headerInfo);
                payload.setCaisoWSHeader(caisoWSHeader);
                payload.setServiceName(MDC.get("serviceName"));
                payload.setTxId(MDC.get("txid"));
                payload.setInteractionId(MDC.get("interactionId"));
                payload.setPayloadSize(os.size());

                return payload;
            } catch (SOAPException e) {
                throw e;
            } catch (Exception e) {
                logger.error("Unable to marshall payload into the domain object wrapper " + parameterType + "\n"
                        + new String(os.toByteArray(), StandardCharsets.UTF_8), e);

                throw new SOAPException(e.getMessage(), e);
            }

        } else if (RawPayload.class.equals(parameterType)) {
            logger.info("Listener are interested in raw payload from received message..");
            // RawPayload payload = new RawPayload();

            try {
                RawPayload payload = new RawPayload();
                payload.setXml(os);
                payload.setHeader(headerInfo);
                payload.setCaisoWSHeader(caisoWSHeader);
                payload.setServiceName(MDC.get("serviceName"));
                payload.setTxId(MDC.get("txid"));
                payload.setInteractionId(MDC.get("interactionId"));
                payload.setPayloadSize(os.size());

                return payload;
            } catch (Exception e) {
                logger.error("Unable to marshall payload into the domain object wrapper " + parameterType + "\n"
                        + new String(os.toByteArray(), StandardCharsets.UTF_8), e);

                throw new SOAPException(e.getMessage(), e);
            }

        }

        // should not happen
        throw new UnsupportedOperationException();
    }

    /**
     * Helper method that extract the payload content from the attachment by
     * verify that the hash code in the header matches the hash code of the
     * attachment.
     * 
     * @param request
     * @param attachment
     * @return
     * @throws SOAPException
     * @throws JAXBException
     */
    private ByteArrayOutputStream extractPayload(SoapMessage request, Attachment attachment) throws SOAPException {
        ByteArrayOutputStream os;
        // get hash value to ensure that the file match

        SoapHeaderElement attachmentHashElem = null;
        Iterator<SoapHeaderElement> headerItr = request.getSoapHeader().examineAllHeaderElements();

        while (headerItr.hasNext()) {
            SoapHeaderElement elem = headerItr.next();
            if ("attachmentHash".equalsIgnoreCase(elem.getName().getLocalPart())) {
                attachmentHashElem = elem;
                break;
            }
        }
        if (attachmentHashElem != null) {
            // TODO Tuan P3, add hook to allow adapter to extract the attachment
            // hash value if there are different name space.
            String attachmentHashPackage = AttachmentHash.class.getPackage().getName();
            String hashValue = null;
            try {
                AttachmentHash attachmentHash = (AttachmentHash) SOAPUtils.unmarshal(attachmentHashPackage, attachmentHashElem.getSource());

                hashValue = attachmentHash.getHashValue();
                if (hashValue != null) {
                    hashValue = hashValue.trim();
                }

            } catch (Exception e) {
                logger.error("AttachmentHash is not wellformed.", e);
                throw new SOAPException("AttachmentHash is not wellformed.", e);
            }
            // get the attachment into byte array so we can compare the hash
            // value to ensure that it is matching the hash value in the
            // header
            try (InputStream attachmentInputStream = attachment.getInputStream()) {
                byte[] attachmentByteArray = new byte[attachmentInputStream.available()];
                int numberOfBytes = attachmentInputStream.read(attachmentByteArray);
                if (numberOfBytes != attachmentByteArray.length) {
                    throw new SOAPException("Unable to read all bytes from the attachment.");
                }
                String attachmentHashValue = CAISOUtils.getBas64SHA1Hash(attachmentByteArray);
                if (!attachmentHashValue.equals(hashValue)) {
                    logger.error("The hash code [hashCode={}] does not match the attachment hash value [attachmentHashCode={}].", hashValue,
                            attachmentHashValue);
                    throw new SOAPException("Attachment Hash is not valid, cannot continue!");
                }
                // decompress the message to get the xml.
                try {
                    // TODO Tuan P3 do we need to check header info for values.
                    os = CAISOUtils.decompressBase64(attachmentByteArray);
                } catch (Exception e) {
                    logger.error("Unable to decompress the attachment.", e);
                    throw new SOAPException("Attachment is not valid, cannot continue!", e);
                }
            } catch (SOAPException e) {
                logger.error("An error occured while getting the hash value of the message.");
                throw e;
            } catch (Exception e) {
                logger.error("An error occured while getting the hash value of the message.");
                throw new SOAPException("Attachment Hash is not valid, cannot continue!", e);
            }

        } else {
            logger.error("Message has attachment but no hash code specified.");
            throw new SOAPException("Attachment Hash header property does not exist in message, cannot continue!");
        }
        return os;
    }

    /**
     * Header method to get the StandardAttachmentInfor from the SOAP header.
     * Null be be returned if the header does not contain the standard
     * attachment infor.
     * 
     * @param request
     * @return
     * @throws JAXBException
     */
    private StandardAttachmentInfor getHeaderInfor(SoapMessage request) throws SOAPException {
        StandardAttachmentInfor headerInfo = null;
        // get standard attachment infor
        Iterator<SoapHeaderElement> elementItr = request.getSoapHeader().examineAllHeaderElements();
        SoapHeaderElement stdAttachmentInforElem = null;
        while (elementItr.hasNext()) {
            SoapHeaderElement elem = elementItr.next();
            if ("standardAttachmentInfor".equalsIgnoreCase(elem.getName().getLocalPart())) {
                stdAttachmentInforElem = elem;
                break;
            }
        }
        try {
            if (stdAttachmentInforElem != null) {
                // TODO Tuan P3, add hook to allow adapter to extract the
                // std attachment info if there are different name space.
                headerInfo = (StandardAttachmentInfor) SOAPUtils.unmarshal(StandardAttachmentInfor.class.getPackage().getName(),
                        stdAttachmentInforElem.getSource());
            }
        } catch (JAXBException e) {
            throw new SOAPException("Standard Attachment Info is not well formed.", e);
        }
        return headerInfo;
    }

    /**
     * Header method to get the SCAISOWSHeader from the SOAP header. Null be be
     * returned if the header does not contain CAISO WS Header
     * 
     * @param request
     * @return
     * @throws JAXBException
     */
    private CAISOWSHeaderType getCAISOWSHeader(SoapMessage request) throws SOAPException {
        CAISOWSHeaderType caisoWSHeader = null;
        // get standard attachment infor
        Iterator<SoapHeaderElement> elemItr = request.getSoapHeader().examineAllHeaderElements();
        SoapHeaderElement caisoHeaderElem = null;

        while (elemItr.hasNext()) {
            SoapHeaderElement elem = elemItr.next();
            if ("CAISOWSHeader".equalsIgnoreCase(elem.getName().getLocalPart())) {
                caisoHeaderElem = elem;
                break;
            }
        }
        try {
            if (caisoHeaderElem != null) {
                // TODO Tuan P3, add hook to allow adapter to extract the
                // CAISOWSHeaderType if there are different name space.
                caisoWSHeader = (CAISOWSHeaderType) SOAPUtils.unmarshal(CAISOWSHeaderType.class.getPackage().getName(), caisoHeaderElem.getSource());
            }
        } catch (JAXBException e) {
            throw new SOAPException("CAISO WS Header Info is not well formed.", e);
        }
        return caisoWSHeader;
    }

}
