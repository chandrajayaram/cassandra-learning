package com.caiso.soa.framework.domain;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class LogEvent {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private Long id;
    private Date eventTime;
    private EventType eventType;
    private String sourceHost;
    private String serviceName;
    private String transactionId;
    private String interactionId;
    private String comments;
    private String payload;

    /**
     * Default constructor.
     */
    public LogEvent() {
        // Default constructor.
    }

    /**
     * Construction an exception event with provided Throwable where the stack
     * trace will be converted into comment.
     * 
     * @param t
     */
    public LogEvent(Throwable t) {
        this(EventType.PROCESS_EXCEPTION, null);
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        setComments(sw.toString());
    }

    /**
     * Construct an event with provided comment.
     * 
     * @param eventType
     * @param comments
     */
    public LogEvent(EventType eventType, String comments) {
        this.transactionId = MDC.get("txid");
        this.serviceName = MDC.get("serviceName");
        this.interactionId = MDC.get("interactionId");
        if (interactionId == null) {
            interactionId = "unknown";
        }
        this.eventTime = new Date();
        this.eventType = eventType;
        try {
            sourceHost = InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            sourceHost = "unknown";
            logger.debug("Unable to get host name.", e);
        }
        this.comments = comments;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the eventTime
     */
    public Date getEventTime() {
        return eventTime;
    }

    /**
     * @param eventTime
     *            the eventTime to set
     */
    public void setEventTime(Date eventTime) {
        this.eventTime = eventTime;
    }

    /**
     * @return the eventType
     */
    public EventType getEventType() {
        return eventType;
    }

    /**
     * @param eventType
     *            the eventType to set
     */
    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    /**
     * @return the sourceHost
     */
    public String getSourceHost() {
        return sourceHost;
    }

    /**
     * @param sourceHost
     *            the sourceHost to set
     */
    public void setSourceHost(String sourceHost) {
        this.sourceHost = sourceHost;
    }

    /**
     * @return the serviceName
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * @param serviceName
     *            the serviceName to set
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    /**
     * @return the transactionId
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * @param transactionId
     *            the transactionId to set
     */
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    /**
     * @return the interactionId
     */
    public String getInteractionId() {
        return interactionId;
    }

    /**
     * @param interactionId
     *            the interactionId to set
     */
    public void setInteractionId(String interactionId) {
        this.interactionId = interactionId;
    }

    /**
     * @return the comments
     */
    public String getComments() {

        if (comments != null && comments.length() > 512) {
            return comments.substring(0, 500);
        } else {
            return comments;
        }

    }

    /**
     * @param comments
     *            the comments to set
     */
    public void setComments(String comments) {
        this.comments = comments;
    }

    /**
     * @return the payload
     */
    public String getPayload() {
        return payload;
    }

    /**
     * @param payload
     *            the payload to set
     */
    public void setPayload(String payload) {
        this.payload = payload;
    }

    /**
     * Types of log events.
     */
    public enum EventType {
                           PROCESS_START,
                           PROCESS_REQUEST,
                           PROCESS_SEND,
                           PROCESS_RECEIVE,
                           PROCESS_PUBLISH,
                           PROCESS_COMPLETE,
                           PROCESS_EXCEPTION,
                           PROCESS_INFO,
                           PROCESS_WARNING,
                           PROCESS_ERROR,
                           PROCESS_RETRY;
    }

}
