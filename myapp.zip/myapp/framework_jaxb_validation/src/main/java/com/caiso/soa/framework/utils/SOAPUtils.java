package com.caiso.soa.framework.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.util.JAXBSource;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.xml.transform.StringSource;
import org.xml.sax.SAXException;

import com.caiso.mrtu.soa.schemas._2005._09.attachmenthash.AttachmentHash;
import com.caiso.soa._2006_06_13.standardattachmentinfor.Attachment;
import com.caiso.soa._2006_06_13.standardattachmentinfor.CompressFlag;
import com.caiso.soa._2006_06_13.standardattachmentinfor.StandardAttachmentInfor;
import com.caiso.soa._2006_10_26.isoattachment.ISOAttachment;

public class SOAPUtils {

	private static Logger logger = LoggerFactory.getLogger(SOAPUtils.class);
	// Format the the body of the mime attachment
	private static final String MIME_ATTACHMENT_BODY = "<%s xmlns=\"%s\"><%s_attachment href=\"cid:%s\" /></%s>";
	// jaxb context so we don't have to do lookup.
	private static ConcurrentMap<String, JAXBContext> jaxbContexts = new ConcurrentHashMap<>();


	private SOAPUtils() {
		// NULL
	}

	/**
	 * Helper method that marshall data into xml stream.
	 * 
	 * @param data
	 * @return
	 * @throws JAXBException
	 */
	public static ByteArrayOutputStream marshal(Object data) throws JAXBException {
		return marshal(data, false);
	}

	public static ByteArrayOutputStream marshal(Object data, boolean ignoreDeclaration) throws JAXBException {
		// normally we don't have to replace the ".impl" with empty string but
		// we need this here to
		// handle the weird way the service jar generated the xml elements.
		if (data == null) {
			return new ByteArrayOutputStream(0);
		}
		
		JAXBContext jaxbContext = getJaxbContext(data);
		
		Marshaller marshaller = jaxbContext.createMarshaller();

		if (ignoreDeclaration) {
			if (marshaller.getClass().getCanonicalName().contains("v2")) {
				marshaller.setProperty("jaxb.fragment", Boolean.TRUE);
			} else {
				marshaller.setProperty("com.sun.xml.bind.xmlDeclaration", Boolean.FALSE);
			}

		}
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		marshaller.marshal(data, os);
		return os;
	}

	public static Marshaller getMarshaller(Object data) throws JAXBException {
		JAXBContext jaxbContext = getJaxbContext(data);
		return jaxbContext.createMarshaller();

	}

	public static Object unmarshal(String packageName, Source source) throws JAXBException {
		JAXBContext jaxbContext = getJaxbContext(packageName);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		Object object = unmarshaller.unmarshal(source);
		if (object instanceof JAXBElement) {
			object = ((JAXBElement<?>) object).getValue();
		}
		return object;
	}

	public static Object unmarshal(String packageName, String xml) throws JAXBException {
		JAXBContext jaxbContext = getJaxbContext(packageName);
		
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		Object object = unmarshaller.unmarshal(new StringSource(xml));
		if (object instanceof JAXBElement) {
			object = ((JAXBElement<?>) object).getValue();
		}
		return object;
	}

	public static ByteArrayOutputStream getPayloadAsDocAttachment(Object data) throws JAXBException, IOException {
		byte[] uncompressedBytes;
		if (data instanceof String) {
			uncompressedBytes = data.toString().getBytes(StandardCharsets.UTF_8);
		} else {
			ByteArrayOutputStream os = marshal(data);
			uncompressedBytes = os.toByteArray();
		}

		ISOAttachment isoAttachment = new ISOAttachment();
		isoAttachment
				.setAttachmentValue(new String(CAISOUtils.compressBase64(uncompressedBytes), StandardCharsets.UTF_8));
		// marshall the ISO attachment data type so we can publish
		return marshal(isoAttachment);
	}

	/**
	 * Helper method to add the provided data into the mime attachment for the
	 * message.
	 * 
	 * @param message
	 * @param data
	 * @param serviceName
	 * @param attachmentName
	 * @param serviceNS
	 * @throws IOException
	 * @throws TransformerException
	 * @throws JAXBException
	 * @throws NoSuchAlgorithmException
	 */
	public static void addMimeAttachmentToMessage(WebServiceMessage message, Object data, String serviceName,
			String attachmentName, String serviceNS)
			throws IOException, TransformerException, JAXBException, NoSuchAlgorithmException {
		byte[] uncompressedBytes;
		// if string type it is already in xml.

		if (data instanceof String) {
			uncompressedBytes = data.toString().getBytes(StandardCharsets.UTF_8);
		} else {
			ByteArrayOutputStream os = marshal(data);
			uncompressedBytes = os.toByteArray();
		}

		byte[] compressedBytes = CAISOUtils.compressBase64(uncompressedBytes);
		String hashValue = CAISOUtils.getBas64SHA1Hash(compressedBytes);

		SoapMessage soapMessage = (SoapMessage) message;
		// add attachment and the attachment header
		String transactionId = MDC.get("txid");
		if (transactionId == null) {
			transactionId = UUID.randomUUID().toString();
		}
		String fileName = "txid-" + transactionId;
		soapMessage.addAttachment(fileName, new ByteArrayResource(compressedBytes), "application/octetstream");
		// custom CAISO header
		addAttachmentHashToHeader(hashValue, soapMessage);
		addAttachmentInforToHeader(soapMessage);
		// modify the body
		SoapBody soapBody = soapMessage.getSoapBody();

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();

		String serviceInfor = attachmentName;
		if (serviceInfor == null) {
			serviceInfor = serviceName.replace("broadcast", "");
			if (serviceInfor.contains("_")) {
				serviceInfor = serviceInfor.substring(0, serviceInfor.indexOf("_"));
			}
		}

		String body = String.format(MIME_ATTACHMENT_BODY, serviceName, serviceNS, serviceInfor, fileName, serviceName);
		StringSource s = new StringSource(body);
		transformer.transform(s, soapBody.getPayloadResult());
		// guarding log since this is used for testing only
		if (logger.isDebugEnabled()) {
			logger.debug(new String(compressedBytes, StandardCharsets.UTF_8));
		}
	}

	/**
	 * Helper method that add the hash value to the header of the message.
	 * 
	 * @param jobData
	 * @param hashValue
	 * @param soapMessage
	 * @throws TransformerException
	 */
	public static void addAttachmentHashToHeader(String hashValue, SoapMessage soapMessage)
			throws TransformerException {
		AttachmentHash attachmentHash = new AttachmentHash();
		attachmentHash.setHashValue(hashValue);
		try {
			ByteArrayOutputStream os = marshal(attachmentHash);
			TransformerFactory.newInstance().newTransformer().transform(
					new StreamSource(new ByteArrayInputStream(os.toByteArray())),
					soapMessage.getSoapHeader().getResult());

			SoapHeaderElement attachmentQName = soapMessage.getSoapHeader()
					.examineHeaderElements(
							new QName("http://www.caiso.com/mrtu/soa/schemas/2005/09/attachmenthash", "attachmentHash"))
					.next();
			attachmentQName.setMustUnderstand(false);
			attachmentQName.setActorOrRole("http://schemas.xmlsoap.org/soap/actor/next");
		} catch (Exception e) {
			throw new TransformerException(e.getMessage(), e);
		}

	}

	/**
	 * Helper method that add the StandardAttachmentInfor to the header of the
	 * message.
	 * 
	 * @param soapMessage
	 * @throws TransformerException
	 */
	public static void addAttachmentInforToHeader(SoapMessage soapMessage) throws TransformerException {
		StandardAttachmentInfor stdInfo = new StandardAttachmentInfor();
		Attachment attachment = new Attachment();
		attachment.setId("1");
		attachment.setCompressFlag(CompressFlag.YES);
		attachment.setCompressMethod("gzip");
		stdInfo.getAttachment().add(attachment);

		try {
			// generate the output data type based
			// on the exception.
			ByteArrayOutputStream os = marshal(stdInfo);
			// add the output data type into the
			// fault detail.
			TransformerFactory.newInstance().newTransformer().transform(
					new StreamSource(new ByteArrayInputStream(os.toByteArray())),
					soapMessage.getSoapHeader().getResult());

		} catch (Exception t) {
			throw new TransformerException(t.getMessage(), t);
		}
	}

	public static XMLGregorianCalendar convert(Date date) throws DatatypeConfigurationException {
		GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
		cal.setTime(date);
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
	}

	public static XMLGregorianCalendar convert(Calendar date) throws DatatypeConfigurationException {
		GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
		cal.setTime(date.getTime());
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
	}

	public static XMLGregorianCalendar currentTime() throws DatatypeConfigurationException {
		GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
		cal.setTime(new Date());
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
	}


	public static void validateJaxbData(Validator validator, Object data) throws SAXException, JAXBException, IOException {
		Source source = null;
		if (data instanceof String) {
        	StringReader reader = new StringReader((String) data);
            source = new StreamSource(reader);
        } else {
             source = new JAXBSource(getJaxbContext(data), data);
        }
        validator.validate(source);
	}
	private static JAXBContext getJaxbContext(String packageName) throws JAXBException{
		JAXBContext jaxbContext = jaxbContexts.get(packageName);

		if (jaxbContext == null) {
			jaxbContext = JAXBContext.newInstance(packageName);
			jaxbContexts.put(packageName, jaxbContext);
		}
		return jaxbContext;
	}
	private static JAXBContext getJaxbContext(Object data) throws JAXBException{
		String packageName = data.getClass().getPackage().getName().replace(".impl", "");
		return getJaxbContext(packageName);
	}
	
	
}
