package com.caiso.soa.framework.quartz;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.matchers.GroupMatcher;
import org.quartz.impl.matchers.KeyMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.security.crypto.codec.Hex;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.caiso.soa.framework.domain.AdditionalJobs;
import com.caiso.soa.framework.domain.BaseAdditionalJob;
import com.caiso.soa.framework.domain.SchedulingJob;

@RestController
public class QuartzRestController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static UnsupportedOperationException badCodingException = new UnsupportedOperationException(
            "The code should never be executed so please double with developer.");
    private static UnsupportedOperationException invalidCredentialException = new UnsupportedOperationException(
            "userName and password is required in the request header.");
    private static UnsupportedOperationException unableToValidateException = new UnsupportedOperationException(
            "quartzDS datasource is not defined.  Unable to validate user.");
    private static UnsupportedOperationException badCredentialException = new UnsupportedOperationException(
            "Invalid user name and password.");
    @Autowired
    private SchedulerFactoryBean schedulerBean;

    @Autowired
    AutowireCapableBeanFactory factory;

    private JdbcTemplate jdbcTemplate;

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/")
    public List<SchedulingJob> index() throws SchedulerException {
        List<AdditionalJobs> additionalJobs = new LinkedList<>();
        try {
            Object additionalJobsObject = factory.getBean("additionalQuartzJobs");
            if (additionalJobsObject instanceof List<?>) {
                additionalJobs = (List<AdditionalJobs>) additionalJobsObject;
                logger.info("There are {} additional jobs found.", additionalJobs.size());
            } else {
                logger.error(
                        "The bean additionalQuartzJobs is not of List<AdditionalJobs> type.  Ignore additional job.");
            }
        } catch (Exception e) {
            // best effort.
            logger.info("There are not additional jobs defined.");
            logger.debug("Exception trying to get addtional quartz job.", e);
        }
        Scheduler scheduler = schedulerBean.getScheduler();
        Set<JobKey> allJobs = scheduler.getJobKeys(GroupMatcher.anyJobGroup());
        List<SchedulingJob> jobs = new LinkedList<>();
        for (JobKey job : allJobs) {
            SchedulingJob schedulingJob = new SchedulingJob(job.getName());
            for (AdditionalJobs additionalJob : additionalJobs) {
                if (job.getName().equalsIgnoreCase(additionalJob.getName())) {
                    BaseAdditionalJob aj = new BaseAdditionalJob();
                    aj.setExample(additionalJob.getExample());
                    aj.setUrl(additionalJob.getUrl());
                    schedulingJob.getCustom().add(aj);
                }
            }
            // If not custom url is defined, then we set the custom list to be
            // null so that it would not be rendered by the json.
            // This makes it easier for the user to see.
            if (schedulingJob.getCustom().isEmpty()) {
                schedulingJob.setCustom(null);
            }
            jobs.add(schedulingJob);
        }
        Collections.sort(jobs);
        return jobs;
    }

    @RequestMapping(value = "/{jobName}")
    public String executeJob(@PathVariable final String jobName,
            @RequestParam final MultiValueMap<String, String> params, @RequestHeader String userName,
            @RequestHeader String password) throws SchedulerException {
        final String txId = UUID.randomUUID().toString();
        MDC.put("txid", txId);
        MDC.put("serviceName", jobName + "_" + userName);
        try {
            validate(userName, password);
            logger.info("Getting request to schedule {} with from {} with the params: {}.", jobName, userName,
                    params.toString());
            Scheduler scheduler = schedulerBean.getScheduler();
            JobKey jobOfInterest = getJobOfInterest(jobName, scheduler);
            // this blocking queue is used to wait until we got the status back
            // from the job that was kicked off by the scheduler. It is an
            // asynch call so we can't just get the status.
            final BlockingQueue<Object> status = new LinkedBlockingQueue<>();
            // add listener to listen for the status of the job and add status
            // to the blocking queue.
            scheduler.getListenerManager().addJobListener(
                    new CustomJobListener(txId, status, params, jobName, scheduler),
                    KeyMatcher.keyEquals(jobOfInterest));

            // tell the scheduler to schedule the job.
            scheduler.triggerJob(jobOfInterest);
            // checking for the run status by retrieving the status from
            // blocking queue. Don't want to wait more than 60 seconds since
            // most job should not take more than 60 seconds.
            Object runStatus = null;
            try {
                logger.info("Waiting for job job status.");
                runStatus = status.poll(60, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                logger.error("Unable to get the job status.", e);
                Thread.currentThread().interrupt();
            }
            if (runStatus == null) {
                return "Unable to get the job status after waiting 60 seconds.  Please see the log file for additional detail.";
            } else if (runStatus instanceof Boolean) {
                return jobName + " is successfully processed.";
            } else if (runStatus instanceof Exception) {
                logger.error("Failed to process " + jobName, runStatus);
                return jobName + " failed to process. See the log file for additional detail. \n"
                        + ((Exception) runStatus).getMessage();
            } else {
                logger.error("Invalid job name provided: " + jobName);
                throw badCodingException;
            }

        } finally {
            MDC.remove("txid");
            MDC.remove("serviceName");
        }
    }

    private JobKey getJobOfInterest(final String jobName, Scheduler scheduler) throws SchedulerException {
        Set<JobKey> allJobs = scheduler.getJobKeys(GroupMatcher.anyJobGroup());
        JobKey jobOfInterest = null;
        for (JobKey job : allJobs) {
            if (job.getName().equals(jobName)) {
                jobOfInterest = job;
                break;
            }
        }
        if (jobOfInterest == null) {
            throw new UnsupportedOperationException("Unable to find " + jobName);
        }
        return jobOfInterest;
    }

    /**
     * Helper method that validate the user name + password against the db.
     * 
     * @param username
     * @param password
     */
    private void validate(String username, String password) {
        if (username == null || password == null) {
            throw invalidCredentialException;
        }
        try {
            byte[] array = MessageDigest.getInstance("MD5").digest(password.getBytes(StandardCharsets.UTF_8));
            String hashedPassword = new String(Hex.encode(array));
            Object dataSource = factory.getBean("quartzDS");
            if (dataSource == null) {
                throw unableToValidateException;
            }
            if (jdbcTemplate == null) {
                jdbcTemplate = new JdbcTemplate();
                jdbcTemplate.setDataSource((DataSource) dataSource);
            }
            SqlRowSet result = jdbcTemplate.queryForRowSet(
                    "SELECT * FROM REST_CONTROL_USER WHERE USER_NAME = ? and upper(PASSWORD) = ?", username,
                    hashedPassword.toUpperCase());
            if (!result.next()) {
                throw badCredentialException;
            }
        } catch (NoSuchAlgorithmException e) {
            logger.error("Unable to check user name and password.", e);
            throw new UnsupportedOperationException("Unable to validate user name and password.", e);
        }
    }

    /**
     * This here is to primary support the unit test. It is a bad practive but
     * we don't want to introduce mock database.
     * 
     * @param template
     */
    public void setJdbcTemplate(JdbcTemplate template) {
        this.jdbcTemplate = template;
    }
}
