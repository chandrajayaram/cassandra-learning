package com.caiso.soa.framework.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.soa.framework.domain.LogEvent;

@Repository
public class ProcessLogEventDAO {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final String INSERT = "INSERT INTO SOA_PROCESS_EVENT(ID,EVENT_TIME,EVENT_TYPE, SOURCE_HOST, SERVICE_NAME, TRANSACTIONID, INTERACTIONID, COMMENTS) VALUES (SOA_PROCESS_EVENT_SQ.nextval,?,?,?,?,?,?, ?)";
    private static final String DELETE_OLD_DATA = "DELETE FROM SOA_PROCESS_EVENT WHERE EVENT_TIME < ?";

    @Autowired
    @Qualifier("logEventJdbcTemplate")
    private JdbcTemplate template;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public boolean insert(final LogEvent event) {
        try {
            template.update(INSERT, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setTimestamp(1, new Timestamp(event.getEventTime().getTime()));
                    ps.setObject(2, event.getEventType().toString());
                    ps.setObject(3, event.getSourceHost());
                    ps.setObject(4, event.getServiceName());
                    ps.setObject(5, event.getTransactionId());
                    ps.setObject(6, event.getInteractionId());
                    ps.setObject(7, event.getComments());
                }

            });
            return true;
        } catch (Exception t) {
            // BEST effort
            logger.warn("Unable to insert event into SOA_PROCESS_EVENT table.", t);
        }
        return false;
    }

    /**
     * Default clean up data that is more than 30 days.
     * 
     * @return
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public int cleanupOldData() {
        return cleanupOldData(30);
    }

    /**
     * Clean up date that is older than the provided days
     * 
     * @param days
     * @return
     */

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public int cleanupOldData(int days) {
        logger.info("Cleaning up data in the log event table that is more than {} days old", days);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, (-1) * days);
        return template.update(DELETE_OLD_DATA, new Timestamp(cal.getTimeInMillis()));
    }
}
