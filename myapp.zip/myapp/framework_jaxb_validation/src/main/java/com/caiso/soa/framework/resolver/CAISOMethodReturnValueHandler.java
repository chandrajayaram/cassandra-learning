package com.caiso.soa.framework.resolver;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;

import javax.xml.bind.JAXBException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.core.MethodParameter;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.adapter.method.MethodReturnValueHandler;
import org.springframework.ws.soap.SoapBodyException;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.server.endpoint.annotation.SoapAction;
import org.springframework.xml.transform.StringSource;

import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;
import com.caiso.soa.framework.configuration.ResponseType;
import com.caiso.soa.framework.quartz.BroadcastType;
import com.caiso.soa.framework.utils.CAISOUtils;
import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.standardoutput_v1.StandardOutput;

/**
 * The resolver that intercept the return type defined by the end point and
 * modify the header and body of the response message to fit CAISO stand
 * specification.
 * </p>
 * The following snippet shows an example of supported declarations.
 * 
 * <pre>
 * <code>
 * &#64;SoapAction("http://www.caiso.com/soa/retrieveVERMeasurements_v1_DocAttach")
 * &#64;ResponsePayload
 * &#64;ResponseType(msgType = BroadcastType.DOC_ATTACHMENT)
  *public MeterMeasurements retrieveVERMeasurements_v1_DocAttach(@RequestPayload RequestVERMeasurementsWrapper elem) {
 * 
 * }
 * </code>
 * </pre>
 * 
 * @author tta
 *
 */
public class CAISOMethodReturnValueHandler implements MethodReturnValueHandler {
    private static UnsupportedOperationException responseTypeIsRequired = new UnsupportedOperationException(
            "@ResponseType is required for broadcast of type MIME_ATTACHMENT.");

    private static UnsupportedOperationException serviceNameAndServiceNSIsRequired = new UnsupportedOperationException(
            "serviceName and serviceNS is required for response type of MIME_ATTACHMENT..  Update the @ResponseType annotation to include the serviceName and seviceNS.");

    private static UnsupportedOperationException unsupportedMessageType = new UnsupportedOperationException(
            "Message type defined is not supported.");

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AutowireCapableBeanFactory factory;

    /**
     * Checking for the return type to supported by this resolver. This
     * currently supports by all return types except the OutputDataType. The
     * OutputDataType is the standard ACK that response to the receives payload
     * and will handled by the default XML resolvers since the OutputDataType is
     * the standard jaxb element.
     */
    @Override
    public boolean supportsReturnType(MethodParameter returnType) {
        // accepts all return types, where there is an ResponseType annotation
        // is defined.
        Class<?> parameterType = returnType.getParameterType();

        ResponseType responseTypeAnnotation = returnType.getMethod().getAnnotation(ResponseType.class);
        if (responseTypeAnnotation != null || Boolean.class.equals(parameterType)) {
            return true;
        }
        return false;
    }

    /**
     * <p>
     * Any return type of the method will be intercepted here and convert to
     * appropriate return type by inspecting the annotation
     * {@link com.caiso.soa.framework.configuration.ResponseType @ResponseType}
     * and modify the header and body to CAISO standard specification.
     * </p>
     * 
     * @param messageContext
     *            The message context of the request.
     * @param returnType
     *            The return type as specified by the endpoint.
     * @param returnValue
     *            The return value for the endpoint.
     * @throws Exception
     * 
     */
    @Override
    public void handleReturnValue(MessageContext messageContext, MethodParameter returnType, Object returnValue)
            throws Exception {
        Class<?> parameterType = returnType.getParameterType();
        ResponseType responseTypeAnnotation = returnType.getMethod().getAnnotation(ResponseType.class);
        SoapAction soapActionAnnotation = returnType.getMethod().getAnnotation(SoapAction.class);
        String actionName = soapActionAnnotation.value().replaceFirst(".*/([^/?]+).*", "$1");

        if (Boolean.class.equals(parameterType)) {
            // This is the response from the receive. Convert into the standard
            // response method.
            boolean status = (Boolean) returnValue;
            Object responseData;
            Class<?> responseType = OutputDataType.class;
            // guard condition to support case where response type annotation is
            // not defined.
            if (responseTypeAnnotation != null) {
                responseType = responseTypeAnnotation.responseType();
            }
            if (responseType.equals(OutputDataType.class)) {
                if (status) {
                    responseData = CAISOUtils.generateSuccessfullResponse(actionName);
                } else {
                    logger.error("Adapter for {} service indicates failure to process payload.", actionName);
                    responseData = CAISOUtils.generateErrorResponse(actionName);
                }
            } else if (responseType.equals(StandardOutput.class)) {
                String source = null;
                try {
                    Object sourceObject = factory.getBean("AppName");
                    if (sourceObject instanceof String) {
                        source = (String) sourceObject;
                    }
                } catch (Exception e) {
                    logger.info("Unable to get bean [AppName].");
                    logger.debug("Error trying to bet the app name.", e);
                }
                if (source == null) {
                    logger.info(
                            "Bean [AppName] is not define.  The application name is unknown.  Set source in the repsonse message to be null.");
                }
                if (responseTypeAnnotation != null) {
                    responseData = CAISOUtils.generateSuccessStandardOutput(source, actionName,
                            status ? responseTypeAnnotation.successStatus() : responseTypeAnnotation.failStatus());
                } else {
                    responseData = CAISOUtils.generateSuccessStandardOutput(source, actionName,
                            status ? StatusCode.RECEIVE_SERVICE_SUCCESS : StatusCode.RECEIVE_CONNECTOR_FAILURE);
                }
            } else {
                logger.error("The response type {} is not supported.", responseType);
                responseData = "Unable to construct response.";
            }
            inlineResponse(responseData, messageContext);
        } else if (String.class.equals(parameterType) && responseTypeAnnotation != null
                && responseTypeAnnotation.batchIdIsReturned()) {
            // batch id is returned as string

            Object responseData;
            Class<?> responseType = responseTypeAnnotation.responseType();
            if (responseType.equals(OutputDataType.class)) {
                logger.error("The OutputDataType class does not support batch id.");
                responseData = "Unable to construct response.";
            } else if (responseType.equals(StandardOutput.class)) {
                String source = null;
                try {
                    Object sourceObject = factory.getBean("AppName");
                    if (sourceObject instanceof String) {
                        source = (String) sourceObject;
                    }
                } catch (Exception e) {
                    logger.info("Unable to get bean [AppName].");
                    logger.debug("Error trying to bet the app name.", e);
                }
                if (source == null) {
                    logger.info(
                            "Bean [AppName] is not define.  The application name is unknow.  Set source in the repsonse message to be null.");
                }
                responseData = CAISOUtils.generateSuccessStandardOutput(source, actionName, (String) returnValue,
                        responseTypeAnnotation.successStatus());
            } else {
                logger.error("The response type {} is not supported.", responseType);
                responseData = "Unable to construct response.";
            }
            inlineResponse(responseData, messageContext);

        } else {
            // This is the response from retrieve
            BroadcastType broadcastType = BroadcastType.DOC_ATTACHMENT;
            if (responseTypeAnnotation != null) {
                broadcastType = responseTypeAnnotation.msgType();
            } else {
                logger.warn("@ResponseType is not specified, defined to use the default value of {}", broadcastType);
            }

            logger.info("Sending response data type {} as {}.", parameterType, broadcastType);
            switch (broadcastType) {
            case DOC_ATTACHMENT:
                docAttachmentResponse(returnValue, messageContext);
                break;
            case INLINE:
                inlineResponse(returnValue, messageContext);
                break;
            case MIME_ATTACHMENT:
                // mime attachment requireds the service name and service ns
                if (responseTypeAnnotation == null) {
                    throw responseTypeIsRequired;
                }
                String serviceName = responseTypeAnnotation.serviceName();
                String serviceNS = responseTypeAnnotation.serviceNS();
                if (serviceName == null || serviceName.trim().isEmpty() || serviceNS == null
                        || serviceNS.trim().isEmpty()) {
                    logger.error(
                            "serviceName and serviceNS is required for response type of MIME_ATTACHMENT.  Update the @ResponseType annotation to include the serviceName and seviceNS.");
                    throw serviceNameAndServiceNSIsRequired;
                }
                mimeAttachmentResponse(returnValue, messageContext, serviceName, serviceNS);
                break;
            default:
                throw unsupportedMessageType;
            }
        }

    }

    /**
     * Convert to doc attachment response message
     * 
     * @param data
     * @param messageContext
     * @param broadcastType
     * @throws IOException
     * @throws JAXBException
     * @throws TransformerFactoryConfigurationError
     * @throws TransformerException
     * @throws TransformerConfigurationException
     * @throws SoapBodyException
     * @throws Exception
     */
    private void docAttachmentResponse(Object data, MessageContext messageContext) throws JAXBException, IOException,
            SoapBodyException, TransformerException, TransformerFactoryConfigurationError {
        ByteArrayOutputStream os = SOAPUtils.getPayloadAsDocAttachment(data);
        // modify the body
        SoapMessage soapMessage = (SoapMessage) messageContext.getResponse();
        TransformerFactory.newInstance().newTransformer().transform(
                new StreamSource(new ByteArrayInputStream(os.toByteArray())),
                soapMessage.getSoapBody().getPayloadResult());
    }

    /**
     * Convert to inline response message
     * 
     * @param data
     * @param messageContext
     * @throws JAXBException
     * @throws TransformerFactoryConfigurationError
     * @throws TransformerException
     * @throws TransformerConfigurationException
     * @throws SoapBodyException
     * @throws Exception
     */
    private void inlineResponse(Object data, MessageContext messageContext)
            throws JAXBException, SoapBodyException, TransformerException, TransformerFactoryConfigurationError {
        StringSource ss;
        // if string type it is already in xml.
        if (data instanceof String) {
            ss = new StringSource((String) data);
        } else {
            ByteArrayOutputStream os = SOAPUtils.marshal(data);
            ss = new StringSource(new String(os.toByteArray(), StandardCharsets.UTF_8));
        }

        // modify the body
        SoapMessage soapMessage = (SoapMessage) messageContext.getResponse();
        TransformerFactory.newInstance().newTransformer().transform(ss, soapMessage.getSoapBody().getPayloadResult());

    }

    /**
     * Convert to mime attachment response message.
     * 
     * @param data
     * @param messageContext
     * @param serviceName
     * @param serviceNS
     * @throws JAXBException
     * @throws TransformerException
     * @throws IOException
     * @throws NoSuchAlgorithmException
     * @throws Exception
     */
    private void mimeAttachmentResponse(Object data, MessageContext messageContext, String serviceName,
            String serviceNS) throws NoSuchAlgorithmException, IOException, TransformerException, JAXBException {
        WebServiceMessage response = messageContext.getResponse();
        // modify the body, appending respones to the service name to indicate
        // it is a response.
        SOAPUtils.addMimeAttachmentToMessage(response, data, serviceName + "Response", null, serviceNS);
    }

}
