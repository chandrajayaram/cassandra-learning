package com.caiso.soa.framework.resolver;

public enum StatusCode {
                        RECEIVE_SERVICE_SUCCESS("SCSS0001"),
                        RECEIVE_CONNECTOR_FAILURE("FMWK0009"),
                        RETRIEVE_CONNECTOR_FAILURE("FMWK0008");
    private final String description;

    private StatusCode(String description) {
        this.description = description;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

}
