package com.caiso.soa.framework.configuration;

import java.io.File;
import java.io.FileInputStream;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.server.endpoint.adapter.method.MethodArgumentResolver;
import org.springframework.ws.server.endpoint.adapter.method.MethodReturnValueHandler;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.security.wss4j.Wss4jSecurityInterceptor;
import org.springframework.ws.soap.server.endpoint.SimpleSoapExceptionResolver;

import com.caiso.soa.framework.quartz.AutowiringSpringBeanJobFactory;
import com.caiso.soa.framework.resolver.CAISOEndpointInterceptor;
import com.caiso.soa.framework.resolver.CAISOMethodReturnValueHandler;
import com.caiso.soa.framework.resolver.CAISOPayloadMethodArgumentResolver;
import com.caiso.soa.framework.resolver.CAISOSoapExceptionResolver;

/**
 * Default Service configuration for all services that auto configure
 * interceptors for Spring WS.
 * 
 * @author tta
 *
 */
@Configuration
public class CAISOServiceConfiguration extends WsConfigurerAdapter {

    private static RuntimeException invalidQuartzResource = new RuntimeException(
            "quartzProperty bean is not of org.springframework.core.io.Resource type");
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AutowireCapableBeanFactory factory;

    @PostConstruct
    public void loadAuthServicePropertyFile() {
        String propertyLocations = System.getProperty("spring.config.location");
        if (propertyLocations != null) {
            String[] allPropertieFiles = propertyLocations.split(",");
            for (String propertyFile : allPropertieFiles) {
                Properties prop = new Properties();
                try {
                    prop.load(new FileInputStream(new File(propertyFile)));
                    Enumeration<Object> propertyKeys = prop.keys();
                    while (propertyKeys.hasMoreElements()) {
                        Object key = propertyKeys.nextElement();
                        if (key.toString().contains("AuthService") || key.toString().contains("WebAppSec")) {
                            System.getProperties().put(key, prop.get(key));
                        }
                    }
                } catch (Exception e) {
                    throw new UnsupportedOperationException("Unable to read property file " + propertyFile, e);
                }

            }
        }
    }

    @Override
    public void addArgumentResolvers(List<MethodArgumentResolver> argumentResolvers) {
        argumentResolvers.add(new CAISOPayloadMethodArgumentResolver());
        super.addArgumentResolvers(argumentResolvers);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.ws.config.annotation.WsConfigurerAdapter#
     * addReturnValueHandlers(java.util.List)
     */
    @Override
    public void addReturnValueHandlers(List<MethodReturnValueHandler> returnValueHandlers) {
        returnValueHandlers.add(new CAISOMethodReturnValueHandler());
        super.addReturnValueHandlers(returnValueHandlers);
    }

    /**
     * Add interceptor to log txid and service name.
     */
    @Override
    public void addInterceptors(List<EndpointInterceptor> interceptors) {

        // adding intercepter to add the tx id and service name to logging.
        interceptors.add(new CAISOEndpointInterceptor(factory));

        // always understand the security header since it is marked as
        // understand but the Proxy, ESB, AI already take care of security prior
        // getting to use.
        interceptors.add(new Wss4jSecurityInterceptor() {
            /*
             * (non-Javadoc)
             *
             * @see org.springframework.ws.soap.security.
             * AbstractWsSecurityInterceptor#understands(org.springframework.ws.
             * soap.SoapHeaderElement)
             */
            @Override
            public boolean understands(SoapHeaderElement headerElement) {
                return true;
            }

        });
    }

    @Bean
    public WebServiceTemplate webServiceTemplate() {
        return new WebServiceTemplate();
    }

    /**
     * Custom Resolver to convert exception into standard CAISO SOAP response
     * message.
     * 
     * @return
     */
    @Bean
    public SimpleSoapExceptionResolver simpleSoapExceptionResolver() {
        return new CAISOSoapExceptionResolver();
    }

    /**
     * Allow auto-wire other beans into quart job if the quartzDS data source is
     * defined.
     * 
     * @return
     */
    @Bean
    public SchedulerFactoryBean quartzScheduler(ApplicationContext applicationContext) {

        Object quartzDS = null;
        try {
            quartzDS = applicationContext.getBean("quartzDS");
        } catch (Exception t) {
            // NULL check to see if bean is defined.
            logger.debug("QuartzDS bean is not defined, there is no need to start quartz job.", t);
        }
        Object quartzProperty = null;
        try {
            quartzProperty = applicationContext.getBean("quartzProperty");
        } catch (Exception e) {
            // NULL Check to see if bean is defined.
            logger.debug("No custom quartz property is defined.", e);
        }
        Resource quartzPropertyResource = quartzProperty();
        if (quartzProperty != null) {
            if (!Resource.class.isAssignableFrom(quartzProperty.getClass())) {
                throw invalidQuartzResource;
            }
            quartzPropertyResource = (Resource) quartzProperty;
        }

        SchedulerFactoryBean quartzScheduler = new SchedulerFactoryBean();
        if (quartzDS != null) {
            AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
            jobFactory.setApplicationContext(applicationContext);
            quartzScheduler.setJobFactory(jobFactory);

            quartzScheduler.setConfigLocation(quartzPropertyResource);
            quartzScheduler.setDataSource((DataSource) quartzDS);
            try {
                Object autoStartQuartz = applicationContext.getBean("quartzAutoStart");
                boolean autoStart = (boolean) autoStartQuartz;
                if (autoStart) {
                    logger.info("Quartz job is being enabled");
                } else {
                    quartzScheduler.setAutoStartup(false);
                    logger.info("Quartz job is being disabled.");
                }

            } catch (Exception e) {
                // NULL since default to auto start.
                logger.info("Quartz job is being enabled.", e);

            }

        } else {
            quartzScheduler.setAutoStartup(false);
            logger.info("Quartz job is being disabled.");
        }
        return quartzScheduler;
    }

    /**
     * The resource that defines quartz behavior.
     * 
     * @return
     */
    public final Resource quartzProperty() {
        return new ClassPathResource("caiso_default_quartz.properties");
    }

    /**
     * The data source bean name for quartz. If null is returned, quartz job
     * will be disabled.
     * 
     * @return
     */
    public String quartzDataSourcBeanName() {
        return null;
    }

}
