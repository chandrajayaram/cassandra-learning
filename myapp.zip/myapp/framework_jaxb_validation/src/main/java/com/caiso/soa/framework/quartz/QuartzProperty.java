package com.caiso.soa.framework.quartz;

public enum QuartzProperty {
                            URI("uri"),
                            BROADCAST_TYPE("broadcastType"),
                            RETRY("retry"),
                            RETRY_INTERVAL("retryInterval"),
                            SOAP_ACTION("soapAction"),
                            ATTACHMENT_NAME("attachmentName"),
                            SERVICE_NAME("serviceName"),
                            VALIDTA_AGAINST_SCHEMA("validateAgainstSchema"),
                            SCHEMA_FILE("schemaFile");
	

    private String val;

    private QuartzProperty(String val) {
        this.val = val;
    }

    /**
     * @return the val
     */
    public String getVal() {
        return val;
    }

    /**
     * @param val
     *            the val to set
     */
    public void setVal(String val) {
        this.val = val;
    }

}
