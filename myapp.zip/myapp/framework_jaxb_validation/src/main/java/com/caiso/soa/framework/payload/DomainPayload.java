package com.caiso.soa.framework.payload;

import java.io.ByteArrayOutputStream;

/**
 * <p>
 * This payload is used to received the POJO object that is mapped from the xml
 * payload. Caller can override the {@link #customMarshaller()} if the default
 * marshaller is not desired.
 * </p>
 * 
 * 
 * The following snippet shows this is used in spring-ws
 * 
 * <pre>
 * <code>
 * // This class indicate that it is used to receive the MeterMeasurement POJO
 * public class MeterMeasurementsWrapper extends DomainPayload<MeterMeasurements> {
 * 
 * }
 * 
 * &#64;PayloadRoot(namespace = NAMESPACE_URI + "/receiveALFSActuals_v2", localPart = "receiveALFSActuals_v2")
 * &#64;ResponsePayload
 * public OutputDataType receiveALFSActuals_v2(@RequestPayload MeterMeasurementsWrapper elem) {
 * 	MeterMeasurement payload = elem.getDomainObject();
 * }
 * </code>
 * </pre>
 * 
 * 
 * @author tta
 * 
 * @param <T>
 */
public abstract class DomainPayload<T> extends RawPayload {

    private static UnsupportedOperationException unsupportedException = new UnsupportedOperationException("No custom marshaller");

    private T                                    domainObject;

    /**
     * Hook to allow different implement marshaller than the default. Ideally,
     * return null would indicate that default marshaller will be use.
     * 
     * @param payload
     *            The raw payload.
     * @return The POJO object, null if the payload is not of interest.
     */
    public T customUnMarshaller(ByteArrayOutputStream os) {
        // Ideally we want to return null to indicate that no one is overriding
        // this method. However, null could be a valid return so we are throwing
        // an unsupported exception here to indicate that the method is not
        // being overridden. We are re-use a static exception instead of create
        // a new one every time for performance since it is expensive to create
        // new exception.
        throw unsupportedException;
    }

    /**
     * Hook to allow service to validate individual payload type. Use this in
     * conjunction with the validate method.
     * 
     * @return
     */
    public boolean isValidationRequired() {
        return false;
    }

    /**
     * <p>
     * Hook to allow the service to validate individual payload type. Use this
     * in conjunction with the isValidateionRequired() method.
     * </p>
     * This method is only invoked if the isValidtionRequired returned true.
     * 
     * 
     * @param payload
     * @return True to indicate valid. Otherwise false.
     */
    public boolean validate(String payload) {
        return true;
    }

    /**
     * Hook to allow handling rpc style request. Default element name is of type
     * T unless overrided with this method.
     * 
     * @return
     */
    public String getElementName() {
        return null;
    }

    /**
     * @return the domainObject
     */
    public T getDomainObject() {
        return domainObject;
    }

    /**
     * @param domainObject
     *            the domainObject to set
     */
    public void setDomainObject(T domainObject) {
        this.domainObject = domainObject;
    }

    public boolean isRawAlsoNeeded() {
        return false;
    }

}
