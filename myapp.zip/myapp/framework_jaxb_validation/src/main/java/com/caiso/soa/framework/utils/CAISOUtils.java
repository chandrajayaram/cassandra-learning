package com.caiso.soa.framework.utils;

import com.caiso.soa._2006_06_13.standardoutput.Event;
import com.caiso.soa._2006_06_13.standardoutput.EventLog;
import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;
import com.caiso.soa._2006_06_13.standardoutput.Service;
import com.caiso.soa.framework.resolver.StatusCode;
import com.caiso.soa.standardoutput_v1.Batch;
import com.caiso.soa.standardoutput_v1.MessageHeader;
import com.caiso.soa.standardoutput_v1.MessagePayload;
import com.caiso.soa.standardoutput_v1.StandardOutput;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.UUID;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class CAISOUtils {
    private static final String STANDARD_OUTPUT_VER_V20160301 = "v20160301";
    private static Logger      logger         = LoggerFactory.getLogger(CAISOUtils.class);
    public static final String SEVERITY_ERROR = "ERROR";
    public static final String SEVERITY_FATAL = "FATAL";
    public static final String SEVERITY_INFO  = "INFO";
    public static final String SEVERITY_WARN  = "WARN";

    private CAISOUtils() {

    }

    /**
     * This method get the SHA hash of the input stream then encode that in base
     * 64 which should be equals to the hash value provided in the SOAP header.
     * 
     * @param is
     * @return
     * @throws IOException
     * @throws NoSuchAlgorithmException
     */
    public static String getBas64SHA1Hash(byte[] bytes) throws IOException, NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA1");
        md.update(bytes);
        return Base64.encodeBase64String(md.digest());
    }

    /**
     * Method to converted base 64 compressed byte array into the uncompressed
     * string.
     * 
     * @param bytes
     * @return
     * @throws IOException
     */
    public static ByteArrayOutputStream decompressBase64(byte[] bytes) throws IOException {
        byte[] compressedBytes = Base64.decodeBase64(bytes);

        try (GZIPInputStream gzis = new GZIPInputStream(new ByteArrayInputStream(compressedBytes));
                ByteArrayOutputStream uncompressedBytes = new ByteArrayOutputStream();) {
            int len;
            byte[] buffer = new byte[1024];
            while ((len = gzis.read(buffer)) > 0) {
                uncompressedBytes.write(buffer, 0, len);
            }
            return uncompressedBytes;
        }
    }

    /**
     * Method to converted base 64 byte array into the compressed base 64 byte
     * array.
     * 
     * 
     * @param bytes
     *            bytes to compress and encode base64
     * @return base64 byte array that have been compressed.
     * @throws IOException
     */
    public static byte[] compressBase64(byte[] bytes) throws IOException {
        try (ByteArrayOutputStream os = new ByteArrayOutputStream(); GZIPOutputStream gzos = new GZIPOutputStream(os);) {
            gzos.write(bytes);
            gzos.close();
            return Base64.encodeBase64(os.toByteArray(), true);
        }
    }

    public static OutputDataType generateSuccessfullResponse(String serviceName) {

        EventLog eventLog = generateStdResponse(StatusCode.RECEIVE_SERVICE_SUCCESS, serviceName, SEVERITY_INFO, serviceName, serviceName, serviceName, "None");
        OutputDataType ouputDataType = new OutputDataType();
        ouputDataType.getEventLog().add(eventLog);
        return ouputDataType;
    }

    public static OutputDataType generateErrorResponse(String serviceName) {
        EventLog eventLog = generateStdResponse(StatusCode.RECEIVE_CONNECTOR_FAILURE, serviceName, SEVERITY_FATAL, serviceName, serviceName, serviceName,
                "None");
        OutputDataType ouputDataType = new OutputDataType();
        ouputDataType.getEventLog().add(eventLog);
        return ouputDataType;
    }

    /**
     * Helper method to generate response from the exception.
     * 
     * @param serviceName
     * @param t
     * @param statusCode
     * @return
     */
    public static OutputDataType generateResponse(String serviceName, Throwable t, StatusCode statusCode) {

        EventLog eventLog = generateStdResponse(statusCode, serviceName, SEVERITY_ERROR, serviceName, serviceName, t.getMessage(), "None");
        OutputDataType ouputDataType = new OutputDataType();
        ouputDataType.getEventLog().add(eventLog);
        return ouputDataType;
    }

    public static EventLog generateStdResponse(StatusCode statusCode, String eventName, String eventSeverity, String eventType, String serviceName,
            String serviceDescription, String serviceComments) {

        EventLog eventLog = new EventLog();
        try {
            eventLog.setCreationTime(DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar()));

        } catch (DatatypeConfigurationException e) {
            logger.error("Unable to generate date for the soap response.", e);
        }

        String transactionId = MDC.get("txid");
        if (transactionId == null) {
            transactionId = UUID.randomUUID().toString();
        }
        eventLog.setId(transactionId);
        eventLog.setCollectionQuantity("1");

        Event event = new Event();
        event.setId("1");
        event.setCreationTime(eventLog.getCreationTime());
        event.setEventType(eventType);
        event.setSeverity(eventSeverity);
        event.setResult(statusCode.getDescription());
        event.setName(eventName);
        // add to event log
        eventLog.getEvent().add(event);

        Service service = new Service();
        service.setId(transactionId);
        service.setName(serviceName);
        service.setDescription(serviceDescription);
        service.setComments(serviceComments);
        // add to event log
        eventLog.getService().add(service);

        return eventLog;

    }

    public static com.caiso.soa._2006_06_13.submitstandardoutput.OutputDataType generateSubmitSuccessfulResponse() {
        com.caiso.soa._2006_06_13.submitstandardoutput.OutputDataType outputDataType = new com.caiso.soa._2006_06_13.submitstandardoutput.OutputDataType();
        com.caiso.soa._2006_06_13.submitstandardoutput.EventLog eventLog = new com.caiso.soa._2006_06_13.submitstandardoutput.EventLog();
        com.caiso.soa._2006_06_13.submitstandardoutput.Event event = new com.caiso.soa._2006_06_13.submitstandardoutput.Event();
        event.setId("1");
        try {
            event.setCreationTime(SOAPUtils.convert(new Date()));
        } catch (DatatypeConfigurationException e) {
            // null since this is not critical
            logger.warn("Unable to generate the created time for the response.", e);
        }
        event.setDescription(MDC.get("serviceName"));
        event.setResult(StatusCode.RECEIVE_SERVICE_SUCCESS.getDescription());
        eventLog.setEvent(event);

        com.caiso.soa._2006_06_13.submitstandardoutput.Service service = new com.caiso.soa._2006_06_13.submitstandardoutput.Service();
        String txId = MDC.get("txid");
        if (txId == null) {
            txId = UUID.randomUUID().toString();
        }
        service.setId(txId);
        service.setName(MDC.get("serviceName"));
        eventLog.setService(service);
        outputDataType.setEventLog(eventLog);
        return outputDataType;
    }

    /**
     * Generate success standard output where batch id is the transaction id.
     * 
     * @param source
     * @param serviceName
     * @param status
     * @return
     */
    public static StandardOutput generateSuccessStandardOutput(String source, String serviceName, StatusCode status) {
        String transactionId = MDC.get("txid");
        if (transactionId == null) {
            transactionId = UUID.randomUUID().toString();
        }
        return generateStandardOutput(source, serviceName, transactionId, status, serviceName);
    }

    /**
     * Generate success standard output where batch id is the transaction id.
     * 
     * @param source
     * @param serviceName
     * @param status
     * @return
     */
    public static StandardOutput generateSuccessStandardOutput(String source, String serviceName, String batchId, StatusCode status) {
        return generateStandardOutput(source, serviceName, batchId, status, serviceName);
    }

    /**
     * Helper method to generate error from the exception.
     * 
     * @param serviceName
     * @param t
     * @param statusCode
     * @return
     */
    public static StandardOutput generateStandardOuputResponse(String source, String serviceName, Throwable t, StatusCode statusCode) {

        return generateStandardOutput(source, serviceName, null, statusCode, t.getMessage());
    }

    public static StandardOutput generateStandardOutput(String source, String serviceName, String batchId, StatusCode statusCode, String eventDescription) {
        String transactionId = MDC.get("txid");
        if (transactionId == null) {
            transactionId = UUID.randomUUID().toString();
        }

        XMLGregorianCalendar currentTime = null;
        try {
            currentTime = SOAPUtils.convert(new Date());
        } catch (DatatypeConfigurationException e) {
            logger.warn("Unable to set time for the header.", e);
        }
        StandardOutput standardOutput = new StandardOutput();
        MessageHeader messageHeader = new MessageHeader();
        standardOutput.setMessageHeader(messageHeader);

        messageHeader.setSource(source);
        messageHeader.setTimeDate(currentTime);
        messageHeader.setVersion(STANDARD_OUTPUT_VER_V20160301);

        MessagePayload messagePayload = new MessagePayload();
        standardOutput.setMessagePayload(messagePayload);
        com.caiso.soa.standardoutput_v1.EventLog eventLog = new com.caiso.soa.standardoutput_v1.EventLog();

        if (batchId != null) {
            Batch batch = new Batch();
            batch.setCreationTime(currentTime);
            batch.setMRID(batchId);
            eventLog.setBatch(batch);
        }

        com.caiso.soa.standardoutput_v1.Event event = new com.caiso.soa.standardoutput_v1.Event();
        event.setId(transactionId);
        event.setCreationDateTime(currentTime);
        event.setDescription(eventDescription);
        event.setResult(statusCode.getDescription());
        eventLog.setEvent(event);

        com.caiso.soa.standardoutput_v1.Service service = new com.caiso.soa.standardoutput_v1.Service();
        service.setId(source);
        service.setName(serviceName);
        eventLog.setService(service);

        messagePayload.setEventLog(eventLog);

        return standardOutput;
    }

    /**
     * Helper method to get the hour ending (DST) based on the provided date.
     * For the long date, the duplicated hour #2 will be mark ast 25.
     * 
     * @param date
     * @return
     */
    public static int getHourEnding(Calendar time) {
        TimeZone zone = TimeZone.getTimeZone("America/Los_Angeles");

        Calendar lastHour = (Calendar) time.clone();
        lastHour.add(Calendar.HOUR, -1);

        int hourEnding;
        // transition from short day to long day
        if (!zone.inDaylightTime(time.getTime()) && zone.inDaylightTime(lastHour.getTime())) {
            hourEnding = 25;
        } else {
            SimpleDateFormat format = new SimpleDateFormat("HH");
            format.setTimeZone(zone);
            String hour = format.format(time.getTime());
            hourEnding = Integer.parseInt(hour);
            // add one since it is hour ending
            ++hourEnding;
        }
        return hourEnding;
    }

}
