package com.caiso.soa.framework.payload;

import com.caiso.soa._2006_06_13.standardattachmentinfor.StandardAttachmentInfor;
import com.caiso.soa._2006_09_30.caisowsheader.CAISOWSHeaderType;

import java.io.ByteArrayOutputStream;

/**
 * <p>
 * This payload return the raw xml data. It is not recommended to be used.
 * </p>
 * 
 * @author tta
 * 
 */
public class RawPayload {
    private ByteArrayOutputStream   xml;
    private StandardAttachmentInfor header;
    private CAISOWSHeaderType       caisoWSHeader;
    private String                  serviceName;
    private String                  txId;
    private String                  interactionId;
    private int                     payloadSize;

    /**
     * @return the xml
     */
    public ByteArrayOutputStream getXml() {
        return xml;
    }

    /**
     * @param xml
     *            the xml to set
     */
    public void setXml(ByteArrayOutputStream xml) {
        this.xml = xml;
    }

    /**
     * @return the header
     */
    public StandardAttachmentInfor getHeader() {
        return header;
    }

    /**
     * @param header
     *            the header to set
     */
    public void setHeader(StandardAttachmentInfor header) {
        this.header = header;
    }

    /**
     * @return the caisoWSHeader
     */
    public CAISOWSHeaderType getCaisoWSHeader() {
        return caisoWSHeader;
    }

    /**
     * @param caisoWSHeader
     *            the caisoWSHeader to set
     */
    public void setCaisoWSHeader(CAISOWSHeaderType caisoWSHeader) {
        this.caisoWSHeader = caisoWSHeader;
    }

    /**
     * @return the serviceName
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * @param serviceName
     *            the serviceName to set
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    /**
     * @return the txId
     */
    public String getTxId() {
        return txId;
    }

    /**
     * @param txId
     *            the txId to set
     */
    public void setTxId(String txId) {
        this.txId = txId;
    }

    /**
     * @return the interactionId
     */
    public String getInteractionId() {
        return interactionId;
    }

    /**
     * @param interactionId
     *            the interactionId to set
     */
    public void setInteractionId(String interactionId) {
        this.interactionId = interactionId;
    }

    /**
     * @return the payloadSize
     */
    public int getPayloadSize() {
        return payloadSize;
    }

    /**
     * @param payloadSize
     *            the payloadSize to set
     */
    public void setPayloadSize(int payloadSize) {
        this.payloadSize = payloadSize;
    }

}
