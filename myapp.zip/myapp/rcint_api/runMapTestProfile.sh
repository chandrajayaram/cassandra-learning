mvn clean spring-boot:run -Drun.profiles=MAPTEST
