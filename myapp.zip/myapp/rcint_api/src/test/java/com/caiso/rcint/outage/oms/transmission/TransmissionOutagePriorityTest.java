package com.caiso.rcint.outage.oms.transmission;

import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.outage.oms.CosOutageDataMapper;
import com.caiso.rcint.util.MarshallingUtil;
import com.caiso.soa.transmissionoutageresultscaiso_v2.EmergencyReturnTimeKind;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutage;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class TransmissionOutagePriorityTest {
	
	@Autowired
	CosOutageDataMapper cosOutageDataMapper;
	
	@Test
	public void testOutagePriority (){
		TransmissionOutageResultsCaiso transmissionOutageResults = MarshallingUtil.getObject("TransmissionOutage.xml");
		TransmissionOutage transmissionOutage = transmissionOutageResults.getMessagePayload().getTransmissionOutages().get(0);
		transmissionOutage.setEmergencyReturnTimeType(EmergencyReturnTimeKind.DURATION);
		assertNotNull(cosOutageDataMapper.mapCosOutagePriorityId(transmissionOutage));
		transmissionOutage.setEmergencyReturnTimeType(EmergencyReturnTimeKind.IMMEDIATE);
		assertNotNull(cosOutageDataMapper.mapCosOutagePriorityId(transmissionOutage));
		transmissionOutage.setEmergencyReturnTimeType(EmergencyReturnTimeKind.HOURS);
		transmissionOutage.setEmergencyReturnTime(BigInteger.valueOf(2));
		assertNotNull(cosOutageDataMapper.mapCosOutagePriorityId(transmissionOutage));
		transmissionOutage.setEmergencyReturnTimeType(EmergencyReturnTimeKind.MINUTES);
		transmissionOutage.setEmergencyReturnTime(BigInteger.valueOf(20));
		assertNotNull(cosOutageDataMapper.mapCosOutagePriorityId(transmissionOutage));
		transmissionOutage.setEmergencyReturnTimeType(EmergencyReturnTimeKind.DAYS);
		transmissionOutage.setEmergencyReturnTime(BigInteger.valueOf(20));
		assertNotNull(cosOutageDataMapper.mapCosOutagePriorityId(transmissionOutage));
		transmissionOutage.setEmergencyReturnTimeType(EmergencyReturnTimeKind.YEARS);
		transmissionOutage.setEmergencyReturnTime(BigInteger.valueOf(1));
		assertNotNull(cosOutageDataMapper.mapCosOutagePriorityId(transmissionOutage));
	}
	
}
