package com.caiso.rcint.outage.oms.service;

import org.springframework.stereotype.Service;

import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

@Service 
public class TestTransmissionOutageService {
	public void process(TransmissionOutageResultsCaiso transmissionOutageResultsCaiso){
		
	}
}
