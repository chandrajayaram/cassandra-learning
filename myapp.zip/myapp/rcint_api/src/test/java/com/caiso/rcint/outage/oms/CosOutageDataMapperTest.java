package com.caiso.rcint.outage.oms;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.util.MarshallingUtil;
import com.caiso.soa.resourceoutageresultscaiso_v2.ResourceOutageResultsCaiso;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class CosOutageDataMapperTest {
	
	@Autowired
	CosOutageDataMapper cosOutageDataMapper;
	
	@Test
	public void test() {
		ResourceOutageResultsCaiso resourceOutageResults = MarshallingUtil.getObject("resource/resource_status.xml");
		cosOutageDataMapper.mapCosOutageStatusId(resourceOutageResults.getMessagePayload().getRegisteredResourceOutages().get(0));
	}

}
