package com.caiso.rcint.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPMessage;

import com.caiso.rcint.domain.TransmissionOutageWrapper;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;
import com.caiso.soa.regulatoryauthorityoutagestatus_v1.TransmissionOutage;
import com.caiso.soa.resourceoutageresultscaiso_v2.ResourceOutageResultsCaiso;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

public class MarshallingUtil {

	private static JAXBContext ctx;
	private static Marshaller marshaller;
	private static Unmarshaller unMarshaller;
	
	static{
		try {
			ctx = JAXBContext.newInstance(TransmissionOutageResultsCaiso.class, ResourceOutageResultsCaiso.class, AvailabilityResultsCaiso.class, TransmissionOutageWrapper.class);
			marshaller = ctx.createMarshaller();
			unMarshaller = ctx.createUnmarshaller(); 
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}
	
	public static <T> void toXml(List<T> payloads,String serviceName){
		    try {
	        	
	        	marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	            int i=0;
	        	for(T payload: payloads){
	        		FileOutputStream fout = new FileOutputStream(new File("c:\\TEMP\\testoutput\\"+ serviceName+"_"+ ++i +".xml"));  
	                marshaller.marshal(payload, fout);	
	        	}
	        	
	        }
	        catch (Exception e) {
	        	e.printStackTrace();
	        }
	}
	@SuppressWarnings("unchecked")
	public static <T> T getObject(String fileName){
	    try {
	    	return (T) unMarshaller.unmarshal(MarshallingUtil.class.getClassLoader().getResourceAsStream("testdata/"+fileName));
        }
        catch (Exception e) {
        	e.printStackTrace();
        }
	    return null;
	}
	
	public static SOAPMessage getSOAPMessage(String fileName){
	    try {
	    	MessageFactory  factory = MessageFactory.newInstance();
			MimeHeaders headers = new MimeHeaders();
			return factory.createMessage(headers, MarshallingUtil.class.getClassLoader().getResourceAsStream("testdata/"+fileName));
        }
        catch (Exception e) {
        	e.printStackTrace();
        }
	    return null;
	}
	
	
	
	
}
