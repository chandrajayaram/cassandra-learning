package com.caiso.rcint.outage.oms.transmission;

import java.io.IOException;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.xml.soap.SOAPException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.transmission.TransmissionOutageProcessor;
import com.caiso.rcint.util.MarshallingUtil;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class TransmissionOutageProcessorTest {

	@Autowired
	private TransmissionOutageProcessor transmissionOutageService;
	
	
	@PostConstruct
	public void init() {
		System.getProperties().put("spring.config.location",
		TransmissionOutageProcessorTest.class.getResource("/application.properties").getFile());
	}

	@Before
	public void setUp() {
		TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
	}

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void persistPayload() throws SOAPException, IOException, RCINTApplicationException {
		TransmissionOutageResultsCaiso transmissionOutage = MarshallingUtil.getObject("transoutage1.xml");
		transmissionOutageService.process(transmissionOutage);
	}
}
