package com.caiso.rcint.dao;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import com.caiso.rcint.util.MarshallingUtil;

public class TestJava {
	
	public static void main1(String[] args) throws IOException, SOAPException {
		SOAPMessage message = MarshallingUtil.getSOAPMessage("cospayload.xml");
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		message.writeTo(stream);
		String url = "https://cos2.test.peakrc.org/crowapi/service.asmx";
		String SOAPAction=  "http://crow.equinox.ca/OutageSchedule_SubmitRequest";
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("POST");

		//add request header
		con.setRequestProperty("SOAPAction", "http://crow.equinox.ca/OutageSchedule_SubmitRequest");
		con.setRequestProperty("Content-Type","text/xml");
		con.setDoOutput(true);
		
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		wr.writeBytes(new String(stream.toByteArray()));
		wr.flush();
		wr.close();
		
		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		//print result
		System.out.println(response.toString());
	}
	public static void main2(String[] args) {
		List<Integer> data = Arrays.asList(new Integer[]{1,2,3,4,5});
		
		data=	data.stream().filter(e -> e%2 == 0).collect(Collectors.toList());
		System.out.println(data);
	}
	 public static void main(String args[]) throws DatatypeConfigurationException {
		    Date date = new Date();
		    SimpleDateFormat sdf;
		    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
		    sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssz");
		    System.out.println(sdf.format(date));
		    GregorianCalendar calendar = new GregorianCalendar();
		    calendar.setTime(new Date());
		    DatatypeFactory df = DatatypeFactory.newInstance();
		    XMLGregorianCalendar dateTime = df.newXMLGregorianCalendar(calendar);
		    System.out.println(dateTime.toString());
		  }
}
