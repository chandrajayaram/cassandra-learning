/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 27, 2017 1:51:20 PM
 * Project: rcint-app
 * File: TempTest.java
 */
package com.caiso.rcint.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.soap.MessageFactory;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;

import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;

import ca.equinox.crow.ObjectFactory;
/**
 * @author gselvaratnam
 *
 */
@Ignore
public class TempTest {
    ObjectFactory objFactory = new ObjectFactory();

   
    @Test
    public void test() throws Exception {
        String xmlStr = 
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                "    <SOAP-ENV:Header />" +
                "    <SOAP-ENV:Body>" +
                "        <receiveRegulatoryAuthorityOutageStatus_v1 xmlns=\"http://www.caiso.com/soa/receiveRegulatoryAuthorityOutageStatus_v1\">" +
                "            <outputDataType xmlns=\"http://www.caiso.com/soa/2006-06-13/StandardOutput.xsd\">" +
                "                <EventLog>" +
                "                    <Event>" +
                "                        <result>Success</result>" +
                "                        <creationTime>2017-03-01T00:45:10.2395121Z</creationTime>" +
                "                    </Event>" +
                "                    <Service>" +
                "                        <id>1</id>" +
                "                        <name>receiveRegulatoryAuthorityOutageStatus_v1</name>" +
                "                        <description>http://www.caiso.com/soa/receiveRegulatoryAuthorityOutageStatus_v1.wsdl</description>" +
                "                        <comments>Success</comments>" +
                "                    </Service>" +
                "                </EventLog>" +
                "            </outputDataType>" +
                "        </receiveRegulatoryAuthorityOutageStatus_v1>" +
                "    </SOAP-ENV:Body>" +
                "</SOAP-ENV:Envelope>";
        MessageFactory mf = MessageFactory.newInstance();
        SaajSoapMessageFactory saajSoapMessageFactory = new SaajSoapMessageFactory(mf);
        InputStream stream = new ByteArrayInputStream(xmlStr.getBytes(StandardCharsets.UTF_8));
        SaajSoapMessage saajSoapMessage = saajSoapMessageFactory.createWebServiceMessage(stream);
        String soapBodyStr = extractSoapBodyAsString(saajSoapMessage);

        OutputDataType outputDataType = findOutputDataType(soapBodyStr);

        
        System.out.println("outputDataType : " + outputDataType);
    }

    protected OutputDataType findOutputDataType(String soapBodyStr) throws JAXBException {
        OutputDataType outputDataType = null;

        JAXBContext jaxbContext = JAXBContext.newInstance("com.caiso.soa._2006_06_13.standardoutput");
        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
        JAXBElement<OutputDataType> root = jaxbUnmarshaller.unmarshal(new StreamSource(new StringReader(soapBodyStr)), OutputDataType.class);
        outputDataType = root.getValue();

        return outputDataType;
    }

    private String extractSoapBodyAsString(SaajSoapMessage soapMessage) {
        String responseStr;
        final StringWriter sw = new StringWriter();
        try {
            TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSoapBody().getPayloadSource(), new StreamResult(sw));
        } catch (Exception exception) {
            throw new RCINTRuntimeException(exception);
        }
        responseStr = new String(sw.toString());
        return responseStr;
    }

    private String getString() {
        return "TestVal";
    }

    private JAXBElement<Double> getDouble() {
        return objFactory.createSystemEventDouble1(new Double(1234));
    }

}
