/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 27, 2017 4:57:42 PM
 * Project: rcint-app
 * File: RCRdfIdMapRepositoryTest.java
 */
package com.caiso.rcint.dao;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.domain.RCRdfIdMap;

/**
 * @author gselvaratnam
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class RCRdfIdMapDaoTest {

    @Autowired
    private RCRdfIdMapDao rcRdfIdMapDao;

    @Test
    public void test() {
//        List<RCRdfIdMap> rcRdfIdMapList = rcRdfIdMapRepository.findByCosNameRdfIdIsNotNull("Noxon Ava-Hot Springs 2 230KV Line");
        List<RCRdfIdMap> rcRdfIdMapList = rcRdfIdMapDao.findByCosNameRdfIdIsNotNull("Benton - South Othello Section of Benton - Othello Switching Station 115kV Line");
        for(RCRdfIdMap rcRdfIdMap : rcRdfIdMapList) {
            System.out.println(rcRdfIdMap);
        }
     
        RCRdfIdMap newRCRdfIdMap = new RCRdfIdMap();
        newRCRdfIdMap.setControlArea("BLA");
        newRCRdfIdMap.setStation("TEST");
        newRCRdfIdMap.setVoltageClass(String.valueOf(3));
        newRCRdfIdMap.setCosName("Benton - South Othello Section of Benton - Othello Switching Station 115kV Line");
        newRCRdfIdMap.setCreatedDate(new Date());
        newRCRdfIdMap.setUpdatedDate(new Date());
        newRCRdfIdMap.setUpdatedBy("RCINTAPI");

        rcRdfIdMapDao.createRCRdfIdMap(newRCRdfIdMap);
    }
}
