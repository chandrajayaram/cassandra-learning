package com.caiso.rcint.outage.oms.transmission;

import java.io.IOException;

import javax.xml.soap.SOAPException;

import org.apache.http.client.HttpClient;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.common.OutagePublisher;
import com.caiso.rcint.util.MarshallingUtil;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class TransmissionOutageFlowTest {

	@Autowired
	private TransmissionOutageProcessor transmissionOutageService;
	
	@Autowired
	private HttpClient defaultHttpClient;
	
	@Autowired
	private OutagePublisher transmissionOutagePublisher;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void testFlow() throws SOAPException, IOException, RCINTApplicationException, InterruptedException {
		System.setProperty("javax.xml.soap.MessageFactory","com.sun.xml.internal.messaging.saaj.soap.ver1_2.SOAPMessageFactory1_2Impl");
		
		
		/*String cosURL = "https://cos2.test.peakrc.org/crowapi/service.asmx";
		String SOAPAction = "http://crow.equinox.ca/OutageSchedule_SubmitRequest";
		SOAPMessageTemplate template=new SOAPMessageTemplateImpl(){
			@Override
			public SOAPMessage sendMessage(String endPointUrl, String soapAction, SOAPMessage soapRequest,
					HttpClient httpClient, int retryCount) throws RCINTApplicationException {
				SOAPMessage response = MarshallingUtil.getSOAPMessage("cosResponse.xml");
				return response;
			}
		};
		transmissionOutagePublisher.setSoapMessageTemplate(template);*/
		TransmissionOutageResultsCaiso transmissionOutage = MarshallingUtil.getObject("TransmissionOutage.xml");
		//String mrid = transmissionOutage.getMessagePayload().getTransmissionOutages().get(0).getMRID();
		//long lmrid = Long.valueOf(mrid);
		//transmissionOutage.getMessagePayload().getTransmissionOutages().get(0).setMRID(lmrid+"");
		transmissionOutageService.process(transmissionOutage);
		//System.in.read();
		
		
	}
}
