package com.caiso.rcint.outage.oms.availability;

import static org.junit.Assert.assertEquals;

import java.util.Map;
import java.util.Map.Entry;

import org.junit.Test;

import com.caiso.rcint.domain.AvailabilityResultsWrapper;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.util.MarshallingUtil;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;

public class PayloadManagerTest {

	public static PaylaodManager payloadManager = new PaylaodManager();

	@Test
	public void shouldReturnOneAvailabilityWrapper() throws RCINTApplicationException {
		AvailabilityResultsCaiso availabilityResults = MarshallingUtil.getObject("availability/availability_4434717.xml");
		Map<String, AvailabilityResultsWrapper> payloadData = payloadManager.preparePayload(availabilityResults);
		assertEquals(payloadData.keySet().size(), 1);
	}
	
	@Test
	public void shouldReturnOneAvailability() throws RCINTApplicationException {
		AvailabilityResultsCaiso availabilityResults = MarshallingUtil.getObject("availability/availability_4434717.xml");
		Map<String, AvailabilityResultsWrapper> payloadData = payloadManager.preparePayload(availabilityResults);
		for(Entry<String, AvailabilityResultsWrapper> entry: payloadData.entrySet()){
			assertEquals(entry.getValue().getRegisteredGenerators().get(0).getOutagedRegisteredResource().getAvailabilities().size(), 1);
		}
	}

	@Test
	public void shouldReturnSixAvailabilityWrapper() throws RCINTApplicationException {
		AvailabilityResultsCaiso availabilityResults = MarshallingUtil.getObject("availability/multipleResourceAvailabilities.xml");
		Map<String, AvailabilityResultsWrapper> payloadData = payloadManager.preparePayload(availabilityResults);
		assertEquals(payloadData.keySet().size(), 6);
	}
	
	@Test
	public void shouldReturnOneAvailabilityData() throws RCINTApplicationException {
		AvailabilityResultsCaiso availabilityResults = MarshallingUtil.getObject("availability/multipleResourceAvailabilities.xml");
		Map<String, AvailabilityResultsWrapper> payloadData = payloadManager.preparePayload(availabilityResults);
		for(Entry<String, AvailabilityResultsWrapper> entry: payloadData.entrySet()){
			assertEquals(entry.getValue().getRegisteredGenerators().get(0).getOutagedRegisteredResource().getAvailabilities().size(), 1);
		}
	}
	
	@Test
	public void shouldReturnEmptyMap() throws RCINTApplicationException {
		AvailabilityResultsCaiso availabilityResults = MarshallingUtil.getObject("availability/availabilitiesWithNoResources.xml");
		Map<String, AvailabilityResultsWrapper> payloadData = payloadManager.preparePayload(availabilityResults);
		assertEquals(payloadData.keySet().size(), 0);
	}
	@Test
	public void shouldReturnEmptyMapForNonCriteria() throws RCINTApplicationException {
		AvailabilityResultsCaiso availabilityResults = MarshallingUtil.getObject("availability/availabilitiesWithNoResources.xml");
		Map<String, AvailabilityResultsWrapper> payloadData = payloadManager.preparePayload(availabilityResults);
		assertEquals(payloadData.keySet().size(), 0);
	}
	
	
	
	
	

}
