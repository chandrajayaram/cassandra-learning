/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 18, 2017 4:06:47 PM
 * Project: caiso-rcint_api
 * File: WebServiceCallOutServiceTest.java
 */
package com.caiso.rcint.service;

import java.io.ByteArrayInputStream;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.domain.RCPublishInfoType;
import com.caiso.rcint.util.DateUtil;

/**
 * @author gselvaratnam
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
@Ignore
public class WebServiceCallOutService_OnServerTest {

    @Autowired
    private WebServiceCallOutService webServiceCallOutService;

    @Test
    public void testCallOmsWebService() throws Exception {
        String soapRequestXml = webServiceCallOutService.getOmsReceiveRegulatoryAuthorityOutageStatus_v1SoapXMLString();

        String xmlAttachementString = webServiceCallOutService.getOmsAttachementRegulatoryAuthorityOutageStatusXMLString(
                DateUtil.convertToXmlGregorianCalendar(new Date()).toString(), "3138947",
                "4", "SOME ERROR", "1-00250900", "PENDING");

        String responseSoapMessage = webServiceCallOutService.callOmsWebService_soap_12(soapRequestXml, xmlAttachementString, RCPublishInfoType.OMS_TRANS_OUTAGE);

//        System.out.println(message);
        
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new InputSource(new ByteArrayInputStream(responseSoapMessage.getBytes("utf-8"))));
        
        XPathFactory xpathFactory = XPathFactory.newInstance();
        XPath xpath = xpathFactory.newXPath();
        XPathExpression expr = xpath.compile("/receiveRegulatoryAuthorityOutageStatus_v1/outputDataType/EventLog/Event/result");
        
        String msg = (String)expr.evaluate(doc, XPathConstants.STRING);
        System.out.println(msg);

//        Iterator<Attachment> attachmentIt = responseSoapMessage.getAttachments();
//        while(attachmentIt.hasNext()) {
//            Attachment attachment = attachmentIt.next();
//            
//            StringWriter writer = new StringWriter();
//            IOUtils.copy(attachment.getInputStream(), writer, "UTF-8");
//            String theString = writer.toString();
//
//            System.out.println("Attachment " + theString);
//        }
    }
}
