package com.caiso.rcint.outage.oms.common;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.xml.soap.SOAPMessage;

import org.apache.http.client.HttpClient;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.util.MarshallingUtil;
import com.caiso.rcint.util.SOAPMessageTemplate;
import com.caiso.rcint.util.SOAPMessageTemplateImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class OutagePublisherTest {

	@Autowired
	private OutagePublisher outagePublisher;
	@Autowired
	private HttpClient defaultHttpClient;
		
	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void sendAndReceivePayload() throws Exception {
		System.setProperty("javax.xml.soap.MessageFactory","com.sun.xml.internal.messaging.saaj.soap.ver1_1.SOAPMessageFactory1_1Impl");
		SOAPMessage message = MarshallingUtil.getSOAPMessage("cospayload.xml");
		SOAPMessage response = MarshallingUtil.getSOAPMessage("cosResponse.xml");
		String cosURL = "https://cos2.test.peakrc.org/crowapi/service.asmx";
		String SOAPAction = "http://crow.equinox.ca/OutageSchedule_SubmitRequest";
		SOAPMessageTemplate template=mock(SOAPMessageTemplateImpl.class);
		when(template.sendMessage(cosURL, SOAPAction, message, defaultHttpClient, 2)).thenReturn(response);
		AcknowledgementPublisher ackPublisher=new AcknowledgementPublisher(){
			@Override
			public void processAcknowledgement(long payloadId, String omsOutageId, String omsOutageVersion,
					String outageType, String cosId, String errorMsg, String status) {
				System.out.println("here");
			}
		};
		WECCPayload payload = new WECCPayload();
		payload.setWeccPayload(message);
		outagePublisher.setSoapMessageTemplate(template);
		outagePublisher.setAckPublisher(ackPublisher);
		outagePublisher.processWECCPayload(173288, payload);
	}
}
