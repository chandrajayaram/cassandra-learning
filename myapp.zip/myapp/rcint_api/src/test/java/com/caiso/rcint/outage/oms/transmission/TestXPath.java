package com.caiso.rcint.outage.oms.transmission;

import java.io.StringWriter;

import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.caiso.rcint.util.MarshallingUtil;

public class TestXPath {
	public static void main(String[] args) throws Exception{
		System.setProperty("javax.xml.soap.MessageFactory","com.sun.xml.internal.messaging.saaj.soap.ver1_2.SOAPMessageFactory1_2Impl");

		SOAPMessage response = MarshallingUtil.getSOAPMessage("cosResponse.xml");
		SOAPBody soapBody = response.getSOAPBody();
		Document document = soapBody.extractContentAsDocument();
		
		DOMSource domSource = new DOMSource(document);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(domSource, result);
		XPath xpath = XPathFactory.newInstance().newXPath();

		String outageNumberExp ="//*[local-name()='outageNumber']";
		Node outageNumberNode =  (Node) xpath.evaluate(outageNumberExp, document, XPathConstants.NODE);
		String weccId = outageNumberNode.getFirstChild().getNodeValue();
		String remoteSystemOutageNumberExp ="//*[local-name()='remoteSystemOutageNumber']";
		Node remoteSystemOutageNumberNode =  (Node) xpath.evaluate(remoteSystemOutageNumberExp, document, XPathConstants.NODE);
		String omsId =remoteSystemOutageNumberNode.getFirstChild().getNodeValue();
		String erroCodes ="//*[local-name()='errorCode']";
		NodeList erroList =  (NodeList) xpath.evaluate(erroCodes, document, XPathConstants.NODESET);
		boolean containsError =false;
		boolean containsWarring =false;
		for(int i=0;i<erroList.getLength();i++){
			int errorCode= Integer.valueOf(erroList.item(i).getFirstChild().getNodeValue());
			if(errorCode < 0 ){
				containsError = true;
			}else if(errorCode > 0){
				containsWarring =true;
			}
		}

		if((!containsError && !containsWarring) && !weccId.equals("0-00000000")){
			
		}else if(!containsError && containsWarring && !weccId.equals("0-00000000")){
			
		}else{
			
		}
		

	}
}
