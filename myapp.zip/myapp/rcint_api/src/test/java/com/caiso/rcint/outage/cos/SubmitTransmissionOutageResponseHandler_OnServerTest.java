/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 14, 2017 9:27:34 AM
 * Project: rcint-app
 * File: SubmitTransmissionOutageResponseHandler_OnServerTest.java
 */
package com.caiso.rcint.outage.cos;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.dao.RCPublishPayloadRepository;
import com.caiso.rcint.domain.PayloadType;
import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.transmissionoutagedata_v1.TransmissionOutageData;

/**
 * @author gselvaratnam
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
@Ignore
public class SubmitTransmissionOutageResponseHandler_OnServerTest {
    private static final Logger                       logger = LoggerFactory.getLogger(SubmitTransmissionOutageResponseHandler_OnServerTest.class);
    @Autowired
    private RCPublishPayloadRepository                rcPublishPayloadRepository;

    @Autowired
    protected SubmitTransmissionOutageResponseHandler submitTransmissionOutageResponseHandler;

    @Test
    public void handleResponseTest() {
        String payloadId = "173810";
        try {
            RCPublishPayload rcPublishPayload = rcPublishPayloadRepository.findOne(Long.valueOf(payloadId));

            if (rcPublishPayload == null) {
                throw new RCINTRuntimeException("Could not find payload : " + payloadId);
            } else if (PayloadType.OMS_TRANS_OUTAGE.getPayloadType().equalsIgnoreCase(rcPublishPayload.getPayloadType())
                    || PayloadType.OMS_TRANS_OUTAGE_CHANGE_REQUEST.getPayloadType().equalsIgnoreCase(rcPublishPayload.getPayloadType())) {

                logger.debug("RCPublishPayload : {}", rcPublishPayload);

                String xmlStr = Utils.decompress(rcPublishPayload.getData());

                String omsId = submitTransmissionOutageResponseHandler.handleResponse(getTransmissionOutageData(xmlStr), null, Long.valueOf(payloadId));

                logger.info("SubmitTransmissionOutage_v1 OmsID : " + omsId);

            } else {
                throw new RCINTRuntimeException("The payload type must be " + PayloadType.OMS_TRANS_OUTAGE.getPayloadType() + " or "
                        + PayloadType.OMS_TRANS_OUTAGE_CHANGE_REQUEST.getPayloadType());
            }
        } catch (Exception e) {
            logger.error("Unexpected Error", e);
        }
    }

    protected TransmissionOutageData getTransmissionOutageData(String xmlString) throws JAXBException {
        TransmissionOutageData transmissionOutageData;
        JAXBContext jaxbContext = JAXBContext.newInstance("com.caiso.soa.transmissionoutagedata_v2");
        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
        JAXBElement<TransmissionOutageData> root = jaxbUnmarshaller.unmarshal(new StreamSource(new StringReader(xmlString)), TransmissionOutageData.class);
        transmissionOutageData = root.getValue();
        return transmissionOutageData;
    }
}
