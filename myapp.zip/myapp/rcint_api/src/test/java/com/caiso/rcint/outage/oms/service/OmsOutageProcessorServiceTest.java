/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 12, 2017 3:47:35 PM
 * Project: caiso-rcint_api
 * File: OmsOutageProcessorServiceTest.java
 */
package com.caiso.rcint.outage.oms.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.outage.cos.CosOutageProcessorService;

/**
 * @author gselvaratnam
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class OmsOutageProcessorServiceTest {

    @Autowired
    private CosOutageProcessorService omsOutageProcessorService;

    @Test
    public void test_ProcessOmsOutages() {

        omsOutageProcessorService.processOmsOutages();
    }
}
