/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 31, 2017 9:01:13 AM
 * Project: rcint-app
 * File: DateUtilTest.java
 */
package com.caiso.rcint.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

import com.caiso.rcint.domain.RCIntConstants;

/**
 * @author gselvaratnam
 *
 */
public class DateUtilTest {

    @Test
    public void test_FormatDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 2017);
        calendar.set(Calendar.MONTH, Calendar.JANUARY);
        calendar.set(Calendar.DAY_OF_MONTH, 1);

        System.out.println(calendar.getTime());

        String dateStr = DateUtil.formatDate(calendar, DateUtil.COS5_DATE_FORMAT);

        System.out.println(dateStr);

        assertThat(dateStr.contains("2017/01/01")).isTrue();
    }

    @Test
    public void test_getDateFromString() {
        String lastRunDateStr = "2017/01/01 09:17:27";

        System.out.println(lastRunDateStr);

        Date lastRunDate = DateUtil.getDateFromString(lastRunDateStr, DateUtil.COS5_DATE_FORMAT);

        System.out.println(lastRunDate);

    }
}