package com.caiso.rcint.outage.oms.transmission;

import static org.junit.Assert.assertNotNull;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.transmission.TransmissionOutageDAO;
import com.caiso.rcint.util.MarshallingUtil;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutage;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class TransmissionOutageDAOTest {

	@Autowired
	TransmissionOutageDAO transmissionOutageDAO;

	@Autowired
	NamedParameterJdbcTemplate rcintJdbcTemplate;

	@PostConstruct
	public void init() {
		System.getProperties().put("spring.config.location",
				TransmissionOutageDAO.class.getResource("/application.properties").getFile());
	}

	@Before
	public void setUp() {
		TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
	}

	@Rule
	public ExpectedException thrown = ExpectedException.none();
	@Test
	public void savePayload() throws RCINTApplicationException {
		TransmissionOutageResultsCaiso transmissionOutage = MarshallingUtil.getObject("transoutage1.xml");
		Map<Long, TransmissionOutage> createdOutages  = transmissionOutageDAO.createTORTransmissionOutage(transmissionOutage);
		Set<Long> ids = createdOutages.keySet();
		for(long id: ids){
		Long resultLongId = rcintJdbcTemplate.query("SELECT OID FROM RC_OMS_MESSAGE_PAYLOAD WHERE OID=" + id,
				new ResultSetExtractor<Long>() {
					@Override
					public Long extractData(ResultSet paramResultSet) throws SQLException, DataAccessException {
						while (paramResultSet.next()) {
							return paramResultSet.getLong(1);
						}
						return null;
					}
				});
			assertNotNull(resultLongId);
		}
	}
	
	public void retrievePayload() throws JAXBException {
		/*TransmissionOutageResultsCaiso payload = transmissionOutageDAO.getTransmissionOutagePayload(25003);
		assertNotNull(payload);*/
	}
}
