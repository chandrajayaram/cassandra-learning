package com.caiso.rcint.outage.oms.availability;

import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.domain.AvailabilityResultsWrapper;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.transmission.TransmissionOutageDAO;
import com.caiso.rcint.util.MarshallingUtil;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class AvailabilityResultsDAOTest {
	
	@Autowired
	AvailabilityResultsDAO availabilityResultsDAO;
	
	@Autowired
	PaylaodManager payloadManager;
	
	@Autowired
	NamedParameterJdbcTemplate rcintJdbcTemplate;

	@Before
	public void setUp() {
		TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
	}

	@Rule
	public ExpectedException thrown = ExpectedException.none();
	@Test
	public void savePayload() throws  RCINTApplicationException {
		AvailabilityResultsCaiso  availabilityResultsCaiso = MarshallingUtil.getObject("availability/availability1.xml");
		Map<String, AvailabilityResultsWrapper> payloadData = payloadManager.preparePayload(availabilityResultsCaiso);
		Set<String> mrdis =  availabilityResultsDAO.createAvailabilityResults(availabilityResultsCaiso,payloadData) ;
		System.out.println(mrdis);
	}
	

}
