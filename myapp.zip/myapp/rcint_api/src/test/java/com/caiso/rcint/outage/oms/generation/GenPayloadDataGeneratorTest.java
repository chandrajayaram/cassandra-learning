package com.caiso.rcint.outage.oms.generation;

import java.io.IOException;
import java.util.TimeZone;

import javax.xml.soap.SOAPException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.availability.AvailabilityResultsProcessor;
import com.caiso.rcint.outage.oms.resource.ResourceOutageProcessor;
import com.caiso.rcint.util.MarshallingUtil;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;
import com.caiso.soa.resourceoutageresultscaiso_v2.ResourceOutageResultsCaiso;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
public class GenPayloadDataGeneratorTest {


	@Autowired
	GenerationOutagePayloadGenerator generator;

	@Autowired
	public AvailabilityResultsProcessor availabilityProcessor; 
	
	@Autowired
	private ResourceOutageProcessor resourceOutageProcessor;
	@Before
	public void setUp() {
		TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
	}

	@Rule
	public ExpectedException thrown = ExpectedException.none();
	@Test
	public void savePayload() throws  RCINTApplicationException, SOAPException, IOException {
		System.setProperty("javax.xml.soap.MessageFactory","com.sun.xml.internal.messaging.saaj.soap.ver1_2.SOAPMessageFactory1_2Impl");
		String resource="resource/resource_4187899.xml" ;
		String availability ="availability/availability_4187899.xml" ;
		ResourceOutageResultsCaiso resourceOutageResults = MarshallingUtil.getObject(resource);		
		resourceOutageProcessor.processAsync(resourceOutageResults);
		AvailabilityResultsCaiso availabilityResults = MarshallingUtil.getObject(availability);
		availabilityProcessor.processAsync(availabilityResults);
	}
	

}
