package com.caiso.rcint.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

@Configuration
@EnableAutoConfiguration
@EnableConfigurationProperties
@Import(ApplicationConfiguration.class)
@PropertySource(value = { "classpath:application.properties"})
public class AppTestConfiguration {

}	
