/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 15, 2017 9:13:18 AM
 * Project: rcint-app
 * File: DbPropertyServiceTest.java
 */
package com.caiso.rcint.service;

import java.util.Calendar;
import java.util.Date;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.StringUtils;

import com.caiso.rcint.config.AppTestConfiguration;
import com.caiso.rcint.util.DateUtil;

/**
 * @author gselvaratnam
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
@Ignore
public class DbPropertyServiceTest {
    private static final Logger logger = LoggerFactory.getLogger(DbPropertyServiceTest.class);
    @Autowired
    private DbPropertyService   dbPropertyService;

    @Test
    public void addOrUpdatePropertyTest() {
        Calendar processStartTime = Calendar.getInstance();

        Calendar todayCal = Calendar.getInstance();
        String lastRunDateStr = dbPropertyService.getProperty("retrieveWeccOutagelastRunInterval");

        if (!StringUtils.isEmpty(lastRunDateStr)) {
            todayCal.add(Calendar.HOUR, -24);

            Date lastRunDate = DateUtil.getDateFromString(lastRunDateStr, DateUtil.COS5_DATE_FORMAT);
            Calendar lastRunCal = Calendar.getInstance();
            lastRunCal.setTime(lastRunDate);

            processStartTime.setTime(lastRunDate);

            logger.info("The Start time : {}", processStartTime.getTime());

            String currentTimeStr = DateUtil.formatDate(Calendar.getInstance(), DateUtil.COS5_DATE_FORMAT);

            logger.info("Now time : {}", currentTimeStr);

            dbPropertyService.createOrUpdateProperty("retrieveWeccOutagelastRunInterval", currentTimeStr);
        }

        lastRunDateStr = dbPropertyService.getProperty("retrieveWeccOutagelastRunInterval");

        logger.info("After Updated Time : {}", processStartTime.getTime());
    }
}
