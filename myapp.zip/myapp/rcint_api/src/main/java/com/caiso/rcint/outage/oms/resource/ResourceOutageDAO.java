package com.caiso.rcint.outage.oms.resource;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.dao.MessagePayloadDAOImpl;
import com.caiso.rcint.domain.PayloadStatus;
import com.caiso.rcint.domain.RegisteredResourceOutageWrapper;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.soa.framework.utils.CAISOUtils;
import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.resourceoutageresultscaiso_v2.MessageHeader;
import com.caiso.soa.resourceoutageresultscaiso_v2.MessagePayload;
import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;
import com.caiso.soa.resourceoutageresultscaiso_v2.ResourceOutageResultsCaiso;

@Repository
public class ResourceOutageDAO {
	public static final Logger logger = LoggerFactory.getLogger(ResourceOutageDAO.class);
	
	private MessagePayloadDAOImpl messagePayloadDAO;
	
	@Autowired
	public void setMessagePayloadDAO(MessagePayloadDAOImpl messagePayloadDAO) {
		this.messagePayloadDAO = messagePayloadDAO;
	}

	public Map<Long,RegisteredResourceOutage> createResourceOutage(ResourceOutageResultsCaiso resourceOutageResults) throws RCINTApplicationException {
		logger.info("Creating resource outage");
		MessageHeader header = resourceOutageResults.getMessageHeader();
		
		long messageId = messagePayloadDAO.createMessageHeader(header.getTimeDate(), header.getSource(), header.getVersion(),"RESOURCE");
		Map<Long,RegisteredResourceOutage> outageMap= new HashMap<>();
		RegisteredResourceOutageWrapper wrapper;
		XMLGregorianCalendar start = null;
		XMLGregorianCalendar end = null;
		for (RegisteredResourceOutage outage : resourceOutageResults.getMessagePayload().getRegisteredResourceOutages()) {
			wrapper = new RegisteredResourceOutageWrapper();
			wrapper.setRegisteredResourceOutage(outage);
			if(outage.getActualPeriod()!=null){
				start = outage.getActualPeriod().getStart();
				end = outage.getActualPeriod().getEnd();
			}else if(outage.getEstimatedPeriod()!=null){
				start = outage.getEstimatedPeriod().getStart();
				end = outage.getEstimatedPeriod().getEnd();
			}
			long id = messagePayloadDAO.createMessagePayload(wrapper, messageId, outage.getMRID(), outage.getVersionID().longValue(),start, end);
			outageMap.put(id,outage);
		}
		return outageMap;
	}

	public ResourceOutageResultsCaiso getResourceOutage(long oid) {
		return messagePayloadDAO.getOutagePayload(oid, rs -> {
				try {
					while (rs.next()) {
						ResourceOutageResultsCaiso resourceOutage = new ResourceOutageResultsCaiso();
						MessageHeader header = new MessageHeader();
						resourceOutage.setMessageHeader(header);
						MessagePayload payload = new MessagePayload();
						resourceOutage.setMessagePayload(payload);
						GregorianCalendar c = new GregorianCalendar();
						c.setTime(new Date(rs.getTimestamp("TIME_DATE").getTime()));
						XMLGregorianCalendar date2;
						date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
						header.setTimeDate(date2);
						header.setSource(rs.getString("SOURCE"));
						header.setVersion(rs.getString("VERSION"));
						byte[] compressedData = rs.getBytes("PAYLOAD");
						ByteArrayOutputStream bytes = CAISOUtils.decompressBase64(compressedData);
						RegisteredResourceOutageWrapper outageWrapper = (RegisteredResourceOutageWrapper) SOAPUtils
								.unmarshal(RegisteredResourceOutageWrapper.class.getPackage().getName(),
										bytes.toString());
						payload.getRegisteredResourceOutages().add(outageWrapper.getRegisteredResourceOutage());
						return resourceOutage;
					}
				} catch (SQLException | DatatypeConfigurationException | IOException | JAXBException e) {
					throw new RCINTRuntimeException(e);
				}
				return null;
			});
	}
	public ResourceOutageResultsCaiso getResourceOutage(String mrid, XMLGregorianCalendar start, XMLGregorianCalendar end) throws RCINTApplicationException{
		String payloadXML = messagePayloadDAO.getOutagePayload(mrid, start, end, "RESOURCE");
		if(payloadXML!=null){
			ResourceOutageResultsCaiso resourceOutage = new ResourceOutageResultsCaiso();
			MessagePayload payload = new MessagePayload();
			resourceOutage.setMessagePayload(payload);
			RegisteredResourceOutageWrapper outageWrapper;
			try {
				outageWrapper = (RegisteredResourceOutageWrapper) SOAPUtils.unmarshal(RegisteredResourceOutageWrapper.class.getPackage().getName(), payloadXML);
				payload.getRegisteredResourceOutages().add(outageWrapper.getRegisteredResourceOutage());
				return resourceOutage;
			} catch (JAXBException e) {
				throw new RCINTApplicationException(e);
			}
		}
		return null;
	}

	public Map<Long,RegisteredResourceOutage> getOutagePayloadList(Set<String> outagedResources, PayloadStatus status) throws RCINTApplicationException {
		Map<Long,RegisteredResourceOutage> registeredResourceOutages = new HashMap<>();
		Map<Long, String> payloadMap = messagePayloadDAO.getOutagePayloadList(outagedResources, "RESOURCE", status);
		if(payloadMap!=null &&! payloadMap.isEmpty()){
			try {
				RegisteredResourceOutageWrapper outageWrapper;
				for(Entry<Long, String> entry:payloadMap.entrySet()){
					outageWrapper = (RegisteredResourceOutageWrapper) SOAPUtils.unmarshal(RegisteredResourceOutageWrapper.class.getPackage().getName(), entry.getValue());
					registeredResourceOutages.put(entry.getKey(), outageWrapper.getRegisteredResourceOutage());
				}
			} catch (JAXBException e) {
				throw new RCINTApplicationException(e);
			}
		}
		return registeredResourceOutages;
	}

}
