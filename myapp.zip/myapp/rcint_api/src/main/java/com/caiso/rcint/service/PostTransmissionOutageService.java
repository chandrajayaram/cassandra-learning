/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 7, 2017 11:44:11 AM
 * Project: rcint-app
 * File: SubmitPayloadController.java
 */
package com.caiso.rcint.service;

import com.caiso.rcint.entity.RCPublishPayload;

/**
 * @author gselvaratnam
 *
 */
public interface PostTransmissionOutageService {

    String resendPayload(RCPublishPayload rcPublishPayload);

}