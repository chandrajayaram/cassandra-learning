package com.caiso.rcint.outage.oms.generation;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caiso.rcint.dao.MessagePayloadDAO;
import com.caiso.rcint.dao.RCPublishPayloadDAO;
import com.caiso.rcint.dao.WECCOutageDataDAO;
import com.caiso.rcint.domain.PayloadStatus;
import com.caiso.rcint.outage.oms.common.OutagePublisher;
import com.caiso.rcint.outage.oms.common.WECCPayload;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.availabilityresultscaiso_v1.RegisteredGenerator;
import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;

@Service
public class GenerationOutageProcessor {

    public static final Logger logger = LoggerFactory.getLogger(GenerationOutageProcessor.class);

	@Autowired
	private MessagePayloadDAO messagePayloadDAO;
	@Autowired
	private RCPublishPayloadDAO rcPublishPayloadDAO;
	@Autowired
	private WECCOutageDataDAO weccOutageDataDAO;
	@Autowired
	private GenerationOutagePayloadGenerator generationOutagePayloadGenerator;
	@Autowired
	private OutagePublisher outagePublisher;
    
    private long saveCOSPayload(long oid, WECCPayload weccPayload) {
        try {
            ByteArrayOutputStream boutStream = new ByteArrayOutputStream();
            weccPayload.getWeccPayload().writeTo(boutStream);
            return rcPublishPayloadDAO.savePayload("WECC_OUTAGE", Utils.compress(boutStream.toByteArray()));
        } catch (Exception e) {
            logger.error("Error occoured while saving the generated cos payload", e);
            messagePayloadDAO.updateMessageStatus(oid, PayloadStatus.ERROR, "COS PAYLOAD PERSISTENCE FAILED");
            return -1;
        }
    }

    private int saveWECCOutageData(long oid, long payloadId, RegisteredResourceOutage outage, WECCPayload weccPayload) {
        try {
            weccPayload.addData("OID", oid);
            weccPayload.addData("OMS_OUTAGE_ID", outage.getMRID());
            weccPayload.addData("OMS_OUTAGE_VERSION", outage.getVersionID().longValue());
            weccPayload.addData("OMS_OUTAGE_STATUS", outage.getOutageStatus().value());
            weccPayload.addData("OMS_OUTAGE_TYPE", "GENERATION");
            weccPayload.addData("PAYLOAD_ID", payloadId);
            weccOutageDataDAO.saveWECCOutageData(weccPayload.getOutageData());
            return 0;
        } catch (Exception e) {
            logger.error("Error occoured while saving WECC OUTAGE DATE", e);
            messagePayloadDAO.updateMessageStatus(oid, PayloadStatus.ERROR, "WECC OUTAGE DATA SAVE FAILED");
            return -1;
        }
    }

	public void process(Long oid, RegisteredResourceOutage resourceOutage, List<RegisteredGenerator> registoredGenerators) {
    	WECCPayload weccPayload = generationOutagePayloadGenerator.process(resourceOutage, registoredGenerators);
    	 if (weccPayload == null) {
             return;
         }
    	 long payloadId = saveCOSPayload(oid, weccPayload);
         if (payloadId == -1) {
             return;
         }
         int status = saveWECCOutageData(oid, payloadId, resourceOutage, weccPayload);
         if (status == -1) {
             return;
         }
        outagePublisher.process(payloadId, weccPayload);
	}
}
