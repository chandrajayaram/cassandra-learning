/**
 * 
 */
package com.caiso.rcint.dao;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.entity.RCPublishPayload;

/**
 * @author gselvaratnam
 *
 */
@Repository
public interface RCPublishPayloadRepository extends JpaRepository<RCPublishPayload, Long> {

    @Modifying
    @Query(value = "Update RC_PUBLISH_PAYLOAD rcpp SET rcpp.STATUS=?1, rcpp.UPDATED_DTS = ?2 WHERE rcpp.PAYLOAD_ID IN (Select rcod.ID from RC_OUTAGE_DATA rcod where rcod.WECC_OUTAGE_ID < ?3 And rcod.WECC_REVISION_NUMBER = ?4 And rcod.OMS_OUTAGE_ID != NULL)", nativeQuery = true)
    public void updateStatusAll(String status, Date updatedDate, String weccOutageId, Long weccRevisionNumber);

    @Modifying
    @Query("Update RCPublishPayload rcpp Set rcpp.status = ?1, rcpp.response = ?2, rcpp.retry = rcpp.retry + 1, rcpp.updatedDate = ?3 Where rcpp.payloadId = ?4")
    public void updateStatusAndResponseByPayloadId(String status, String response, Date updatedDate, Long payloadId);
}
