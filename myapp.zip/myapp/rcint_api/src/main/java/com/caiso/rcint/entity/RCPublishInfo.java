/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.entity;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
@Entity
@Table(name = "RC_PUBLISH_INFO")
public class RCPublishInfo implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    @Id
    @Column(name = "TYPE_ID", nullable = false)
    private Long              typeId;

    @Column(name = "TYPE_NAME", nullable = false)
    private String            typeName;

    @Column(name = "PROTOCOL", nullable = false)
    private String            protocall;

    @Column(name = "ACTION", nullable = false)
    private String            action;

    @Column(name = "DESTINATION", nullable = false)
    private String            destination;

    @Column(name = "ENABLED", nullable = false)
    private String            enabled;

    @Column(name = "DESCRIPTION", nullable = true)
    private String            description;

    @Column(name = "GROUP_NAME", nullable = true)
    private String            groupName;

    @Column(name = "SOAP_ACTION", nullable = true)
    private String            soapAction;

    /**
     * @return the typeId
     */
    public Long getTypeId() {
        return typeId;
    }

    /**
     * @param typeId
     *            the typeId to set
     */
    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    /**
     * @return the typeName
     */
    public String getTypeName() {
        return typeName;
    }

    /**
     * @param typeName
     *            the typeName to set
     */
    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    /**
     * @return the protocall
     */
    public String getProtocall() {
        return protocall;
    }

    /**
     * @param protocall
     *            the protocall to set
     */
    public void setProtocall(String protocall) {
        this.protocall = protocall;
    }

    /**
     * @return the action
     */
    public String getAction() {
        return action;
    }

    /**
     * @param action
     *            the action to set
     */
    public void setAction(String action) {
        this.action = action;
    }

    /**
     * @return the destination
     */
    public String getDestination() {
        return destination;
    }

    /**
     * @param destination
     *            the destination to set
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }

    /**
     * @return the enabled
     */
    public String getEnabled() {
        return enabled;
    }

    /**
     * @param enabled
     *            the enabled to set
     */
    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the groupName
     */
    public String getGroupName() {
        return groupName;
    }

    /**
     * @param groupName
     *            the groupName to set
     */
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    /**
     * @return the soapAction
     */
    public String getSoapAction() {
        return soapAction;
    }

    /**
     * @param soapAction
     *            the soapAction to set
     */
    public void setSoapAction(String soapAction) {
        this.soapAction = soapAction;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final RCPublishInfo other = (RCPublishInfo) obj;
        return Objects.equals(this.typeId, other.typeId) && Objects.equals(this.typeName, other.typeName) && Objects.equals(this.protocall, other.protocall)
                && Objects.equals(this.action, other.action) && Objects.equals(this.destination, other.destination)
                && Objects.equals(this.enabled, other.enabled) && Objects.equals(this.description, other.description)
                && Objects.equals(this.groupName, other.groupName) && Objects.equals(this.soapAction, other.soapAction);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.typeId, this.typeName, this.protocall, this.action, this.destination, this.enabled, this.description, this.groupName,
                this.soapAction);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}