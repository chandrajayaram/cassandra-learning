/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 24, 2017 3:51:46 PM
 * Project: rcint-app
 * File: PostRegulatoryAuthorityOutageStatusService.java
 */
package com.caiso.rcint.service;

import com.caiso.rcint.entity.RCPublishPayload;

/**
 * @author gselvaratnam
 *
 */
public interface PostRegulatoryAuthorityOutageStatusService {

    String resendPayload(RCPublishPayload rcPublishPayload);

}