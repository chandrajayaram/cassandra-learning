package com.caiso.rcint.domain;

public enum PayloadType {
    OMS_TRANS_OUTAGE("OMS_TRANS_OUTAGE"), OMS_TRANS_OUTAGE_CHANGE_REQUEST("OMS_TRANS_OUTAGE_CHANGE_REQUEST"), OMS_RESOURCE_OUTAGE(
            "OMS_RESOURCE_OUTAGE"), OMS_RESOURCE_OUTAGE_CHANGE_REQUEST(
                    "OMS_RESOURCE_OUTAGE_CHANGE_REQUEST"), WECC_OUTAGE("WECC_OUTAGE"), OMS_REGULATORY_AUTH_RESPONSE("OMS_REGULATORY_AUTH_RESPONSE");

    private String payloadType;

    private PayloadType(String payloadType) {
        this.payloadType = payloadType;
    }

    public String getPayloadType() {
        return payloadType;
    }

}
