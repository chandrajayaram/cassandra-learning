/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 3, 2017 12:13:29 PM
 * Project: rcint-app
 * File: CosSubmitTransmissionOutageServiceImpl.java
 */
package com.caiso.rcint.outage.cos;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.caiso.rcint.dao.WECCOutageData;
import com.caiso.rcint.domain.CosOutageStatusType;
import com.caiso.rcint.domain.RCPublishInfoType;
import com.caiso.rcint.domain.RCPublishPayloadType;
import com.caiso.rcint.entity.RCOutage;
import com.caiso.rcint.entity.RCOutageData;
import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.outage.oms.CosOutageDataMapper;
import com.caiso.rcint.service.RCProcessLogService;
import com.caiso.rcint.service.SaveInNewTransactionService;
import com.caiso.rcint.service.WebServiceCallOutService;
import com.caiso.rcint.util.DateUtil;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.transmissionoutagedata_v1.TransmissionOutageData;

import ca.equinox.crow.OutageSchedule;
import ca.equinox.crow.ReturnedOutage;

/**
 * @author gselvaratnam
 *
 */
@Service
public class CosSubmitTransmissionOutageServiceImpl extends BaseCosSubmitTransmissionOutageProcessor implements CosSubmitTransmissionOutageService {

    private static final Logger                       logger                        = LoggerFactory.getLogger(CosSubmitTransmissionOutageServiceImpl.class);

    public static final String                        LOG_EVT_TYPE_PROCESS_CONTINUE = "PROCESS_CONTINUE";

    @Autowired
    protected WebServiceCallOutService                webServiceCallOutService;

    @Autowired
    protected SaveInNewTransactionService             saveInNewTransactionService;

    @Autowired
    protected SubmitTransmissionOutageResponseHandler submitTransmissionOutageResponseHandler;

    @Autowired
    private ReceiveRegulatoryAuthorityOutageStatusService receiveRegulatoryAuthorityOutageStatusService;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.caiso.rcint.outage.oms.service.OmsSubmitTransmissionOutageService#
     * processSubmitTransmissionOutage(ca.equinox.crow.ReturnedOutage,
     * java.util.List, boolean, java.lang.String)
     */
    @Override
    public void processSubmitTransmissionOutage(ReturnedOutage returnedOutage, List<WECCOutageData> weccOutageDataList, boolean bWeccOutagePublishedToOMS,
            String logRefId) {

        logger.debug("Begin::CosSubmitTransmissionOutageServiceImpl::processReturnedOutage");

        rcProcessLogService.createLogEntry(LOG_EVT_TYPE_PROCESS_CONTINUE, logRefId, "CosSubmitTransmissionOutageServiceImpl", "processSubmitTransmissionOutage",
                "starting the process");

        try {
            String soapRequestXml;
            SaajSoapMessage loadItemSoapMessage;
            String weccOutageNumber = returnedOutage.getOutageNumber();

            String outageStatus = returnedOutage.getOutageStatus();
            String revisionNumber = String.valueOf(returnedOutage.getRevisionNumber());

            rcProcessLogService.createLogEntry(LOG_EVT_TYPE_PROCESS_CONTINUE, logRefId, "CosSubmitTransmissionOutageServiceImpl",
                    "processSubmitTransmissionOutage", "Calling COS OutageSchedule_LoadItem");

            soapRequestXml = webServiceCallOutService.getPeakOutageSchedule_LoadItemSoapXMLString(weccOutageNumber, revisionNumber);
            String outSchedule_LoadItmSoapResponse = webServiceCallOutService.callPeakCosWebService(soapRequestXml,
                    "http://crow.equinox.ca/OutageSchedule_LoadItem");

            OutageSchedule outageEquipInfo = findOutageSchedule(outSchedule_LoadItmSoapResponse);

            // RLAM: CAPTURE THE EQUIPMENT MAP FROM GENERATING THE OUTAGE
            // OBJECT
            StringBuffer equipmentMap = new StringBuffer();

            TransmissionOutageData omsOutageDataObject = createTransmissionOutageData(returnedOutage, outageEquipInfo, weccOutageDataList, equipmentMap, logRefId);

            RCOutage rcOutage = new RCOutage();
            rcOutage.setControlArea(returnedOutage.getOperatedByControlCenters());
            rcOutage.setCreatedDate(new Date());
            rcOutage.setDuration(String.valueOf(returnedOutage.getDuration()));
            rcOutage.setDurationUnit(returnedOutage.getDurationUnits());
            rcOutage.setOutageStart(returnedOutage.getSwitchingStart());
            rcOutage.setOutageEnd(returnedOutage.getRestorationComplete());
            rcOutage.setOutageType(returnedOutage.getContinuousDaily());
            rcOutage.setUpdatedDate(new Date());
            rcOutage.setWeccOutageId(returnedOutage.getOutageNumber());
            rcOutage = saveInNewTransactionService.saveNewRCOutage(rcOutage);

            // PERSIST THE WECC PAYLOAD DATA INTO RC_OUTAGE_DATA
            RCOutageData rcOutageData = new RCOutageData();
            rcOutageData.setWeccOutageId(rcOutage.getWeccOutageId());
            rcOutageData.setWeccRevisionNumber(Long.valueOf(revisionNumber));
            rcOutageData.setWeccOutageStatus(outageStatus);
            rcOutageData.setWeccEquipmentData(Utils.compress(outSchedule_LoadItmSoapResponse));
            String weccOutageType = CosOutageDataMapper.mapCosOutagePriorityName(outageEquipInfo.getOutagePriority());
            rcOutageData.setWeccOutageType(weccOutageType);

            ca.equinox.crow.ObjectFactory objectFactory = new ca.equinox.crow.ObjectFactory();
            QName qName = new QName("http://crow.equinox.ca/", returnedOutage.toString());
            JAXBElement<ReturnedOutage> jaxbElement = new JAXBElement(qName, returnedOutage.getClass(), returnedOutage);

            rcOutageData.setWeccOutageData(Utils.compress(Utils.marshallToString(jaxbElement, objectFactory.createOutageRequestQueryExecuteQueryResponse())));
            rcOutageData.setEquipmentMap(equipmentMap.toString().replace("'", "^"));
            rcOutageData.setCreatedDate(new Date());
            rcOutageData.setUpdatedDate(new Date());

            rcOutageData = saveInNewTransactionService.createOrUpdateRcOutageData(rcOutageData);
            Long rcOutageDataId = rcOutageData.getId();

            if (omsOutageDataObject != null) {

                String omsOutagePayload = Utils.marshallToString(omsOutageDataObject, omsOutageDataObject);

                String payloadType = getPayloadType(bWeccOutagePublishedToOMS);

                RCPublishPayload rcPublishPayload = new RCPublishPayload();
                rcPublishPayload.setPayloadType(payloadType);
                rcPublishPayload.setStatus(RCPublishPayloadType.NEW.name());
                rcPublishPayload.setData(Utils.compress(omsOutagePayload));
                rcPublishPayload.setCreatedDate(new Date());
                rcPublishPayload.setUpdatedDate(new Date());
                rcPublishPayload = saveInNewTransactionService.createOrUpdateRCPublishPayload(rcPublishPayload);

                saveInNewTransactionService.updateRCOutageData(rcPublishPayload.getPayloadId(), Utils.compress(omsOutagePayload), rcOutageDataId);

                String responseOmsId = submitTransmissionOutageResponseHandler.handleResponse(omsOutageDataObject, logRefId, rcPublishPayload.getPayloadId());

                if (!StringUtils.isEmpty(responseOmsId)) {
                    
                    String attachmentXml = webServiceCallOutService.getOmsAttachementRegulatoryAuthorityOutageStatusXMLString(
                            DateUtil.convertToXmlGregorianCalendar(new Date()).toString(), responseOmsId, revisionNumber, null, weccOutageNumber,
                            "PENDING");

                    Map<String, Object> response = receiveRegulatoryAuthorityOutageStatusService.executeService(attachmentXml, null);

                    saveInNewTransactionService.updateRCOutageData((Long) response.get(ReceiveRegulatoryAuthorityOutageStatusService.EXECUTE_SERVICE_PAYLOAD_ID), 
                            rcOutageData.getId());
                }

                saveInNewTransactionService.cancelPriorFailedPublishPayload(weccOutageNumber, Long.valueOf(revisionNumber), CosOutageStatusType.REVISED);
            }
        } catch (RCINTRuntimeException rcintRuntimeException) {
            throw rcintRuntimeException;
        } catch (RCINTApplicationException rcintApplicationException) {
            throw new RCINTRuntimeException(rcintApplicationException);
        } catch (Exception exception) {
            throw new RCINTRuntimeException(exception);
        }
        logger.debug("End::OmsSubmitTransmissionOutageService::processReturnedOutage");
    }
}
