package com.caiso.rcint.outage.oms.transmission;

import java.io.ByteArrayOutputStream;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.rcint.dao.MessagePayloadDAO;
import com.caiso.rcint.dao.RCPublishPayloadDAO;
import com.caiso.rcint.dao.WECCOutageDataDAO;
import com.caiso.rcint.domain.PayloadStatus;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.common.OutagePublisher;
import com.caiso.rcint.outage.oms.common.WECCPayload;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutage;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

@Service
@Transactional
public class TransmissionOutageProcessorImpl implements TransmissionOutageProcessor {
	public static final Logger logger = LoggerFactory.getLogger(TransmissionOutageProcessorImpl.class);

	private TransmissionOutageSubmissionCriteria submissionCriteria;
	private TransmissionOutageDAO transmissionOutageDAO;
	private RCPublishPayloadDAO rcPublishPayloadDAO;
	private WECCOutageDataDAO weccOutageDataDAO;
	private TranmissionOutagePayloadGenerator tranmissionOutagePayloadGenerator;
	private OutagePublisher outagePublisher;
	private MessagePayloadDAO messagePayloadDAO;
	
	@Autowired
	public void setMessagePayloadDAO(MessagePayloadDAO messagePayloadDAO) {
		this.messagePayloadDAO = messagePayloadDAO;
	}

	@Autowired
	public void setCosService(OutagePublisher outagePublisher) {
		this.outagePublisher = outagePublisher;
	}

	@Autowired
	public void setRcPublishPayloadDAO(RCPublishPayloadDAO rcPublishPayloadDAO) {
		this.rcPublishPayloadDAO = rcPublishPayloadDAO;
	}

	@Autowired
	public void setTranmissionOutagePayloadGenerator(
			TranmissionOutagePayloadGenerator tranmissionOutagePayloadGenerator) {
		this.tranmissionOutagePayloadGenerator = tranmissionOutagePayloadGenerator;
	}

	@Autowired
	public void setTransmissionOutageDAO(TransmissionOutageDAO transmissionOutageDAO) {
		this.transmissionOutageDAO = transmissionOutageDAO;
	}

	@Autowired
	public void setWeccOutageDataDAO(WECCOutageDataDAO weccOutageDataDAO) {
		this.weccOutageDataDAO = weccOutageDataDAO;
	}

	@Autowired
	public void setSubmissionCriteria(TransmissionOutageSubmissionCriteria submissionCriteria) {
		this.submissionCriteria = submissionCriteria;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.caiso.rcint.transmissionoutage.TransmissionOutageService#process(com.
	 * caiso.soa.transmissionoutageresultscaiso_v2.
	 * TransmissionOutageResultsCaiso)
	 */
	@Override
	public void process(TransmissionOutageResultsCaiso transOutageResults) throws RCINTApplicationException {
		Map<Long, TransmissionOutage> outageMap = createTORTransmissionOutage(transOutageResults);
		if (outageMap == null) {
			return;
		}
		for(Entry<Long, TransmissionOutage> entry:  outageMap.entrySet()){
			long oid = entry.getKey();
			TransmissionOutage outage = entry.getValue();
			if(!isSubmissionCriteriaMet(oid, outage)){
				return;
			}
			WECCPayload weccPayload = generateCOSPayload(oid, outage);
			if (weccPayload == null) {
				return;
			}
			long payloadId = saveCOSPayload(oid, weccPayload);
			if (payloadId == -1) {
				return;
			}
			int status = saveWECCOutageData(oid, payloadId, outage, weccPayload);
			if (status == -1) {
				return;
			}
			outagePublisher.process(payloadId, weccPayload);
		}
	}

	private boolean isSubmissionCriteriaMet(Long oid, TransmissionOutage outage) {
		try {
			if (!submissionCriteria.isSubmissionCriteriaMet(outage)) {
				logger.info("Submission criteria was not met");
				messagePayloadDAO.updateMessageStatus(oid, PayloadStatus.IGNORED,"SUBMISSION-CRITERIA-NOT-MET");
				return false;
			}
			return true;
		} catch (Exception e) {
			logger.error("Error occoured while checking the submission criteria", e);
			messagePayloadDAO.updateMessageStatus(oid, PayloadStatus.ERROR,  "ERROR CHECKING SUBMISSION CRITERIA");
			return false;
		}
	}
	private Map<Long, TransmissionOutage> createTORTransmissionOutage(
			TransmissionOutageResultsCaiso transOutageResults) {
		try {
			return transmissionOutageDAO.createTORTransmissionOutage(transOutageResults);

		} catch (RCINTApplicationException e) {
			logger.error("Error occoured while saving the transmission outage", e);
			return null;
		}
	}

	private WECCPayload generateCOSPayload(Long oid, TransmissionOutage outage) {
		try {
			return tranmissionOutagePayloadGenerator.generatePayload(oid, outage);
		} catch (RCINTApplicationException e) {
			logger.error("Error occoured while generating the payload", e);
			messagePayloadDAO.updateMessageStatus(oid, PayloadStatus.ERROR, "COS PAYLOAD GENERATION FAILED");
			return null;
		}
	}

	private long saveCOSPayload(long oid, WECCPayload weccPayload) {
		try {
			ByteArrayOutputStream boutStream = new ByteArrayOutputStream();
			weccPayload.getWeccPayload().writeTo(boutStream);
			return rcPublishPayloadDAO.savePayload("WECC_OUTAGE", Utils.compress(boutStream.toByteArray()));
		} catch (Exception e) {
			logger.error("Error occoured while saving the generated cos payload", e);
			messagePayloadDAO.updateMessageStatus(oid, PayloadStatus.ERROR, "COS PAYLOAD PERSISTENCE FAILED");
			return -1;
		}
	}
	
	private int saveWECCOutageData(long oid, long payloadId, TransmissionOutage outage, WECCPayload weccPayload) {
		try {
			weccPayload.addData("OID", oid);
			weccPayload.addData("OMS_OUTAGE_ID", outage.getMRID());
			weccPayload.addData("OMS_OUTAGE_VERSION", outage.getVersionID().longValue());
			weccPayload.addData("OMS_OUTAGE_STATUS", outage.getOutageStatus().value());
			weccPayload.addData("OMS_OUTAGE_TYPE", "TRANSMISSION");
			weccPayload.addData("PAYLOAD_ID", payloadId);
			weccOutageDataDAO.saveWECCOutageData(weccPayload.getOutageData());
			return 0;
		} catch (Exception e) {
			logger.error("Error occoured while saving WECC OUTAGE DATE", e);
			messagePayloadDAO.updateMessageStatus(oid, PayloadStatus.ERROR, "WECC OUTAGE DATA SAVE FAILED");
			return -1;
		}
	}
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.caiso.rcint.transmissionoutage.TransmissionOutageProcessor#
	 * processAsync(com.caiso.soa.transmissionoutageresultscaiso_v2.
	 * TransmissionOutageResultsCaiso)
	 */
	@Override
	@Async
	public void processAsync(TransmissionOutageResultsCaiso transOutageResults) throws RCINTApplicationException {
		process(transOutageResults);
	}

}
