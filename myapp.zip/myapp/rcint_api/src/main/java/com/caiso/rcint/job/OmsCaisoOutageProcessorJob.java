package com.caiso.rcint.job;

import java.util.TimeZone;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.caiso.rcint.domain.RCIntConstants;
import com.caiso.rcint.outage.cos.CosCaisoOutageProcessorService;
import com.caiso.rcint.outage.cos.CosOutageProcessorService;

@DisallowConcurrentExecution
public class OmsCaisoOutageProcessorJob extends QuartzJobBean {

    private static final Logger logger = LoggerFactory.getLogger(OmsCaisoOutageProcessorJob.class);

    @Autowired
    private CosCaisoOutageProcessorService omsCaisoOutageProcessorService;

    public OmsCaisoOutageProcessorJob() {
        super();
        TimeZone.setDefault(RCIntConstants.DEFAULT_TIME_ZONE);
    }

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        logger.info("BEGIN::OmsCaisoOutageProcessorJob.executeInternal");

        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();

        omsCaisoOutageProcessorService.processOmsOutages();

        logger.info("END::OmsCaisoOutageProcessorJob.executeInternal");
    }
}
