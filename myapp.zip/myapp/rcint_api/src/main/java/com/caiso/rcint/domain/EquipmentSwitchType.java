/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 25, 2017 2:15:35 PM
 * Project: rcint-app
 * File: EquipmentSwitchType.java
 */
package com.caiso.rcint.domain;

/**
 * @author gselvaratnam
 *
 */
public enum EquipmentSwitchType {
    DISCONNECT, BREAKER, SWITCH;
}
