/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 13, 2017 3:45:25 PM
 * Project: caiso-rcint_api
 * File: DbPropertyService.java
 */
package com.caiso.rcint.service;

import com.caiso.rcint.entity.RCPublishInfo;

/**
 * @author gselvaratnam
 *
 */
public interface DbPropertyService {

    void createOrUpdateProperty(String propertyName, String value);

    String getProperty(String propertyName);

    RCPublishInfo getRCPublishInfo(String typeName);

}