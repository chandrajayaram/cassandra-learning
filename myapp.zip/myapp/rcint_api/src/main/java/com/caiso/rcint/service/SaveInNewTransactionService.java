/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 23, 2017 4:58:18 PM
 * Project: caiso-rcint_api
 * File: SaveInNewTransactionService.java
 */
package com.caiso.rcint.service;

import java.util.Date;

import com.caiso.rcint.domain.CosOutageStatusType;
import com.caiso.rcint.entity.RCOutage;
import com.caiso.rcint.entity.RCOutageData;
import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.entity.WeccOutageRegAuthUpdate;

/**
 * @author gselvaratnam
 *
 */
public interface SaveInNewTransactionService {

    void updateRCOutageDataAndRCPublishPayloadforCancellation(CosOutageStatusType cosOutageStatusType, String weccOutageNumber, Long revisionNumber);

    RCOutage saveNewRCOutage(RCOutage rcOutage);

    RCOutageData createOrUpdateRcOutageData(RCOutageData rcOutageData);

    RCPublishPayload createOrUpdateRCPublishPayload(RCPublishPayload rcPublishPayload);

    void updateRCOutageData(Long payloadId, byte [] omsOutagePayload, Long rcOutageDataId);

    void cancelPriorFailedPublishPayload(String weccOutageNumber, Long revisionNumber, CosOutageStatusType cosOutageStatusType);

    void updateRCOutageDataOmsOutageId(String omsOutageId, Long payloadId);

    void updateStatusAndResponseByPayloadId(String status, String response, Long payloadId);

    void updateRCOutageData(Long regAuthPayloadId, Long payloadId);

    void updateWECCOutageData(String weccOutageStatus, String weccOutageType, Long   oid);

    void createOrUpdateWeccOutageRegAuthUpdate(WeccOutageRegAuthUpdate weccOutageRegAuthUpdate);

}
