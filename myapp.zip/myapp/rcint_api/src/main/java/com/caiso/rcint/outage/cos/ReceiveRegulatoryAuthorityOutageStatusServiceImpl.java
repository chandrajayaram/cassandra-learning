/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 24, 2017 1:40:13 PM
 * Project: rcint-app
 * File: ReceiveRegulatoryAuthorityOutageStatusServiceImpl.java
 */
package com.caiso.rcint.outage.cos;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.soap.MessageFactory;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;

import com.caiso.rcint.dao.RCPublishPayloadRepository;
import com.caiso.rcint.domain.RCPublishInfoType;
import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.service.SaveInNewTransactionService;
import com.caiso.rcint.service.WebServiceCallOutService;
import com.caiso.rcint.util.Utils;
import com.caiso.soa._2006_06_13.standardoutput.EventLog;
import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;

/**
 * @author gselvaratnam
 *
 */
@Service
public class ReceiveRegulatoryAuthorityOutageStatusServiceImpl implements ReceiveRegulatoryAuthorityOutageStatusService {

    @Autowired
    private WebServiceCallOutService    webServiceCallOutService;

    @Autowired
    private SaveInNewTransactionService saveInNewTransactionService;

    @Autowired
    private RCPublishPayloadRepository  rcPublishPayloadRepository;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.caiso.rcint.outage.cos.ReceiveRegulatoryAuthorityOutageStatusService#
     * executeService(com.caiso.rcint.dao.WECCOutageData, java.lang.String,
     * java.lang.Long)
     */
    @Override
    public Map<String, Object> executeService(String attachmentXml, Long payloadId) {

        Map<String, Object> response = new HashMap<>();
        String receiveRegAuthOutStatusResponse = null;

        String soapRequestXml = webServiceCallOutService.getOmsReceiveRegulatoryAuthorityOutageStatus_v1SoapXMLString();

        boolean exceptionOccured = false;
        try {
            receiveRegAuthOutStatusResponse = webServiceCallOutService.callOmsWebService_soap_11(soapRequestXml, attachmentXml,
                    RCPublishInfoType.OMS_REGULATORY_AUTH_RESPONSE);
        } catch (Exception exception) {
            receiveRegAuthOutStatusResponse = exception.getMessage();
            exceptionOccured = true;
        }

        RCPublishPayload rcPublishPayload = null;
        if (payloadId == null) {
            rcPublishPayload = new RCPublishPayload();
            rcPublishPayload.setPayloadType("OMS_REGULATORY_AUTH_RESPONSE");

            setupStatus(receiveRegAuthOutStatusResponse, rcPublishPayload, exceptionOccured);

            rcPublishPayload.setData(attachmentXml.getBytes());
            rcPublishPayload.setCreatedDate(new Date());
            rcPublishPayload.setUpdatedDate(new Date());

            rcPublishPayload = saveInNewTransactionService.createOrUpdateRCPublishPayload(rcPublishPayload);
            payloadId = rcPublishPayload.getPayloadId();
        } else {
            rcPublishPayload = rcPublishPayloadRepository.findOne(payloadId);
            if (rcPublishPayload == null) {
                throw new RCINTRuntimeException("Could not find Payload using payloadId : " + payloadId);
            }

            setupStatus(receiveRegAuthOutStatusResponse, rcPublishPayload, exceptionOccured);
            rcPublishPayload.setUpdatedDate(new Date());

            rcPublishPayload = saveInNewTransactionService.createOrUpdateRCPublishPayload(rcPublishPayload);
        }
        response.put(ReceiveRegulatoryAuthorityOutageStatusService.EXECUTE_SERVICE_RESPONSE, receiveRegAuthOutStatusResponse);
        response.put(ReceiveRegulatoryAuthorityOutageStatusService.EXECUTE_SERVICE_PAYLOAD_ID, payloadId);

        return response;
    }

    /**
     * @param receiveRegAuthOutStatusResponse
     * @param rcPublishPayload
     */
    private void setupStatus(String receiveRegAuthOutStatusResponse, RCPublishPayload rcPublishPayload, boolean exceptionOccured) {
        if (receiveRegAuthOutStatusResponse.contains("SUCCESS")) {
            rcPublishPayload.setStatus("ACCEPTED");
            rcPublishPayload.setResponse("SUCCESS");
        } else {
            if (exceptionOccured) {
                rcPublishPayload.setStatus("REJECTED");
                receiveRegAuthOutStatusResponse = Utils.substring(receiveRegAuthOutStatusResponse, 1000);
                rcPublishPayload.setResponse(receiveRegAuthOutStatusResponse);
            } else {
                OutputDataType outputDataType = findOutputDataType(receiveRegAuthOutStatusResponse);

                receiveRegAuthOutStatusResponse = findComments(outputDataType);

                rcPublishPayload.setStatus("REJECTED");
                receiveRegAuthOutStatusResponse = Utils.substring(receiveRegAuthOutStatusResponse, 1000);
                rcPublishPayload.setResponse(receiveRegAuthOutStatusResponse);
            }
        }
    }

    /**
     * @param outputDataType
     * @return
     */
    private String findComments(OutputDataType outputDataType) {
        String response;
        StringBuilder commentsBuilder = new StringBuilder();
        List<EventLog> eventLogList = outputDataType.getEventLog();
        if (!CollectionUtils.isEmpty(eventLogList)) {
            for (EventLog eventLog : eventLogList) {
                List<com.caiso.soa._2006_06_13.standardoutput.Service> serviceList = eventLog.getService();
                if (!CollectionUtils.isEmpty(serviceList)) {
                    for (com.caiso.soa._2006_06_13.standardoutput.Service newService : serviceList) {
                        commentsBuilder.append(newService.getComments());
                        commentsBuilder.append(" ");
                    }
                }
            }
        }
        response = commentsBuilder.toString();
        return response;
    }

    private OutputDataType findOutputDataType(String receiveRegAuthOutStatusResponse) {
        OutputDataType outputDataType = null;

        try {
            MessageFactory mf = MessageFactory.newInstance();
            SaajSoapMessageFactory saajSoapMessageFactory = new SaajSoapMessageFactory(mf);
            InputStream stream = new ByteArrayInputStream(receiveRegAuthOutStatusResponse.getBytes(StandardCharsets.UTF_8));
            SaajSoapMessage saajSoapMessage = saajSoapMessageFactory.createWebServiceMessage(stream);
            String soapBodyStr = extractSoapBodyAsString(saajSoapMessage);

            JAXBContext jaxbContext = JAXBContext.newInstance("com.caiso.soa._2006_06_13.standardoutput");
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            JAXBElement<OutputDataType> root = jaxbUnmarshaller.unmarshal(new StreamSource(new StringReader(soapBodyStr)), OutputDataType.class);
            outputDataType = root.getValue();

            if (outputDataType == null) {
                throw new RCINTRuntimeException("com.caiso.soa._2006_06_13.standardoutput.OutputDataType cannot be null");
            }
        } catch (Exception exception) {
            throw new RCINTRuntimeException(exception);
        }

        return outputDataType;
    }

    private String extractSoapBodyAsString(SaajSoapMessage soapMessage) {
        String responseStr;
        final StringWriter sw = new StringWriter();
        try {
            TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSoapBody().getPayloadSource(), new StreamResult(sw));
        } catch (Exception exception) {
            throw new RCINTRuntimeException(exception);
        }
        responseStr = new String(sw.toString());
        return responseStr;
    }
}
