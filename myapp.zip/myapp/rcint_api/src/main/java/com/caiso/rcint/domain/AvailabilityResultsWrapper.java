package com.caiso.rcint.domain;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.caiso.soa.availabilityresultscaiso_v1.RegisteredGenerator;

@XmlRootElement(name="AvailabilityResultsWrapper")
public class AvailabilityResultsWrapper {
	
	protected List<RegisteredGenerator> registeredGenerators;
	
	@XmlElement(name="RegisteredGenerator")
	public List<RegisteredGenerator> getRegisteredGenerators() {
		if(registeredGenerators == null){
			registeredGenerators = new ArrayList<>();
		}
		return registeredGenerators;
	}

	public void setRegisteredGenerators(List<RegisteredGenerator> registeredGenerators) {
		this.registeredGenerators = registeredGenerators;
	}
	 
}
