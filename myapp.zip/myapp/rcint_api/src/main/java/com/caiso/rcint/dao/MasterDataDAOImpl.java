package com.caiso.rcint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.domain.WECCEquipment;

@Repository
public class MasterDataDAOImpl implements MasterDataDAO {

    @Autowired
	private NamedParameterJdbcTemplate rcintJdbcTemplate;

	private static final String selectWECCEquipments = "SELECT SUBSTATION,EQ_NAME,BASEVOLTAGE,EQ_TYPE,RDFID,SUBSTATION_LONGNAME,MOD_SWITCH_LABEL,"+
			"LINE_TYPE,COS_LABEL,SUB_CONTROL_AREA FROM WECC_EQUIPMENTS WHERE RDFID IN(:RDFIDS)";
	
	
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.MasterDataDAO#findWECCEquipment(java.util.Set)
     */
	@Override
    public Map<String,WECCEquipment> findWECCEquipment(Set<String> rdfids){
		final Map<String,WECCEquipment> exuipments = new HashMap<String, WECCEquipment>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("RDFIDS", rdfids);
		rcintJdbcTemplate.query(selectWECCEquipments,parameters, new ResultSetExtractor<Map<String,WECCEquipment>>(){
			@Override
			public Map<String, WECCEquipment> extractData(ResultSet rs) throws SQLException  {
				WECCEquipment equipment; 
				while(rs.next()){
					equipment = new WECCEquipment();
					equipment.setSubStation(rs.getString("SUBSTATION")); 
					equipment.setEqNname(rs.getString("EQ_NAME")); 
					equipment.setBaseVoltage(rs.getString("BASEVOLTAGE")); 
					equipment.setEqType(rs.getString("EQ_TYPE"));   
					equipment.setRdfid(rs.getString("RDFID"));   
					equipment.setSubstationLongname(rs.getString("SUBSTATION_LONGNAME"));   
					equipment.setModSwitchLabel(rs.getString("MOD_SWITCH_LABEL"));  
					equipment.setLineType(rs.getString("LINE_TYPE"));   
					equipment.setCosLabel(rs.getString("COS_LABEL"));  
					equipment.setSubControlArea(rs.getString("SUB_CONTROL_AREA"));
					exuipments.put(rs.getString("RDFID"), equipment);
				}
				return exuipments;
			}
		});
		return exuipments;
	}
	          
	
  
}
