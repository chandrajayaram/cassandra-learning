package com.caiso.rcint.dao;

import static com.caiso.rcint.util.Utils.dateToSqlTimeStampFn;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class WECCOutageDataDAOImpl implements WECCOutageDataDAO {
	public static final Logger logger = LoggerFactory.getLogger(WECCOutageDataDAOImpl.class);

	private static final String WECC_OUTAGE_DATA_FIND_BY_WECC_OUTAGE_ID = "SELECT * FROM WECC_OUTAGE_DATA WHERE WECC_OUTAGE_ID = :WECC_OUTAGE_ID";
	private static final String WECC_OUTAGE_DATA_INSERT_QUERY ="INSERT INTO WECC_OUTAGE_DATA(OID, OMS_OUTAGE_ID, OMS_OUTAGE_VERSION, OMS_OUTAGE_STATUS , OMS_OUTAGE_TYPE, EQUIPMENT_NAME, OUTAGE_START_DTS, OUTAGE_END_DTS, PAYLOAD_ID, CREATED_DTS, UPDATED_DTS, UPDATED_BY) VALUES (:OID, :OMS_OUTAGE_ID, :OMS_OUTAGE_VERSION, :OMS_OUTAGE_STATUS , :OMS_OUTAGE_TYPE, :EQUIPMENT_NAME, :OUTAGE_START_DTS, :OUTAGE_END_DTS, :PAYLOAD_ID, sysdate, sysdate, 'RCINTAPI')";
	private static final String UPDATE_WECC_OUTAGE_DATA_WITH_WECC_ID = "UPDATE WECC_OUTAGE_DATA SET WECC_OUTAGE_ID = :WECC_OUTAGE_ID,WECC_OUTAGE_TYPE=:WECC_OUTAGE_TYPE,WECC_OUTAGE_STATUS=:WECC_OUTAGE_STATUS, UPDATED_DTS = :UPDATED_DTS, UPDATED_BY = :UPDATED_BY WHERE PAYLOAD_ID = :PAYLOAD_ID";
	private static final String UPDATE_WECC_OUTAGE_DATE_WITH_REG_AUTH_PAYLOAD_ID = "UPDATE WECC_OUTAGE_DATA SET REG_AUTH_PAYLOAD_ID = :REG_AUTH_PAYLOAD_ID, UPDATED_DTS = :UPDATED_DTS, UPDATED_BY = :UPDATED_BY WHERE PAYLOAD_ID = :PAYLOAD_ID";
	private static final String SELECT_WECC_OUTAGE_ID ="SELECT WECC_OUTAGE_ID FROM WECC_OUTAGE_DATA WHERE OID = (SELECT OID FROM RC_OMS_MESSAGE_PAYLOAD WHERE MRID =':MRID' AND VERSIONID=:VERSIONID)";
	private static final String SELECT_WECC_OUTAGE_TYPE ="SELECT WECC_OUTAGE_TYPE FROM WECC_OUTAGE_DATA WHERE OMS_OUTAGE_ID=:OMS_OUTAGE_ID and OMS_OUTAGE_VERSION= :OMS_OUTAGE_VERSION and OMS_OUTAGE_TYPE = :OMS_OUTAGE_TYPE";
			
	@Autowired
	private NamedParameterJdbcTemplate rcintJdbcTemplate;

	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.WECCOutageDataDAO#saveWECCOutageData(java.util.Map)
     */
	@Override
    public void saveWECCOutageData(Map<String, Object> params){
		logger.info("WECCOutageDataDAOImpl::Creating WECC outage date");
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("OID",params.get("OID"));
		paramSource.addValue("OMS_OUTAGE_ID",params.get("OMS_OUTAGE_ID"));
		paramSource.addValue("OMS_OUTAGE_VERSION",params.get("OMS_OUTAGE_VERSION"));
		paramSource.addValue("OMS_OUTAGE_STATUS",params.get("OMS_OUTAGE_STATUS"));
		paramSource.addValue("OMS_OUTAGE_TYPE",params.get("OMS_OUTAGE_TYPE"));
		paramSource.addValue("EQUIPMENT_NAME",params.get("EQUIPMENT_NAME"));
		paramSource.addValue("OUTAGE_START_DTS",dateToSqlTimeStampFn.apply((Date) params.get("OUTAGE_START_DTS")));
		paramSource.addValue("OUTAGE_END_DTS",dateToSqlTimeStampFn.apply((Date) params.get("OUTAGE_END_DTS")));
		paramSource.addValue("PAYLOAD_ID",params.get("PAYLOAD_ID"));

		rcintJdbcTemplate.update(WECC_OUTAGE_DATA_INSERT_QUERY, paramSource);
	}
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.WECCOutageDataDAO#updateWECCOutageData(java.lang.String, long)
     */
	@Override
    public void updateWECCOutageData(String outageId, long payloadId,String outageType, String outageStatus){
		logger.info("WECCOutageDataDAOImpl::Updating WECC outage date with outageId and payloadId");
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("WECC_OUTAGE_ID",outageId);
		paramSource.addValue("PAYLOAD_ID",payloadId);
		paramSource.addValue("WECC_OUTAGE_TYPE",outageType);
		paramSource.addValue("WECC_OUTAGE_STATUS",outageStatus);
		paramSource.addValue("UPDATED_DTS", new Date());
        paramSource.addValue("UPDATED_BY", "RCINTAPI");

		rcintJdbcTemplate.update(UPDATE_WECC_OUTAGE_DATA_WITH_WECC_ID, paramSource);
	}
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.WECCOutageDataDAO#updateAuthPayloadIdForWECCOutageData(long, long)
     */
	@Override
    public void updateAuthPayloadIdForWECCOutageData(long payloadId, long ackPayloadId){
		logger.info("WECCOutageDataDAOImpl::Updating WECC outage date with authAckPayloadId");
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("PAYLOAD_ID",payloadId);
		paramSource.addValue("REG_AUTH_PAYLOAD_ID",ackPayloadId);
		paramSource.addValue("UPDATED_DTS", new Date());
        paramSource.addValue("UPDATED_BY", "RCINTAPI");
		rcintJdbcTemplate.update(UPDATE_WECC_OUTAGE_DATE_WITH_REG_AUTH_PAYLOAD_ID, paramSource);
	}
    /* (non-Javadoc)
     * @see com.caiso.rcint.dao.WECCOutageDataDAO#findWECCOutageDataByWeccOutageId(java.lang.String)
     */
    @Override
    public List<WECCOutageData> findWECCOutageDataByWeccOutageId(String weccOutageId) {
         logger.debug("WECCOutageDataDAOImpl::Find WECCOutageData by weccOutageId : {}", weccOutageId);

         MapSqlParameterSource paramSource = new MapSqlParameterSource();
         paramSource.addValue("WECC_OUTAGE_ID",weccOutageId);

         List<WECCOutageData> responseList = rcintJdbcTemplate.query(WECC_OUTAGE_DATA_FIND_BY_WECC_OUTAGE_ID, paramSource,
                 new BeanPropertyRowMapper<WECCOutageData>(WECCOutageData.class));

         Collections.sort(responseList, new WeccVersionComparator());

        return responseList;
    }

    @Override
    public void updateWECCOutageData(String weccOutageStatus, String weccOutageType, Long   oid) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("OID",oid);
        paramSource.addValue("WECC_OUTAGE_STATUS",weccOutageStatus);
        paramSource.addValue("WECC_OUTAGE_TYPE",weccOutageType);
        paramSource.addValue("UPDATED_DTS", new Date());
        paramSource.addValue("UPDATED_BY", "RCINTAPI");
        rcintJdbcTemplate.update("UPDATE WECC_OUTAGE_DATA SET "
                + "WECC_OUTAGE_STATUS = :WECC_OUTAGE_STATUS, WECC_OUTAGE_TYPE = :WECC_OUTAGE_TYPE, "
                + "UPDATED_DTS = :UPDATED_DTS, UPDATED_BY = :UPDATED_BY  WHERE OID = :OID", paramSource);
    }

    @Override
    public String findWeccOutageId(String mrid,int version){
    	MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("MRID",mrid);
		paramSource.addValue("VERSIONID",version);
		return rcintJdbcTemplate.query(SELECT_WECC_OUTAGE_ID, paramSource, new ResultSetExtractor<String>() {
			@Override
			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				while(rs.next()){
					return rs.getString("WECC_OUTAGE_ID");
				}
				return null;
			}
		});
    }
	
    class WeccVersionComparator implements Comparator<WECCOutageData> {
            @Override
            public int compare(WECCOutageData o1, WECCOutageData o2) {
                int compareVal = o1.getWeccOutageId().compareTo(o2.getWeccOutageId());

                if(compareVal != 0) {
                    return compareVal;
                }

                compareVal = o1.getOmsOutageVersion() - o2.getOmsOutageVersion();

                return compareVal;
            }
    }
    
    @Override
    public String findWECCOutageType(String omsId, BigInteger omsVersion, String outageType) {
         logger.debug("WECCOutageDataDAOImpl::Find WECCOutageType::");

         MapSqlParameterSource paramSource = new MapSqlParameterSource();
         paramSource.addValue("OMS_OUTAGE_ID",omsId);
         paramSource.addValue("OMS_OUTAGE_VERSION",omsVersion.intValue());
         paramSource.addValue("OMS_OUTAGE_TYPE",outageType);
         

        return rcintJdbcTemplate.query(SELECT_WECC_OUTAGE_TYPE, paramSource, new ResultSetExtractor<String>() {

			@Override
			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				while(rs.next()){
					return rs.getString("WECC_OUTAGE_TYPE");
				}
				return null;
			}
         });
    }


}

