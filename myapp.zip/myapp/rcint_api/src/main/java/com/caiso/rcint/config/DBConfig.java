package com.caiso.rcint.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableJpaRepositories(basePackages = {"com.caiso.rcint.dao" })
@EnableTransactionManagement
public class DBConfig {

    @Bean(name = "rcintDatasource")
    @Primary
    @ConfigurationProperties(prefix = "spring.rcint.datasource")
    public DataSource masterDataSource() {
        return DataSourceBuilder.create().build();
    }


    @Bean
    @Primary
    public JpaVendorAdapter getHibernateJpaVendorAdapter() {
        HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
        hibernateJpaVendorAdapter.setDatabasePlatform("org.hibernate.dialect.OracleDialect");
        return hibernateJpaVendorAdapter;
    }

    @Bean(name = "entityManagerFactory")
    @Primary
    public LocalContainerEntityManagerFactoryBean getEntityManager(@Qualifier("rcintDatasource") DataSource rcintDatasource, JpaVendorAdapter jpaVendorAdapter) {

        Properties jpaProperties = new Properties();
        jpaProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
        
        LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
        localContainerEntityManagerFactoryBean.setDataSource(rcintDatasource);
        localContainerEntityManagerFactoryBean.setPackagesToScan("com.caiso.rcint");
        localContainerEntityManagerFactoryBean.setPersistenceUnitName("rcint_data_pu");
        localContainerEntityManagerFactoryBean.setJpaProperties(jpaProperties);
        localContainerEntityManagerFactoryBean.setJpaVendorAdapter(jpaVendorAdapter);
        
        return localContainerEntityManagerFactoryBean;
    }
    
    @Bean(name ="transactionManager")
    @Primary
    public JpaTransactionManager getTransactionManager(@Qualifier("entityManagerFactory")EntityManagerFactory entityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory);
        transactionManager.setPersistenceUnitName("rcint_data_pu");
        return transactionManager;
    }

    /**
     * <p>
     * Defines JDBC Template to be use the rcint.
     * </p>
     * <p>
     * This is app specific jdbc tempalte. The plugin does not use this.
     * </p>
     * 
     * @param rcintDatasource
     * @return
     */
    @Bean(name = "rcintJdbcTemplate")
    public NamedParameterJdbcTemplate rcintJdbcTemplate(@Qualifier("rcintDatasource") DataSource rcintDatasource) {
        NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(rcintDatasource);
        return namedParameterJdbcTemplate;
    }

    /**
     * 
     * <p>
     * Define the jdbc template to allow the plugin to write log event into the
     * table (SOA_PROCESS_EVENT).
     * </p>
     * <p>
     * This is optional. If defined, the plugin in will write log event into the
     * table above.
     * </p>
     * 
     * @param rcintDatasource
     * @return
     */
    @Bean(name = "logEventJdbcTemplate")
    public JdbcTemplate logEventJdbcTemplate(@Qualifier("rcintDatasource") DataSource rcintDatasource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(rcintDatasource);
        return jdbcTemplate;
    }
}	
