package com.caiso.rcint.job;

import java.util.TimeZone;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.caiso.rcint.domain.RCIntConstants;
import com.caiso.rcint.outage.cos.CosOutageProcessorService;

@DisallowConcurrentExecution
public class OmsOutageProcessorJob extends QuartzJobBean {

    private static final Logger logger = LoggerFactory.getLogger(OmsOutageProcessorJob.class);

    @Autowired
    private CosOutageProcessorService omsOutageProcessorService;

    public OmsOutageProcessorJob() {
        super();
        TimeZone.setDefault(RCIntConstants.DEFAULT_TIME_ZONE);
    }

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        logger.info("BEGIN::OmsOutageProcessorJob.executeInternal");

        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();

        omsOutageProcessorService.processOmsOutages();

        logger.info("END::OmsOutageProcessorJob.executeInternal");
    }
}
