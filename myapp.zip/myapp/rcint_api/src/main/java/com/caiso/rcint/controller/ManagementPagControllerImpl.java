/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 10, 2017 10:08:21 AM
 * Project: rcint-app
 * File: ManagementPagControllerImpl.java
 */
package com.caiso.rcint.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.caiso.rcint.exception.RCINTRuntimeException;

/**
 * @author gselvaratnam
 *
 */
@RestController
public class ManagementPagControllerImpl {

    @RequestMapping(path = "/manage", method = RequestMethod.GET)
    public void handle(HttpServletResponse seResponse) {
        try {
            seResponse.sendRedirect("/jsp/welcome.jsp");
        } catch (IOException e) {
            throw new RCINTRuntimeException(e);
        }
    }
}
