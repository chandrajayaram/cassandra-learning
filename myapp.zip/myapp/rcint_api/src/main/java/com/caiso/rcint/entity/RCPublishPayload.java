/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
@Entity
@Table(name = "RC_PUBLISH_PAYLOAD")
public class RCPublishPayload implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    @Id
    @SequenceGenerator(name = "RC_PUBLISH_PAYLOAD_ID_GENERATOR", sequenceName = "RC_PAYLOAD_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RC_PUBLISH_PAYLOAD_ID_GENERATOR")
    @Column(name = "PAYLOAD_ID", nullable = false)
    private Long              payloadId;

    @Column(name = "PAYLOAD_TYPE")
    private String            payloadType;

    @Column(name = "STATUS")
    private String            status;

    @Lob
    @Column(name = "DATA", columnDefinition = "BLOB")
    private byte[]            data;

    @Column(name = "RETRY")
    private int               retry;

    @Column(name = "RESPONSE")
    private String            response;

    @Column(name = "CREATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              createdDate;

    @Column(name = "UPDATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              updatedDate;

    /**
     * @return the payloadId
     */
    public Long getPayloadId() {
        return payloadId;
    }

    /**
     * @param payloadId
     *            the payloadId to set
     */
    public void setPayloadId(Long payloadId) {
        this.payloadId = payloadId;
    }

    /**
     * @return the payloadType
     */
    public String getPayloadType() {
        return payloadType;
    }

    /**
     * @param payloadType
     *            the payloadType to set
     */
    public void setPayloadType(String payloadType) {
        this.payloadType = payloadType;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the data
     */
    public byte[] getData() {
        return data;
    }

    /**
     * @param data
     *            the data to set
     */
    public void setData(byte[] data) {
        this.data = data;
    }

    /**
     * @return the retry
     */
    public int getRetry() {
        return retry;
    }

    /**
     * @param retry
     *            the retry to set
     */
    public void setRetry(int retry) {
        this.retry = retry;
    }

    /**
     * @return the response
     */
    public String getResponse() {
        return response;
    }

    /**
     * @param response
     *            the response to set
     */
    public void setResponse(String response) {
        this.response = response;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final RCPublishPayload other = (RCPublishPayload) obj;
        return Objects.equals(this.payloadId, other.payloadId) && Objects.equals(this.createdDate, other.createdDate)
                && Objects.equals(this.payloadType, other.payloadType) && Objects.equals(this.response, other.response)
                && Objects.equals(this.retry, other.retry) && Objects.equals(this.status, other.status) && Objects.equals(this.updatedDate, other.updatedDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.payloadId, this.createdDate, this.payloadId, this.payloadType, this.response, this.retry, this.status, this.updatedDate);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
