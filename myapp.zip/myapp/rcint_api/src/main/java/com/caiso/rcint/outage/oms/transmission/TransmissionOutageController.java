package com.caiso.rcint.outage.oms.transmission;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.caiso.rcint.dao.RCPublishPayloadDAO;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

@RestController
@RequestMapping("/transmissionOutagePayload")
public class TransmissionOutageController {
	
	@Autowired
	private TransmissionOutageDAO transmissionOutageDAO;
	
	@Autowired
	private RCPublishPayloadDAO rcPublishPayloadDAO; 
	
	
	@RequestMapping(path="/{oid}", method = RequestMethod.GET, produces="application/xml")
	public TransmissionOutageResultsCaiso retrieveTranmissionOutage(@PathVariable long oid) {
		return transmissionOutageDAO.getTransmissionOutagePayload(oid);
    }
	
	@RequestMapping(path="/cosPayload/{payloadId}", method = RequestMethod.GET, produces="application/xml")
	public String retrieveCOSPayload(@PathVariable long payloadId,HttpServletResponse response) {
		byte[] payload = rcPublishPayloadDAO.retrievePayload(payloadId);
		if(payload != null){
			return new String(rcPublishPayloadDAO.retrievePayload(payloadId));	
		}
		response.setStatus(HttpServletResponse.SC_NOT_FOUND);
		return null;
    }
}
