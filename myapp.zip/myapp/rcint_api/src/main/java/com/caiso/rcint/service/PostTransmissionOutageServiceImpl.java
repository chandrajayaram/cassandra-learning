/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 6, 2017 3:36:31 PM
 * Project: rcint-app
 * File: SubmitPayloadControllerImpl.java
 */
package com.caiso.rcint.service;

import java.io.StringReader;
import java.util.Date;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.caiso.rcint.dao.RCOutageDataRepository;
import com.caiso.rcint.entity.RCOutageData;
import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.outage.cos.BaseCosSubmitTransmissionOutageProcessor;
import com.caiso.rcint.outage.cos.ReceiveRegulatoryAuthorityOutageStatusService;
import com.caiso.rcint.outage.cos.SubmitTransmissionOutageResponseHandler;
import com.caiso.rcint.util.DateUtil;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.transmissionoutagedata_v1.TransmissionOutageData;

/**
 * @author gselvaratnam
 *
 */
@Service
public class PostTransmissionOutageServiceImpl extends BaseCosSubmitTransmissionOutageProcessor implements PostTransmissionOutageService {
    private static final Logger                           logger = LoggerFactory.getLogger(PostTransmissionOutageServiceImpl.class);

    @Autowired
    protected WebServiceCallOutService                    webServiceCallOutService;

    @Autowired
    protected RCOutageDataRepository                      rcOutageDataRepository;

    @Autowired
    protected SubmitTransmissionOutageResponseHandler     submitTransmissionOutageResponseHandler;

    @Autowired
    protected SaveInNewTransactionService                 saveInNewTransactionService;

    @Autowired
    private ReceiveRegulatoryAuthorityOutageStatusService receiveRegulatoryAuthorityOutageStatusService;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.caiso.rcint.controller.SubmitPayloadController#resendPayload(java.
     * lang.String)
     */
    @Override
    public String resendPayload(RCPublishPayload rcPublishPayload) {
        logger.info("Begin::PostTransmissionOutageServiceImpl.resendPayload");
        try {
            validate(rcPublishPayload);

            RCOutageData rcOutageData = rcOutageDataRepository.findByPayloadId(rcPublishPayload.getPayloadId());
            String omsOutagePayload = Utils.decompress(rcPublishPayload.getData());
            TransmissionOutageData omsOutageDataObject = getTransmissionOutageData(omsOutagePayload);

            String responseOmsId = submitTransmissionOutageResponseHandler.handleResponse(omsOutageDataObject, null, rcPublishPayload.getPayloadId());

            if (!StringUtils.isEmpty(responseOmsId)) {

                String attachmentXml = webServiceCallOutService.getOmsAttachementRegulatoryAuthorityOutageStatusXMLString(
                        DateUtil.convertToXmlGregorianCalendar(new Date()).toString(), responseOmsId, String.valueOf(rcOutageData.getWeccRevisionNumber()),
                        null, rcOutageData.getWeccOutageId(), "PENDING");

                Map<String, Object> response = receiveRegulatoryAuthorityOutageStatusService.executeService(attachmentXml, null);

                saveInNewTransactionService.updateRCOutageData((Long) response.get(ReceiveRegulatoryAuthorityOutageStatusService.EXECUTE_SERVICE_PAYLOAD_ID),
                        rcOutageData.getId());
            }

            return "SubmitTransmissionOutage_v1 OmsID : " + responseOmsId;
        } catch (JAXBException jaxbException) {
            throw new RCINTRuntimeException(jaxbException);
        } finally {
            logger.info("End::SubmitPayloadControllerImpl.resendPayload");
        }
    }

    protected TransmissionOutageData getTransmissionOutageData(String xmlString) {
        TransmissionOutageData transmissionOutageData;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance("com.caiso.soa.transmissionoutagedata_v1");
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            JAXBElement<TransmissionOutageData> root = jaxbUnmarshaller.unmarshal(new StreamSource(new StringReader(xmlString)), TransmissionOutageData.class);
            transmissionOutageData = root.getValue();
        } catch (JAXBException jaxbException) {
            throw new RCINTRuntimeException(jaxbException);
        }
        return transmissionOutageData;
    }

    private void validate(RCPublishPayload rcPublishPayload) {
        if (rcPublishPayload == null) {
            throw new RCINTRuntimeException("RCPublishPayload cannot be null");
        }
    }
}
