package com.caiso.rcint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ConfigDAO {
	
	private  final Map<String,String> configData = new HashMap<>();
	private static final String SELECT_CONFIG_PROPERTIES = "SELECT PROPERTY, VALUE, TYPE FROM RC_CONFIG";
	private static final String SELECT_ENDPOINT_CONFIG = "SELECT DESTINATION, SOAP_ACTION FROM RC_PUBLISH_INFO WHERE TYPE_NAME = :TYPE_NAME";
	
	@Autowired
	private NamedParameterJdbcTemplate rcintJdbcTemplate;
	
	public ConfigDAO(){
		
	}
	
	public String getConfigProperty(String propertyName){
		return configData.get(propertyName);
	}
	@PostConstruct 
	public void initialize(){
		rcintJdbcTemplate.query(SELECT_CONFIG_PROPERTIES, new ResultSetExtractor<Void>() {

			@Override
			public Void extractData(ResultSet rs) throws SQLException, DataAccessException {
				while(rs.next()){
					
					configData.put(rs.getString(1), rs.getString(2));
				}
				return null;
			}
		});
	}
	
	public Map<String, String> getEndpointConfig(String configName){
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("TYPE_NAME", configName);
		return rcintJdbcTemplate.query(SELECT_ENDPOINT_CONFIG, parameters,new ResultSetExtractor<Map<String, String>>() {

			@Override
			public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map<String, String> config = new HashMap<>();
				while(rs.next()){
					config.put("DESTINATION", rs.getString("DESTINATION"));
					config.put("SOAP_ACTION", rs.getString("SOAP_ACTION"));
				}
				return config;
			}
		});
	}
}
