/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
@Entity
@Table(name = "RC_OUTAGE")
public class RCOutage implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    @Id
    @Column(name = "WECC_OUTAGE_ID", nullable = false)
    private String              weccOutageId;

    @Column(name = "CONTROL_AREA")
    private String            controlArea;

    @Column(name = "OUTAGE_TYPE")
    private String            outageType;

    @Column(name = "OUTAGE_START")
    private String            outageStart;

    @Column(name = "OUTAGE_END")
    private String            outageEnd;

    @Column(name = "DURATION")
    private String            duration;

    @Column(name = "DURATION_UNIT")
    private String            durationUnit;

    @Column(name = "CREATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              createdDate;

    @Column(name = "UPDATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              updatedDate;

    /**
     * @return the weccOutageId
     */
    public String getWeccOutageId() {
        return weccOutageId;
    }

    /**
     * @param weccOutageId the weccOutageId to set
     */
    public void setWeccOutageId(String weccOutageId) {
        this.weccOutageId = weccOutageId;
    }

    /**
     * @return the controlArea
     */
    public String getControlArea() {
        return controlArea;
    }

    /**
     * @param controlArea the controlArea to set
     */
    public void setControlArea(String controlArea) {
        this.controlArea = controlArea;
    }

    /**
     * @return the outageType
     */
    public String getOutageType() {
        return outageType;
    }

    /**
     * @param outageType the outageType to set
     */
    public void setOutageType(String outageType) {
        this.outageType = outageType;
    }

    /**
     * @return the outageStart
     */
    public String getOutageStart() {
        return outageStart;
    }

    /**
     * @param outageStart the outageStart to set
     */
    public void setOutageStart(String outageStart) {
        this.outageStart = outageStart;
    }

    /**
     * @return the outageEnd
     */
    public String getOutageEnd() {
        return outageEnd;
    }

    /**
     * @param outageEnd the outageEnd to set
     */
    public void setOutageEnd(String outageEnd) {
        this.outageEnd = outageEnd;
    }

    /**
     * @return the duration
     */
    public String getDuration() {
        return duration;
    }

    /**
     * @param duration the duration to set
     */
    public void setDuration(String duration) {
        this.duration = duration;
    }

    /**
     * @return the durationUnit
     */
    public String getDurationUnit() {
        return durationUnit;
    }

    /**
     * @param durationUnit the durationUnit to set
     */
    public void setDurationUnit(String durationUnit) {
        this.durationUnit = durationUnit;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final RCOutage other = (RCOutage) obj;
        return Objects.equals(this.controlArea, other.controlArea) && Objects.equals(this.createdDate, other.createdDate)
                && Objects.equals(this.duration, other.duration) && Objects.equals(this.durationUnit, other.durationUnit)
                && Objects.equals(this.outageEnd, other.outageEnd) && Objects.equals(this.outageStart, other.outageStart)
                && Objects.equals(this.outageType, other.outageType) && Objects.equals(this.updatedDate, other.updatedDate)
                && Objects.equals(this.weccOutageId, other.weccOutageId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.controlArea, this.createdDate, this.duration, this.durationUnit, this.outageEnd, this.outageStart, this.outageType,
                this.updatedDate, this.weccOutageId);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
