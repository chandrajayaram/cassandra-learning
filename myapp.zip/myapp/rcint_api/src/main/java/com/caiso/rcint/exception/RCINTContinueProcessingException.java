/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 25, 2017 10:53:16 AM
 * Project: rcint-app
 * File: RcOutageEquipmentBypassException.java
 */
package com.caiso.rcint.exception;

/**
 * @author gselvaratnam
 *
 */
public class RCINTContinueProcessingException extends RCINTRuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * 
     */
    public RCINTContinueProcessingException() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public RCINTContinueProcessingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param message
     * @param cause
     */
    public RCINTContinueProcessingException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param message
     */
    public RCINTContinueProcessingException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param cause
     */
    public RCINTContinueProcessingException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }
}
