/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
@Entity
@Table(name = "RC_OUTAGE_DATA")
public class RCOutageData implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    @Id
    @SequenceGenerator(name = "RC_OUTAGE_DATA_ID_GENERATOR", sequenceName = "RC_OUTAGE_DATA_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RC_OUTAGE_DATA_ID_GENERATOR")
    @Column(name = "ID", nullable = false)
    private Long              id;

    @Column(name = "WECC_OUTAGE_ID")
    private String            weccOutageId;

    @Column(name = "OMS_OUTAGE_ID")
    private String            omsOutageId;

    @Column(name = "WECC_OUTAGE_STATUS")
    private String            weccOutageStatus;

    @Column(name = "WECC_REVISION_NUMBER")
    private Long               weccRevisionNumber;

    @Lob
    @Column(name = "WECC_OUTAGE_DATA", columnDefinition = "BLOB")
    private byte[]            weccOutageData;

    @Lob
    @Column(name = "WECC_EQUIPMENT_DATA", columnDefinition = "BLOB")
    private byte[]            weccEquipmentData;

    @Lob
    @Column(name = "OMS_OUTAGE_DATA", columnDefinition = "BLOB")
    private byte[]            omsOutageData;

    @Column(name = "PAYLOAD_ID")
    private Long               payloadId;

    @Column(name = "REG_AUTH_PAYLOAD_ID")
    private Long               regAuthPayloadId;
    
    @Column(name = "REGEN")
    private String            regen;

    @Column(name = "IGNORE")
    private String            ignore;

    @Column(name = "WECC_OUTAGE_TYPE")
    private String            weccOutageType;

    @Column(name = "CREATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              createdDate;

    @Column(name = "UPDATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              updatedDate;

    @Column(name = "EQUIPMENT_MAP")
    private String            equipmentMap;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the weccOutageId
     */
    public String getWeccOutageId() {
        return weccOutageId;
    }

    /**
     * @param weccOutageId the weccOutageId to set
     */
    public void setWeccOutageId(String weccOutageId) {
        this.weccOutageId = weccOutageId;
    }

    /**
     * @return the omsOutageId
     */
    public String getOmsOutageId() {
        return omsOutageId;
    }

    /**
     * @param omsOutageId the omsOutageId to set
     */
    public void setOmsOutageId(String omsOutageId) {
        this.omsOutageId = omsOutageId;
    }

    /**
     * @return the weccOutageStatus
     */
    public String getWeccOutageStatus() {
        return weccOutageStatus;
    }

    /**
     * @param weccOutageStatus the weccOutageStatus to set
     */
    public void setWeccOutageStatus(String weccOutageStatus) {
        this.weccOutageStatus = weccOutageStatus;
    }

    /**
     * @return the weccRevisionNumber
     */
    public Long getWeccRevisionNumber() {
        return weccRevisionNumber;
    }

    /**
     * @param weccRevisionNumber the weccRevisionNumber to set
     */
    public void setWeccRevisionNumber(Long weccRevisionNumber) {
        this.weccRevisionNumber = weccRevisionNumber;
    }

    /**
     * @return the weccOutageData
     */
    public byte[] getWeccOutageData() {
        return weccOutageData;
    }

    /**
     * @param weccOutageData the weccOutageData to set
     */
    public void setWeccOutageData(byte[] weccOutageData) {
        this.weccOutageData = weccOutageData;
    }

    /**
     * @return the weccEquipmentData
     */
    public byte[] getWeccEquipmentData() {
        return weccEquipmentData;
    }

    /**
     * @param weccEquipmentData the weccEquipmentData to set
     */
    public void setWeccEquipmentData(byte[] weccEquipmentData) {
        this.weccEquipmentData = weccEquipmentData;
    }

    /**
     * @return the omsOutageData
     */
    public byte[] getOmsOutageData() {
        return omsOutageData;
    }

    /**
     * @param omsOutageData the omsOutageData to set
     */
    public void setOmsOutageData(byte[] omsOutageData) {
        this.omsOutageData = omsOutageData;
    }

    /**
     * @return the payloadId
     */
    public Long getPayloadId() {
        return payloadId;
    }

    /**
     * @param payloadId the payloadId to set
     */
    public void setPayloadId(Long payloadId) {
        this.payloadId = payloadId;
    }

    /**
     * @return the regen
     */
    public String getRegen() {
        return regen;
    }

    /**
     * @param regen the regen to set
     */
    public void setRegen(String regen) {
        this.regen = regen;
    }

    /**
     * @return the ignore
     */
    public String getIgnore() {
        return ignore;
    }

    /**
     * @param ignore the ignore to set
     */
    public void setIgnore(String ignore) {
        this.ignore = ignore;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * @return the equipmentMap
     */
    public String getEquipmentMap() {
        return equipmentMap;
    }

    /**
     * @param equipmentMap the equipmentMap to set
     */
    public void setEquipmentMap(String equipmentMap) {
        this.equipmentMap = equipmentMap;
    }

    /**
     * @return the weccOutageType
     */
    public String getWeccOutageType() {
        return weccOutageType;
    }

    /**
     * @param weccOutageType the weccOutageType to set
     */
    public void setWeccOutageType(String weccOutageType) {
        this.weccOutageType = weccOutageType;
    }

    /**
     * @return the regAuthPayloadId
     */
    public Long getRegAuthPayloadId() {
        return regAuthPayloadId;
    }

    /**
     * @param regAuthPayloadId the regAuthPayloadId to set
     */
    public void setRegAuthPayloadId(Long regAuthPayloadId) {
        this.regAuthPayloadId = regAuthPayloadId;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final RCOutageData other = (RCOutageData) obj;
        return Objects.equals(this.id, other.id) && Objects.equals(this.createdDate, other.createdDate) && Objects.equals(this.equipmentMap, other.equipmentMap)
                && Objects.equals(this.ignore, other.ignore) && Objects.equals(this.omsOutageData, other.omsOutageData)
                && Objects.equals(this.omsOutageId, other.omsOutageId) && Objects.equals(this.payloadId, other.payloadId)
                && Objects.equals(this.regen, other.regen) && Objects.equals(this.updatedDate, other.updatedDate)
                && Objects.equals(this.weccEquipmentData, other.weccEquipmentData) && Objects.equals(this.weccOutageData, other.weccOutageData)
                && Objects.equals(this.weccOutageId, other.weccOutageId) && Objects.equals(this.weccOutageStatus, other.weccOutageStatus)
                && Objects.equals(this.weccRevisionNumber, other.weccRevisionNumber)
                && Objects.equals(this.weccOutageType, other.weccOutageType)
                && Objects.equals(this.regAuthPayloadId, other.regAuthPayloadId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.createdDate, this.equipmentMap, this.ignore, this.omsOutageData, this.omsOutageId, this.payloadId, this.regen,
                this.updatedDate, this.weccEquipmentData, this.weccOutageData, this.weccOutageId, this.weccOutageStatus, this.weccRevisionNumber, this.weccOutageType, this.regAuthPayloadId);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
