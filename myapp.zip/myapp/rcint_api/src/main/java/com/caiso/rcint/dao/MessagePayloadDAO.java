/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 28, 2017 6:51:21 PM
 * Project: rcint-app
 * File: MessagePayloadDAO.java
 */
package com.caiso.rcint.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.caiso.rcint.domain.PayloadStatus;
import com.caiso.rcint.exception.RCINTApplicationException;

/**
 * @author gselvaratnam
 *
 */
public interface MessagePayloadDAO {

    long createMessageHeader(XMLGregorianCalendar dateTime, String source, String version, String payloadType);

    long createMessagePayload(Object outage, long messageId, String mrid, long version, XMLGregorianCalendar startDateTime, XMLGregorianCalendar endDateTime)
            throws RCINTApplicationException;

    <T> T getOutagePayload(long oid, ResultSetExtractor<T> resultSetExtractor);

    String getOutagePayload(String mrid, XMLGregorianCalendar start, XMLGregorianCalendar end, String type) throws RCINTApplicationException;
    
    List<String> getOutagePayloadList(String mrid, XMLGregorianCalendar start, XMLGregorianCalendar end, String type) throws RCINTApplicationException;

    void updateMessageStatus(long oid, PayloadStatus status, String notes);

	Map<Long, String> getOutagePayloadList(Set<String> mrids, String type, PayloadStatus status)
			throws RCINTApplicationException;

	List<String> getOutagePayloadList(Set<Long> dataSet) throws RCINTApplicationException;

}