	package com.caiso.rcint.outage.oms.generation;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caiso.rcint.domain.PayloadStatus;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.availability.AvailabilityResultsDAO;
import com.caiso.rcint.outage.oms.resource.ResourceOutageDAO;
import com.caiso.soa.availabilityresultscaiso_v1.RegisteredGenerator;
import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;
@Service
public class GenerationOutageReceiverImpl implements GenerationOutageReceiver{
	
	public static final Logger logger = LoggerFactory.getLogger(GenerationOutageReceiverImpl.class);
	
	private AvailabilityResultsDAO availabilityResultsDAO;
	private ResourceOutageDAO resourceOutageDAO;
	private GenerationOutageProcessor genOutageProcessor; 
	
	@Autowired
	public void setGenOutageProcessor(GenerationOutageProcessor genOutageProcessor) {
		this.genOutageProcessor = genOutageProcessor;
	}
	@Autowired
	public void setAvailabilityResultsDAO(AvailabilityResultsDAO availabilityResultsDAO) {
		this.availabilityResultsDAO = availabilityResultsDAO;
	}
	@Autowired
	public void setResourceOutageDAO(ResourceOutageDAO resourceOutageDAO) {
		this.resourceOutageDAO = resourceOutageDAO;
	}
	
	@Override
	public void processAsyn(Map<Long, RegisteredResourceOutage> resourceOutageMap){
		logger.info("Processing resource outage results");
		
		for(Entry<Long, RegisteredResourceOutage> resourceOutageMapEntry: resourceOutageMap.entrySet()){
			RegisteredResourceOutage outage = resourceOutageMapEntry.getValue();
			XMLGregorianCalendar start = null;
			XMLGregorianCalendar end = null;
			if(outage.getActualPeriod()!=null){
				start = outage.getActualPeriod().getStart();
				end = outage.getActualPeriod().getEnd();
			}else if(outage.getEstimatedPeriod()!=null){
				start = outage.getEstimatedPeriod().getStart();
				end = outage.getEstimatedPeriod().getEnd();
			}
			try {
				List<RegisteredGenerator> registeredGenerators = availabilityResultsDAO.getAvailabilityRegisteredResource(outage.getMRID(), start, end);
				if(registeredGenerators!=null && !registeredGenerators.isEmpty()){
					genOutageProcessor.process(resourceOutageMapEntry.getKey(),outage, registeredGenerators);
				}else{
					logger.info("Availabilty results for resource outage not found");
				}
			} catch (RCINTApplicationException e) {
				logger.error("Error occoured while retrieveing availability results for the resource outage", e);
			}
		}
	}

	
	@Override
	public void processAsyn(Set<String> outagedResources) throws RCINTApplicationException {
			Map<Long, RegisteredResourceOutage> resourceOutageMap = resourceOutageDAO.getOutagePayloadList(outagedResources, PayloadStatus.RECEIVED);
			processAsyn(resourceOutageMap);
	}
	
	

}
