/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 9, 2017 2:33:39 PM
 * Project: rcint-app
 * File: ManageService.java
 */
package com.caiso.rcint.controller;

/**
 * @author gselvaratnam
 *
 */
public interface ManageService {

    /**
     * 
     * public String resendPayload(@PathVariable(value = "payloadId") String
     * payloadId) {
     * 
     * @return
     */
    String manageService(String serviceName, Boolean status);

}