/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 23, 2017 10:17:12 AM
 * Project: caiso-rcint_api
 * File: CosOutageStatusType.java
 */
package com.caiso.rcint.domain;

/**
 * @author gselvaratnam
 *
 */
public enum CosOutageStatusType {

    CANCELLED, DENIED, RECALLED, REVISED;
}
