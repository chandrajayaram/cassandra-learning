package com.caiso.rcint.outage.oms.common;

import java.io.StringWriter;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.caiso.rcint.dao.ConfigDAO;
import com.caiso.rcint.dao.RCPublishPayloadDAO;
import com.caiso.rcint.dao.WECCOutageDataDAO;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.soa._2006_06_13.standardoutput.EventLog;
import com.caiso.soa._2006_06_13.standardoutput.OutputDataType;
import com.caiso.soa.framework.utils.SOAPUtils;

@Service
public class AcknowledgementPublisher {
	public static final Logger logger = LoggerFactory.getLogger(AcknowledgementPublisher.class);

	@Autowired
	private Template ackTemplate;

	@Autowired
	private RCPublishPayloadDAO rcPublishPayloadDAO;

	@Autowired
	private WECCOutageDataDAO weccOutageDataDAO;

	@Autowired
	private ConfigDAO configDAO;

	@Qualifier("webServiceTemplate_11")
	@Autowired
	private WebServiceTemplate webServiceTemplate11;

	private String omsEndpoint;

	private String soapAction;

	public void processAcknowledgement(long payloadId, String omsOutageId, String omsOutageVersion, String outageType,
			String cosId, String errorMsg, String outageStatus) {
		try {
			String outageStatusType = "TRANSMISSION".equalsIgnoreCase(outageType) ? "TransmissionOutage"
					: "RegisteredResourceOutage";
			String acknoledgement = generateAcknowledgementPayload(omsOutageId, omsOutageVersion, cosId, errorMsg,
					outageStatus, outageStatusType);
			long ackPayloadId = rcPublishPayloadDAO.savePayload("OMS_REGULATORY_AUTH_RESPONSE",
					acknoledgement.getBytes());
			weccOutageDataDAO.updateAuthPayloadIdForWECCOutageData(payloadId, ackPayloadId);
			sendAcknowledgementToOMS(ackPayloadId, acknoledgement);
		} catch (Exception e) {
			rcPublishPayloadDAO.updatePayloadStatus(payloadId, "ERROR", e.getMessage());
			logger.error("Error occoured while sending the acknowledgement to WEBOMS", e);
		}
	}

	private void sendAcknowledgementToOMS(final long ackPayloadId, String acknoledgement) throws RCINTApplicationException {

		webServiceTemplate11.sendAndReceive(
				omsEndpoint,  (WebServiceMessage message) -> 
						attachPayload(soapAction, acknoledgement,
								"RegulatoryAuthorityOutageStatus_attachment", message)
				,(WebServiceMessage message) ->
						processAcknowledgementResponse(ackPayloadId, message) 
					 );
	}

	private String generateAcknowledgementPayload(String omsOutageId, String omsOutageVersion, String cosId,
			String errorMsg, String outageStatus, String outageStatusType) throws DatatypeConfigurationException {
		VelocityContext context = new VelocityContext();
		
		GregorianCalendar calendar = new GregorianCalendar();
	    calendar.setTime(new Date());
	    DatatypeFactory df = DatatypeFactory.newInstance();
	    XMLGregorianCalendar dateTime = df.newXMLGregorianCalendar(calendar);
	    
		context.put("dateTime", dateTime.toString());
		context.put("outageStatusType", outageStatusType);
		context.put("omsOutageId", omsOutageId);
		context.put("omsOutageVersion", omsOutageVersion);
		context.put("errorMsg", errorMsg);
		context.put("cosId", cosId);
		context.put("status", outageStatus);
		StringWriter ackWriter = new StringWriter();
		ackTemplate.merge(context, ackWriter);
		return ackWriter.toString();
	}

	private void processAcknowledgementResponse(long payloadId, WebServiceMessage message) {
		try {
			
			DOMSource domSource = (DOMSource) message.getPayloadSource();
				if (("receiveRegulatoryAuthorityOutageStatus_v1").equalsIgnoreCase(domSource.getNode().getLocalName())) {
					NodeList nodeList = domSource.getNode().getChildNodes();
					int length =nodeList.getLength();
					for(int i =0;i<length;i++){
						if(nodeList.item(i).getNodeType() == Node.ELEMENT_NODE && nodeList.item(i).getLocalName().equalsIgnoreCase("outputDataType")){
							OutputDataType output = (OutputDataType) SOAPUtils
									.unmarshal(OutputDataType.class.getPackage().getName(), new DOMSource(nodeList.item(i)));
							EventLog eventLog = output.getEventLog().get(0);
							String result  = eventLog.getEvent().get(0).getResult();
							if(result.equalsIgnoreCase("SUCCESS")){
								rcPublishPayloadDAO.updatePayloadStatus(payloadId, "SENT", "ACCEPTED");	
							}else{
								String comments = eventLog.getService().get(0).getComments();
								rcPublishPayloadDAO.updatePayloadStatus(payloadId, "REJECTED", comments);
							}		
							break;
						}
					}
				}
		} catch (Exception e) {
			rcPublishPayloadDAO.updatePayloadStatus(payloadId, "ERROR", e.getMessage());
			logger.warn("Unable to extract payload from response message.", e);
		}	
	}

	@PostConstruct
	public void initialize() {
		Map<String, String> endpoint = configDAO.getEndpointConfig("OMS_REGULATORY_AUTH_RESPONSE");
		omsEndpoint = endpoint.get("DESTINATION");
		soapAction = endpoint.get("SOAP_ACTION");
	}

	private void attachPayload(final String soapAction, final String data, String attachmentName,
			WebServiceMessage message) throws TransformerException {
		try {
			// extract the operation name
			String serviceName = soapAction.substring(soapAction.lastIndexOf("/") + 1);
			SOAPUtils.addMimeAttachmentToMessage(message, data, serviceName, attachmentName, soapAction);

			((SoapMessage) message).setSoapAction(soapAction);
		} catch (Exception e) {
			throw new TransformerException("Unable to convert message into mime attachment.", e);
		}
	}
}
