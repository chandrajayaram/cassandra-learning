/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 24, 2017 3:49:42 PM
 * Project: rcint-app
 * File: RegulatoryAuthorityOutageStatusServiceImpl.java
 */
package com.caiso.rcint.service;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.outage.cos.ReceiveRegulatoryAuthorityOutageStatusService;

/**
 * @author gselvaratnam
 *
 */
@Service
public class PostRegulatoryAuthorityOutageStatusServiceImpl implements PostRegulatoryAuthorityOutageStatusService {
    
    private static final Logger logger = LoggerFactory.getLogger(PostRegulatoryAuthorityOutageStatusServiceImpl.class);

    ReceiveRegulatoryAuthorityOutageStatusService receiveRegulatoryAuthorityOutageStatusService;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.caiso.rcint.controller.PostRegulatoryAuthorityOutageStatusService#
     * resendPayload(com.caiso.rcint.entity.RCPublishPayload)
     */
    @Override
    public String resendPayload(RCPublishPayload rcPublishPayload) {
        logger.info("Begin::PostRegulatoryAuthorityOutageStatusServiceImpl.resendPayload");

        String response = null;
        validate(rcPublishPayload);

        Map<String, Object> responseMap = receiveRegulatoryAuthorityOutageStatusService.executeService(new String(rcPublishPayload.getData()), rcPublishPayload.getPayloadId());
        response = (String) responseMap.get(ReceiveRegulatoryAuthorityOutageStatusService.EXECUTE_SERVICE_RESPONSE);
        
        logger.info("End::PostRegulatoryAuthorityOutageStatusServiceImpl.resendPayload");
        return response;
    }

    private void validate(RCPublishPayload rcPublishPayload) {
        if (rcPublishPayload == null) {
            throw new RCINTRuntimeException("RCPublishPayload cannot be null");
        }
    }
}
