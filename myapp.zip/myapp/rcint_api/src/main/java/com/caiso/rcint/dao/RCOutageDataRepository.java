/**
 * 
 */
package com.caiso.rcint.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.entity.RCOutageData;


/**
 * @author gselvaratnam
 *
 */
@Repository
public interface RCOutageDataRepository  extends JpaRepository<RCOutageData, Long> {

    @Modifying
    @Query("Update RCOutageData rcod SET rcod.ignore='Y', rcod.updatedDate = ?1 WHERE rcod.weccOutageId = ?2 And rcod.weccRevisionNumber = ?3 And rcod.omsOutageId is NULL")
    public void updateAsIgnored(Date updatedDate, String weccOutageId, String weccRevisionNumber);

    @Modifying
    @Query("Update RCOutageData rcod SET rcod.ignore='Y', rcod.updatedDate = ?1 WHERE rcod.weccOutageId = ?2 And rcod.weccRevisionNumber < ?3 And rcod.omsOutageId is NULL")
    public void updateAsIgnoredAll(Date updatedDate, String weccOutageId, Long weccRevisionNumber);

    public List<RCOutageData> findByWeccOutageIdAndWeccRevisionNumber(String weccOutageId, Long weccRevisionNumber);

    @Modifying
    @Query("Update RCOutageData rcod SET rcod.payloadId=?1, rcod.omsOutageData=?2, rcod.regen=NULL, rcod.ignore=NULL, rcod.updatedDate = ?3 WHERE rcod.id = ?4")
    public void updateOmsOutageDate(Long payloadId, byte [] omsOutagePayload, Date updatedDate, Long rcOutageDataId);

    @Modifying
    @Query("Update RCOutageData rcod SET rcod.regAuthPayloadId=?1, rcod.updatedDate = ?2 WHERE rcod.id = ?3")
    public void updateRCOutageData(Long regAuthPayloadId, Date updatedDate, Long id);

    @Modifying
    @Query("Update RCOutageData rcod SET rcod.omsOutageId=?1, rcod.updatedDate = ?2 WHERE rcod.payloadId = ?3")
    public void updateOmsOutageId(String omsOutageId, Date updatedDate, Long payloadId);

    public RCOutageData findByPayloadId(Long payloadId);
}
