package com.caiso.rcint.outage.oms.transmission;

import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

public interface TransmissionOutageProcessor {

	void process(TransmissionOutageResultsCaiso transOutageResults) throws RCINTApplicationException;

	void processAsync(TransmissionOutageResultsCaiso transOutageResults) throws RCINTApplicationException;
}