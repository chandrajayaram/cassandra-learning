/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 2, 2017 1:16:41 PM
 * Project: rcint-app
 * File: RCPublishInfoRepository.java
 */
package com.caiso.rcint.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.entity.RCPublishInfo;

/**
 * @author gselvaratnam
 *
 */
@Repository
public interface RCPublishInfoRepository extends JpaRepository<RCPublishInfo, Long> {

    public RCPublishInfo findByTypeName(String typeName);
}
