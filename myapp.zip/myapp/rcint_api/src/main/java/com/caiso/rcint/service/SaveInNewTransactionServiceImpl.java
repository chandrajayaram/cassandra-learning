/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 23, 2017 4:58:30 PM
 * Project: caiso-rcint_api
 * File: SaveInNewTransactionServiceImpl.java
 */
package com.caiso.rcint.service;


import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.rcint.dao.RCOutageDataRepository;
import com.caiso.rcint.dao.RCOutageRepository;
import com.caiso.rcint.dao.RCPublishPayloadRepository;
import com.caiso.rcint.dao.WECCOutageDataDAO;
import com.caiso.rcint.dao.WeccOutageRegAuthUpdateRepository;
import com.caiso.rcint.domain.CosOutageStatusType;
import com.caiso.rcint.entity.RCOutage;
import com.caiso.rcint.entity.RCOutageData;
import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.entity.WeccOutageRegAuthUpdate;

/**
 * @author gselvaratnam
 *
 */
@Service
@Transactional(propagation = Propagation.REQUIRES_NEW)
public class SaveInNewTransactionServiceImpl implements SaveInNewTransactionService {

    @Autowired
    private RCOutageDataRepository rcOutageDataRepository;

    @Autowired
    private RCPublishPayloadRepository rcPublishPayloadRepository;

    @Autowired
    private RCOutageRepository rcOutageRepository;

    @Autowired
    private WECCOutageDataDAO weccOutageDataDAO;

    @Autowired
    private WeccOutageRegAuthUpdateRepository weccOutageRegAuthUpdateRepository;

    @Override
    public void updateRCOutageDataAndRCPublishPayloadforCancellation (CosOutageStatusType cosOutageStatusType, String weccOutageNumber, Long revisionNumber) {
        rcOutageDataRepository.updateAsIgnoredAll(new Date(), weccOutageNumber, revisionNumber);
        rcPublishPayloadRepository.updateStatusAll(cosOutageStatusType.name(), new Date(), weccOutageNumber, revisionNumber);
    }

    @Override
    public void cancelPriorFailedPublishPayload(String weccOutageNumber, Long revisionNumber, CosOutageStatusType cosOutageStatusType) {
        rcOutageDataRepository.updateAsIgnoredAll(new Date(), weccOutageNumber, Long.valueOf(revisionNumber));
        rcPublishPayloadRepository.updateStatusAll(cosOutageStatusType.name(), new Date(), weccOutageNumber, revisionNumber);
    }

    @Override
    public RCOutage saveNewRCOutage(RCOutage rcOutage) {
        rcOutage = rcOutageRepository.save(rcOutage);
        return rcOutage;
    }

    @Override
    public RCOutageData createOrUpdateRcOutageData(RCOutageData rcOutageData) {
        rcOutageData = rcOutageDataRepository.save(rcOutageData);
        return rcOutageData;
    }

    @Override
    public RCPublishPayload createOrUpdateRCPublishPayload(RCPublishPayload rcPublishPayload) {
        rcPublishPayload = rcPublishPayloadRepository.save(rcPublishPayload);
        return rcPublishPayload;
    }
    
    @Override
    public void updateRCOutageData(Long payloadId, byte [] omsOutagePayload, Long rcOutageDataId) {
        rcOutageDataRepository.updateOmsOutageDate(payloadId, omsOutagePayload, new Date(), rcOutageDataId);
    }

    @Override
    public void updateRCOutageData(Long regAuthPayloadId, Long id) {
        rcOutageDataRepository.updateRCOutageData(regAuthPayloadId, new Date(), id);
    }

    @Override
    public void updateRCOutageDataOmsOutageId(String omsOutageId, Long payloadId) {
        rcOutageDataRepository.updateOmsOutageId(omsOutageId, new Date(), payloadId);
    }

    @Override
    public void updateStatusAndResponseByPayloadId(String status, String response, Long payloadId) {
        rcPublishPayloadRepository.updateStatusAndResponseByPayloadId(status, response, new Date(), payloadId);
    }

    @Override
    public void updateWECCOutageData(String weccOutageStatus, String weccOutageType, Long   oid) {
        weccOutageDataDAO.updateWECCOutageData(weccOutageStatus, weccOutageType, oid);
    }

    @Override
    public void createOrUpdateWeccOutageRegAuthUpdate(WeccOutageRegAuthUpdate weccOutageRegAuthUpdate) {
        weccOutageRegAuthUpdateRepository.save(weccOutageRegAuthUpdate);
    }
}
