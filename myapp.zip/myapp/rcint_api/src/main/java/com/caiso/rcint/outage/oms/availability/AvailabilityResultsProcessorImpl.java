package com.caiso.rcint.outage.oms.availability;

import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caiso.rcint.domain.AvailabilityResultsWrapper;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.generation.GenerationOutageReceiver;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;

@Service
public class AvailabilityResultsProcessorImpl implements AvailabilityResultsProcessor{
	
	@Autowired
	private AvailabilityResultsDAO availabilityResultsDAO;
	
	@Autowired
	private GenerationOutageReceiver generationOutageReceiver;
	
	@Autowired
	private PaylaodManager payloadManager;
	
	@Override
	public void processAsync(AvailabilityResultsCaiso availabilityResults) throws RCINTApplicationException {
		Map<String,AvailabilityResultsWrapper> outageAvailabilityMap = payloadManager.preparePayload(availabilityResults);
		Set<String>  outagedResources = availabilityResultsDAO.createAvailabilityResults(availabilityResults,outageAvailabilityMap);
		generationOutageReceiver.processAsyn(outagedResources);
		
	}
	
}
