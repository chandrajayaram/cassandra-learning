package com.caiso.rcint.domain;

import javax.xml.datatype.XMLGregorianCalendar;

public class XMLGregorianCalendarInterval {
	private XMLGregorianCalendar start;
	private XMLGregorianCalendar end;
	
	public XMLGregorianCalendarInterval(XMLGregorianCalendar start, XMLGregorianCalendar end) {
		this.start= start;
		this.end= end;
	}
	public XMLGregorianCalendar getStart() {
		return start;
	}
	public void setStart(XMLGregorianCalendar start) {
		this.start = start;
	}
	public XMLGregorianCalendar getEnd() {
		return end;
	}
	public void setEnd(XMLGregorianCalendar end) {
		this.end = end;
	}

}
