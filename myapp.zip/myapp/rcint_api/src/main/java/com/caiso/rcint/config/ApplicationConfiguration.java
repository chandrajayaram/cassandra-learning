package com.caiso.rcint.config;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.velocity.Template;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolExecutorFactoryBean;

@Configuration
@EnableConfigurationProperties
@ComponentScan(basePackages = { "com.caiso.rcint.*" })
@Import({ DBConfig.class, JMSConfig.class, QuartzConfig.class, WebServiceConfig.class })
@EnableAsync
@EnableRetry
public class ApplicationConfiguration {

    @Bean
    public VelocityEngine velocityEngine() {
        VelocityEngine ve = new VelocityEngine();
        ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
        ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
        ve.setProperty("classpath.resource.loader.path", "templates");
        ve.init();
        return ve;
    }

    @Bean
    public Template cosTransmissionOutageTemplate(VelocityEngine velocityEngine) {
        return velocityEngine.getTemplate("templates/cosTransmissionOutage.vm");
    }

    @Bean
    public Template cosGenOutageTemplate(VelocityEngine velocityEngine) {
        return velocityEngine.getTemplate("templates/cosGenOutage.vm");
    }

    @Bean
    public Template cosGenOutageCancelTemplate(VelocityEngine velocityEngine) {
        return velocityEngine.getTemplate("templates/cosGenOutageCancel.vm");
    }

    @Bean
    public Template cosTransmissionOutageCancelTemplate(VelocityEngine velocityEngine) {
        return velocityEngine.getTemplate("templates/cosTransmissionOutageCancel.vm");
    }

    @Bean
    public Template ackTemplate(VelocityEngine velocityEngine) {
        return velocityEngine.getTemplate("templates/regulatoryAuthorityResponse.vm");
    }

    @Bean
    public ExecutorService cosExecutorService() {
        return Executors.newFixedThreadPool(5);
    }

    @Bean
    public HttpClient defaultHttpClient() {
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setDefaultMaxPerRoute(5);
        connectionManager.setMaxTotal(100);
        return HttpClients.createMinimal(connectionManager);
    }
    
    @Bean
    public ExecutorService transmisiionOutageExecutorService() {
        return Executors.newFixedThreadPool(5); 
    }
    
    @Bean
    public ExecutorService resourceOutageExecutorService() {
        return Executors.newFixedThreadPool(1); 
    }
    
    
    
    
}
