/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 13, 2017 3:16:19 PM
 * Project: caiso-rcint_api
 * File: DbPropertyServiceImpl.java
 */
package com.caiso.rcint.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.rcint.dao.RCConfigJpaRepository;
import com.caiso.rcint.dao.RCPublishInfoRepository;
import com.caiso.rcint.entity.RCConfig;
import com.caiso.rcint.entity.RCPublishInfo;

/**
 * @author gselvaratnam
 *
 */
@Service
public class DbPropertyServiceImpl implements DbPropertyService {

    @Autowired
    private RCConfigJpaRepository rcConfigDao;

    @Autowired
    private RCPublishInfoRepository rcPublishInfoRepository;

    /* (non-Javadoc)
     * @see com.caiso.rcint.service.DbPropertyService#addOrUpdateProperty(java.lang.String, java.lang.String)
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void createOrUpdateProperty(String propertyName, String value) {
        RCConfig rcConfig = rcConfigDao.findByProperty(propertyName);

        if(rcConfig == null) {
            rcConfig = new RCConfig();
            rcConfig.setProperty(propertyName);
            rcConfig.setPropertyValue(value);
            rcConfig.setCreatedDate(new Date());
            rcConfig.setUpdatedDate(new Date());    
        } else {
            rcConfig.setUpdatedDate(new Date());
            rcConfig.setPropertyValue(value);
        }

        rcConfigDao.save(rcConfig);
    }

    @Override
    public String getProperty(String propertyName) {
        String propVal = null;
        RCConfig rcConfig = rcConfigDao.findByProperty(propertyName);

        if(rcConfig != null) {
            propVal = rcConfig.getPropertyValue();
        }

        return propVal;
    }

    @Override
    public RCPublishInfo getRCPublishInfo(String typeName) {
        return rcPublishInfoRepository.findByTypeName(typeName);
    }
}
