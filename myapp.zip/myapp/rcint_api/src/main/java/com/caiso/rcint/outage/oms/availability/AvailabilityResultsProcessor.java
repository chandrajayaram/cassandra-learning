package com.caiso.rcint.outage.oms.availability;

import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;

public interface AvailabilityResultsProcessor {
	public void processAsync(AvailabilityResultsCaiso availabilityResults) throws RCINTApplicationException;
}
