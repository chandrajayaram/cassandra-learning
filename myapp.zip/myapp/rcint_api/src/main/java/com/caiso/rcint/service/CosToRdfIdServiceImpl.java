package com.caiso.rcint.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.caiso.rcint.dao.RCRdfIdMapDao;
import com.caiso.rcint.domain.RCRdfIdMap;

@Service
public class CosToRdfIdServiceImpl implements CosToRdfIdService {

    @Autowired
    private RCRdfIdMapDao rcRdfIdMapDao;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.caiso.rcint.service.CosToRdfIdService#findAllRCRdfIdMaps(java.lang.
     * String)
     */
    @Override
    public List<RCRdfIdMap> findAllRCRdfIdMaps(String cosName) {
        return rcRdfIdMapDao.findByCosNameRdfIdIsNotNull(cosName);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public boolean addNewRCRdfIdMap(String controlArea, String stationName, Double voltageClass, String equipmentName) {

        boolean response = false;

        List<RCRdfIdMap> rcRdfIdMapList = rcRdfIdMapDao.findByCosName(equipmentName);

        if(CollectionUtils.isEmpty(rcRdfIdMapList)) {
        
            RCRdfIdMap newRCRdfIdMap = new RCRdfIdMap();
            newRCRdfIdMap.setControlArea(controlArea);
            newRCRdfIdMap.setStation(stationName);
            newRCRdfIdMap.setVoltageClass(String.valueOf(voltageClass));
            newRCRdfIdMap.setCosName(equipmentName);
            newRCRdfIdMap.setCreatedDate(new Date());
            newRCRdfIdMap.setUpdatedDate(new Date());
            newRCRdfIdMap.setUpdatedBy("RCINTAPI");

            rcRdfIdMapDao.createRCRdfIdMap(newRCRdfIdMap);
            response = true;
        } else {
            RCRdfIdMap newRCRdfIdMap = new RCRdfIdMap();
            newRCRdfIdMap.setControlArea(controlArea);
            newRCRdfIdMap.setStation(stationName);
            newRCRdfIdMap.setVoltageClass(String.valueOf(voltageClass));
            newRCRdfIdMap.setCosName(equipmentName);
            newRCRdfIdMap.setCreatedDate(new Date());
            newRCRdfIdMap.setUpdatedDate(new Date());
            newRCRdfIdMap.setUpdatedBy("RCINTAPI");
            
            if(!rcRdfIdMapList.contains(newRCRdfIdMap)) {
                rcRdfIdMapDao.createRCRdfIdMap(newRCRdfIdMap);
                response = true;
            }
        }

        return response;
    }
}
