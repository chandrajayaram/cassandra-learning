/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 28, 2017 6:51:43 PM
 * Project: rcint-app
 * File: MasterDataDAO.java
 */
package com.caiso.rcint.dao;

import java.util.Map;
import java.util.Set;

import com.caiso.rcint.domain.WECCEquipment;

/**
 * @author gselvaratnam
 *
 */
public interface MasterDataDAO {

    Map<String, WECCEquipment> findWECCEquipment(Set<String> rdfids);

}