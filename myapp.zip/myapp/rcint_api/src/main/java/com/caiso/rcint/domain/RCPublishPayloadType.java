/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 3, 2017 10:31:14 AM
 * Project: rcint-app
 * File: RCPublishPayloadType.java
 */
package com.caiso.rcint.domain;

/**
 * @author gselvaratnam
 *
 */
public enum RCPublishPayloadType {
    FAILED,
    IN_SERVICE,
    REJECTED,
    CANCELLED,
    SUCCESS,
    NEW,
    ERROR,
    REVISED;
}
