package com.caiso.rcint.domain;

public class WECCEquipment {
	
	private String subStation;  
	private String eqNname;  
	private String baseVoltage;  
	private String eqType;  
	private String rdfid;  
	private String substationLongname;  
	private String modSwitchLabel; 
	private String lineType; 
	/*updated_dts          
	updated_by*/  
	private String cosLabel; 
	private String subControlArea;

	
	public String getSubStation() {
		return subStation;
	}
	public void setSubStation(String subStation) {
		this.subStation = subStation;
	}
	public String getEqNname() {
		return eqNname;
	}
	public void setEqNname(String eqNname) {
		this.eqNname = eqNname;
	}
	public String getBaseVoltage() {
		return baseVoltage;
	}
	public void setBaseVoltage(String baseVoltage) {
		this.baseVoltage = baseVoltage;
	}
	public String getEqType() {
		return eqType;
	}
	public void setEqType(String eqType) {
		this.eqType = eqType;
	}
	public String getRdfid() {
		return rdfid;
	}
	public void setRdfid(String rdfid) {
		this.rdfid = rdfid;
	}
	public String getSubstationLongname() {
		return substationLongname;
	}
	public void setSubstationLongname(String substationLongname) {
		this.substationLongname = substationLongname;
	}
	public String getModSwitchLabel() {
		return modSwitchLabel;
	}
	public void setModSwitchLabel(String modSwitchLabel) {
		this.modSwitchLabel = modSwitchLabel;
	}
	public String getLineType() {
		return lineType;
	}
	public void setLineType(String lineType) {
		this.lineType = lineType;
	}
	public String getCosLabel() {
		return cosLabel;
	}
	public void setCosLabel(String cosLabel) {
		this.cosLabel = cosLabel;
	}
	public String getSubControlArea() {
		return subControlArea;
	}
	public void setSubControlArea(String subControlArea) {
		this.subControlArea = subControlArea;
	}
		
}
