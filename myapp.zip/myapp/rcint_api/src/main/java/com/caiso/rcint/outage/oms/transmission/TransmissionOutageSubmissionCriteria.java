package com.caiso.rcint.outage.oms.transmission;

import java.sql.ResultSet;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import com.caiso.soa.transmissionoutageresultscaiso_v2.EquipmentOutage;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutage;
import com.caiso.soa.transmissionoutageresultscaiso_v2.WorkKind;
import com.caiso.soa.transmissionoutageresultscaiso_v2.YesNo;

@Component
public class TransmissionOutageSubmissionCriteria {

    @Autowired
	private NamedParameterJdbcTemplate rcintJdbcTemplate;

    private Set<String> operatingParticaipantMRIDs = new HashSet<>();
	private Set<WorkKind> supportedWorkKinds = new HashSet<>();
	
	private static final String SELECT_EQUIPMENT_EXCEPTION = "SELECT EXCEPTION_TYPE FROM WECC_RESOURCES "
			+ "WHERE EQUIPMENT_ID=:EQUIPMENT_ID AND EFFECTIVE_START <= CURRENT_TIMESTAMP AND EFFECTIVE_END > CURRENT_TIMESTAMP";
	
	public TransmissionOutageSubmissionCriteria(){
		operatingParticaipantMRIDs.add("TO02"); //SDGE - San Diego Gas & Electric
		operatingParticaipantMRIDs.add("TO03"); //SCE - Southern California Edison
		operatingParticaipantMRIDs.add("TO05"); //PGE - Pacific Gas & Electric
		operatingParticaipantMRIDs.add("TO06"); //City of Azusa
		operatingParticaipantMRIDs.add("TO07"); //City of Banning
		operatingParticaipantMRIDs.add("TO08"); //City of Riverside
		operatingParticaipantMRIDs.add("TO09"); //City of Anaheim
		operatingParticaipantMRIDs.add("TO10"); //City of Vernon
		operatingParticaipantMRIDs.add("TO11"); //City of Pasadena
		operatingParticaipantMRIDs.add("TO12"); //Western Area Power Admin.
		operatingParticaipantMRIDs.add("TO13"); //DATC Path 15
		operatingParticaipantMRIDs.add("TO14"); //STARTRANS IO
		operatingParticaipantMRIDs.add("TO15"); //TBC - Trans Bay Cable
		operatingParticaipantMRIDs.add("TO17"); //VEA
		//operatingParticaipantMRIDs.add("TO18"); //SVP
		//operatingParticaipantMRIDs.add("TO19"); //MWD
		//operatingParticaipantMRIDs.add("TO20"); //CCSF
		
		supportedWorkKinds.add(WorkKind.RELAY_WORK);
		supportedWorkKinds.add(WorkKind.EQUIPMENT_DERATE);
		supportedWorkKinds.add(WorkKind.EQUIPMENT_ABNORMAL);
		supportedWorkKinds.add(WorkKind.PATH_LIMITATION);
		supportedWorkKinds.add(WorkKind.ENERGIZED_WORK);
		supportedWorkKinds.add(WorkKind.COMMUNICATIONS);
	}
	
	
	public boolean isSubmissionCriteriaMet(TransmissionOutage outage){
		EquipmentOutage outageEquipment = outage.getEquipments().get(0);
		boolean faultyEquipment = isEquipmentHasException(outageEquipment.getName());
		if (faultyEquipment) {
			return false;
		}
		
		String operatingParticipantMRID = outage.getOperatingParticipant().getMRID();
		boolean submitOutageToRegulatoryAuthority = outage.getRegulatoryAuthorityOutage()
				.isSubmitOutageToRegulatoryAuthority();
		
		if (!submitOutageToRegulatoryAuthority && !operatingParticaipantMRIDs.contains(operatingParticipantMRID)){
			return false;
		}
		
		boolean outageEquipmentHasSwitches = outageEquipment.getOutagedEquipment().getSwitches().isEmpty();
		if (outageEquipmentHasSwitches && outage.getAffectsRASSPS() == YesNo.NO && !supportedWorkKinds.contains(outage.getWork().getKind())) {
			return false;									
		}
		
		return true;
	}
	
	private boolean isEquipmentHasException(String equipmentName) {
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue("EQUIPMENT_ID", equipmentName);
		return rcintJdbcTemplate.query(SELECT_EQUIPMENT_EXCEPTION, parameterSource, (ResultSet rs) -> {
				while (rs.next()) {
					return rs.getString("EXCEPTION_TYPE") == null ? false : true;
				}
				return false;
			});
	}
}
