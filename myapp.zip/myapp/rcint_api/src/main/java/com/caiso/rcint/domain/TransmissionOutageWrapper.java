package com.caiso.rcint.domain;

import javax.xml.bind.annotation.XmlRootElement;

import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutage;

@XmlRootElement(name = "TransmissionOutageWrapper")
public class TransmissionOutageWrapper {
	
	
	private TransmissionOutage transmissionOutage;

	public TransmissionOutage getTransmissionOutage() {
		return transmissionOutage;
	}

	public void setTransmissionOutage(TransmissionOutage transmissionOutage) {
		this.transmissionOutage = transmissionOutage;
	}
	
}
