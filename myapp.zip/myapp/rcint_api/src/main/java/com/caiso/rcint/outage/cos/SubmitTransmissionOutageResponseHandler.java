/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 7, 2017 2:16:15 PM
 * Project: rcint-app
 * File: SubmitTransmissionOutageResponseHandler.java
 */
package com.caiso.rcint.outage.cos;

import javax.xml.bind.JAXBException;

import com.caiso.soa.transmissionoutagedata_v1.TransmissionOutageData;

/**
 * @author gselvaratnam
 *
 */
public interface SubmitTransmissionOutageResponseHandler {

    /**
     * Make the OMS SubmitTransmissionOutage call.
     * @param omsOutageDataObject
     * @param logRefId
     * @param payloadId
     * @return the OMS ID if sucessfull.
     * @throws JAXBException
     */
    String handleResponse(TransmissionOutageData omsOutageDataObject, String logRefId, Long payloadId) throws JAXBException;

}