/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 3, 2017 12:44:06 PM
 * Project: rcint-app
 * File: CosSubmitTransmissionOutageService.java
 */
package com.caiso.rcint.outage.cos;

import java.util.List;

import com.caiso.rcint.dao.WECCOutageData;

import ca.equinox.crow.ReturnedOutage;

/**
 * @author gselvaratnam
 *
 */
public interface CosSubmitTransmissionOutageService {

    void processSubmitTransmissionOutage(ReturnedOutage returnedOutage, List<WECCOutageData> weccOutageDataList, boolean bWeccOutagePublishedToOMS,
            String logRefId);

}