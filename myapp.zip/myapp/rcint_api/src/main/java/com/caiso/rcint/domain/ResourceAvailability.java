package com.caiso.rcint.domain;

import static com.caiso.rcint.util.Utils.formatDateTimeWithGivenPatternFn;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public class ResourceAvailability {
	private String outageId;
	private String mrid;
	private List<Availability> availabilities;
	private Interval dateInterval;
	private BigDecimal maximumOperatingMW; 
	
	public BigDecimal getMaximumOperatingMW() {
		return maximumOperatingMW;
	}

	public void setMaximumOperatingMW(BigDecimal maximumOperatingMW) {
		this.maximumOperatingMW = maximumOperatingMW;
	}

	public Interval getDateInterval() {
		return dateInterval;
	}

	public void setDateInterval(Interval dateInterval) {
		this.dateInterval = dateInterval;
	}

	public String getMrid() {
		return mrid;
	}

	public void setMrid(String mrid) {
		this.mrid = mrid;
	}

	public List<Availability> getAvailabilities() {
		return availabilities;
	}

	public void setAvailabilities(List<Availability> availabilities) {
		this.availabilities = availabilities;
	}

	public BigDecimal calculateMinimumAvailabilityNextDay() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DAY_OF_MONTH, 1);
		final Date nextDay = cal.getTime();
			
		Function<Availability, BigDecimal> mapper =(Availability aval)-> {
			if((aval.getInterval().getStartDate().compareTo(nextDay) <1) &&	(aval.getInterval().getEndDate().compareTo(dateInterval.getStartDate()) >1)){
				return aval.getValue();
			}else{
				return BigDecimal.valueOf(99999);	
			}
		};
		Optional<BigDecimal> val = availabilities.stream().map(mapper).min(BigDecimal::compareTo);
		return val.isPresent()? val.get(): BigDecimal.valueOf(0);
	}
	
	public BigDecimal calculateMinimumMW() {
		Optional<BigDecimal> val = availabilities.stream().map(e -> e.getValue()).min(BigDecimal::compareTo);
		return val.isPresent()? val.get(): BigDecimal.valueOf(0);
	}

	public String createAvailabilityPayloadData() {
		StringBuilder builder = new StringBuilder("{\"Availability_mw_profile\":  [\n");
		List<String> recs = new ArrayList<>();
		availabilities.forEach(availibility -> {
			Date startDate;
			if(availibility.getInterval().getStartDate().compareTo(new Date())<1){
				startDate = new Date(); 
			}else{
				startDate = availibility.getInterval().getStartDate();
			}
			recs.add("{\"dt\": \"" + formatDateTimeWithGivenPatternFn.apply(startDate,"MM/dd/yyyy HH:mm:ss")
					+ "\", \"mw\": \"" + availibility.getValue().floatValue() + "\"}");
		});
		builder.append(String.join(",\n", recs));
		builder.append("\n]}");
		return builder.toString();
	} 
	public String getOutageId() {
		return outageId;
	}

	public void setOutageId(String outageId) {
		this.outageId = outageId;
	}

	public BigDecimal getAmountToDerate() {
		Optional<BigDecimal> totalAmoutToDerate = availabilities.stream().filter(e -> !e.isOutOfService()).map(e -> e.getValue()).min(BigDecimal::compareTo);
		if(totalAmoutToDerate.isPresent()){
			return totalAmoutToDerate.get(); 
		}else{
			return BigDecimal.valueOf(0);
		}
		
		/*for(Availability avai: availabilityData){
			totalAmoutToDerate = totalAmoutToDerate.add(avai.getValue());
		}
		if(totalAmoutToDerate.intValue()==0){
			return totalAmoutToDerate;
		}else{
			totalAmoutToDerate = maximumOperatingMW.subtract(totalAmoutToDerate);
			return totalAmoutToDerate;
		}*/
		
	}
	public int getPortionOutType() {
		BigDecimal totalAmoutToDerate = getAmountToDerate();
		if(totalAmoutToDerate.intValue() == 0 || totalAmoutToDerate.compareTo(maximumOperatingMW)==0){
			return 0;
		}else{
			return 3;
		}
	}
	
	
}
