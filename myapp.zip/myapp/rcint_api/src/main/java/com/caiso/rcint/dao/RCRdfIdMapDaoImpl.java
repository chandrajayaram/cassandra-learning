/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 28, 2017 6:50:45 PM
 * Project: rcint-app
 * File: RCRdfIdMapDaoImpl.java
 */
package com.caiso.rcint.dao;

import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.domain.RCRdfIdMap;

/**
 * @author gselvaratnam
 *
 */
@Repository
public class RCRdfIdMapDaoImpl implements RCRdfIdMapDao {

    public static final String FIND_BY_COS_NAME_RDFID_IS_NOT_NULL = "SELECT * FROM RC_RDFID_MAP WHERE COS_NAME = :COS_NAME AND RDF_ID IS NOT NULL";
    public static final String FIND_BY_COS_NAME_RDFID = "SELECT * FROM RC_RDFID_MAP WHERE COS_NAME = :COS_NAME";

    public static final Logger logger = LoggerFactory.getLogger(WECCOutageDataDAOImpl.class);

    @Autowired
    private NamedParameterJdbcTemplate rcintJdbcTemplate;

    private SimpleJdbcInsert insertRCRdfIdMap;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.insertRCRdfIdMap = new SimpleJdbcInsert(dataSource).withTableName("RC_RDFID_MAP");
    }

    /* (non-Javadoc)
     * @see com.caiso.rcint.dao.RCRdfIdMapDao#findByCosNameRdfIdIsNotNull(java.lang.String)
     */
    @Override
    public List<RCRdfIdMap> findByCosNameRdfIdIsNotNull(String cosName) {
        logger.debug("RCRdfIdMapDaoImpl::findByCosNameRdfIdIsNotNull : {}", cosName);

        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("COS_NAME",cosName);

        List<RCRdfIdMap> responseList = rcintJdbcTemplate.query(FIND_BY_COS_NAME_RDFID_IS_NOT_NULL, paramSource,
                new BeanPropertyRowMapper<RCRdfIdMap>(RCRdfIdMap.class));

       return responseList;
    }

    @Override
    public List<RCRdfIdMap> findByCosName(String cosName) {
        logger.debug("RCRdfIdMapDaoImpl::findByCosName : {}", cosName);

        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("COS_NAME",cosName);

        List<RCRdfIdMap> responseList = rcintJdbcTemplate.query(FIND_BY_COS_NAME_RDFID, paramSource,
                new BeanPropertyRowMapper<RCRdfIdMap>(RCRdfIdMap.class));

       return responseList;
    }

    @Override
    public void createRCRdfIdMap(RCRdfIdMap rcRdfIdMap) {
        SqlParameterSource parameterSource = new BeanPropertySqlParameterSource(rcRdfIdMap);
        insertRCRdfIdMap.execute(parameterSource);
    }
}
