package com.caiso.rcint.dao;

import static com.caiso.rcint.util.Utils.xmlGregorianCalendarToSqlTimeStampFn;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBException;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.domain.PayloadStatus;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.soa.framework.utils.CAISOUtils;
import com.caiso.soa.framework.utils.SOAPUtils;

@Repository
public class MessagePayloadDAOImpl implements MessagePayloadDAO {

	public static final Logger logger = LoggerFactory.getLogger(MessagePayloadDAOImpl.class);

	private static final String INSERT_RC_OMS_MESSAGE_HEADER = "INSERT INTO RC_OMS_MESSAGE_HEADER(TIME_DATE,SOURCE,VERSION,TYPE) VALUES (:TIME_DATE,:SOURCE,:VERSION,:TYPE)";
	
	private static final String INSERT_RC_OMS_MESSAGE_PAYLOAD = "INSERT INTO RC_OMS_MESSAGE_PAYLOAD(MESSAGE_ID,MRID,VERSIONID,PAYLOAD,STATUS,OUTAGE_START_DATE,OUTAGE_END_DATE) VALUES (:MESSAGE_ID,:MRID,:VERSIONID,:PAYLOAD,:STATUS,:OUTAGE_START_DATE,:OUTAGE_END_DATE)";
	
	private static final String SELECT_RC_OMS_MESSAGE_PAYLOAD = "SELECT H.MESSAGE_ID, TIME_DATE, SOURCE, VERSION, PAYLOAD FROM RC_OMS_MESSAGE_HEADER H INNER JOIN RC_OMS_MESSAGE_PAYLOAD P ON H.MESSAGE_ID = P.MESSAGE_ID WHERE OID = :OID";	
	
	private static final String SELECT_OUTAGE = "SELECT PAYLOAD FROM RC_OMS_MESSAGE_PAYLOAD P INNER JOIN RC_OMS_MESSAGE_HEADER H ON ON H.MESSAGE_ID = P.MESSAGE_ID WHERE MRID = :MRID AND OUTAGE_START_DATE = :OUTAGE_START_DATE AND OUTAGE_END_DATE = :OUTAGE_END_DATE AND TYPE = :TYPE";
	
	private static final String SELECT_OUTAGE_LIST = "SELECT PAYLOAD FROM RC_OMS_MESSAGE_PAYLOAD P INNER JOIN RC_OMS_MESSAGE_HEADER H ON ON H.MESSAGE_ID = P.MESSAGE_ID WHERE MRID = :MRID AND OUTAGE_START_DATE >= :OUTAGE_START_DATE AND OUTAGE_END_DATE <= :OUTAGE_END_DATE AND TYPE = :TYPE";

	private static final String SELECT_OUTAGE_BY_STATUS = "SELECT OID,PAYLOAD FROM RC_OMS_MESSAGE_PAYLOAD P, RC_OMS_MESSAGE_HEADER H,(SELECT MRID, MAX (VERSIONID) VERSIONID FROM RCINT_MSTR.RC_OMS_MESSAGE_PAYLOAD WHERE MRID IN(:MRIDS) GROUP BY MRID) V WHERE H.MESSAGE_ID = P.MESSAGE_ID AND P.MRID IN(:MRIDS) AND TYPE = :TYPE AND STATUS = :STATUS AND P.MRID= V.MRID AND P.VERSIONID = V.VERSIONID";
	
	private static final String UPDATE_MESSAGE_STATUS = "UPDATE RC_OMS_MESSAGE_PAYLOAD SET STATUS = :STATUS, NOTES= :NOTES WHERE OID = :OID";
	
	private static final String SELECT_RC_OMS_MESSAGE_PAYLOAD_BY_OID = "SELECT PAYLOAD FROM RC_OMS_MESSAGE_PAYLOAD WHERE OID in(:OIDS)";	

	

	@Autowired
	private NamedParameterJdbcTemplate rcintJdbcTemplate;
	
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.MessagePayloadDAO#createMessageHeader(javax.xml.datatype.XMLGregorianCalendar, java.lang.String, java.lang.String, java.lang.String)
     */
	@Override
    public long createMessageHeader(XMLGregorianCalendar dateTime, String source, String version, String payloadType) {
		logger.info("Creating message header for transmission outage");
		KeyHolder keyHolder = new GeneratedKeyHolder();
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TIME_DATE", xmlGregorianCalendarToSqlTimeStampFn.apply(dateTime));
		paramSource.addValue("SOURCE", source);
		paramSource.addValue("VERSION", version);
		paramSource.addValue("TYPE", payloadType);
		int row = rcintJdbcTemplate.update(INSERT_RC_OMS_MESSAGE_HEADER, paramSource, keyHolder,
				new String[] { "MESSAGE_ID" });
		if (row > 0) {
			long messageId = keyHolder.getKey().longValue();
			logger.info("Created message header for outage with messageId " + messageId);
			return messageId;
		}
		return -1;
	}

	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.MessagePayloadDAO#createMessagePayload(java.lang.Object, long, java.lang.String, long, javax.xml.datatype.XMLGregorianCalendar, javax.xml.datatype.XMLGregorianCalendar)
     */
	@Override
    public long createMessagePayload(Object outage, long messageId,String mrid, long version,XMLGregorianCalendar startDateTime,XMLGregorianCalendar endDateTime) throws RCINTApplicationException{
		logger.info("Creating message payload for outage");
		try (ByteArrayOutputStream outputStream = SOAPUtils.marshal(outage)) {
			byte[] bytes = CAISOUtils.compressBase64(outputStream.toByteArray());

			KeyHolder keyHolder = new GeneratedKeyHolder();
			MapSqlParameterSource paramSource = new MapSqlParameterSource();
			paramSource.addValue("MESSAGE_ID", messageId);
			paramSource.addValue("MRID", mrid);
			paramSource.addValue("VERSIONID", version);
			paramSource.addValue("PAYLOAD", bytes, Types.BINARY);
			paramSource.addValue("STATUS", PayloadStatus.RECEIVED.toString());
			paramSource.addValue("OUTAGE_START_DATE",xmlGregorianCalendarToSqlTimeStampFn.apply(startDateTime));
			paramSource.addValue("OUTAGE_END_DATE",xmlGregorianCalendarToSqlTimeStampFn.apply(endDateTime));
			
			int row = rcintJdbcTemplate.update(INSERT_RC_OMS_MESSAGE_PAYLOAD, paramSource, keyHolder, new String[] { "OID" });
			if (row > 0) {
				long oid = keyHolder.getKey().longValue();
				logger.info("Created message payload for outage with messageId " + messageId + " OID " + oid);
				return oid;
			}
		} catch (IOException | JAXBException  e ){
			throw new RCINTApplicationException(e);
		} 
		 
		return -1;
	}
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.MessagePayloadDAO#getOutagePayload(long, org.springframework.jdbc.core.ResultSetExtractor)
     */
	@Override
    public <T> T getOutagePayload(long oid,ResultSetExtractor<T> resultSetExtractor){
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("OID", oid);
		
		return  rcintJdbcTemplate.query(SELECT_RC_OMS_MESSAGE_PAYLOAD, paramSource,resultSetExtractor);
	}
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.MessagePayloadDAO#getOutagePayload(java.lang.String, javax.xml.datatype.XMLGregorianCalendar, javax.xml.datatype.XMLGregorianCalendar, java.lang.String)
     */
	@Override
    public String  getOutagePayload(String mrid, XMLGregorianCalendar start, XMLGregorianCalendar end, String type) throws RCINTApplicationException{
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("MRID", mrid);
		paramSource.addValue("OUTAGE_START_DATE",xmlGregorianCalendarToSqlTimeStampFn.apply(start));
		paramSource.addValue("OUTAGE_END_DATE",xmlGregorianCalendarToSqlTimeStampFn.apply(end));
		paramSource.addValue("TYPE",type);
		
		return  rcintJdbcTemplate.query(SELECT_OUTAGE, paramSource, new ResultSetExtractor<String>() {
			@Override
			public String extractData(ResultSet rs) {
				try {
					while (rs.next()) {
						byte [] compressedData = rs.getBytes("PAYLOAD");
						ByteArrayOutputStream bytes = CAISOUtils.decompressBase64(compressedData);
						return bytes.toString();
					} 
				} catch (SQLException | IOException e) {
						throw new RCINTRuntimeException(e);
				}
				return null;
			}
		});
	}
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.MessagePayloadDAO#updateMessageStatus(long, com.caiso.rcint.domain.PayloadStatus, java.lang.String)
     */
	@Override
    public void updateMessageStatus(long oid, PayloadStatus status, String notes){
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("OID", oid);
		paramSource.addValue("STATUS",status.toString());
		paramSource.addValue("NOTES",notes);
		rcintJdbcTemplate.update(UPDATE_MESSAGE_STATUS, paramSource);
	}

	@Override
	public List<String> getOutagePayloadList(String mrid, XMLGregorianCalendar start, XMLGregorianCalendar end,
			String type) throws RCINTApplicationException {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("MRID", mrid);
		paramSource.addValue("OUTAGE_START_DATE",xmlGregorianCalendarToSqlTimeStampFn.apply(start));
		paramSource.addValue("OUTAGE_END_DATE",xmlGregorianCalendarToSqlTimeStampFn.apply(end));
		paramSource.addValue("TYPE",type);
		
		return  rcintJdbcTemplate.query(SELECT_OUTAGE_LIST, paramSource, new ResultSetExtractor<List<String>>() {
			@Override
			public List<String> extractData(ResultSet rs) {
				List<String> paylaods = new ArrayList<>();
				try {
					while (rs.next()) {
						byte [] compressedData = rs.getBytes("PAYLOAD");
						ByteArrayOutputStream bytes = CAISOUtils.decompressBase64(compressedData);
						paylaods.add(bytes.toString());
					} 
				} catch (SQLException | IOException e) {
						throw new RCINTRuntimeException(e);
				}
				return paylaods;
			}
		});
	}
	
	@Override
	public Map<Long,String> getOutagePayloadList(Set<String> mrids, String type, PayloadStatus status) throws RCINTApplicationException {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("MRIDS", mrids);
		paramSource.addValue("TYPE",type);
		paramSource.addValue("STATUS", status.toString());
		return  rcintJdbcTemplate.query(SELECT_OUTAGE_BY_STATUS, paramSource, new ResultSetExtractor<Map<Long,String>>() {
			@Override
			public Map<Long,String> extractData(ResultSet rs) {
				Map<Long,String> paylaods = new HashMap<>();
				try {
					while (rs.next()) {
						byte [] compressedData = rs.getBytes("PAYLOAD");
						ByteArrayOutputStream bytes = CAISOUtils.decompressBase64(compressedData);
						paylaods.put(rs.getLong("OID"), bytes.toString());
					} 
				} catch (SQLException | IOException e) {
						throw new RCINTRuntimeException(e);
				}
				return paylaods;
			}
		});
	}
	
	@Override
	public List<String> getOutagePayloadList(Set<Long> oids) throws RCINTApplicationException {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("OIDS", oids);
		return  rcintJdbcTemplate.query(SELECT_RC_OMS_MESSAGE_PAYLOAD_BY_OID, paramSource, new ResultSetExtractor<List<String>>() {
			@Override
			public List<String> extractData(ResultSet rs) {
				List<String> paylaods = new ArrayList<>();
				try {
					while (rs.next()) {
						byte [] compressedData = rs.getBytes("PAYLOAD");
						ByteArrayOutputStream bytes = CAISOUtils.decompressBase64(compressedData);
						paylaods.add(bytes.toString());
					} 
				} catch (SQLException | IOException e) {
						throw new RCINTRuntimeException(e);
				}
				return paylaods;
			}
		});
	}
	

}