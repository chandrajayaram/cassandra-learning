/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 26, 2017 6:00:35 PM
 * Project: rcint-app
 * File: EventType.java
 */
package com.caiso.rcint.domain;

/**
 * @author gselvaratnam
 *
 */
public enum ProcessLogEventType {
    /**
     * Start
     */
    PROCESS_START,

    /**
     * End
     */
    PROCESS_END,

    /***************************************************
     * Wecc types start
     ***************************************************/

    /**
     * Wecc outages
     */
    RETRIEVE_WECC_OUTAGES,
    /**
     * Control areas
     */
    RETRIEVE_CONTROL_AREAS,
    /**
     * Load outages
     */
    LOAD_OUTAGES,
    /**
     * Process outages
     */
    PROCESS_OUTAGES,
    /**
     * Outage
     */
    OUTAGE,
    /**
     * Outage data
     */
    OUTAGE_DATA,

    /**
     * Outage data
     */
    LOAD_OUTAGE_INFO,

    /**
     * Publish
     */
    PUBLISH,

    /***************************************************
     * Wecc types END
     ***************************************************/

    PROCESSING,

    PROCESS_SEND,

    PROCESS_RECEIVE,

    PROCESS_TRANSFORM,

    PROCESS_PUBLISH,

    PROCESS_COMPLETE,

    PROCESS_EXCEPTION,

    PROCESS_FAILED,

    PROCESS_RETRY,

    PROCESS_RESPONSE_ERROR;
}
