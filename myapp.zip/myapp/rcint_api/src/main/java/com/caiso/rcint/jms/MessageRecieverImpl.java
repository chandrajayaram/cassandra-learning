/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Dec 14, 2016 2:00:22 PM
 * Project: caiso-rcint_api
 * File: MessageRecieverImpl.java
 */
package com.caiso.rcint.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.soap.MimeHeaders;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;

import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.outage.oms.transmission.TransmissionOutageProcessor;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

/**
 * @author gselvaratnam
 *
 */
@Service
@Profile("jms")
public class MessageRecieverImpl implements MessageReciever {

    private static final Logger logger = LoggerFactory.getLogger(MessageRecieverImpl.class);

    @Autowired
    private TransmissionOutageProcessor transmissionOutageProcessor;
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.caiso.rcint.jms.MessageReciever#recieveTransmissionOutage(javax.jms.
     * Message)
     */
    @Override
    @JmsListener(destination = "Consumer.A.VirtualTopic.Order")
    public void recieveTransmissionOutage(Message theJmsMessage) {
        logger.info("BEGIN::MessageRecieverImpl.recieveTransmissionOutage");
        String theStringMessage = "";
        if (theJmsMessage instanceof TextMessage) {
            try {
                theStringMessage = ((TextMessage) theJmsMessage).getText();
                logger.debug("The message : " + theStringMessage);
            } catch (JMSException jmsException) {
                throw new RCINTRuntimeException(jmsException);
            }
        } else {
            throw new RCINTRuntimeException("Unknown JMS message type!");
        }
        
        if(StringUtils.isNotEmpty(theStringMessage)) {
            if(theStringMessage.contains("TransmissionOutageResultsCaiso")) {
                TransmissionOutageResultsCaiso transmissionOutageResultsCaiso;
                try {
                    transmissionOutageResultsCaiso = extractTransmissionOutageResultsCaiso(theStringMessage, theJmsMessage);
                    transmissionOutageProcessor.processAsync(transmissionOutageResultsCaiso);
                } catch (Exception exception) {
                    throw new RCINTRuntimeException(exception);
                }
            }
        }
        logger.info("BEGIN::MessageRecieverImpl.recieveTransmissionOutage");
    }

    private TransmissionOutageResultsCaiso extractTransmissionOutageResultsCaiso(String theSoapRequest, Message theJmsMessage) throws Exception {
        TransmissionOutageResultsCaiso responseObj = null;
        
        // These headers are added by camel. We need these headers to
        // recreate soap message.
        // All custom headers will be available as string property.
        MimeHeaders headers = new MimeHeaders();
        headers.addHeader("Content-Type", (String) theJmsMessage.getStringProperty("Content_HYPHEN_Type"));
        headers.addHeader("Content-Length", (String) theJmsMessage.getStringProperty("content_HYPHEN_length"));
        headers.addHeader("Accept-Encoding", (String) theJmsMessage.getStringProperty("accept_HYPHEN_encoding"));
        headers.addHeader("SOAPAction", (String) theJmsMessage.getStringProperty("soapaction"));

//        String attachement = SoapHelper.extractAttachementFromSoapRequest(theSoapRequest, headers);

//        responseObj = SoapHelper.getTransmissionOutageResultsCaiso(attachement);

        return responseObj;
    }
}
