/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Dec 22, 2016 1:20:10 PM
 * Project: caiso-rcint_api
 * File: DateUtil.java
 */
package com.caiso.rcint.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import com.caiso.rcint.domain.RCIntConstants;
import com.caiso.rcint.exception.RCINTRuntimeException;

/**
 * @author gselvaratnam
 *
 */
public final class DateUtil {

    private static final String GMT_DATETIME_FORMAT = "yyyy/MM/dd HH:mm:ssZ";
    private static final String DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss";
    private static final String DATE_FORMAT = "yyyy/MM/dd";
    private static final String TIME_FORMAT= "HH:mm:ss";
    public static final String COS5_DATE_FORMAT ="yyyy/MM/dd HH:mm:ss";
    public static final String NEW_DATE_FORMAT ="MM/dd/yyyy HH:mm:ss";

    /**
     * Converts the date class in to an <code>XMLGregorianCalendar</code> object. 
     * The default System time zone will be used within the <code>XMLGregorianCalendar</code> object.
     * @param date
     * @return
     */
    public static XMLGregorianCalendar getXmlGregorianCalendar(Date date) {

        XMLGregorianCalendar xmlGregorianCalendar = null;

        if (date != null) {
            GregorianCalendar gregorianCalendar = new GregorianCalendar();
            gregorianCalendar.setTime(date);
            try {
                xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
            } catch (DatatypeConfigurationException datatypeConfigurationException) {
                throw new RCINTRuntimeException(datatypeConfigurationException);
            }
        }
        return xmlGregorianCalendar;
    }

    public static Calendar getCalendarDate(String date) {
        
        /*
        String date = "2014/05/28 15:00:00-0000" // since we know that the date is GMT let's add the GMT offset.  That way it will get created correctly
                  
        SimpleDateFormat inDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ssZ");
        Calendar calendar = Calendar.getInstance();

        Date formattedDate = inDateFormat.parse(date);
        calendar.setTime(formattedDate);
        
        SimpleDateFormat outDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        outDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        
        String timestamp = outDateFormat.format(calendar.getTime());       
              System.out.println("timestamp: " + timestamp);
        */
              
        SimpleDateFormat dateFormat = new SimpleDateFormat(GMT_DATETIME_FORMAT);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        try {
            Date formattedDate = dateFormat.parse(date+"-0000");
            calendar.setTime(formattedDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return calendar;

    }

    public static XMLGregorianCalendar getXMLGregorianCalendarDate(String date) {
        
        XMLGregorianCalendar xmlGregorianCalendar = null;
              
        SimpleDateFormat dateFormat = new SimpleDateFormat(GMT_DATETIME_FORMAT);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        
        try {
            Date formattedDate = dateFormat.parse(date+"-0000");
            calendar.setTime(formattedDate);
            xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
        } catch (Exception exception) {
            throw new RCINTRuntimeException(exception);
        }
        
        return xmlGregorianCalendar;

    }
    
    public static String formatDate(Calendar date, String format) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        if (date == null || format == null) {
            return "";
        }       
        
        return dateFormat.format(date.getTime());       
    }
    
    public static String getTimeFromDate(String dateValue){
        SimpleDateFormat dateFormatatter = new SimpleDateFormat(DATE_TIME_FORMAT);
        SimpleDateFormat timeFormatter = new SimpleDateFormat(TIME_FORMAT);
        Date date = null;
        try {
            date = dateFormatatter.parse(dateValue);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return timeFormatter.format(date);
    
    }
    
    public static String addDaysToDate(String dateValue, int days){
        SimpleDateFormat dateFormatatter = new SimpleDateFormat(DATE_TIME_FORMAT);
        Date date = null;
        try {
            date = dateFormatatter.parse(dateValue);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days);
 
        return new SimpleDateFormat(DATE_FORMAT).format(cal.getTime());
    
    }
    
    public static Calendar getCurrentDateAndTime() {
        // create a calendar
          Calendar cal = Calendar.getInstance();

          // get the current time
          System.out.println("Current time is :" + cal.getTime());

          // create new date and set it
          Date date = new Date();
          cal.setTime(date);
          
          // print the new time
          System.out.println("After setting Time:  " + cal.getTime());
          return cal;
    }
    
    public static DateTime getCurrentHourInUTC(){
        return  new DateTime(DateTimeZone.UTC).hourOfDay().roundFloorCopy();
    }

    /**
     * Convert to <code>UTC</code> {@link XMLGregorianCalendar} from {@link Date}.
     *
     * @param dateString
     * @return
     */
    public static XMLGregorianCalendar convertToXmlGregorianCalendar(Date givenDate) {
        XMLGregorianCalendar xmlGregorianCalendar = null;
        try {
            GregorianCalendar gregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
            gregorianCalendar.setTime(givenDate);
            xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
        } catch (Exception exception) {
            throw new RCINTRuntimeException(exception);
        }
        return xmlGregorianCalendar;
    }

    public static Date getDateFromString(String dateValue) {
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        Date parsedDate  = null;
        try {
            parsedDate = df.parse(dateValue);
        } 
        catch (ParseException parseException) {
            throw new RCINTRuntimeException(parseException);
        }
        return parsedDate;
    }

    public static Date getDateFromString(String dateValue, String dateFormat) {
        DateFormat df = new SimpleDateFormat(dateFormat);
        Date parsedDate  = null;
        try {
            parsedDate = df.parse(dateValue);
        } 
        catch (ParseException parseException) {
            throw new RCINTRuntimeException(parseException);
        }
        return parsedDate;
    }
}
