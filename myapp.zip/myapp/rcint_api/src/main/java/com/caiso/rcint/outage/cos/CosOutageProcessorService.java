/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 9, 2017 10:19:49 AM
 * Project: caiso-rcint_api
 * File: CosOutageProcessorService.java
 */
package com.caiso.rcint.outage.cos;

/**
 * @author gselvaratnam
 *
 */
public interface CosOutageProcessorService {

    String SERVICE_NAME = "CosOutageProcessorService";
    String  COS_OUTPROC_SVC_LAST_RUNTIME = "COS_OUTPROC_SVC_LAST_RUNTIME";

    void processOmsOutages();

    void manageService(Boolean status);

}
