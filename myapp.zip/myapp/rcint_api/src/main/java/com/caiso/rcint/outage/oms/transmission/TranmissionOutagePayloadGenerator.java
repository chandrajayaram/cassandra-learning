package com.caiso.rcint.outage.oms.transmission;

import static com.caiso.rcint.util.Utils.formatDateTimeFn;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caiso.rcint.dao.ConfigDAO;
import com.caiso.rcint.dao.MasterDataDAO;
import com.caiso.rcint.dao.WECCOutageDataDAO;
import com.caiso.rcint.domain.Interval;
import com.caiso.rcint.domain.WECCEquipment;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.CosOutageDataMapper;
import com.caiso.rcint.outage.oms.common.WECCPayload;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.transmissionoutageresultscaiso_v2.EquipmentOutage;
import com.caiso.soa.transmissionoutageresultscaiso_v2.OutageStatusKind;
import com.caiso.soa.transmissionoutageresultscaiso_v2.PSRKind;
import com.caiso.soa.transmissionoutageresultscaiso_v2.SwitchState;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutage;

@Service
public class TranmissionOutagePayloadGenerator {
	
	private List<OutageStatusKind> statusKindCancelRequest;
	
	public static final Logger logger = LoggerFactory.getLogger(TranmissionOutagePayloadGenerator.class);
	
	private Template cosTransmissionOutageTemplate;
	private Template cosTransmissionOutageCancelTemplate;
	
	
	private ConfigDAO config;
	private MasterDataDAO masterData;
	private	WECCOutageDataDAO weccOutageDataDAO;
	
	@Autowired
	private	CosOutageDataMapper  cosOutageDataMapper;
	
	
	public WECCPayload generatePayload(long oid, TransmissionOutage outage) throws RCINTApplicationException {
		try {
				WECCPayload weccPayload = new WECCPayload();
				EquipmentOutage outageEquipment = outage.getEquipments().get(0);
				VelocityContext context = new VelocityContext();
				
				context.put("cosUserName", config.getConfigProperty("WECC_COS_USERNAME"));
				context.put("cosPassword", config.getConfigProperty("WECC_COS_PASSWORD"));
				context.put("omsOutageId", outage.getMRID());
				
				Interval interval = Utils.getInterval(outage); 
				
				if(interval.getStartDate() != null){
					context.put("startDate", formatDateTimeFn.apply(interval.getStartDate()));
					weccPayload.addData("OUTAGE_START_DTS", interval.getStartDate());
				}
				
				if (interval.getEndDate() != null) {
						context.put("endDate", formatDateTimeFn.apply(interval.getEndDate()));
						weccPayload.addData("OUTAGE_END_DTS", interval.getEndDate());
				}

				context.put("duration", Utils.calculateDuration(interval).toString());
				
				context.put("outagePriority", cosOutageDataMapper.mapCosOutagePriorityId(outage));

				String resourceType = getResourceType(outageEquipment);
				context.put("resourceType", resourceType);
				context.put("resourceName", "");

				String resourceName = getResourceName(outage);
				context.put("resourceLabelName", resourceName);
				weccPayload.addData("EQUIPMENT_NAME", resourceName);

				
				context.put("shortDescription", outage.getDescription().replace("\n", "").replace("\r", ""));
				context.put("label", resourceName);
				
				SwitchState state = outageEquipment.getOutagedEquipment().getSwitches().get(0).getSwitchingOperations()
						.get(0).getNewState();
				
				if (state == SwitchState.OPEN)
					context.put("status", "Open");
				else
					context.put("status", "Closed");
				context.put("userName", config.getConfigProperty("WECC_COS_USERNAME"));
				
				Template template;
				if(statusKindCancelRequest.contains(outage.getOutageStatus())){
					template = cosTransmissionOutageCancelTemplate;
				}else{
					template = cosTransmissionOutageTemplate;
					String peakId= weccOutageDataDAO.findWeccOutageId(outage.getMRID(), outage.getVersionID().intValue());	
					if(peakId == null){
						context.put("peakId", "");
						context.put("action", "SubmitRequest");
					}else{
						context.put("peakId", peakId);
						context.put("action", "SaveChanges");
					}
					String statusId;
					if((statusId = cosOutageDataMapper.mapCosOutageStatusId(outage)) != null){
						context.put("statusId", "<crow:outageStatusID>"+statusId+"</crow:outageStatusID>");	
					}else{
						context.put("statusId", "");	
					}
					
					context.put("voltage", getBaseVoltage(outage));
					if (outage.getComment() == null) {
						context.put("reason", outage.getDescription());
					} else if (outage.getComment().length() > 400) {
						context.put("reason", outage.getComment().substring(0, 400));
					} else {
						context.put("reason",outage.getComment());
					}
					String operatingRestriction ="";
					if ("SUBSTATION".equals(resourceType) || resourceName == null)
						context.put("portionOutType", "5");
					else
						context.put("portionOutType", "0");
					
					if ("SUBSTATION".equals(resourceType)) {
						operatingRestriction = "Sub Station";
					} else if (resourceName == null) {
						operatingRestriction = "Operating Restriction";
					}
					context.put("operatingRestriction",operatingRestriction);
					context.put("deratedToAmount","0");
					
				}
				
				StringWriter writer = new StringWriter();
				template.merge(context, writer);
				ByteArrayInputStream in = new ByteArrayInputStream(writer.toString().getBytes());
				MessageFactory factory = MessageFactory.newInstance();
				MimeHeaders headers = new MimeHeaders();
				SOAPMessage message = factory.createMessage(headers, in);
				weccPayload.setWeccPayload(message);
				return weccPayload;
		} catch (IOException | SOAPException e) {
			logger.error("Error occoured while generating the transmission outage payload", e);
			throw new RCINTApplicationException(e);
		}
	}

	

	private String getResourceType(EquipmentOutage equipment) {
		PSRKind psrKind = equipment.getPSRType().getType();
		if (psrKind == PSRKind.ACLINESEGMENT || psrKind == PSRKind.LINE) {
			return PSRKind.LINE.value();
		} else if (psrKind == PSRKind.COMMUNICATIONS) {
			return "RemedialActionScheme";
		} else {
			return "";
		}
	}

	public String getResourceName(TransmissionOutage outage) {
		
		boolean submitOutageToRegulatoryAuthority = outage.getRegulatoryAuthorityOutage()
				.isSubmitOutageToRegulatoryAuthority();
		EquipmentOutage outageEquipment = outage.getEquipments().get(0);
		String rdfids = outageEquipment.getMRID();
		Set<String> setRDFIDS = new HashSet<>();
		setRDFIDS.add(rdfids);
		WECCEquipment weccEquipment = masterData.findWECCEquipment(setRDFIDS).get(rdfids);
		if (submitOutageToRegulatoryAuthority) {
			if (weccEquipment.getCosLabel() != null) {
				return weccEquipment.getCosLabel();
			} else {
				return outageEquipment.getName();
			}
		}
		PSRKind psrKind = outageEquipment.getPSRType().getType();
		if (psrKind == PSRKind.ACLINESEGMENT || psrKind == PSRKind.LINE || psrKind == PSRKind.COMMUNICATIONS) {
			return outage.getEquipments().get(0).getName();
		} else if (psrKind == PSRKind.SUBSTATION) {
			return weccEquipment.getSubstationLongname();
		} else if ((psrKind == PSRKind.DISCONNECT || psrKind == PSRKind.BREAKER)
				&& weccEquipment.getModSwitchLabel() != null) {
			return weccEquipment.getModSwitchLabel();
		} else {
			if (outageEquipment.getName() != null) {
				return weccEquipment.getSubstationLongname() + " " + weccEquipment.getBaseVoltage() + "kV" + " "
						+ outageEquipment.getPSRType().getType().value() + " " + outageEquipment.getName();
			} else {
				return "";
			}
		}
		
	}
	private String getBaseVoltage(TransmissionOutage outage) {
		EquipmentOutage equipment = outage.getEquipments().get(0);
		PSRKind psrKind = equipment.getPSRType().getType();
		String rdfids = equipment.getMRID();
		Set<String> setRDFIDS = new HashSet<>();
		setRDFIDS.add(rdfids);
		WECCEquipment weccEquipment = masterData.findWECCEquipment(setRDFIDS).get(rdfids);
		if(weccEquipment != null){
			if (psrKind == PSRKind.POWERTRANSFORMER) {
				return weccEquipment.getBaseVoltage().substring(0, 2);
			} else {
				if (weccEquipment.getBaseVoltage() != null) {
					return weccEquipment.getBaseVoltage();
				} else {
					return "0";
				}
			}
		}
		return "0";
	}
	@Autowired
	public void setCosTransmissionOutageTemplate(Template cosTransmissionOutageTemplate) {
		this.cosTransmissionOutageTemplate = cosTransmissionOutageTemplate;
	}
	
	@Autowired
	public void setConfig(ConfigDAO config) {
		this.config = config;
	}
	
	@Autowired
	public void setMasterData(MasterDataDAO masterData) {
		this.masterData = masterData;
	}
	@Autowired
	public void setCosTransmissionOutageCancelTemplate(Template cosTransmissionOutageCancelTemplate) {
		this.cosTransmissionOutageCancelTemplate = cosTransmissionOutageCancelTemplate;
	}
	
	@PostConstruct
	private void initialize() {

		statusKindCancelRequest = new ArrayList<>();
		statusKindCancelRequest.add(OutageStatusKind.CANCELLED);
		statusKindCancelRequest.add(OutageStatusKind.DISAPPROVED);
	}
	
	@Autowired
	public void setWeccOutageDataDAO(WECCOutageDataDAO weccOutageDataDAO) {
		this.weccOutageDataDAO = weccOutageDataDAO;
	}

	
}
