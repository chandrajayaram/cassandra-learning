/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
@Entity
@Table(name = "WECC_OUTAGE_REGAUTH_UPDATE")
public class WeccOutageRegAuthUpdate implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    @Id
    @SequenceGenerator(name = "WECC_OUTAGE_PAYLOAD_ID_GENERATOR", sequenceName = "WECC_OUTAGE_PAYLOAD_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "WECC_OUTAGE_PAYLOAD_ID_GENERATOR")
    @Column(name = "ID", nullable = false)
    private Long              id;

    @Column(name = "WECC_OUTAGE_ID")
    private String            weccOutageId;

    @Column(name = "PAYLOAD_ID")
    private Long              payloadId;

    @Column(name = "OMS_OUTAGE_ID")
    private String            omsOutageId;

    @Column(name = "OMS_OUTAGE_VERSION")
    private int               omsOutageVersion;

    @Column(name = "CREATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              createdDate;

    @Column(name = "UPDATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              updatedDate;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the weccOutageId
     */
    public String getWeccOutageId() {
        return weccOutageId;
    }

    /**
     * @param weccOutageId
     *            the weccOutageId to set
     */
    public void setWeccOutageId(String weccOutageId) {
        this.weccOutageId = weccOutageId;
    }

    /**
     * @return the payloadId
     */
    public Long getPayloadId() {
        return payloadId;
    }

    /**
     * @param payloadId
     *            the payloadId to set
     */
    public void setPayloadId(Long payloadId) {
        this.payloadId = payloadId;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * @return the omsOutageId
     */
    public String getOmsOutageId() {
        return omsOutageId;
    }

    /**
     * @param omsOutageId the omsOutageId to set
     */
    public void setOmsOutageId(String omsOutageId) {
        this.omsOutageId = omsOutageId;
    }

    /**
     * @return the omsOutageVersion
     */
    public int getOmsOutageVersion() {
        return omsOutageVersion;
    }

    /**
     * @param omsOutageVersion the omsOutageVersion to set
     */
    public void setOmsOutageVersion(int omsOutageVersion) {
        this.omsOutageVersion = omsOutageVersion;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final WeccOutageRegAuthUpdate other = (WeccOutageRegAuthUpdate) obj;
        return Objects.equals(this.id, other.id) && Objects.equals(this.payloadId, other.payloadId) && Objects.equals(this.weccOutageId, other.weccOutageId)
                && Objects.equals(this.createdDate, other.createdDate) && Objects.equals(this.updatedDate, other.updatedDate)
                && Objects.equals(this.omsOutageId, other.omsOutageId) && Objects.equals(this.omsOutageVersion, other.omsOutageVersion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.payloadId, this.weccOutageId, this.createdDate, this.updatedDate, this.omsOutageId, this.omsOutageVersion);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}