package com.caiso.rcint.outage.oms.generation;

import static com.caiso.rcint.util.Utils.formatDateTimeFn;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.caiso.rcint.dao.ConfigDAO;
import com.caiso.rcint.dao.MasterDataDAO;
import com.caiso.rcint.domain.Interval;
import com.caiso.rcint.domain.ResourceAvailability;
import com.caiso.rcint.domain.XMLGregorianCalendarInterval;
import com.caiso.rcint.outage.oms.CosOutageDataMapper;
import com.caiso.rcint.outage.oms.common.WECCPayload;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.availabilityresultscaiso_v1.RegisteredGenerator;
import com.caiso.soa.resourceoutageresultscaiso_v2.OutageStatusKind;
import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;

@Service
public class GenerationOutagePayloadGenerator {

	private List<OutageStatusKind> statusKindSubmitRequest;
	private List<OutageStatusKind> statusKindCancelRequest;
	
	public static final Logger logger = LoggerFactory.getLogger(GenerationOutagePayloadGenerator.class);

	private static final String SELECT_RES_NAME_LABEL = "SELECT RESMRID,NVL(WG.EIM_INDICATOR,'N') AS EIM_INDICATOR, CASE WHEN (UPPER(wg.EIM_INDICATOR) ='Y') THEN TO_CHAR (NVL (wg.COS_LABEL, '')) ELSE pvAllRes.RESMRID END AS RES_ID , wg.station_name AS station_name  FROM pvallresource pvAllRes, WECC_GENERATORS wg WHERE"
			+ " PVALLRES.RESMRID = wg.RES_ID"
			+ " AND PVALLRES.RESMRID IN(:MRIDS)  AND PVALLRES.RESSTARTEFFECTIVEDATE <= :START_DATE"
			+ " AND PVALLRES.RESENDEFFECTIVEDATE > :START_DATE AND PVALLRES.UPDATENOTICE = 'A'"
			+ " AND (PVALLRES.EIMPARTICIPATING IS NULL OR :SUBMIT_REG_AUTH = 'true') AND PVALLRES.MARKETPARTICIPATIONFLAG ='Y'";

	private NamedParameterJdbcTemplate rcintJdbcTemplate;

	private Template cosGenOutageTemplate;
	private Template cosGenOutageCancelTemplate;
	private ConfigDAO config;
	private AvailabilityPayloadDataGenerator availabilityPayloadGenerator;
	
	@Autowired
	private	CosOutageDataMapper  cosOutageDataMapper;
	
	@Autowired
	public void setAvailabilityPayloadGenerator(AvailabilityPayloadDataGenerator availabilityPayloadGenerator) {
		this.availabilityPayloadGenerator = availabilityPayloadGenerator;
	}

	@Autowired
	public void setRcintJdbcTemplate(NamedParameterJdbcTemplate rcintJdbcTemplate) {
		this.rcintJdbcTemplate = rcintJdbcTemplate;
	}

	private void createSOAPMessage(Template template, VelocityContext context, WECCPayload weccPayload) {
		try {
			StringWriter writer = new StringWriter();
			template.merge(context, writer);
			ByteArrayInputStream in = new ByteArrayInputStream(writer.toString().getBytes());
			MessageFactory factory = MessageFactory.newInstance();
			MimeHeaders headers = new MimeHeaders();
			SOAPMessage message = factory.createMessage(headers, in);
			weccPayload.setWeccPayload(message);
		} catch (IOException | SOAPException e) {
			logger.error("Error occoured while generating the GENERATION outage payload", e);
		}
	}
	

	private String getResourceLabelName(Set<String> mrids, XMLGregorianCalendarInterval outageInterval,
			boolean sumbitOutageToRegAuthority) {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("MRIDS", mrids);
		parameters.addValue("SUBMIT_REG_AUTH", sumbitOutageToRegAuthority);
		parameters.addValue("START_DATE", outageInterval.getStart().toGregorianCalendar().getTime());
		
		return rcintJdbcTemplate.query(SELECT_RES_NAME_LABEL, parameters, rs -> {
			StringBuilder resourceName = new StringBuilder();
			String eimIndicator;
			String resId;
			String pefix;
			while (rs.next()) {
				resId = rs.getString("RES_ID");
				eimIndicator = rs.getString("EIM_INDICATOR");
				pefix = " ";
				if ("Y".equals(eimIndicator)) {
					pefix = " ";
				} else if (null != rs.getString("station_name")) {
					pefix = rs.getString("station_name") + " ";
				}
				resourceName.append(pefix + resId);
			}
			return resourceName.toString();
		});

	}

	private XMLGregorianCalendarInterval getInterval(RegisteredResourceOutage outage) {
		XMLGregorianCalendar startDate = null;
		XMLGregorianCalendar endDate = null;
		if (outage.getActualPeriod() != null) {
			if (outage.getActualPeriod().getStart() != null) {
				startDate = outage.getActualPeriod().getStart();
			}
			if (outage.getActualPeriod().getEnd() != null) {
				endDate = outage.getActualPeriod().getEnd();
			}
		} else if (outage.getEstimatedPeriod() != null) {
			if (outage.getEstimatedPeriod().getStart() != null) {
				startDate = outage.getEstimatedPeriod().getStart();
			}
			if (outage.getEstimatedPeriod().getEnd() != null) {
				endDate = outage.getEstimatedPeriod().getEnd();
			}
		}
		return new XMLGregorianCalendarInterval(startDate, endDate);
	}

	private Interval getDateInterval(RegisteredResourceOutage outage) {
		Date startDate = null;
		Date endDate = null;
		if (outage.getActualPeriod() != null) {
			if (outage.getActualPeriod().getStart() != null) {
				startDate = outage.getActualPeriod().getStart().toGregorianCalendar().getTime();
			}
			if (outage.getActualPeriod().getEnd() != null) {
				endDate = outage.getActualPeriod().getEnd().toGregorianCalendar().getTime();
			}
		} else if (outage.getEstimatedPeriod() != null) {
			if (outage.getEstimatedPeriod().getStart() != null) {
				startDate = outage.getEstimatedPeriod().getStart().toGregorianCalendar().getTime();
			}
			if (outage.getEstimatedPeriod().getEnd() != null) {
				endDate = outage.getEstimatedPeriod().getEnd().toGregorianCalendar().getTime();
			}
		}
		return new Interval(startDate, endDate);
	}

	@Autowired
	public void setConfig(ConfigDAO config) {
		this.config = config;
	}

	@Autowired
	public void setMasterData(MasterDataDAO masterData) {
	}

	@Autowired
	public void setCosGenOutageTemplate(Template cosGenOutageTemplate) {
		this.cosGenOutageTemplate = cosGenOutageTemplate;
	}

	@Autowired
	public void setCosGenOutageCancelTemplate(Template cosGenOutageCancelTemplate) {
		this.cosGenOutageCancelTemplate = cosGenOutageCancelTemplate;
	}
	

	public WECCPayload process(RegisteredResourceOutage resourceOutage,
			List<RegisteredGenerator> registoredGenerators) {
		
		Map<String, List<ResourceAvailability>> resourceAvailibilityMap = availabilityPayloadGenerator
				.process(resourceOutage, registoredGenerators);

		boolean sumbitOutageToRegAuthority = resourceOutage.getRegulatoryAuthorityOutage()
				.isSubmitOutageToRegulatoryAuthority();
		String outageId = resourceOutage.getMRID();
		XMLGregorianCalendarInterval outageInterval = getInterval(resourceOutage);
		Interval dateInterval = getDateInterval(resourceOutage);

		Set<String> mrids = resourceOutage.getRegisteredGeneratorsAndRegisteredInterTiesAndRegisteredLoads()
				.stream().map(e -> e.getMRID()).collect(Collectors.toSet());
		
		String resourceLabel = getResourceLabelName(mrids, outageInterval, sumbitOutageToRegAuthority);

		WECCPayload weccPayload = new WECCPayload();
		VelocityContext context = new VelocityContext();

		context.put("cosUserName", config.getConfigProperty("WECC_COS_USERNAME"));
		context.put("cosPassword", config.getConfigProperty("WECC_COS_PASSWORD"));
		if(resourceOutage.getMktOrgOutageID()!= null && !resourceOutage.getMktOrgOutageID().isEmpty()){
			context.put("peakId", resourceOutage.getMktOrgOutageID());
		}else{
			context.put("peakId", "");	
		}
		
		context.put("omsOutageId", outageId);
		
		String reason = "";
     /*   if (resourceOutage.getComment() == null || resourceOutage.getComment().trim().length()==0) {
            reason = resourceOutage.getDescription();
        } else if (resourceOutage.getComment().length() > 400) {
            reason = resourceOutage.getComment().substring(0, 400);
        } else {
            reason = resourceOutage.getComment();
        }
        */
		

		if (dateInterval.getStartDate() != null) {
			context.put("startDate", formatDateTimeFn.apply(dateInterval.getStartDate()));
			weccPayload.addData("OUTAGE_START_DTS", dateInterval.getStartDate());
		}

		if (dateInterval.getEndDate() != null) {
			context.put("endDate", formatDateTimeFn.apply(dateInterval.getEndDate()));
			weccPayload.addData("OUTAGE_END_DTS", dateInterval.getEndDate());
		}

		context.put("duration", Utils.calculateDuration(dateInterval).toString());

		context.put("outagePriority", cosOutageDataMapper.mapCosOutagePriorityId(resourceOutage));


		context.put("resourceLabelName", resourceLabel);
        weccPayload.addData("EQUIPMENT_NAME", resourceLabel);

		context.put("userName", config.getConfigProperty("WECC_COS_USERNAME"));
		
		String shortDescription= resourceOutage.getDescription().replace("\n", "").replace("\r", "");
		
		context.put("shortDescription", shortDescription);
		
		if(statusKindCancelRequest.contains(resourceOutage.getOutageStatus())){
			createSOAPMessage(cosGenOutageCancelTemplate,context,weccPayload);
			return weccPayload;
		}
			
		if (statusKindSubmitRequest.contains(resourceOutage.getOutageStatus())) {
			context.put("action", "SubmitRequest");
		}else {
			context.put("action", "SaveChanges");
		}
		String statusId;
		
		if((statusId = cosOutageDataMapper.mapCosOutageStatusId(resourceOutage)) != null){
			context.put("statusId", "<crow:outageStatusID>"+statusId+"</crow:outageStatusID>");	
		}else{
			context.put("statusId", "");	
		}
		reason = shortDescription;
		List<ResourceAvailability> resourceAvailabilities =resourceAvailibilityMap.get(outageId);
        if(!CollectionUtils.isEmpty(resourceAvailabilities)) {
            ResourceAvailability resourceAvailability=  resourceAvailabilities.get(0);

            String availabilityData = resourceAvailability.createAvailabilityPayloadData();

            if (availabilityData != null && !availabilityData.isEmpty()) {
            	reason = reason + "\n " + availabilityData;
            }
            
            BigDecimal amountToDerate = resourceAvailability.getAmountToDerate();
            context.put("deratedToAmount", amountToDerate); 
            
            context.put("portionOutType", resourceAvailability.getPortionOutType());
        }
        context.put("reason", reason);

        
		createSOAPMessage(cosGenOutageTemplate,context,weccPayload);
		return weccPayload;
		
	}
	
	@PostConstruct 
	public void initialize(){
		statusKindSubmitRequest = new ArrayList<>();
		statusKindCancelRequest = new ArrayList<>();
		statusKindSubmitRequest.add(OutageStatusKind.LATE_TO_START);
		statusKindSubmitRequest.add(OutageStatusKind.LATE_TO_END);
		statusKindSubmitRequest.add(OutageStatusKind.OUT);
		statusKindSubmitRequest.add(OutageStatusKind.OUT_OK);
		statusKindSubmitRequest.add(OutageStatusKind.PRE_APPROVED);
		statusKindSubmitRequest.add(OutageStatusKind.RECEIVED);
		statusKindSubmitRequest.add(OutageStatusKind.APPROVED);
		statusKindSubmitRequest.add(OutageStatusKind.IN_OK);
		statusKindSubmitRequest.add(OutageStatusKind.IN_SERVICE);
		statusKindSubmitRequest.add(OutageStatusKind.IN_SERVICE_EDITABLE);
		statusKindSubmitRequest.add(OutageStatusKind.STUDY);
		statusKindSubmitRequest.add(OutageStatusKind.ISO_HOLD);
		statusKindSubmitRequest.add(OutageStatusKind.OE_NOT_RECOMMENDED);
		statusKindSubmitRequest.add(OutageStatusKind.OE_RECOMMENDED);

		statusKindCancelRequest.add(OutageStatusKind.CANCELLED);
		statusKindCancelRequest.add(OutageStatusKind.DISAPPROVED);
	}
}
