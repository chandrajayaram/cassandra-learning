/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 24, 2017 9:57:08 AM
 * Project: caiso-rcint_api
 * File: RCOutageRepository.java
 */
package com.caiso.rcint.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.entity.RCOutage;

/**
 * @author gselvaratnam
 *
 */
@Repository
public interface RCOutageRepository   extends JpaRepository<RCOutage, Long> {

}
