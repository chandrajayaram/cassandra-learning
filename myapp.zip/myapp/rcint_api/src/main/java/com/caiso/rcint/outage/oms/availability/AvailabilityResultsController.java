package com.caiso.rcint.outage.oms.availability;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.caiso.rcint.dao.RCPublishPayloadDAO;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;

@RestController
@RequestMapping("/availabilityPayload")
public class AvailabilityResultsController {
	
	@Autowired
	private AvailabilityResultsDAO availabilityDAO;
	
	@Autowired
	private RCPublishPayloadDAO rcPublishPayloadDAO; 
	
	
	@RequestMapping(path="/{oid}", method = RequestMethod.GET, produces="application/xml")
	public AvailabilityResultsCaiso retrieveAvailabilityResults(@PathVariable long oid) {
		return availabilityDAO.getAvailabilityResults(oid);
    }
	
	@RequestMapping(path="/cosPayload/{payloadId}", method = RequestMethod.GET, produces="application/xml")
	public String retrieveCOSPayload(@PathVariable long payloadId,HttpServletResponse response) {
		byte[] payload = rcPublishPayloadDAO.retrievePayload(payloadId);
		if(payload != null){
			return new String(rcPublishPayloadDAO.retrievePayload(payloadId));	
		}
		response.setStatus(HttpServletResponse.SC_NOT_FOUND);
		return null;
    }
}
