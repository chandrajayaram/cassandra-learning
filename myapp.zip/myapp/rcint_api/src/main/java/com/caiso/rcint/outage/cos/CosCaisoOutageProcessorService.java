/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 9, 2017 10:19:49 AM
 * Project: caiso-rcint_api
 * File: CosCaisoOutageProcessorService.java
 */
package com.caiso.rcint.outage.cos;

/**
 * @author gselvaratnam
 *
 */
public interface CosCaisoOutageProcessorService {

    String  SERVICE_NAME = "CosCaisoOutageProcessorService";
    String  COS_CAISO_OUTPROC_SVC_LAST_RUNTIME = "COS_CAISO_OUTPROC_SVC_LAST_RUNTIME";
    
    void processOmsOutages();

    void manageService(Boolean status);
}
