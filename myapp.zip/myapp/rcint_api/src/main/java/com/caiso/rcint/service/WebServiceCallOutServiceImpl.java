/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 18, 2017 1:41:32 PM
 * Project: caiso-rcint_api
 * File: WebServiceCallOutServiceImpl.java
 */
package com.caiso.rcint.service;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.apache.ws.security.util.UUIDGenerator;
import org.apache.xml.security.utils.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.xml.transform.StringSource;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.caiso.rcint.domain.RCIntConstants;
import com.caiso.rcint.domain.RCPublishInfoType;
import com.caiso.rcint.entity.RCPublishInfo;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.soa._2006_09_30.caisowsheader.CAISOUsernameTokenType;
import com.caiso.soa._2006_09_30.caisowsheader.CAISOWSHeaderType;
import com.caiso.soa.framework.utils.SOAPUtils;

/**
 * @author gselvaratnam
 *
 */
@Service
public class WebServiceCallOutServiceImpl implements WebServiceCallOutService {

    private static final Logger logger       = LoggerFactory.getLogger(WebServiceCallOutServiceImpl.class);

    private static final String SOAP_MESSAGE = "SOAP_MESSAGE";

    @Value("${peak.cos.username.label}")
    private String              peakCosUserNameLabel;

    @Value("${peak.cos.password.label}")
    private String              peakCosPasswordLabel;

    @Value("${peak.cos.url.label}")
    private String              peakCosUrlLabel;

    // TODO please remove this. Once the issue with the peakCosUrlLabel is
    // sorted out.
    @Value("${peak.cos.url}")
    private String              tempPeakCosUrl;

    @Value("${web.oms.username}")
    private String              webomsUserName;

    @Qualifier("webServiceTemplate_12")
    @Autowired
    private WebServiceTemplate  webServiceTemplate12;

    @Qualifier("webServiceTemplate_11")
    @Autowired
    private WebServiceTemplate webServiceTemplate11;

    @Autowired
    private DbPropertyService   dbPropertyService;

    @Override
    @Retryable(backoff = @Backoff(maxDelay = 5000))
    public String callPeakCosWebService(final String soapRequestXml, RCPublishInfoType rcPublishInfoType) {

        RCPublishInfo rcPublishInfo = dbPropertyService.getRCPublishInfo(rcPublishInfoType.name());
        if (rcPublishInfo == null) {
            throw new RCINTRuntimeException("Could not find RCPublishInfo for type : " + rcPublishInfoType.name());
        }

        final Map<String, SaajSoapMessage> messageContainer = new HashMap<>();
        WebServiceMessageCallback requestCallback = new WebServiceMessageCallback() {
            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                SaajSoapMessage soapMessage = (SaajSoapMessage) message;
                try {
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder builder = factory.newDocumentBuilder();
                    Document document = builder.parse(new InputSource(new StringReader(soapRequestXml)));
                    soapMessage.setDocument(document);
                    soapMessage.setSoapAction(rcPublishInfo.getSoapAction());

                    MimeHeaders mimeHeader = soapMessage.getSaajMessage().getMimeHeaders();
                    mimeHeader.setHeader("Accept-Encoding", "gzip,deflate");
                    mimeHeader.setHeader("Content-Type", "text/xml");
                    mimeHeader.setHeader("charset", "UTF-8");

                } catch (Exception exception) {
                    throw new RCINTRuntimeException(exception);
                }
            }
        };

        WebServiceMessageCallback responseCallback = new WebServiceMessageCallback() {
            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                SaajSoapMessage soapMessage = (SaajSoapMessage) message;
                messageContainer.put(SOAP_MESSAGE, soapMessage);
            }
        };

        webServiceTemplate12.sendAndReceive(rcPublishInfo.getDestination(), requestCallback, responseCallback);

        SaajSoapMessage soapMessage = messageContainer.get(SOAP_MESSAGE);
        String responseStr = extractSoapBodyAsString(soapMessage);
        return responseStr;
    }

    @Override
    @Retryable(backoff = @Backoff(maxDelay = 5000))
    public String callOmsWebService_soap_11(final String soapRequestXml, final String attachmentXml, RCPublishInfoType rcPublishInfoType) {
        String responseStr = null;

        final Map<String, SaajSoapMessage> messageContainer = new HashMap<>();

        RCPublishInfo rcPublishInfo = dbPropertyService.getRCPublishInfo(rcPublishInfoType.name());
        if (rcPublishInfo == null) {
            throw new RCINTRuntimeException("Could not find RCPublishInfo for type : " + rcPublishInfoType.name());
        }

        WebServiceMessageCallback requestCallback = new WebServiceMessageCallback() {
            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                SaajSoapMessage soapMessage = (SaajSoapMessage) message;
                try {
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder builder = factory.newDocumentBuilder();
                    Document document = builder.parse(new InputSource(new StringReader(soapRequestXml)));
                    soapMessage.setDocument(document);
                    soapMessage.setSoapAction(rcPublishInfo.getSoapAction());

                    MimeHeaders mimeHeader = soapMessage.getSaajMessage().getMimeHeaders();
                    mimeHeader.setHeader("Accept-Encoding", "gzip,deflate");
                    mimeHeader.setHeader("Content-Type", "multipart/related");
                    mimeHeader.setHeader("charset", "UTF-8");

                    GregorianCalendar c = new GregorianCalendar();
                    c.setTime(new Date());
                    XMLGregorianCalendar createdDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);

                    CAISOWSHeaderType caisoHeader = new CAISOWSHeaderType();
                    CAISOUsernameTokenType userTokenInfo = new CAISOUsernameTokenType();
                    caisoHeader.setCAISOUsernameToken(userTokenInfo);
                    userTokenInfo.setUsername(webomsUserName);
                    userTokenInfo.setNonce(Base64.encode(UUIDGenerator.getUUID().getBytes()));
                    userTokenInfo.setCreated(createdDate);

                    SoapHeader header = soapMessage.getSoapHeader();
                    Transformer transformer = TransformerFactory.newInstance().newTransformer();
                    transformer.transform(new StringSource(SOAPUtils.marshal(caisoHeader).toString()), header.getResult());
                    String attachmentName = rcPublishInfo.getAction() + "_attachement";
                    SOAPUtils.addMimeAttachmentToMessage(message, attachmentXml, rcPublishInfo.getAction(), attachmentName, rcPublishInfo.getSoapAction());

                } catch (Exception exception) {
                    throw new RCINTRuntimeException(exception);
                }
            }
        };

        WebServiceMessageCallback responseCallback = new WebServiceMessageCallback() {
            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                SaajSoapMessage soapMessage = (SaajSoapMessage) message;
                messageContainer.put(SOAP_MESSAGE, soapMessage);
            }
        };

        String urlStr = rcPublishInfo.getDestination();
        logger.debug("The OMS UR: : {}", urlStr);
        webServiceTemplate11.sendAndReceive(urlStr, requestCallback, responseCallback);
        SaajSoapMessage soapMessage = messageContainer.get(SOAP_MESSAGE);

        responseStr = extractSoapBodyAsString(soapMessage);

        return responseStr;
    }

    /**
     * @param soapRequestXml
     * @param messageContainer
     * @return
     */
    @Override
    @Retryable(backoff = @Backoff(maxDelay = 5000))
    public String callPeakCosWebService(final String soapRequestXml, String soapAction) {

        final Map<String, SaajSoapMessage> messageContainer = new HashMap<>();
        WebServiceMessageCallback requestCallback = new WebServiceMessageCallback() {
            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                SaajSoapMessage soapMessage = (SaajSoapMessage) message;
                try {
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder builder = factory.newDocumentBuilder();
                    Document document = builder.parse(new InputSource(new StringReader(soapRequestXml)));
                    soapMessage.setDocument(document);
                    soapMessage.setSoapAction(soapAction);

                    MimeHeaders mimeHeader = soapMessage.getSaajMessage().getMimeHeaders();
                    mimeHeader.setHeader("Accept-Encoding", "gzip,deflate");
                    mimeHeader.setHeader("Content-Type", "text/xml");
                    mimeHeader.setHeader("charset", "UTF-8");

                } catch (Exception exception) {
                    throw new RCINTRuntimeException(exception);
                }
            }
        };

        WebServiceMessageCallback responseCallback = new WebServiceMessageCallback() {
            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                SaajSoapMessage soapMessage = (SaajSoapMessage) message;
                messageContainer.put(SOAP_MESSAGE, soapMessage);
            }
        };

        webServiceTemplate12.sendAndReceive(tempPeakCosUrl, requestCallback, responseCallback);

        SaajSoapMessage soapMessage = messageContainer.get(SOAP_MESSAGE);
        String responseStr = extractSoapBodyAsString(soapMessage);
        return responseStr;
    }

    /**
     * @param soapRequestXml
     * @param messageContainer
     * @return
     */
    @Override
    @Retryable(backoff = @Backoff(maxDelay = 5000))
    public String callOmsWebService_soap_12(final String soapRequestXml, final String attachmentXml, RCPublishInfoType rcPublishInfoType) {
        final Map<String, SaajSoapMessage> messageContainer = new HashMap<>();

        RCPublishInfo rcPublishInfo = dbPropertyService.getRCPublishInfo(rcPublishInfoType.name());
        if (rcPublishInfo == null) {
            throw new RCINTRuntimeException("Could not find RCPublishInfo for type : " + rcPublishInfoType.name());
        }

        WebServiceMessageCallback requestCallback = new WebServiceMessageCallback() {
            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                SaajSoapMessage soapMessage = (SaajSoapMessage) message;
                try {
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder builder = factory.newDocumentBuilder();
                    Document document = builder.parse(new InputSource(new StringReader(soapRequestXml)));
                    soapMessage.setDocument(document);
                    soapMessage.setSoapAction(rcPublishInfo.getSoapAction());

                    MimeHeaders mimeHeader = soapMessage.getSaajMessage().getMimeHeaders();
                    mimeHeader.setHeader("Accept-Encoding", "gzip,deflate");
                    mimeHeader.setHeader("Content-Type", "multipart/related");
                    mimeHeader.setHeader("charset", "UTF-8");

                    GregorianCalendar c = new GregorianCalendar();
                    c.setTime(new Date());
                    XMLGregorianCalendar createdDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);

                    CAISOWSHeaderType caisoHeader = new CAISOWSHeaderType();
                    CAISOUsernameTokenType userTokenInfo = new CAISOUsernameTokenType();
                    caisoHeader.setCAISOUsernameToken(userTokenInfo);
                    userTokenInfo.setUsername(webomsUserName);
                    userTokenInfo.setNonce(Base64.encode(UUIDGenerator.getUUID().getBytes()));
                    userTokenInfo.setCreated(createdDate);

                    SoapHeader header = soapMessage.getSoapHeader();
                    Transformer transformer = TransformerFactory.newInstance().newTransformer();
                    transformer.transform(new StringSource(SOAPUtils.marshal(caisoHeader).toString()), header.getResult());
                    String attachmentName = rcPublishInfo.getAction() + "_attachement";
                    SOAPUtils.addMimeAttachmentToMessage(message, attachmentXml, rcPublishInfo.getAction(), attachmentName, rcPublishInfo.getSoapAction());

                } catch (Exception exception) {
                    throw new RCINTRuntimeException(exception);
                }
            }
        };

        WebServiceMessageCallback responseCallback = new WebServiceMessageCallback() {
            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                SaajSoapMessage soapMessage = (SaajSoapMessage) message;
                messageContainer.put(SOAP_MESSAGE, soapMessage);
            }
        };

        String urlStr = rcPublishInfo.getDestination();
        logger.debug("The OMS UR: : {}", urlStr);
        webServiceTemplate12.sendAndReceive(urlStr, requestCallback, responseCallback);
        SaajSoapMessage soapMessage = messageContainer.get(SOAP_MESSAGE);

        String responseStr = extractSoapBodyAsString(soapMessage);

        return responseStr;
    }

    /**
     * @param soapMessage
     */
    private String extractSoapBodyAsString(SaajSoapMessage soapMessage) {
        String responseStr;
        final StringWriter sw = new StringWriter();
        try {
            TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSoapBody().getPayloadSource(), new StreamResult(sw));
        } catch (Exception exception) {
            throw new RCINTRuntimeException(exception);
        }
        responseStr = new String(sw.toString());
        return responseStr;
    }

    /* Note: For COS 5 API
     * This method to construct the soap request for transmission outages from COS   * 
     */
    @Override
    public String getPeakOutageRequestQuery_ExecuteQuerySoapXMLString(String controlArea, String startTime, String endTime, String status, String lastRunTime) {

        String payload =  "<soapenv:Envelope xmlns:soapenv=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:crow=\"http://crow.equinox.ca/\">" +
                "              <soapenv:Header/> " +
                "               <soapenv:Body> " +
                "                  <crow:OutageRequestQuery_ExecuteQuery> " +
                "                      <crow:userName>" + dbPropertyService.getProperty(peakCosUserNameLabel) + "</crow:userName> " +
                "                      <crow:userPassword>" + dbPropertyService.getProperty(peakCosPasswordLabel) + "</crow:userPassword> " +
                "                      <crow:theOutageRequestQuery> " +
                "                      <crow:startDate>" + startTime +"</crow:startDate> " +
                "                      <crow:endDate>" + endTime +"</crow:endDate> " +
                "                      <crow:listingForClass>" + RCIntConstants.CONTROL_CENTER +"</crow:listingForClass> " +
//                "                      <crow:listingForConcat>" + controlArea + "-" + RCIntConstants.WILDCARD_CC + "</crow:listingForConcat> " +
                "                      <crow:listingForConcat>" + controlArea + "-" + RCIntConstants.TCC + "</crow:listingForConcat> " +
                "                      <crow:statusConcat>" + status +  "</crow:statusConcat>" +
                "                      <crow:sortBy>" + RCIntConstants.SWITCHING_START  + "</crow:sortBy> " +
                "                      <crow:sortOrder>" + RCIntConstants.ASC + "</crow:sortOrder> " +
                "                      <crow:lastUpdateStart>" + lastRunTime + "</crow:lastUpdateStart> " +
                "                      </crow:theOutageRequestQuery> " +
                "                  </crow:OutageRequestQuery_ExecuteQuery> " +
                "               </soapenv:Body> " +
                "           </soapenv:Envelope>";
        return payload;
    }

    @Override
    public String getPeakOutageSchedule_LoadItemSoapXMLString(String outageNumber, String revisionNumber) {

        String payload = "<soapenv:Envelope xmlns:soapenv=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:crow=\"http://crow.equinox.ca/\">" +
                "              <soapenv:Header/> " +
                "               <soapenv:Body> " +
                "                  <crow:OutageSchedule_LoadItem>" +
                "                     <crow:userName>" + dbPropertyService.getProperty(peakCosUserNameLabel) + "</crow:userName>" +
                "                     <crow:userPassword>" + dbPropertyService.getProperty(peakCosPasswordLabel) + "</crow:userPassword>" +
                "                     <crow:outageNumber>"+ outageNumber + "</crow:outageNumber>" +
                "                     <crow:revisionNumber>"+ revisionNumber + "</crow:revisionNumber>" +
                "                  </crow:OutageSchedule_LoadItem>" +
                "               </soapenv:Body> " +
                "           </soapenv:Envelope>";
                
        return payload;
    }
    
    @Override
    public String getOmsReceiveRegulatoryAuthorityOutageStatus_v1SoapXMLString() {
        String payload =  "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:rec=\"http://www.caiso.com/soa/receiveRegulatoryAuthorityOutageStatus_v1.wsdl\">" +
                "              <soapenv:Header></soapenv:Header>" +
                "              <soapenv:Body>" +
                "                  <rec:receiveRegulatoryAuthorityOutageStatus_v1/>" +
                "              </soapenv:Body>" +
                "          </soapenv:Envelope>";
        return payload;
    }

    @Override
    public String getOmsAttachementRegulatoryAuthorityOutageStatusXMLString(String timeDate, String omsOutageId, String omsOutageVersion, String errorMsg, String cosId, String status) {
        String payload =
                "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" +
                "<RegulatoryAuthorityOutageStatus xmlns=\"http://www.caiso.com/soa/RegulatoryAuthorityOutageStatus_v1.xsd#\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.caiso.com/soa/RegulatoryAuthorityOutageStatus_v1.xsd# file:///C:/Projects/RCINT/code/rcint_api/src/main/webapp/schema/regulatoryAuthorityOutageStatus/RegulatoryAuthorityOutageStatus_v1.xsd\">" + 
                "              <MessageHeader>" + 
                "                  <TimeDate>" + timeDate + "</TimeDate>" + 
                "                  <Source>RCINT</Source>" + 
                "                  <Version>v20161001</Version>" + 
                "              </MessageHeader>" + 
                "              <MessagePayload>" + 
                "                  <RegisteredResourceOutage>" + 
                "                      <mRID>" + omsOutageId + "</mRID>" + 
                "                      <versionID>" + omsOutageVersion + "</versionID>" + 
                "                      <RegulatoryAuthorityOutage>" + 
                "                          <regulatoryAuthorityOutageErrMessage>" + errorMsg + "</regulatoryAuthorityOutageErrMessage>" + 
                "                          <regulatoryAuthorityOutageID>" + cosId + "</regulatoryAuthorityOutageID>" + 
                "                          <regulatoryAuthorityOutageStatus>" + status + "</regulatoryAuthorityOutageStatus>" + 
                "                      </RegulatoryAuthorityOutage>" + 
                "                  </RegisteredResourceOutage>" + 
                "              </MessagePayload>" + 
                "          </RegulatoryAuthorityOutageStatus>";
        return payload;
    }

    @Override
    public String getOmsSubmitTransmissionOutage_v1SoapXMLString() {
        String payload =  "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"  xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:stan=\"http://www.caiso.com/soa/2006-06-13/StandardAttachmentInfor.xsd\" xmlns:att=\"http://www.caiso.com/soa/AttachmentInfor_v1.xsd\">" +
                "              <soapenv:Header></soapenv:Header>" +
                "              <soapenv:Body>" +
                "                  <att:AttachmentInfor>" +
                "                      <att:attachmentData>cid:306960071958</att:attachmentData>" +
                "                  </att:AttachmentInfor>" +
                "              </soapenv:Body>" +
                "          </soapenv:Envelope>";
        return payload;
    }
}
