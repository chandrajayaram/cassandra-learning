package com.caiso.rcint.outage.oms.generation;

import java.util.Map;
import java.util.Set;

import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;

public interface GenerationOutageReceiver {
	void processAsyn(Map<Long, RegisteredResourceOutage> resourceOutageMap);
	void processAsyn(Set<String> outagedResources) throws RCINTApplicationException;
}
