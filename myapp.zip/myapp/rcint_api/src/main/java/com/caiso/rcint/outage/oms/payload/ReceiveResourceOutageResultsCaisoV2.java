package com.caiso.rcint.outage.oms.payload;

import com.caiso.soa.framework.payload.DomainPayload;
import com.caiso.soa.resourceoutageresultscaiso_v2.ResourceOutageResultsCaiso;

public class ReceiveResourceOutageResultsCaisoV2 extends DomainPayload<ResourceOutageResultsCaiso>{

}
