/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 26, 2017 5:59:11 PM
 * Project: rcint-app
 * File: RCProcessLogServiceImpl.java
 */
package com.caiso.rcint.service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.rcint.dao.RCProcessLogRepository;
import com.caiso.rcint.entity.RCProcessLog;

/**
 * @author gselvaratnam
 *
 */
@Service
@Transactional(propagation = Propagation.REQUIRES_NEW)
public class RCProcessLogServiceImpl implements RCProcessLogService {

    private static final Logger    logger = LoggerFactory.getLogger(RCProcessLogServiceImpl.class);

    @Autowired
    private RCProcessLogRepository rcProcessLogRepository;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.caiso.rcint.service.RCProcessLogService#createLogEntry(java.lang.
     * String, java.lang.String, java.lang.String, java.lang.String,
     * java.lang.String)
     */
    @Override
    public void createLogEntry(String eventType, String refId, String serviceName, String processName, String description) {
        if(refId != null) {
            RCProcessLog rLog = new RCProcessLog();
            rLog.setDescription(trimString(description, 1000));
            rLog.setEventTime(new Date());
            rLog.setEventType(eventType);
            rLog.setProcessName(trimString(processName, 1000));
            rLog.setRefId(refId);
            rLog.setServiceName(serviceName);
            rLog.setSourceHost(getHostName());

            rcProcessLogRepository.save(rLog);            
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.caiso.rcint.service.RCProcessLogService#createExceptionLogEntry(java.
     * lang.String, java.lang.String, java.lang.String, java.lang.String,
     * java.lang.String, java.lang.Exception)
     */
    @Override
    public void createExceptionLogEntry(String eventType, String refId, String serviceName, String processName, String description, Exception exception) {
        RCProcessLog rLog = new RCProcessLog();
        rLog.setDescription(trimString(description, 1000));
        rLog.setEventTime(new Date());
        rLog.setEventType(eventType);
        rLog.setProcessName(trimString(processName, 1000));
        rLog.setRefId(refId);
        rLog.setServiceName(serviceName);
        rLog.setSourceHost(getHostName());
        setupExceptionDetail(rLog, exception);

        rcProcessLogRepository.save(rLog);
    }

    private String getHostName() {
        String response = null;
        try {
            response = InetAddress.getLocalHost().getHostName();
        } catch (Exception exception) {
            logger.debug("Unable to get host name.", exception);
        }
        return response;
    }

    private String trimString(String aStr, int len) {
        if (aStr != null) {
            aStr = aStr.substring(0, Math.min(aStr.length(), len));
        }
        return aStr;
    }

    private void setupExceptionDetail(RCProcessLog rLog, Exception exception) {
        if (exception != null) {
            rLog.setExceptionMessage(trimString(exception.getMessage(), 512));
            rLog.setStackTrace(trimString(parseStackTrace(exception), 1000));
        }
    }

    private String parseStackTrace(Exception exception) {
        String response = null;
        if (exception == null) {
            return response;
        }

        Throwable throwable = exception;

        while (throwable.getCause() != null) {
            throwable = throwable.getCause();
        }

        StringWriter stackTraceWriter = new StringWriter();
        PrintWriter pw = new PrintWriter(stackTraceWriter);
        throwable.printStackTrace(pw);

        response = stackTraceWriter.toString();

        return response;
    }
}
