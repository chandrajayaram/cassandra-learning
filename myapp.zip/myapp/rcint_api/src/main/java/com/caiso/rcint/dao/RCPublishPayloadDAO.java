/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 28, 2017 6:52:18 PM
 * Project: rcint-app
 * File: RCPublishPayloadDAO.java
 */
package com.caiso.rcint.dao;

/**
 * @author gselvaratnam
 *
 */
public interface RCPublishPayloadDAO {

    long savePayload(String payloadType, byte[] bytes);

    void updatePayloadStatus(long payloadId, String status, String response);

    @Deprecated
    void updatePayloadResfresh(long payloadId, byte[] bytes);

    byte[] retrievePayload(long payloadId);

    @Deprecated
    void updateAsIgnored();

	byte[] retrievePayloadForMRID(String payloadType, String mrid, String version);

}