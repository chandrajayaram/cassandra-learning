package com.caiso.rcint.outage.oms.generation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.caiso.rcint.domain.Availability;
import com.caiso.rcint.domain.Interval;
import com.caiso.rcint.domain.ResourceAvailability;
import com.caiso.rcint.domain.XMLGregorianCalendarInterval;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;
import com.caiso.soa.availabilityresultscaiso_v1.DateTimeInterval;
import com.caiso.soa.availabilityresultscaiso_v1.RegisteredGenerator;
import com.caiso.soa.availabilityresultscaiso_v1.YesNo;
import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;
import com.caiso.soa.resourceoutageresultscaiso_v2.ResourceOutageResultsCaiso;

@Service
public class AvailabilityPayloadDataGenerator {
	
	private static final String SELECT_RES_MRID_FOR_AVAILABILITY ="SELECT RESMRID, MAXIMUMOPERATINGMW FROM pvallresource pvAllRes, WECC_RESOURCES WR WHERE"
		    +" PVALLRES.RESMRID IN(:MRIDS)  AND PVALLRES.RESSTARTEFFECTIVEDATE <= :START_DATE"
		    +" AND PVALLRES.RESENDEFFECTIVEDATE > :END_DATE AND PVALLRES.UPDATENOTICE = 'A'"
		    +" AND (PVALLRES.EIMPARTICIPATING IS NULL OR TO_CHAR(:SUBMIT_REG_AUTH) = 'true') AND PVALLRES.MARKETPARTICIPATIONFLAG ='Y'"
		    +" AND PVALLRES.RESOURCETYPE = 'GEN' AND pvAllRes.RESMRID = WR.EQUIPMENT_ID(+) AND WR.EFFECTIVE_START(+) <= CURRENT_TIMESTAMP"
		    +" AND WR.EFFECTIVE_END(+) > CURRENT_TIMESTAMP AND NVL (WR.EXCEPTION_TYPE, 1) = 1 AND (MAXIMUMOPERATINGMW >= 20 OR WR.EXCEPTION_TYPE = 1)";
	
	
	private NamedParameterJdbcTemplate rcintJdbcTemplate;
	
	@Autowired
	public void setRcintJdbcTemplate(NamedParameterJdbcTemplate rcintJdbcTemplate) {
		this.rcintJdbcTemplate = rcintJdbcTemplate;
	}

	public Map<String, List<ResourceAvailability>> process(ResourceOutageResultsCaiso resourceOutageResults, AvailabilityResultsCaiso availabilityResults){
		Map<String, List<Availability>> resourceAvailibilityMap = new HashMap<>();
		Map<String, List<ResourceAvailability>> outageMap = new HashMap<>();
		
		for(RegisteredResourceOutage regResourceOutage: resourceOutageResults.getMessagePayload()
		 .getRegisteredResourceOutages()) 
		{
			
			boolean sumbitOutageToRegAuthority = regResourceOutage.getRegulatoryAuthorityOutage().isSubmitOutageToRegulatoryAuthority();
			XMLGregorianCalendarInterval outageInterval = Utils.getInterval(regResourceOutage);
			Interval dateInterval = getDateInterval(regResourceOutage); 
			List<RegisteredGenerator> registeredGenerators = availabilityResults.getMessagePayload()
					.getRegisteredGenerators().stream().filter(reqGenerator -> (reqGenerator.getLogicalConfiguration()== null || reqGenerator.getLogicalConfiguration().getMRID() ==null)).collect(Collectors.toList());

			for(RegisteredGenerator reqGenerator: registeredGenerators){ 
				List<Availability> availabilities = new ArrayList<>();
				for(com.caiso.soa.availabilityresultscaiso_v1.Availability availability: reqGenerator.getOutagedRegisteredResource().getAvailabilities()) 
				{
					if(availability.getPeriod().getStart().compare(outageInterval.getStart()) >= 0 
						&&  availability.getPeriod().getEnd().compare(outageInterval.getEnd()) <= 0){
						Availability avail = new Availability();
						avail.setInterval(getInterval(availability.getPeriod()));
						avail.setValue(BigDecimal.valueOf(availability.getPmaxValue().getValue()));
						avail.setOutOfService(availability.getOutOfService() == YesNo.YES ? true: false);
						availabilities.add(avail);
					}
				}
				resourceAvailibilityMap.put(reqGenerator.getMRID(),availabilities);
				
			}
			outageMap.put(regResourceOutage.getMRID(), createResourceData(resourceAvailibilityMap,outageInterval,sumbitOutageToRegAuthority, dateInterval, regResourceOutage.getMRID()));
		}
		return outageMap;
	}
	
	

private List<ResourceAvailability> createResourceData(Map<String, List<Availability>> resourceAvailibilityMap,XMLGregorianCalendarInterval outageInterval, boolean sumbitOutageToRegAuthority, Interval dateInterval, String outageId) {
		Set<String> mrids = resourceAvailibilityMap.keySet();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("MRIDS", mrids);
		parameters.addValue("SUBMIT_REG_AUTH", Boolean.toString(sumbitOutageToRegAuthority));
		parameters.addValue("START_DATE",outageInterval.getStart().toGregorianCalendar().getTime());
		parameters.addValue("END_DATE",outageInterval.getEnd().toGregorianCalendar().getTime());
		
		Map<String, BigDecimal> criteriaMeetingMRIDPmaxValue = rcintJdbcTemplate.query(SELECT_RES_MRID_FOR_AVAILABILITY,parameters, rs ->{
				Map<String, BigDecimal> mridsMap = new HashMap<>(); 
				while(rs.next()){
					mridsMap.put(rs.getString("RESMRID"), rs.getBigDecimal("MAXIMUMOPERATINGMW"));
				}
				return mridsMap;
			}
		);
		mrids.retainAll(criteriaMeetingMRIDPmaxValue.keySet());
		resourceAvailibilityMap.keySet().forEach(e->{ if(!mrids.contains(e)) resourceAvailibilityMap.remove(e) ;});
		List<ResourceAvailability> resourceAvailabilities = new ArrayList<>();
		resourceAvailibilityMap.keySet().forEach(mrid -> {
			ResourceAvailability resourceAvailability = new ResourceAvailability();
			resourceAvailability.setMrid(mrid);
			resourceAvailability.setAvailabilities(resourceAvailibilityMap.get(mrid));
			resourceAvailability.setDateInterval(dateInterval);
			resourceAvailability.setOutageId(outageId);
			resourceAvailability.setMaximumOperatingMW(criteriaMeetingMRIDPmaxValue.get(mrid));
			resourceAvailabilities.add(resourceAvailability);
		});
		return resourceAvailabilities;
	}

	private Interval getInterval(DateTimeInterval period) {
		Interval interval = new Interval();
		interval.setStartDate(period.getStart().toGregorianCalendar().getTime());
		interval.setEndDate(period.getEnd().toGregorianCalendar().getTime());
		return interval;
	}
	private Interval getDateInterval(RegisteredResourceOutage outage) {
		Date startDate = null;
		Date endDate = null;
		if (outage.getActualPeriod() != null) {
			if (outage.getActualPeriod().getStart() != null) {
				startDate = outage.getActualPeriod().getStart().toGregorianCalendar().getTime();
			}
			if (outage.getActualPeriod().getEnd() != null) {
				endDate = outage.getActualPeriod().getEnd().toGregorianCalendar().getTime();
			}
		} else if (outage.getEstimatedPeriod() != null) {
			if (outage.getEstimatedPeriod().getStart() != null) {
				startDate = outage.getEstimatedPeriod().getStart().toGregorianCalendar().getTime();
			}
			if (outage.getEstimatedPeriod().getEnd() != null) {
				endDate = outage.getEstimatedPeriod().getEnd().toGregorianCalendar().getTime();
			}
		}
		return new Interval(startDate, endDate);
	}


	public Map<String, List<ResourceAvailability>> process(RegisteredResourceOutage resourceOutage,
			List<RegisteredGenerator> registeredGenerators) {
		Map<String, List<Availability>> resourceAvailibilityMap = new HashMap<>();
		Map<String, List<ResourceAvailability>> outageMap = new HashMap<>();
		
			boolean sumbitOutageToRegAuthority = resourceOutage.getRegulatoryAuthorityOutage().isSubmitOutageToRegulatoryAuthority();
			XMLGregorianCalendarInterval outageInterval = Utils.getInterval(resourceOutage);
			Interval dateInterval = getDateInterval(resourceOutage); 
			for(RegisteredGenerator regGenerator: registeredGenerators) 
			{ 
				
				List<Availability> availabilities = new ArrayList<>();
				for(com.caiso.soa.availabilityresultscaiso_v1.Availability availability : regGenerator.getOutagedRegisteredResource().getAvailabilities()) 
				{
					if(availability.getPeriod().getStart().compare(outageInterval.getStart()) >= 0 
						&&  availability.getPeriod().getEnd().compare(outageInterval.getEnd()) <= 0){
						Availability avail = new Availability();
						avail.setInterval(getInterval(availability.getPeriod()));
						avail.setValue(BigDecimal.valueOf(availability.getPmaxValue().getValue()));
						availabilities.add(avail);
					}
				}
				resourceAvailibilityMap.put(regGenerator.getMRID(),availabilities);
			}
			outageMap.put(resourceOutage.getMRID(), createResourceData(resourceAvailibilityMap,outageInterval,sumbitOutageToRegAuthority, dateInterval, resourceOutage.getMRID()));
		return outageMap;
	}
}
