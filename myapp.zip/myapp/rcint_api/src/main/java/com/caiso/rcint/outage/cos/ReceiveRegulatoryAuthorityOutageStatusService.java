/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 24, 2017 1:45:16 PM
 * Project: rcint-app
 * File: ReceiveRegulatoryAuthorityOutageStatusService.java
 */
package com.caiso.rcint.outage.cos;

import java.util.Map;

import com.caiso.rcint.dao.WECCOutageData;

/**
 * @author gselvaratnam
 *
 */
public interface ReceiveRegulatoryAuthorityOutageStatusService {

    String EXECUTE_SERVICE_RESPONSE = "EXECUTE_SERVICE_RESPONSE";
    String EXECUTE_SERVICE_PAYLOAD_ID = "EXECUTE_SERVICE_PAYLOAD_ID";

    Map<String, Object>  executeService(String attachmentXml, Long payloadId);

}