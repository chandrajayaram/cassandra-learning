/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 24, 2017 3:12:20 PM
 * Project: rcint-app
 * File: PublishPayloadController.java
 */
package com.caiso.rcint.controller;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.caiso.rcint.dao.RCPublishPayloadRepository;
import com.caiso.rcint.domain.PayloadType;
import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.service.PostOutageScheduleSubmitRequestService;
import com.caiso.rcint.service.PostRegulatoryAuthorityOutageStatusService;
import com.caiso.rcint.service.PostTransmissionOutageService;

/**
 * @author gselvaratnam
 *
 */
@RestController
public class PublishPayloadController {
    private static final Logger                        logger = LoggerFactory.getLogger(PublishPayloadController.class);

    @Autowired
    private RCPublishPayloadRepository                 rcPublishPayloadRepository;

    @Autowired
    private PostTransmissionOutageService              postTransmissionOutageService;

    @Autowired
    private PostRegulatoryAuthorityOutageStatusService postRegulatoryAuthorityOutageStatusService;

    @Autowired
    private PostOutageScheduleSubmitRequestService     postOutageScheduleSubmitRequestService;

    @RequestMapping(path = "/OmsSubmitPayload/{payloadId}", method = RequestMethod.GET)
    public String omsSubmitPayload(@PathVariable(value = "payloadId") String payloadId) {
        logger.info("Begin::PublishPayloadController.omsSubmitPayload");

        String response = "OK : ";

        try {
            RCPublishPayload rcPublishPayload = rcPublishPayloadRepository.findOne(Long.valueOf(payloadId));
            validateOmsSubmitPayload(rcPublishPayload, payloadId);

            String payloadType = rcPublishPayload.getPayloadType();
            PayloadType payloadTypeEnum = PayloadType.valueOf(payloadType);

            switch (payloadTypeEnum) {

            case OMS_TRANS_OUTAGE:
            case OMS_TRANS_OUTAGE_CHANGE_REQUEST:
                response = response + postTransmissionOutageService.resendPayload(rcPublishPayload);
                break;

            case OMS_REGULATORY_AUTH_RESPONSE:
                response = response + postRegulatoryAuthorityOutageStatusService.resendPayload(rcPublishPayload);
                break;

            default:
                throw new RCINTRuntimeException("Unknown OMS payload type : " + payloadType);
            }
        } catch (Exception e) {
            logger.error("Unexpected Error", e);
            return "Exception occured : " + e.getMessage();
        } finally {
            logger.info("End::PublishPayloadController.omsSubmitPayload");
        }
        return response;
    }

    @RequestMapping(path = "/CosSubmitPayload/{payloadId}", method = RequestMethod.GET)
    public String cosSubmitPayload(@PathVariable(value = "payloadId") String payloadId) {
        logger.info("Begin::PublishPayloadController.cosSubmitPayload");

        String response = "OK : ";
        try {
            RCPublishPayload rcPublishPayload = rcPublishPayloadRepository.findOne(Long.valueOf(payloadId));
            validateCosSubmitPayload(rcPublishPayload, payloadId);
            String payloadType = rcPublishPayload.getPayloadType();
            PayloadType payloadTypeEnum = PayloadType.valueOf(payloadType);

            switch (payloadTypeEnum) {

            case WECC_OUTAGE:
                response = response + postOutageScheduleSubmitRequestService.resendPayload(rcPublishPayload);
                break;

            default:
                throw new RCINTRuntimeException("Unknown OMS payload type : " + payloadType);
            }
        } catch (Exception e) {
            logger.error("Unexpected Error", e);
            return "Exception occured : " + e.getMessage();
        } finally {
            logger.info("End::PublishPayloadController.omsSubmitPayload");
        }
        return response;
    }

    private void validateOmsSubmitPayload(RCPublishPayload rcPublishPayload, String payloadId) {
        validate(rcPublishPayload, payloadId);

        if (PayloadType.OMS_TRANS_OUTAGE.getPayloadType().equalsIgnoreCase(rcPublishPayload.getPayloadType())
                || PayloadType.OMS_TRANS_OUTAGE_CHANGE_REQUEST.getPayloadType().equalsIgnoreCase(rcPublishPayload.getPayloadType())
                || PayloadType.OMS_REGULATORY_AUTH_RESPONSE.getPayloadType().equalsIgnoreCase(rcPublishPayload.getPayloadType())) {
            // DO nothing
        } else {
            throw new RCINTRuntimeException("The payload type must be " + PayloadType.OMS_TRANS_OUTAGE.getPayloadType() + " or "
                    + PayloadType.OMS_TRANS_OUTAGE_CHANGE_REQUEST.getPayloadType() + " or " + PayloadType.OMS_REGULATORY_AUTH_RESPONSE.getPayloadType());
        }
    }

    /**
     * @param rcPublishPayload
     * @param payloadId
     */
    private void validate(RCPublishPayload rcPublishPayload, String payloadId) {
        if (rcPublishPayload == null) {
            throw new RCINTRuntimeException("Could not find payload : " + payloadId);
        }

        if (ArrayUtils.isEmpty(rcPublishPayload.getData())) {
            throw new RCINTRuntimeException("Payload data column is empty for  : " + payloadId);
        }
    }

    private void validateCosSubmitPayload(RCPublishPayload rcPublishPayload, String payloadId) {
        validate(rcPublishPayload, payloadId);

        if (PayloadType.WECC_OUTAGE.getPayloadType().equalsIgnoreCase(rcPublishPayload.getPayloadType())) {
            // DO nothing
        } else {
            throw new RCINTRuntimeException("The payload type must be " + PayloadType.WECC_OUTAGE.getPayloadType());
        }

    }
}
