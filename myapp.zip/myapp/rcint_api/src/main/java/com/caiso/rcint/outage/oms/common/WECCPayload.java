package com.caiso.rcint.outage.oms.common;

import java.util.HashMap;
import java.util.Map;

import javax.xml.soap.SOAPMessage;

public class WECCPayload {
	
	private SOAPMessage weccPayload;
	
	public SOAPMessage getWeccPayload() {
		return weccPayload;
	}

	public void setWeccPayload(SOAPMessage weccPayload) {
		this.weccPayload = weccPayload;
	}

	private Map<String, Object> outageData = new HashMap<>();
	
	public void addData(String key, Object value){
		outageData.put(key, value);
	}

	public Map<String, Object> getOutageData() {
		return outageData;
	}

	public Object getData(String key){
		return outageData.get(key);
	}

}
