/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Dec 14, 2016 2:29:59 PM
 * Project: caiso-rcint_api
 * File: RcIntApiException.java
 */
package com.caiso.rcint.exception;

/**
 * This is the top level exception that will be thrown out of RCINT Api. All other exceptions should be a subclass of this.
 * @author gselvaratnam
 *
 */
public class RCINTRuntimeException extends RuntimeException {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = 2904895807734715869L;

    /**
     * 
     */
    public RCINTRuntimeException() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public RCINTRuntimeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param message
     * @param cause
     */
    public RCINTRuntimeException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param message
     */
    public RCINTRuntimeException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param cause
     */
    public RCINTRuntimeException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }
}
