/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
@Entity
@Table(name = "RC_CONFIG")
public class RCConfig implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    @Id
    @SequenceGenerator(name = "CONFIG_ID_GENERATOR", sequenceName = "RC_CONFIG_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CONFIG_ID_GENERATOR")
    @Column(name = "CONFIG_ID", nullable = false)
    private Long              id;

    @Column(name = "PROPERTY", nullable = false)
    private String            property;

    @Column(name = "VALUE", nullable = false)
    private String            propertyValue;

    @Column(name = "TYPE", nullable = true)
    private String            propertyType;

    @Column(name = "DESCRIPTION", nullable = true)
    private String            description;

    @Column(name = "CREATE_DT", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date              createdDate;

    @Column(name = "UPDATE_DT", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date              updatedDate;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the property
     */
    public String getProperty() {
        return property;
    }

    /**
     * @param property the property to set
     */
    public void setProperty(String property) {
        this.property = property;
    }

    /**
     * @return the propertyValue
     */
    public String getPropertyValue() {
        return propertyValue;
    }

    /**
     * @param propertyValue the propertyValue to set
     */
    public void setPropertyValue(String propertyValue) {
        this.propertyValue = propertyValue;
    }

    /**
     * @return the propertyType
     */
    public String getPropertyType() {
        return propertyType;
    }

    /**
     * @param propertyType the propertyType to set
     */
    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final RCConfig other = (RCConfig) obj;
        return Objects.equals(this.id, other.id) && Objects.equals(this.property, other.property) && Objects.equals(this.propertyValue, other.propertyValue)
                && Objects.equals(this.description, other.description) && Objects.equals(this.createdDate, other.createdDate)
                && Objects.equals(this.updatedDate, other.updatedDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.property, this.propertyValue, this.description, this.createdDate, this.updatedDate);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
