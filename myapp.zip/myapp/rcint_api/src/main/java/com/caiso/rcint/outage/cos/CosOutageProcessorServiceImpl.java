/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 20, 2017 1:22:33 PM
 * Project: caiso-rcint_api
 * File: CosOutageProcessorServiceImpl.java
 */
package com.caiso.rcint.outage.cos;

import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import javax.xml.bind.JAXBException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.caiso.rcint.dao.RCControlAreaRepository;
import com.caiso.rcint.dao.RCOutageStatusRepository;
import com.caiso.rcint.entity.RCControlArea;
import com.caiso.rcint.entity.RCOutageStatus;
import com.caiso.rcint.exception.RCINTContinueProcessingException;
import com.caiso.rcint.service.DbPropertyService;
import com.caiso.rcint.service.RCProcessLogService;
import com.caiso.rcint.service.WebServiceCallOutService;
import com.caiso.rcint.util.DateUtil;

import ca.equinox.crow.ReturnedOutage;

/**
 * @author gselvaratnam
 *
 */
@Service
public class CosOutageProcessorServiceImpl extends BaseCosCaisoOutageProcessor implements CosOutageProcessorService {

    private static final Logger         logger = LoggerFactory.getLogger(CosOutageProcessorServiceImpl.class);

    public static final String LOG_EVT_TYPE_PROCESS_START = "PROCESS_START";
    public static final String LOG_EVT_TYPE_PROCESS_END = "PROCESS_END";
    public static final String LOG_EVT_TYPE_PROCESS_EXCEPTION = "EXCEPTION";

    @Autowired
    private RCControlAreaRepository     rcControlAreaRepository;

    @Autowired
    private RCOutageStatusRepository    rcOutageStatusRepository;

    @Autowired
    private DbPropertyService           dbPropertyService;

    @Autowired
    private WebServiceCallOutService    webServiceCallOutService;

    @Autowired
    private ReturnedOutageProcessingService returnedOutageProcessingService;

    @Autowired
    private RCProcessLogService rcProcessLogService;

    private Boolean serviceEnabled = true;

    /*
     * (non-Javadoc)
     * 
     * @see com.caiso.rcint.outage.oms.service.OmsOutageProcessorService#
     * processOmsOutages()
     */
    @Override
    public void processOmsOutages() {
        logger.info("Begin::CosOutageProcessorServiceImpl::processOmsOutages");

        if(!serviceEnabled) {
            logger.info("CosOutageProcessorServiceImpl::IS DISABLED");
            return;
        }

        String logRefId = UUID.randomUUID().toString();

        rcProcessLogService.createLogEntry(LOG_EVT_TYPE_PROCESS_START, logRefId, "CosOutageProcessorServiceImpl", "processOmsOutages", "starting the process");

        String currentTimeStr = DateUtil.formatDate(Calendar.getInstance(), DateUtil.COS5_DATE_FORMAT);

        try {
            List<RCOutageStatus> rcOutageStatusList = rcOutageStatusRepository.findAllRCOutageStatuses();
            String concatanatedStatusList = org.apache.commons.lang3.StringUtils.join(rcOutageStatusList, ',');

            List<RCControlArea> listOfControlAreas = rcControlAreaRepository.findAllControllAeas();

            Calendar processStartTime = Calendar.getInstance();
            Calendar processEndTime = Calendar.getInstance();
            Calendar lastRunTime = Calendar.getInstance();

            setupProcessStartAndEndTimes(processStartTime, processEndTime, lastRunTime, CosOutageProcessorService.COS_OUTPROC_SVC_LAST_RUNTIME);

            String startTimeStr = DateUtil.formatDate(processStartTime, DateUtil.COS5_DATE_FORMAT);
            String endTimeStr = DateUtil.formatDate(processEndTime, DateUtil.COS5_DATE_FORMAT);
            String lastRunTimeStr = DateUtil.formatDate(lastRunTime, DateUtil.COS5_DATE_FORMAT);

            for (RCControlArea rcControlArea : listOfControlAreas) {

                List<ReturnedOutage> returnedOutageList = findListOfReturnedOutages(concatanatedStatusList, startTimeStr, endTimeStr, lastRunTimeStr, rcControlArea.getConfigName(), logRefId);

                if (!CollectionUtils.isEmpty(returnedOutageList)) {
                    for (ReturnedOutage returnedOutage : returnedOutageList) {

                        try {

                            returnedOutageProcessingService.processReturnedOutage(returnedOutage, logRefId);

                        } catch (RCINTContinueProcessingException rcintConProcException) {
                            logger.error("Unexcpected Error But Continuing The Process", rcintConProcException);
                            rcProcessLogService.createExceptionLogEntry(LOG_EVT_TYPE_PROCESS_EXCEPTION, logRefId, "CosOutageProcessorServiceImpl", "processOmsOutages", "handling exception", rcintConProcException);
                            continue;
                        }

                    }
                } else {
                    logger.warn("Could not find COS Outages for controll area {}", startTimeStr);
                }
            }

        } catch (Exception exception) {
            logger.error("Unexcpected Error", exception);

            rcProcessLogService.createExceptionLogEntry(LOG_EVT_TYPE_PROCESS_EXCEPTION, logRefId, "CosOutageProcessorServiceImpl", "processOmsOutages", "handling exception", exception);
        }

        dbPropertyService.createOrUpdateProperty(COS_OUTPROC_SVC_LAST_RUNTIME, currentTimeStr);
        rcProcessLogService.createLogEntry(LOG_EVT_TYPE_PROCESS_END, logRefId, "CosOutageProcessorServiceImpl", "processOmsOutages", "ending the process");

        logger.info("End::CosOutageProcessorServiceImpl::processOmsOutages");
    }


    @Override
    public void manageService(Boolean status) {
      this.serviceEnabled = status;        
    }

    /**
     * @return the serviceEnabled
     */
    public Boolean getServiceEnabled() {
        return serviceEnabled;
    }

    /**
     * @param concatanatedStatusList
     * @param startTime
     * @param endTime
     * @param rcControlArea
     * @return
     * @throws TransformerException
     * @throws TransformerConfigurationException
     * @throws TransformerFactoryConfigurationError
     * @throws JAXBException
     */
    private List<ReturnedOutage> findListOfReturnedOutages(String concatanatedStatusList, String startTime, String endTime, String lastRunTime, String controlArea, String logRefId)
            throws TransformerException, TransformerConfigurationException, TransformerFactoryConfigurationError, JAXBException {

        String soapRequestXml = webServiceCallOutService.getPeakOutageRequestQuery_ExecuteQuerySoapXMLString(controlArea, startTime,
                endTime, concatanatedStatusList, lastRunTime);

        logger.debug("SoapRequestXml : {}", soapRequestXml);

        rcProcessLogService.createLogEntry(LOG_EVT_TYPE_PROCESS_START, logRefId, "CosOutageProcessorServiceImpl", "processOmsOutages", "Calling COS PeakOutageRequestQuery_ExecuteQuery");

        String peakOutageRequestQuery_ExecuteQueryResponse = webServiceCallOutService.callPeakCosWebService(soapRequestXml, "http://crow.equinox.ca/OutageRequestQuery_ExecuteQuery");

        List<ReturnedOutage> returnedOutageList = findReturnedOutageList(peakOutageRequestQuery_ExecuteQueryResponse);
        return returnedOutageList;
    }
}