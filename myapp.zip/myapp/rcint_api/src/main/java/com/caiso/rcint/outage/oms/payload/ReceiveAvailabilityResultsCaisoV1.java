package com.caiso.rcint.outage.oms.payload;

import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;
import com.caiso.soa.framework.payload.DomainPayload;

public class ReceiveAvailabilityResultsCaisoV1 extends DomainPayload<AvailabilityResultsCaiso>{

}
