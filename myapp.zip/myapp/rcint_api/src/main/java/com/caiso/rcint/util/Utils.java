package com.caiso.rcint.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.util.StringUtils;
import org.springframework.ws.soap.SoapEnvelope;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.caiso.rcint.domain.Interval;
import com.caiso.rcint.domain.XMLGregorianCalendarInterval;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutage;

public class Utils {

	public static Function<XMLGregorianCalendar, Timestamp> xmlGregorianCalendarToSqlTimeStampFn = new Function<XMLGregorianCalendar, Timestamp>() {

		@Override
		public Timestamp apply(XMLGregorianCalendar cal) {
			if (cal != null) {
				return new Timestamp(cal.toGregorianCalendar().getTime().getTime());
			}
			return null;
		}
	};
	public static Function<Date, Timestamp> dateToSqlTimeStampFn = new Function<Date, Timestamp>() {

		@Override
		public Timestamp apply(Date date) {
			if (date != null) {
				return new Timestamp(date.getTime());
			}
			return null;
		}
	};

	public static Function<XMLGregorianCalendar, String> formatDateFn = new Function<XMLGregorianCalendar, String>() {

		@Override
		public String apply(XMLGregorianCalendar cal) {
			if (cal != null) {
				SimpleDateFormat fmt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				return fmt.format(cal.toGregorianCalendar().getTime().getTime());
			}
			return null;
		}
	};

	public static Function<Date, String> formatDateTimeFn = new Function<Date, String>() {

		@Override
		public String apply(Date date) {
			if (date != null) {
				SimpleDateFormat fmt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				return fmt.format(date);
			}
			return null;
		}
	};

	public static BiFunction<Date, String, String> formatDateTimeWithGivenPatternFn = new BiFunction<Date, String, String>() {

		@Override
		public String apply(Date date, String format) {
			if (date != null) {
				SimpleDateFormat fmt = new SimpleDateFormat(format);
				return fmt.format(date);
			}
			return null;
		}
	};

	public static BigDecimal calculateDuration(Interval interval) {
		if (interval.getStartDate() != null && interval.getEndDate() != null) {
			long diff = interval.getEndDate().getTime() - interval.getStartDate().getTime();
			double diffHours = diff / (60 * 60 * 1000);
			return BigDecimal.valueOf(diffHours).setScale(2, RoundingMode.HALF_UP);
		} else {
			return BigDecimal.valueOf(0);
		}
	}
	public static BigDecimal calculateDurationInMinutes(Interval interval) {
		if (interval.getStartDate() != null && interval.getEndDate() != null) {
			long diff = interval.getEndDate().getTime() - interval.getStartDate().getTime();
			double diffMins = diff / (60 * 1000) % 60;
			return BigDecimal.valueOf(diffMins).setScale(2, RoundingMode.HALF_UP);
		} else {
			return BigDecimal.valueOf(0);
		}
	}

	public static byte[] compress(String data) {
		try {
			if (data != null) {
				ByteArrayOutputStream targetStream = new ByteArrayOutputStream();
				GZIPOutputStream zipStream = new GZIPOutputStream(targetStream);
				zipStream.write(data.getBytes());
				zipStream.close();

				byte[] zipped = targetStream.toByteArray();
				targetStream.close();

				return zipped;
			}
			return null;
		} catch (Exception exception) {
			throw new RCINTRuntimeException(exception);
		}
	}

	public static String decompress(byte[] blob) {
		String unzipped = null;
		try {
			if (!ArrayUtils.isEmpty(blob)) {
				GZIPInputStream gzip = new GZIPInputStream(new ByteArrayInputStream(blob));
				BufferedReader br = new BufferedReader(new InputStreamReader(gzip));
				StringBuilder sb = new StringBuilder();
				String line = "";

				while ((line = br.readLine()) != null) {
					sb.append(line);
				}

				unzipped = sb.toString();

				gzip.close();
				br.close();
			}
		} catch (Exception exception) {
			throw new RCINTRuntimeException(exception);
		}
		return unzipped;
	}

	public static String getSoapEnvelopeAsString(SaajSoapMessage saajSoapMessage) {
		String response = null;
		try {
			SoapEnvelope soapEnvelope = saajSoapMessage.getEnvelope();
			final StringWriter sw = new StringWriter();
			TransformerFactory.newInstance().newTransformer().transform(soapEnvelope.getSource(), new StreamResult(sw));
			response = new String(sw.toString());
		} catch (Exception exception) {
			throw new RCINTRuntimeException(exception);
		}
		return response;
	}

	public static <T, V> String marshallToString(T objectToBeMarshalled, V rootElement) {
		String response = null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(rootElement.getClass());
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			StringWriter sw = new StringWriter();
			jaxbMarshaller.marshal(objectToBeMarshalled, sw);
			response = sw.toString();
		} catch (Exception exception) {
			throw new RCINTRuntimeException(exception);
		}
		return response;
	}

	public static byte[] compress(byte[] data) {
		try {
			if (data != null) {
				ByteArrayOutputStream targetStream = new ByteArrayOutputStream();
				GZIPOutputStream zipStream = new GZIPOutputStream(targetStream);
				zipStream.write(data);
				zipStream.close();

				byte[] zipped = targetStream.toByteArray();
				targetStream.close();

				return zipped;
			}
			return null;
		} catch (Exception exception) {
			throw new RCINTRuntimeException(exception);
		}
	}

	public static String parseStackTrace(Exception exception) {
        String response = null;
        if (exception == null) {
            return response;
        }

        Throwable throwable = exception;

        while (throwable.getCause() != null) {
            throwable = throwable.getCause();
        }

        StringWriter stackTraceWriter = new StringWriter();
        PrintWriter pw = new PrintWriter(stackTraceWriter);
        throwable.printStackTrace(pw);

        response = stackTraceWriter.toString();

        return response;
    }

	public static String substring(String stringVal, int length) {
        String response = stringVal;
        if (StringUtils.isEmpty(stringVal)) {
            response = "";
        } else if(stringVal.length() > length) {
            response = stringVal.substring(0, length);
        }

        return response;
    }
	public static Interval getInterval(TransmissionOutage outage){
		Date startDate = null;
		Date endDate = null;
		if (outage.getActualPeriod()!=null){
			if(outage.getActualPeriod().getStart() != null){
				startDate = outage.getActualPeriod().getStart().toGregorianCalendar().getTime();	
			}
			if (outage.getActualPeriod().getEnd() != null) {
				endDate	 = outage.getActualPeriod().getEnd().toGregorianCalendar().getTime();
			}
		}else if(outage.getEstimatedPeriod()!= null){
			if(outage.getEstimatedPeriod().getStart()!=null){
				startDate = outage.getEstimatedPeriod().getStart().toGregorianCalendar().getTime();
			}
			if(outage.getEstimatedPeriod().getEnd()!=null){
				endDate = outage.getEstimatedPeriod().getEnd().toGregorianCalendar().getTime();
			}
		}
		return new Interval(startDate, endDate);
	}
	public static XMLGregorianCalendarInterval getInterval(RegisteredResourceOutage outage){
		XMLGregorianCalendar startDate = null;
		XMLGregorianCalendar endDate = null;
		if (outage.getActualPeriod()!=null){
			if(outage.getActualPeriod().getStart() != null){
				startDate = outage.getActualPeriod().getStart();	
			}
			if (outage.getActualPeriod().getEnd() != null) {
				endDate	 = outage.getActualPeriod().getEnd();
			}
		}else if(outage.getEstimatedPeriod()!= null){
			if(outage.getEstimatedPeriod().getStart()!=null){
				startDate = outage.getEstimatedPeriod().getStart();
			}
			if(outage.getEstimatedPeriod().getEnd()!=null){
				endDate = outage.getEstimatedPeriod().getEnd();
			}
		}
		return new XMLGregorianCalendarInterval(startDate, endDate);
	}

}
