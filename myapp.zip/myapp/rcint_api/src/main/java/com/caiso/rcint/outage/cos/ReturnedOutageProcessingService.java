/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 27, 2017 12:08:15 PM
 * Project: rcint-app
 * File: ReturnedOutageProcessingService.java
 */
package com.caiso.rcint.outage.cos;

import ca.equinox.crow.ReturnedOutage;

/**
 * @author gselvaratnam
 *
 */
public interface ReturnedOutageProcessingService {

    void processReturnedOutage(ReturnedOutage returnedOutage, String logRefId);

}