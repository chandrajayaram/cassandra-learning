/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 25, 2017 1:30:12 PM
 * Project: rcint-app
 * File: CosToRdfIdService.java
 */
package com.caiso.rcint.service;

import java.util.List;

import com.caiso.rcint.domain.RCRdfIdMap;

/**
 * @author gselvaratnam
 *
 */
public interface CosToRdfIdService {

    List<RCRdfIdMap> findAllRCRdfIdMaps(String cosName);

    boolean addNewRCRdfIdMap(String controlArea, String stationName, Double voltageClass, String equipmentName);

}