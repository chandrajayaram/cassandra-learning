/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 9, 2017 2:02:59 PM
 * Project: rcint-app
 * File: ManageServiceImpl.java
 */
package com.caiso.rcint.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.outage.cos.CosCaisoOutageProcessorService;
import com.caiso.rcint.outage.cos.CosOutageProcessorService;

/**
 * @author gselvaratnam
 *
 */
@RestController
public class ManageServiceImpl implements ManageService {

    private static final Logger logger = LoggerFactory.getLogger(ManageServiceImpl.class);

    @Autowired
    private CosCaisoOutageProcessorService omsCaisoOutageProcessorService;

    @Autowired
    private CosOutageProcessorService omsOutageProcessorService;

    /* (non-Javadoc)
     * @see com.caiso.rcint.controller.ManageService#manageService(java.lang.String, java.lang.Boolean)
     */
    @Override
    @RequestMapping(path = "/manageService/{serviceName}/{status}", method = RequestMethod.GET)
    public String manageService(@PathVariable(value = "serviceName") final String serviceName, @PathVariable(value = "status") Boolean status) {
        logger.info("Begin::ManageServiceImpl.manageService");

        String response = null;
        try {
            switch (serviceName) {
            case CosCaisoOutageProcessorService.SERVICE_NAME:
                omsCaisoOutageProcessorService.manageService(status);

                response = "Set " + CosCaisoOutageProcessorService.SERVICE_NAME + " enabled = " + status;
                break;

            case CosOutageProcessorService.SERVICE_NAME:
                omsOutageProcessorService.manageService(status);

                response = "Set " + CosOutageProcessorService.SERVICE_NAME + " enabled = " + status;
                break;

            default:
                throw new RCINTRuntimeException("Unknown Service Name : " + serviceName);
            }

        } catch (Exception e) {
            response = e.getMessage();
        } finally {
            logger.info("End::ManageServiceImpl.manageService");
        }

        return response;
    }
}
