/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 25, 2017 11:57:19 AM
 * Project: rcint-app
 * File: RCRdfIdMapRepository.java
 */
package com.caiso.rcint.dao;

import java.util.List;

import com.caiso.rcint.domain.RCRdfIdMap;

/**
 * @author gselvaratnam
 *
 */
public interface RCRdfIdMapDao {

    public List<RCRdfIdMap> findByCosNameRdfIdIsNotNull(String cosName);

    void createRCRdfIdMap(RCRdfIdMap rcRdfIdMap);

    List<RCRdfIdMap> findByCosName(String cosName);
}
