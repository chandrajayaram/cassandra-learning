/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 20, 2017 2:01:15 PM
 * Project: caiso-rcint_api
 * File: RCControlAreaRepository.java
 */
package com.caiso.rcint.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.entity.RCControlArea;

/**
 * @author gselvaratnam
 *
 */
@Repository
public interface RCControlAreaRepository extends JpaRepository<RCControlArea, Long> {

    @Query(value = "SELECT * FROM RC_CONTROL_AREA WHERE ENABLED='Y' AND SYSDATE BETWEEN START_DATE AND END_DATE ORDER BY NAME", nativeQuery = true)
    public List<RCControlArea> findAllControllAeas();
}
