package com.caiso.rcint.outage.oms.resource;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.caiso.rcint.dao.MessagePayloadDAO;
import com.caiso.rcint.domain.PayloadStatus;
import com.caiso.rcint.domain.XMLGregorianCalendarInterval;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.generation.GenerationOutageReceiver;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;
import com.caiso.soa.resourceoutageresultscaiso_v2.ResourceOutageResultsCaiso;

@Service
public class ResourceOutageProcessorImpl implements ResourceOutageProcessor {
	
	private static final String SELECT_RES_MRID_FOR_AVAILABILITY ="SELECT count(RESMRID) FROM pvallresource pvAllRes, WECC_RESOURCES WR WHERE"
		    +" PVALLRES.RESMRID IN(:MRIDS)  AND PVALLRES.RESSTARTEFFECTIVEDATE <= :START_DATE"
		    +" AND PVALLRES.RESENDEFFECTIVEDATE > :END_DATE AND PVALLRES.UPDATENOTICE = 'A'"
		    +" AND (PVALLRES.EIMPARTICIPATING IS NULL OR TO_CHAR(:SUBMIT_REG_AUTH) = 'true') AND PVALLRES.MARKETPARTICIPATIONFLAG ='Y'"
		    +" AND PVALLRES.RESOURCETYPE = 'GEN' AND pvAllRes.RESMRID = WR.EQUIPMENT_ID(+) AND WR.EFFECTIVE_START(+) <= CURRENT_TIMESTAMP"
		    +" AND WR.EFFECTIVE_END(+) > CURRENT_TIMESTAMP AND NVL (WR.EXCEPTION_TYPE, 1) = 1 AND (MAXIMUMOPERATINGMW >= 20 OR WR.EXCEPTION_TYPE = 1)";

	@Autowired
	private NamedParameterJdbcTemplate rcintJdbcTemplate;
	
	@Autowired
	private ResourceOutageDAO resourceOutageDAO; 
	
	@Autowired
	private GenerationOutageReceiver genOutageReceiver;
	
	@Autowired
	private MessagePayloadDAO messagePayloadDAO;
	
	@Override
	public void processAsync(ResourceOutageResultsCaiso resourceOutageResults) throws RCINTApplicationException{
		Map<Long,RegisteredResourceOutage> resourceOutageMap = resourceOutageDAO.createResourceOutage(resourceOutageResults);
		Map<Long,RegisteredResourceOutage> criteriaResourceOutageMap = new HashMap<>();
		for(Entry<Long,RegisteredResourceOutage> entry: resourceOutageMap.entrySet()){
			if(isSubmissionCriteriaMet(entry.getValue())){
				criteriaResourceOutageMap.put(entry.getKey(), entry.getValue());
			}else{
				messagePayloadDAO.updateMessageStatus(entry.getKey(), PayloadStatus.IGNORED,"SUBMISSION-CRITERIA-NOT-MET");		
			}
		}
		if(!criteriaResourceOutageMap.isEmpty()){
			genOutageReceiver.processAsyn(resourceOutageMap);
		}	
	}

	private boolean isSubmissionCriteriaMet(RegisteredResourceOutage resOutage) {
		boolean sumbitOutageToRegAuthority = resOutage.getRegulatoryAuthorityOutage().isSubmitOutageToRegulatoryAuthority();
		XMLGregorianCalendarInterval outageInterval = Utils.getInterval(resOutage);
		Set<String> mrids = resOutage.getRegisteredGeneratorsAndRegisteredInterTiesAndRegisteredLoads().stream().map(e -> e.getMRID()).collect(Collectors.toSet());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("MRIDS", mrids);
		parameters.addValue("SUBMIT_REG_AUTH", Boolean.toString(sumbitOutageToRegAuthority));
		parameters.addValue("START_DATE",outageInterval.getStart().toGregorianCalendar().getTime());
		parameters.addValue("END_DATE",outageInterval.getEnd().toGregorianCalendar().getTime());
		
		int count = rcintJdbcTemplate.query(SELECT_RES_MRID_FOR_AVAILABILITY,parameters, rs ->{
				while(rs.next()){
					return rs.getInt(1);
				}
				return 0;
			}
		);
		return count ==0? false: true; 
	}
}
