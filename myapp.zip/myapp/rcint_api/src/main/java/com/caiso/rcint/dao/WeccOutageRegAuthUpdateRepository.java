/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 22, 2017 10:42:24 AM
 * Project: rcint-app
 * File: WeccOutageRegAuthUpdateRepository.java
 */
package com.caiso.rcint.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.entity.WeccOutageRegAuthUpdate;

/**
 * @author gselvaratnam
 *
 */
@Repository
public interface WeccOutageRegAuthUpdateRepository  extends JpaRepository <WeccOutageRegAuthUpdate, Long> {

}
