/**
 * $Header: //depot/Market_Ops_Apps/Main_Apps/RC-INT/RC-INT-Service/src/main/java/com/caiso/rcint/dao/OracleSequence.java#1 $
 * $Revision: #1 $
 * $Date: 2014/06/13 $
 * $Author: rlam $
 */
package com.caiso.rcint.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.support.incrementer.AbstractSequenceMaxValueIncrementer;

public class OracleSequence extends AbstractSequenceMaxValueIncrementer {
	 
    /**
     * Default constructor for bean property style usage.
     * @see #setDataSource
     * @see #setIncrementerName
     */
    public OracleSequence() {
    }
 
    /**
     * Convenience constructor.
     * @param dataSource the DataSource to use
     * @param incrementerName the name of the sequence/table to use
     */
    public OracleSequence(DataSource dataSource, String incrementerName) {
        super(dataSource, incrementerName);
    }
 
 
    @Override
    protected String getSequenceQuery() {
        return "select " + getIncrementerName() + ".nextval from dual";
    }
 
}
