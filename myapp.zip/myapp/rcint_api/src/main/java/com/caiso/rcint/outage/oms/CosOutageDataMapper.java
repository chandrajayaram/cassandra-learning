package com.caiso.rcint.outage.oms;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caiso.rcint.dao.WECCOutageDataDAO;
import com.caiso.rcint.domain.Interval;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;
import com.caiso.soa.transmissionoutageresultscaiso_v2.EmergencyReturnTimeKind;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutage;

@Service
public class CosOutageDataMapper {

	public static final Logger logger = LoggerFactory.getLogger(CosOutageDataMapper.class);
	
	@Autowired
	private WECCOutageDataDAO weccOutageDataDAO;
	
	/**
	 * Returns the PeakRC COS outage priority ID based on the provided OMS outage conditions. 
	 *
	 * @param  TransmissionOutage 
	 * @return COS outage priority as a string
	 */
	public  String mapCosOutagePriorityId(TransmissionOutage transOutage) {
		String weccOutageType =weccOutageDataDAO.findWECCOutageType(transOutage.getMRID(), transOutage.getVersionID(), "TRANSMISSION");
		if (weccOutageType != null){
			return weccOutageType;
		}
		return PEAKRC_OUTAGE_PRIORITY_MAP.get(mapCosOutagePriority(transOutage));
	}	
	
	/**
	 * Returns the PeakRC COS outage priority string based on the provided OMS outage conditions. 
	 *
	 * @param  TransmissionOutage
	 * @return COS outage priority as a string	
	 */
	private String mapCosOutagePriority(TransmissionOutage transOutage) {
		String cosOutagePriority = PEAKRC_PRIORITY_PLANNED;
		
		
		String workKind = transOutage.getWork().getKind().value();
		String affectsRASSPS = transOutage.getAffectsRASSPS().value();				
		
		// TODO - USE THE OUTAGE PRIORITY FROM THE DATABASE IF AVAILABLE, OTHERWISE, CALCULATE THE PRIORITY
		
		if ("COMMUNICATIONS,RELAY_WORK,ENERGIZED_WORK".contains(workKind) && NO.equals(affectsRASSPS)) {
			// RLAM: If (NoW = Communications or Relay_Work or Energized_Work)  And affectsRASSPS = 'N'	Informational
			cosOutagePriority = PEAKRC_PRIORITY_INFORMATIONAL;
		}
		else if (!"COMMUNICATIONS,RELAY_WORK,ENERGIZED_WORK".contains(workKind) || YES.equals(affectsRASSPS)) {
			XMLGregorianCalendar submitTime = transOutage.getCreatedDateTime();
			XMLGregorianCalendar startDate;
			if (transOutage.getActualPeriod() != null) {
				startDate =  transOutage.getActualPeriod().getStart();
			} else if (transOutage.getEstimatedPeriod() != null) {
				startDate =  transOutage.getEstimatedPeriod().getStart();
			} else {
				logger.error("Unable to map COS outage priority for outageId["+transOutage.getMRID()+"]: missing outage actual and estimated period");
				return cosOutagePriority;
			}
					
			try {
				Duration submitMinusStartTime = DatatypeFactory.newInstance().newDuration(submitTime.toGregorianCalendar().getTimeInMillis() - startDate.toGregorianCalendar().getTimeInMillis());
				int emergencyReturnTime = 0;
				
				switch(transOutage.getEmergencyReturnTimeType()){
					case IMMEDIATE:
						emergencyReturnTime = 0;
						break;
					case DURATION:
						Interval interval = Utils.getInterval(transOutage);
						emergencyReturnTime = Utils.calculateDurationInMinutes(interval).intValue();
						break;
					case DAYS:
						emergencyReturnTime = transOutage.getEmergencyReturnTime().intValue() * 1440;
						break;
					case HOURS:
						emergencyReturnTime = transOutage.getEmergencyReturnTime().intValue() * 60;
						break;
					case YEARS:
						emergencyReturnTime = transOutage.getEmergencyReturnTime().intValue() * 525600;
						break;
					case MINUTES:	
						emergencyReturnTime = transOutage.getEmergencyReturnTime().intValue();
						break;
				}
					
				// Forced Automatic: "If (NoW != Communications or Relay_Work or Energized_Work) OR affectsRASSPS = 'Y' And (Submit Time-Start Time <= 0)"	
				if (submitMinusStartTime.getMinutes() <= 0) 
					cosOutagePriority = PEAKRC_PRIORITY_FORCED_AUTOMATIC;
				
				// Operational Transmission: "If (NoW != Communications or Relay_Work or Energized_Work) OR affectsRASSPS = 'Y' And (EmergencyReturnTime < 60 minutes) And (0 < Submit Time-Start Time < 24)"	
				else if (emergencyReturnTime < 60 && 0 < submitMinusStartTime.getHours() && submitMinusStartTime.getHours() < 24) 
					cosOutagePriority = PEAKRC_PRIORITY_OPERATIONAL;

				// Forced Emergency: "If (NoW != Communications or Relay_Work or Energized_Work) or affectsRASSPS = 'Y' And	(EmergencyReturnTime > 60 minutes) And (0 < Submit Time-Start Time < 24 hrs)"	
				else if (emergencyReturnTime > 60 && 0 < submitMinusStartTime.getHours() && submitMinusStartTime.getHours() < 24) 
					cosOutagePriority = PEAKRC_PRIORITY_FORCED_EMERGENCY;
				
				// ISO doesn't use Opportunity for Transmission	Opportunity
				
				// Urgent: "If (NoW != Communications or Relay_Work or Energized_Work) OR affectsRASSPS = 'Y' And (24hrs <= Submit Time-Start Time < 11d)"	
				else if (24 <= submitMinusStartTime.getHours() && submitMinusStartTime.getDays() < 11) 
					cosOutagePriority = PEAKRC_PRIORITY_URGENT;
				
				// Planned: "If (NoW != Communications or Relay_Work or Energized_Work) OR affectsRASSPS = 'Y' And (Submit Time-Start Time >= 11d)"	Planned
				else if (submitMinusStartTime.getDays() >= 11) 
					cosOutagePriority = PEAKRC_PRIORITY_PLANNED;
				
			} catch (DatatypeConfigurationException e) {
				
			}
		}
		
		return cosOutagePriority;
	}
	
	/**
	 * Returns the PeakRC COS outage status ID based on the provided OMS outage conditions. 
	 *
	 * @param  TransmissionOutage
	 * @return COS outage status as a string
	 */
	public String mapCosOutageStatusId(TransmissionOutage transOutage) {
		if(transOutage.getMktOrgOutageID()!=null && !transOutage.getMktOrgOutageID().isEmpty()){
			return null;
		}
		return PEAKRC_OUTAGE_STATUS_MAP.get(mapCosOutageStatus(transOutage));
	}
	
	/**
	 * Returns the PeakRC COS outage status string based on the provided OMS outage conditions. 
	 *
	 * @param  TransmissionOutage
	 * @return COS outage status as a string
	 */
	private String mapCosOutageStatus(TransmissionOutage transOutage) {
		String cosOutageStatus = PEAKRC_STATUS_TOP_CONFIRMED;
		
		//TODO NEED TO CHECK EXISTING OUTAGE TO SEE IF STATUS HAS CHANGED - IF CHANGED, THEN PROVIDE MAPPING, OTHERWISE, RETURN BLANK STRING  
		
		switch (transOutage.getOutageStatus()) {
		case STUDY:
			cosOutageStatus = PEAKRC_STATUS_TOP_PROPOSED;
			break;
		case APPROVED:
			cosOutageStatus = PEAKRC_STATUS_TOP_CONFIRMED;
			break;
		case DISAPPROVED:
			cosOutageStatus = PEAKRC_STATUS_CANCELLED;
			break;
		case CANCELLED:
			cosOutageStatus = PEAKRC_STATUS_CANCELLED;
			break;
		case PRE_APPROVED:
			cosOutageStatus = PEAKRC_STATUS_TOP_CONFIRMED;
			break;
		case OE_RECOMMENDED:
			cosOutageStatus = PEAKRC_STATUS_TOP_CONFIRMED;
			break;
		default: 
				logger.error("Unable to map COS outage status for outageId["+transOutage.getMRID()+"] with status["+transOutage.getOutageStatus().value()+"]");
				break;
		}
		
		return cosOutageStatus;
	}
	
	/**
	 * Returns the PeakRC COS outage priority ID based on the provided OMS outage conditions. 
	 *
	 * @param  RegisteredResourceOutage 
	 * @return COS outage priority as a string
	 */
	public String mapCosOutagePriorityId(RegisteredResourceOutage resourceOutage) {
		String weccOutageType =weccOutageDataDAO.findWECCOutageType(resourceOutage.getMRID(), resourceOutage.getVersionID(), "GENERATION");
		if (weccOutageType != null){
			return weccOutageType;
		}
		return PEAKRC_OUTAGE_PRIORITY_MAP.get(mapCosOutagePriority(resourceOutage));
	}
	
	/**
	 * Returns the PeakRC COS outage priority string based on the provided OMS outage conditions. 
	 *
	 * @param  RegisteredResourceOutage
	 * @return COS outage priority as a string
	 */
	public static String mapCosOutagePriority(RegisteredResourceOutage resourceOutage) {
		String cosOutagePriority = PEAKRC_PRIORITY_PLANNED;
		
		String workKind = resourceOutage.getWork().getKind().value();
		String affectsRASSPS = resourceOutage.getAffectsRASSPS().value();
				
		// Informational: "If (NoW = ICCP or RTU_RIG or Unit_Testing)"
		if ("ICCP,RTU_RIG,UNIT_TESTING".contains(workKind) && NO.equals(affectsRASSPS)) {
			cosOutagePriority = "Informational";
		}
		else if (!"ICCP,RTU_RIG,UNIT_TESTING".contains(workKind) && YES.equals(affectsRASSPS)) {
			XMLGregorianCalendar submitTime = resourceOutage.getCreatedDateTime();
			XMLGregorianCalendar startDate;
			if (resourceOutage.getActualPeriod() != null) {
				startDate =  resourceOutage.getActualPeriod().getStart();
			} else if (resourceOutage.getEstimatedPeriod() != null) {
				startDate =  resourceOutage.getEstimatedPeriod().getStart();
			}
			else {
				logger.error("Unable to map COS outage priority for outageId["+resourceOutage.getMRID()+"]: missing outage actual and estimated period");
				return cosOutagePriority;
			}
			
			String ynShortNotice = resourceOutage.getIsShortNoticeOpportunityOutage().value();
			String ynOffPeak = resourceOutage.getIsOffPeakOpportunityOutage().value();
			
					
			try {
				Duration submitMinusStartTime = DatatypeFactory.newInstance().newDuration(submitTime.toGregorianCalendar().getTimeInMillis() - startDate.toGregorianCalendar().getTimeInMillis());
				
				// Forced Automatic: "If (NoW != Communications or Relay_Work or Energized_Work) OR affectsRASSPS = 'Y' And (Submit Time-Start Time <= 0)"	
				if (submitMinusStartTime.getMinutes() <= 0) 
					cosOutagePriority = PEAKRC_PRIORITY_FORCED_AUTOMATIC;
				
				// Opportunity: "If (NoW != ICCP or RTU_RIG or Unit_Testing) And (0 < Submit Time-Start Time < 48 hrs) And (Short Notice Opportunity OR Off Peak Opportunity = 'Y')"	
				else if (0 < submitMinusStartTime.getHours() && submitMinusStartTime.getHours() < 48 && (YES.equals(ynShortNotice) || YES.equals(ynOffPeak))) 
					cosOutagePriority = PEAKRC_PRIORITY_OPPORTUNITY;
				
				// Forced Emergency: "If (NoW != ICCP or RTU_RIG or Unit_Testing) And (0 < Submit Time-Start Time < 24 hrs) And (Short Notice Opportunity OR Off Peak Opportunity != 'Y')"	
				else if ((0 < submitMinusStartTime.getHours() && submitMinusStartTime.getHours() < 24) && (NO.equals(ynShortNotice) || NO.equals(ynOffPeak))) 
					cosOutagePriority = PEAKRC_PRIORITY_FORCED_EMERGENCY;
				
				// Urgent: "If (NoW != ICCP or RTU_RIG or Unit_Testing) And (24hrs <= Submit Time-Start Time < 11d) And (Short Notice Opportunity OR Off Peak Opportunity != 'Y')"	
				else if ((24 <= submitMinusStartTime.getHours() && submitMinusStartTime.getDays() < 11) && (NO.equals(ynShortNotice) || NO.equals(ynOffPeak))) 
					cosOutagePriority = PEAKRC_PRIORITY_URGENT;
				
				// Planned: "If (NoW != ICCP or RTU_RIG or Unit_Testing) And (Submit Time-Start Time >= 11d)"
				else if (submitMinusStartTime.getDays() >= 11) 
					cosOutagePriority = PEAKRC_PRIORITY_PLANNED;
				
			} catch (DatatypeConfigurationException e) {
				
			}
		}
		
		return cosOutagePriority;
	}
	
	
	/**
	 * Returns the PeakRC COS outage status ID based on the provided OMS outage conditions. 
	 *
	 * @param  RegisteredResourceOutage
	 * @return COS outage status as a string
	 */
	public  String mapCosOutageStatusId(RegisteredResourceOutage resourceOutage) {
		if(resourceOutage.getMktOrgOutageID()!=null && !resourceOutage.getMktOrgOutageID().isEmpty()){
			return null;
		}
		
		return PEAKRC_OUTAGE_STATUS_MAP.get(mapCosOutageStatus(resourceOutage));
	}
	
	/**
	 * Returns the PeakRC COS outage status string based on the provided OMS outage conditions. 
	 *
	 * @param  RegisteredResourceOutage
	 * @return COS outage status as a string
	 */
	public static String mapCosOutageStatus(RegisteredResourceOutage resourceOutage) {
		String cosOutageStatus = PEAKRC_STATUS_BA_TOP_CONFIRMED;
		
		//TODO NEED TO CHECK EXISTING OUTAGE TO SEE IF STATUS HAS CHANGED - IF CHANGED, THEN PROVIDE MAPPING, OTHERWISE, RETURN BLANK STRING
		
		switch (resourceOutage.getOutageStatus()) {
			case STUDY: cosOutageStatus = PEAKRC_STATUS_BA_PROPOSED; break;
			case APPROVED: cosOutageStatus = PEAKRC_STATUS_BA_TOP_CONFIRMED; break;
			case DISAPPROVED: cosOutageStatus = PEAKRC_STATUS_CANCELLED; break;
			case CANCELLED: cosOutageStatus = PEAKRC_STATUS_CANCELLED; break;
			case PRE_APPROVED: cosOutageStatus = PEAKRC_STATUS_BA_TOP_CONFIRMED; break;
			case OE_RECOMMENDED: cosOutageStatus = PEAKRC_STATUS_BA_TOP_CONFIRMED; break;
			default: 
				logger.error("Unable to map COS outage status for outageId["+resourceOutage.getMRID()+"] with status["+resourceOutage.getOutageStatus().value()+"]");
				break;
		}
		
		return cosOutageStatus;
	}
	
	/**
	 * Returns the PeakRC COS outage status name based on the status Id. 
	 *
	 * @param  outageStatusId
	 * @return COS outage status as a string
	 */
	public static String mapCosOutageStatusName(String outageStatusId) {
		for (Entry<String, String> entry : PEAKRC_OUTAGE_STATUS_MAP.entrySet()) {
	        if (Objects.equals(outageStatusId, entry.getValue())) {
	        	return entry.getKey();
	        }
	    }
	    return null;
	}
	public static String mapCosOutageStatusName(int outageStatusId) {
		for (Entry<String, String> entry : PEAKRC_OUTAGE_STATUS_MAP.entrySet()) {
	        if (Objects.equals(Integer.toString(outageStatusId), entry.getValue())) {
	        	return entry.getKey();
	        }
	    }
	    return null;
	}
		
	/**
	 * Returns the PeakRC COS outage priority name based on the priority Id. 
	 *
	 * @param  outageProrityId
	 * @return COS outage status as a string
	 */
	public static String mapCosOutagePriorityName(String outageProrityId) {
		for (Entry<String, String> entry : PEAKRC_OUTAGE_PRIORITY_MAP.entrySet()) {
	        if (Objects.equals(outageProrityId, entry.getValue())) {
	        	return entry.getKey();
	        }
	    }
	    return null;
	}
	public static String mapCosOutagePriorityName(int outageProrityId) {
		for (Entry<String, String> entry : PEAKRC_OUTAGE_PRIORITY_MAP.entrySet()) {
	        if (Objects.equals(Integer.toString(outageProrityId), entry.getValue())) {
	        	return entry.getKey();
	        }
	    }
	    return null;
	}
	
	private static final String RCINT_UNDEFINED = "";
	private static final String YES = "YES";
	private static final String NO = "NO";
	
	private static final String PEAKRC_PRIORITY_PLANNED = "Planned";
	private static final String PEAKRC_PRIORITY_INFORMATIONAL = "Informational";
	private static final String PEAKRC_PRIORITY_FORCED_AUTOMATIC = "Forced Automatic";
	private static final String PEAKRC_PRIORITY_FORCED_EMERGENCY = "Forced Emergency";
	private static final String PEAKRC_PRIORITY_OPERATIONAL = "Operational";
	private static final String PEAKRC_PRIORITY_OPPORTUNITY = "Opportunity";
	private static final String PEAKRC_PRIORITY_URGENT = "Urgent";
		
	private static Map<String, String> PEAKRC_OUTAGE_PRIORITY_MAP; 
	static {
        Map<String, String> pMap = new HashMap<String, String>();
        pMap.put(PEAKRC_PRIORITY_FORCED_AUTOMATIC, 	"4");
        pMap.put(PEAKRC_PRIORITY_OPPORTUNITY, 		"5");
        pMap.put(PEAKRC_PRIORITY_FORCED_EMERGENCY, 	"6");
        pMap.put(PEAKRC_PRIORITY_PLANNED, 			"7");
        pMap.put(PEAKRC_PRIORITY_INFORMATIONAL, 	"10");
        pMap.put(PEAKRC_PRIORITY_URGENT, 			"14");
        pMap.put(PEAKRC_PRIORITY_OPERATIONAL, 		"34");
        pMap.put(RCINT_UNDEFINED, 					"RCINT_UNDEFINED");        
        PEAKRC_OUTAGE_PRIORITY_MAP = Collections.unmodifiableMap(pMap);
    }
	
	private static final String PEAKRC_STATUS_SUBMITTED = "Submitted";
	private static final String PEAKRC_STATUS_CANCELLED = "Cancelled";
	private static final String PEAKRC_STATUS_IMPLEMENTED = "Implemented";
	private static final String PEAKRC_STATUS_COMPLETED = "Completed";
	private static final String PEAKRC_STATUS_BA_PRIMINARY = "PeakRCBAPreliminary";
	private static final String PEAKRC_STATUS_BA_PROPOSED = "PeakRCBAProposed";
	private static final String PEAKRC_STATUS_BA_CONFIRMED = "PeakRCBAConfirmed";
	private static final String PEAKRC_STATUS_BA_TOP_CONFIRMED = "PeakRCBATOPConfirmed";
	private static final String PEAKRC_STATUS_TOP_PRIMINARY = "PeakRCTOPPreliminary";
	private static final String PEAKRC_STATUS_TOP_PROPOSED = "PeakRCTOPProposed";
	private static final String PEAKRC_STATUS_TOP_CONFIRMED = "PeakRCTOPConfirmed";
	private static final String PEAKRC_STATUS_RC_LONGRANGE_CONFIRMED = "PeakRCRCLongRangeConfirmed";
	private static final String PEAKRC_STATUS_RC_LONGRANGE_CONFLICTS_IDENTIFIED = "PeakRCRCLongRangeConflicsIdentified";
	private static final String PEAKRC_STATUS_RC_LONGRANGE_DENIED = "	PeakRCRCLongRangeDenied";
	private static final String PEAKRC_STATUS_RC_SHORTRANGE_CONFIRMED = "PeakRCRCShortRangeConfirmed";
	private static final String PEAKRC_STATUS_RC_SHORTRANGE_CONFLICTS_IDENTIFIED = "PeakRCRCShortRangeConflictsIdentified";
	private static final String PEAKRC_STATUS_RC_SHORTRANGE_DENIED = "	PeakRCRCShortRangeDenied";
	private static final String PEAKRC_STATUS_RC_RCOPAD2_CONFIRMED = "PeakRCRCOPAD2Confirmed";
	private static final String PEAKRC_STATUS_RC_RCOPAD2_CONFLICTS_INDENTIFIED = "PeakRCRCOPAD2ConflictsIdentified";
	private static final String PEAKRC_STATUS_RC_RCOPAD1_CONFIRMED = "PeakRCRCOPAD1Confirmed";
	private static final String PEAKRC_STATUS_RCOPAD1_CONFLICTS_INDENTIFIED = "PeakRCRCOPAD1ConflictsIdentified";
	private static final String PEAKRC_STATUS_RCOP_DENIED = "PeakRCRCOPADenied";
	private static final String PEAKRC_STATUS_RCSO_CONFIRMED = "PeakRCRCSOConfirmed";
	private static final String PEAKRC_STATUS_RCSO_CONFLICTS_INDENTIFIED = "PeakRCRCSOConflictsIdentified";
	private static final String PEAKRC_STATUS_RCSO_DENIED = "PeakRCRCSODenied";
	private static final String PEAKRC_STATUS_IMPLEMENTED_UNVERIFIED = "PeakRCImplementedUnverified";
	private static final String PEAKRC_STATUS_COMPLETED_UNVERIFIED = "PeakRCCompletedUnverified";
	private static final String PEAKRC_STATUS_EXPIRED = "PeakRCExpired";
	
	private static Map<String, String> PEAKRC_OUTAGE_STATUS_MAP; 
	static {
        Map<String, String> statusMap = new HashMap<String, String>();
        statusMap.put(PEAKRC_STATUS_SUBMITTED, "2");
        statusMap.put(PEAKRC_STATUS_CANCELLED, "9");
        statusMap.put(PEAKRC_STATUS_IMPLEMENTED, "10");
        statusMap.put(PEAKRC_STATUS_COMPLETED, "11");
        statusMap.put(PEAKRC_STATUS_BA_PRIMINARY, "30");
        statusMap.put(PEAKRC_STATUS_BA_PROPOSED, "31");
        statusMap.put(PEAKRC_STATUS_BA_CONFIRMED, "32");
        statusMap.put(PEAKRC_STATUS_BA_TOP_CONFIRMED, "33");
        statusMap.put(PEAKRC_STATUS_TOP_PRIMINARY, "34");
        statusMap.put(PEAKRC_STATUS_TOP_PROPOSED, "35");
        statusMap.put(PEAKRC_STATUS_TOP_CONFIRMED, "36");
        statusMap.put(PEAKRC_STATUS_RC_LONGRANGE_CONFIRMED, "37");
        statusMap.put(PEAKRC_STATUS_RC_LONGRANGE_CONFLICTS_IDENTIFIED,  "38");;
        statusMap.put(PEAKRC_STATUS_RC_LONGRANGE_DENIED, "39");
        statusMap.put(PEAKRC_STATUS_RC_SHORTRANGE_CONFIRMED, "40");
        statusMap.put(PEAKRC_STATUS_RC_SHORTRANGE_CONFLICTS_IDENTIFIED, "41");
        statusMap.put(PEAKRC_STATUS_RC_SHORTRANGE_DENIED, "42");
        statusMap.put(PEAKRC_STATUS_RC_RCOPAD2_CONFIRMED, "43");
        statusMap.put(PEAKRC_STATUS_RC_RCOPAD2_CONFLICTS_INDENTIFIED, "44");
        statusMap.put(PEAKRC_STATUS_RC_RCOPAD1_CONFIRMED, "45");
        statusMap.put(PEAKRC_STATUS_RCOPAD1_CONFLICTS_INDENTIFIED, "46");
        statusMap.put(PEAKRC_STATUS_RCOP_DENIED, "47");
        statusMap.put(PEAKRC_STATUS_RCSO_CONFIRMED, "48");
        statusMap.put(PEAKRC_STATUS_RCSO_CONFLICTS_INDENTIFIED, "49");
        statusMap.put(PEAKRC_STATUS_RCSO_DENIED, "50");
        statusMap.put(PEAKRC_STATUS_IMPLEMENTED_UNVERIFIED, "51");
        statusMap.put(PEAKRC_STATUS_COMPLETED_UNVERIFIED, "52");
        statusMap.put(PEAKRC_STATUS_EXPIRED, "53");
        statusMap.put(RCINT_UNDEFINED, RCINT_UNDEFINED);
        PEAKRC_OUTAGE_STATUS_MAP = Collections.unmodifiableMap(statusMap);
    }
}
