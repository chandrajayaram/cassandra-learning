/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 18, 2017 1:41:23 PM
 * Project: caiso-rcint_api
 * File: WebServiceCallOutService.java
 */
package com.caiso.rcint.service;

import com.caiso.rcint.domain.RCPublishInfoType;

/**
 * @author gselvaratnam
 *
 */
public interface WebServiceCallOutService {

    String callOmsWebService_soap_12(final String soapRequestXml, final String attachmentXml, RCPublishInfoType rcPublishInfoType);

    String callPeakCosWebService(final String soapRequestXml, String soapAction);

    String getOmsAttachementRegulatoryAuthorityOutageStatusXMLString(String timeDate, String omsOutageId, String omsOutageVersion, String errorMsg,
            String cosId, String status);

    String getOmsReceiveRegulatoryAuthorityOutageStatus_v1SoapXMLString();

    String getPeakOutageRequestQuery_ExecuteQuerySoapXMLString(String controlArea, String startTime, String endTime, String status, String lastRunTime);

    String getPeakOutageSchedule_LoadItemSoapXMLString(String outageNumber, String revisionNumber);

    String getOmsSubmitTransmissionOutage_v1SoapXMLString();

    String callPeakCosWebService(final String soapRequestXml, RCPublishInfoType rcPublishInfoType);

    String callOmsWebService_soap_11(final String soapRequestXml, final String attachmentXml, RCPublishInfoType rcPublishInfoType);

}
