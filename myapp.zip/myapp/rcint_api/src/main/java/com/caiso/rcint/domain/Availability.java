package com.caiso.rcint.domain;

import java.math.BigDecimal;

public class Availability {
	private Interval interval;
	private BigDecimal value;
	private boolean outOfService;
	
	public boolean isOutOfService() {
		return outOfService;
	}
	public void setOutOfService(boolean outOfService) {
		this.outOfService = outOfService;
	}
	
	public Interval getInterval() {
		return interval;
	}
	public void setInterval(Interval interval) {
		this.interval = interval;
	}
	public BigDecimal getValue() {
		return value;
	}
	public void setValue(BigDecimal value) {
		this.value = value;
	}
	
	
	
}
