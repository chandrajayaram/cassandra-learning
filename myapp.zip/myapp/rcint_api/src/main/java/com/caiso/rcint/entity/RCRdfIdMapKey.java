/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
@Embeddable
@Access(AccessType.FIELD)
@Deprecated
public class RCRdfIdMapKey implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    @Column(name = "CONTROL_AREA")
    private String            controlArea;

    @Column(name = "STATION")
    private String            stattion;

    @Column(name = "VOLTAGE_CLASS")
    private String            voltageClass;

    @Column(name = "COS_NAME", nullable = false)
    private String            cosName;

    @Column(name = "RDF_ID")
    private String            rdfId;

    @Column(name = "CREATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              createdDate;

    @Column(name = "UPDATED_DTS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              updatedDate;

    @Column(name = "UPDATED_BY")
    private String            updatedBy;

    @Column(name = "BATCH_ID")
    private String            batchId;

    /**
     * @return the controlArea
     */
    public String getControlArea() {
        return controlArea;
    }

    /**
     * @param controlArea
     *            the controlArea to set
     */
    public void setControlArea(String controlArea) {
        this.controlArea = controlArea;
    }

    /**
     * @return the stattion
     */
    public String getStattion() {
        return stattion;
    }

    /**
     * @param stattion
     *            the stattion to set
     */
    public void setStattion(String stattion) {
        this.stattion = stattion;
    }

    /**
     * @return the voltageClass
     */
    public String getVoltageClass() {
        return voltageClass;
    }

    /**
     * @param voltageClass
     *            the voltageClass to set
     */
    public void setVoltageClass(String voltageClass) {
        this.voltageClass = voltageClass;
    }

    /**
     * @return the cosName
     */
    public String getCosName() {
        return cosName;
    }

    /**
     * @param cosName
     *            the cosName to set
     */
    public void setCosName(String cosName) {
        this.cosName = cosName;
    }

    /**
     * @return the rdfId
     */
    public String getRdfId() {
        return rdfId;
    }

    /**
     * @param rdfId
     *            the rdfId to set
     */
    public void setRdfId(String rdfId) {
        this.rdfId = rdfId;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy
     *            the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the batchId
     */
    public String getBatchId() {
        return batchId;
    }

    /**
     * @param batchId
     *            the batchId to set
     */
    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final RCRdfIdMapKey other = (RCRdfIdMapKey) obj;
        return Objects.equals(this.batchId, other.batchId) && Objects.equals(this.controlArea, other.controlArea) && Objects.equals(this.cosName, other.cosName)
                && Objects.equals(this.createdDate, other.createdDate) && Objects.equals(this.rdfId, other.rdfId)
                && Objects.equals(this.stattion, other.stattion) && Objects.equals(this.updatedBy, other.updatedBy)
                && Objects.equals(this.updatedDate, other.updatedDate) && Objects.equals(this.voltageClass, other.voltageClass);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.batchId, this.controlArea, this.cosName, this.createdDate, this.rdfId, this.stattion, this.updatedBy, this.updatedDate,
                this.voltageClass);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}