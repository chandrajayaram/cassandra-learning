package com.caiso.rcint.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.exception.RCINTRuntimeException;

public class SOAPMessageTemplateImpl implements SOAPMessageTemplate {
	private static final Logger logger = LoggerFactory.getLogger(SOAPMessageTemplateImpl.class);

	/* (non-Javadoc)
     * @see com.caiso.rcint.util.SOAPMessageTemplate#sendMessage(java.lang.String, java.lang.String, javax.xml.soap.SOAPMessage, org.apache.http.client.HttpClient, int)
     */
	@Override
    public SOAPMessage sendMessage(String endPointUrl, String soapAction, SOAPMessage soapRequest,
			HttpClient httpClient, int retryCount) throws RCINTApplicationException {

		HttpResponse response = null;
		byte[] message = convertSAOPMessageToByteArray(soapRequest);

		HttpPost httpRequest = new HttpPost(endPointUrl);

		HttpEntity entity = new ByteArrayEntity(message);

		httpRequest.setEntity(entity);

		httpRequest.addHeader("SOAPAction", soapAction);

		httpRequest.addHeader("Content-Type", "text/xml");
		if(logger.isDebugEnabled())
			logger.debug("message=" + new String(message));
		logger.info("endpoint=" + endPointUrl);
		logger.info("soapAction=" + soapAction);

		int currRetryCount = 1;
		while ((currRetryCount < retryCount) && (response == null)) {

			try {
				response = httpClient.execute(httpRequest);
				logger.info("http status = " + response.getStatusLine());
			} catch (Exception e) {
				logger.info("failed on " + retryCount + " of " + retryCount);
				logger.error("Error occourced while sending the request to URL " + endPointUrl, e);
			}
			currRetryCount++;
		}

		if (response == null)
			throw new RCINTApplicationException("An unexpected error occurred while processing the request.");
		
		return convertHttpResponseToSAOPMessage(response);
	}
	
	/* (non-Javadoc)
     * @see com.caiso.rcint.util.SOAPMessageTemplate#sendMessage(java.lang.String, java.lang.String, org.apache.http.client.HttpClient, int)
     */
	@Override
    public String sendMessage(String endPointUrl,  String requestXML, Map<String, String> httpHeaders,
			HttpClient httpClient, int retryCount) throws RCINTApplicationException {

		HttpResponse response = null;
		HttpPost httpRequest = new HttpPost(endPointUrl);

		HttpEntity entity = new ByteArrayEntity(requestXML.getBytes());

		httpRequest.setEntity(entity);

		if(null!= httpHeaders){
			httpHeaders.entrySet().forEach(entry ->  httpRequest.addHeader(entry.getKey(), entry.getValue()));
		}
		
		if(logger.isDebugEnabled())
			logger.debug("message=" + requestXML);
		
		logger.info("endpoint=" + endPointUrl);
		

		int currRetryCount = 1;
		while ((currRetryCount < retryCount) && (response == null)) {

			try {
				response = httpClient.execute(httpRequest);
				logger.info("http status = " + response.getStatusLine());
			} catch (Exception e) {
				logger.info("failed on " + retryCount + " of " + retryCount);
				logger.error("Error occourced while sending the request to URL " + endPointUrl, e);
			}
			currRetryCount++;
		}

		if (response == null)
			throw new RCINTApplicationException("An unexpected error occurred while processing the request.");
		
		HttpEntity responseEntity = response.getEntity();
		InputStream instream;
		try {
			instream = responseEntity.getContent();
			return new BufferedReader(new InputStreamReader(instream))
					  .lines().collect(Collectors.joining("\n"));

		} catch (UnsupportedOperationException | IOException e) {
			throw new RCINTApplicationException("An unexpected error occurred while processing the request.",e);
		}
	}
	

	private byte[] convertSAOPMessageToByteArray(SOAPMessage soapMessage) {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		try {
			soapMessage.writeTo(stream);
			return stream.toByteArray();
		} catch (SOAPException | IOException e) {
			throw new RCINTRuntimeException("An unexpected error occurred when converting soap message to byte array.", e);
		} 
		
	}
	
	private SOAPMessage convertHttpResponseToSAOPMessage(HttpResponse response) {
		HttpEntity entity = response.getEntity();
		try {
			InputStream instream = entity.getContent();
			MessageFactory 	factory = MessageFactory.newInstance();
			MimeHeaders headers = new MimeHeaders();
			return factory.createMessage(headers, instream);
		} catch (SOAPException | IOException e) {
			throw new RCINTRuntimeException("An unexpected error occurred when converting http response to soap message.", e);
		}
	}

	

}
