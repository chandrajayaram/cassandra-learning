/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.entity;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
@Entity
@Table(name = "RC_OUTAGE_STATUS")
public class RCOutageStatus implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    @Id
    @Column(name = "ID", nullable = false)
    private Long              id;

    @Column(name = "STATUS")
    private String            status;

    @Column(name = "ENABLED")
    private String            enabled;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the enabled
     */
    public String getEnabled() {
        return enabled;
    }

    /**
     * @param enabled the enabled to set
     */
    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final RCOutageStatus other = (RCOutageStatus) obj;
        return Objects.equals(this.id, other.id) && Objects.equals(this.status, other.status) && Objects.equals(this.enabled, other.enabled);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.status, this.enabled);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
