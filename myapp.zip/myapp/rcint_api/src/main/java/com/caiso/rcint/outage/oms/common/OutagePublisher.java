package com.caiso.rcint.outage.oms.common;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.http.client.HttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.caiso.rcint.dao.ConfigDAO;
import com.caiso.rcint.dao.RCPublishPayloadDAO;
import com.caiso.rcint.dao.WECCOutageDataDAO;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.util.SOAPMessageTemplate;
import com.caiso.soa.regulatoryauthorityoutagestatus_v1.OutageStatusKind;

@Service
public class OutagePublisher {

	public static final Logger logger = LoggerFactory.getLogger(OutagePublisher.class);

	private ConfigDAO configDAO;
	private SOAPMessageTemplate soapMessageTemplate;
	private ExecutorService cosExecutorService;
	private RCPublishPayloadDAO rcPublishPayloadDAO;
	private WECCOutageDataDAO weccOutageDataDAO;
	private HttpClient defaultHttpClient;
	private AcknowledgementPublisher ackPublisher;

	@Autowired
	public void setAckPublisher(AcknowledgementPublisher ackPublisher) {
		this.ackPublisher = ackPublisher;
	}

	@Autowired
	public void setDefaultHttpClient(HttpClient defaultHttpClient) {
		this.defaultHttpClient = defaultHttpClient;
	}

	@Autowired
	public void setSoapMessageTemplate(SOAPMessageTemplate soapMessageTemplate) {
		this.soapMessageTemplate = soapMessageTemplate;
	}

	@Autowired
	public void setConfigDAO(ConfigDAO configDAO) {
		this.configDAO = configDAO;
	}

	@Autowired
	public void setWeccOutageDataDAO(WECCOutageDataDAO weccOutageDataDAO) {
		this.weccOutageDataDAO = weccOutageDataDAO;
	}

	@Autowired
	public void setRcPublishPayloadDAO(RCPublishPayloadDAO rcPublishPayloadDAO) {
		this.rcPublishPayloadDAO = rcPublishPayloadDAO;
	}

	@Autowired
	public void setCosExecutorService(ExecutorService cosExecutorService) {
		this.cosExecutorService = cosExecutorService;
	}

	public void process(long payloadId, WECCPayload weccPayload) {
		cosExecutorService.submit(createCOSProcess(payloadId, weccPayload));
	}

	private Runnable createCOSProcess(long payloadId, WECCPayload weccPayload) {
		return ()-> processWECCPayload(payloadId, weccPayload); 
		
	}

	void processWECCPayload(long payloadId, WECCPayload weccPayload) {
		
		String weccId = "";
		StringBuilder errorDescription = new StringBuilder();
		String status;
		
		SOAPMessage response = null;
		
		try {
			response = publishPayloadToCOS(payloadId, weccPayload);
			if(response == null){
				return;
			}
			
			SOAPBody soapBody = response.getSOAPBody();
			Document document = soapBody.extractContentAsDocument();
			XPath xpath = XPathFactory.newInstance().newXPath();
			
			Node outageNumberNode = (Node) xpath.evaluate( "//*[local-name()='outageNumber']", document, XPathConstants.NODE);
			if(outageNumberNode.getFirstChild()!=null){
				weccId = outageNumberNode.getFirstChild().getNodeValue();	
			}
			
			Node remoteSystemOutageNumberNode = (Node) xpath.evaluate("//*[local-name()='remoteSystemOutageNumber']", document,
					XPathConstants.NODE);
			String omsId = remoteSystemOutageNumberNode.getFirstChild().getNodeValue();
			
			NodeList errorList = (NodeList) xpath.evaluate("//*[local-name()='errorCode']", document, XPathConstants.NODESET);
			List<Integer> errorCodes = new ArrayList<>();
			for (int i = 0; i < errorList.getLength(); i++) {
				int errorCode = Integer.parseInt(errorList.item(i).getFirstChild().getNodeValue());
				errorCodes.add(errorCode);
			}
			
			String statusMessage = "";
			if(!weccId.equals("") && !weccId.equals("0-00000000")){
				status = OutageStatusKind.ACCEPTED.toString();
				String outageType="";
				String outageStatus="";
				
				Node outageTypeNode = (Node) xpath.evaluate("//*[local-name()='outagePriorityName']", document,
						XPathConstants.NODE);
				outageType = outageTypeNode.getFirstChild().getNodeValue();
				
				Node outageStatusNode = (Node) xpath.evaluate("//*[local-name()='outageStatus']", document,
						XPathConstants.NODE);
				outageStatus = outageStatusNode.getFirstChild().getNodeValue();
				
				if(errorCodes.stream().filter( e -> e > 0).count() > 0){
					statusMessage =	"ACCEPTED WITH WARNINGS: Published WebOMS outage[" + omsId + "] as WECC outage [" + weccId + "]";
				}else if(errorCodes.stream().filter( e -> e < 0).count() == 0){
					statusMessage = "ACCEPTED: Published WebOMS outage[" + omsId + "] as WECC outage [" + weccId + "]";
				}
				weccOutageDataDAO.updateWECCOutageData(weccId, payloadId, outageType, outageStatus);
				rcPublishPayloadDAO.updatePayloadStatus(payloadId, status,statusMessage);
			}else{
				status = OutageStatusKind.REJECTED.toString();
				String errorDesc = "//*[local-name()='errorDescription']";
				NodeList errorDescList = (NodeList) xpath.evaluate(errorDesc, document, XPathConstants.NODESET);
				for (int i = 0; i < errorDescList.getLength(); i++) {
					if (!"No Error".equals(errorDescList.item(i).getFirstChild().getNodeValue())) {
						errorDescription.append(errorDescList.item(i).getFirstChild().getNodeValue());
					}
				}
				rcPublishPayloadDAO.updatePayloadStatus(payloadId, status, errorDescription.toString());
			}
		} catch (Exception e) {
			logger.error("Error occoured while processing the response from COS", e);
			String responseStr ="";
			if(response!=null){
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				try {
					response.writeTo(out);
					responseStr = new String(out.toByteArray());
				} catch (SOAPException | IOException e1) {
					logger.error("error creating cos response", e1);
				}	
			
			}
			
			rcPublishPayloadDAO.updatePayloadStatus(payloadId, "ERROR", "ERROR PROCESSING THE RESPONSE [ " +  responseStr + " ] "+e.getMessage());
			return;
		}
		
		ackPublisher.processAcknowledgement(payloadId, (String) weccPayload.getData("OMS_OUTAGE_ID"),
				((Long) weccPayload.getData("OMS_OUTAGE_VERSION")).toString(), "TRANSMISSION", weccId, errorDescription.toString(),
				status);
	}

	private synchronized SOAPMessage publishPayloadToCOS(long payloadId, WECCPayload weccPayload)
			throws RCINTApplicationException, SOAPException {
		
		String cosURL = configDAO.getConfigProperty("WECC_COS_URL");
		String soapAction = "http://crow.equinox.ca/OutageSchedule_SubmitRequest";
		
		SOAPMessage response= soapMessageTemplate.sendMessage(cosURL, soapAction, weccPayload.getWeccPayload(), defaultHttpClient, 2);
		if (response == null) {
			rcPublishPayloadDAO.updatePayloadStatus(payloadId, "ERROR", "NO RESPONSE FROM COS"); 
			logger.error("Response was not reived from the COS");
			return null;
		}
		if (response.getSOAPBody().hasFault()) {
			rcPublishPayloadDAO.updatePayloadStatus(payloadId, "ERROR", "CAUSE RESPONSE HAS FAULT");
			logger.error("Response from COS contains fault " + response.getSOAPBody().getFault().getFaultString());
			return null;
		}
		return response;
	}

}
