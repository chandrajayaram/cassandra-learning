/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 23, 2017 8:59:51 AM
 * Project: caiso-rcint_api
 * File: BaseCosCaisoOutageProcessor.java
 */
package com.caiso.rcint.outage.cos;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.caiso.rcint.dao.WECCOutageData;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.service.DbPropertyService;
import com.caiso.rcint.util.DateUtil;

import ca.equinox.crow.ArrayOfErrorCode;
import ca.equinox.crow.ArrayOfReturnedOutage;
import ca.equinox.crow.ErrorCode;
import ca.equinox.crow.OutageRequestQueryExecuteQueryResponse;
import ca.equinox.crow.OutageRequestQueryResult;
import ca.equinox.crow.ReturnedOutage;

/**
 * @author gselvaratnam
 *
 */
public class BaseCosCaisoOutageProcessor {

    @Autowired
    private DbPropertyService           dbPropertyService;

    protected String parseControlArea(String controlArea) {
        String parser = "-";

        if (controlArea != null) {
            return controlArea.indexOf(parser) < 0 ? controlArea : controlArea.substring(0, controlArea.indexOf(parser));
        } else {
            return "";
        }
    }

    /**
     * @param soapMessage
     * @throws JAXBException
     */
    protected List<ReturnedOutage> findReturnedOutageList(String peakOutageRequestQuery_ExecuteQueryResponse) throws JAXBException {
        List<ReturnedOutage> returnedOutageList = null;

        JAXBContext jaxbContext = JAXBContext.newInstance("ca.equinox.crow");
        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
        JAXBElement<OutageRequestQueryExecuteQueryResponse> root = jaxbUnmarshaller.unmarshal(new StreamSource(new StringReader(peakOutageRequestQuery_ExecuteQueryResponse)),
                OutageRequestQueryExecuteQueryResponse.class);
        OutageRequestQueryExecuteQueryResponse outageRequestQueryExecuteQueryResponse = root.getValue();
        if (isNoError(outageRequestQueryExecuteQueryResponse)) {
            OutageRequestQueryResult outageRequestQueryResult = outageRequestQueryExecuteQueryResponse.getOutageRequestQueryExecuteQueryResult();
            if (outageRequestQueryResult != null && outageRequestQueryResult.getReturnedOutages() != null) {
                ArrayOfReturnedOutage arrayOfReturnedOutage = outageRequestQueryResult.getReturnedOutages();
                returnedOutageList = arrayOfReturnedOutage.getReturnedOutages();
            }
        }

        return returnedOutageList;
    }

    /**
     * @param outageRequestQueryExecuteQueryResponse
     */
    protected boolean isNoError(OutageRequestQueryExecuteQueryResponse outageRequestQueryExecuteQueryResponse) {
        if (outageRequestQueryExecuteQueryResponse != null && outageRequestQueryExecuteQueryResponse.getOutageRequestQueryExecuteQueryResult() != null) {
            ArrayOfErrorCode arrayOfErrorCode = outageRequestQueryExecuteQueryResponse.getOutageRequestQueryExecuteQueryResult().getErrorCodes();
            for (ErrorCode errorCode : arrayOfErrorCode.getErrorCodes()) {
                if (errorCode.getErrorCode() == 0) {
                    return true;
                } else {
                    throw new RCINTRuntimeException("Error:OutageRequestQuery_ExecuteQuery [Error Code:]" + errorCode.getErrorCode() + " [Error Message:]"
                            + errorCode.getErrorDescription());
                }
            }
        }
        return false;
    }

    /**
     * 
     * @param soapMessage
     * @return
     * @throws TransformerFactoryConfigurationError
     * @throws TransformerException
     * @throws TransformerConfigurationException
     */
    @Deprecated
    protected String findOutageSchedule_LoadItemResponseAsString(SaajSoapMessage soapMessage)
            throws TransformerConfigurationException, TransformerException, TransformerFactoryConfigurationError {
        String response = null;
        final StringWriter sw = new StringWriter();
        TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSoapBody().getPayloadSource(), new StreamResult(sw));
        response = new String(sw.toString());
        // response = implementWeccOutageWorkarounds(response);
        return response;
    }

    @Deprecated
    protected String implementWeccOutageWorkarounds(String weccLoadOutageInfo) {

        // WORKAROUND: CONVERT REQUESTED_EQUIPMENT TO REQUESTED_EQUIPMENT_LIST
        weccLoadOutageInfo = weccLoadOutageInfo.replace("requestedEquipment>", "RequestedEquipmentList>");

        // WORKAROUND: COS 4 - CONVERT RequestedEquipmentStr TO
        // requestedEquipmentStr
        weccLoadOutageInfo = weccLoadOutageInfo.replace("RequestedEquipmentStr", "requestedEquipmentStr");

        // WORKAROUND: CONVERT <OutageApproval xsi:nil="true"/> TO NONE
        weccLoadOutageInfo = weccLoadOutageInfo.replace("<OutageApproval xsi:nil=\"true\"/>", "");

        return weccLoadOutageInfo;
    }

    protected boolean isWeccOutagePublishedToOMS(List<WECCOutageData> weccOutageDataList) {
        boolean response = false;
        List<WECCOutageData> newWeccOutageDataList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(weccOutageDataList)) {
            for (WECCOutageData weccOutageData : weccOutageDataList) {
                if (weccOutageData.getOmsOutageId() != null) {
                    newWeccOutageDataList.add(weccOutageData);
                }
            }
        }

        if (!CollectionUtils.isEmpty(newWeccOutageDataList)) {
            response = true;
        }
        return response;
    }

    /**
     * @param processStartTime
     * @param processEndTime
     */
    protected void setupProcessStartAndEndTimes(Calendar processStartTime, Calendar processEndTime, Calendar lastRunTime, String lastRunTimeProperty) {
        Calendar todayCal = Calendar.getInstance();

        String lastRunDateStr = dbPropertyService.getProperty(lastRunTimeProperty);

        if (!StringUtils.isEmpty(lastRunDateStr)) {
            todayCal.add(Calendar.HOUR, -24);

            Date lastRunDate = DateUtil.getDateFromString(lastRunDateStr, DateUtil.COS5_DATE_FORMAT);
            Calendar lastRunCal = Calendar.getInstance();
            lastRunCal.setTime(lastRunDate);
            if(todayCal.after(lastRunCal)) {
                processStartTime.setTime(lastRunDate);
                lastRunTime.setTime(lastRunDate);
                lastRunTime.add(Calendar.HOUR, -24);
            } else {
                processStartTime.setTime(lastRunDate);
                lastRunTime.add(Calendar.HOUR, -24);
            }
        }
        processEndTime.setTime(processStartTime.getTime());
        processEndTime.add(Calendar.YEAR, 2);
    }
}