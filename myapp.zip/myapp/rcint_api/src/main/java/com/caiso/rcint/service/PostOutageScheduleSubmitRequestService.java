/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 8, 2017 11:16:29 AM
 * Project: rcint-app
 * File: PostOutageScheduleSubmitRequestController.java
 */
package com.caiso.rcint.service;

import com.caiso.rcint.entity.RCPublishPayload;

/**
 * @author gselvaratnam
 *
 */
public interface PostOutageScheduleSubmitRequestService {

    String resendPayload(RCPublishPayload rcPublishPayload);

}