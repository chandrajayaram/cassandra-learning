package com.caiso.rcint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class RCPublishPayloadDAOImpl implements RCPublishPayloadDAO {
	public static final Logger logger = LoggerFactory.getLogger(RCPublishPayloadDAOImpl.class);
	
	private static final String RC_PUBLISH_PAYLOAD = "INSERT INTO RC_PUBLISH_PAYLOAD (PAYLOAD_ID,PAYLOAD_TYPE, STATUS, CREATED_DTS, RETRY, UPDATED_DTS, DATA) Values (:PAYLOAD_ID, :PAYLOAD_TYPE, 'NEW', SYSDATE, 0, SYSDATE, :DATA)";
	private static final String RC_PUBLISH_PAYLOAD_SEQ	= "SELECT RC_PAYLOAD_SEQ.NEXTVAL FROM DUAL";
	private static final String RC_PUBLISH_PAYLOAD_STATUS_UPDATE ="UPDATE RC_PUBLISH_PAYLOAD SET STATUS = :STATUS, RETRY=RETRY+1, RESPONSE = :RESPONSE WHERE PAYLOAD_ID = :PAYLOAD_ID" ;
	public static final String  RC_PUBLISH_PAYLOAD_REFRESH ="UPDATE RC_PUBLISH_PAYLOAD SET DATA=:DATA, STATUS='NEW', RETRY=0, RESPONSE=NULL WHERE PAYLOAD_ID = :PAYLOAD_ID";
	private static final String SELECT_COS_PAYLOAD = "SELECT DATA FROM RC_PUBLISH_PAYLOAD WHERE PAYLOAD_ID =:PAYLOAD_ID";
	private static final String SELECT_COS_PAYLOAD_FOR_MRID = "SELECT DATA FROM RC_PUBLISH_PAYLOAD WHERE PAYLOAD_ID =(SELECT PAYLOAD_ID FROM WECC_OUTAGE_DATA WHERE OMS_OUTAGE_ID=:OMS_OUTAGE_ID AND OMS_OUTAGE_TYPE=:OMS_OUTAGE_TYPE AND OMS_OUTAGE_VERSION=:OMS_OUTAGE_VERSION)";
	
	@Autowired
	private NamedParameterJdbcTemplate rcintJdbcTemplate;
	
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.RCPublishPayloadDAO#savePayload(java.lang.String, byte[])
     */
	@Override
    public long savePayload(String payloadType, byte[] bytes){
		logger.info("Creating rc publish payload");
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		long payloadId = getNextSequenceValue();
		paramSource.addValue("PAYLOAD_ID", payloadId);
		paramSource.addValue("PAYLOAD_TYPE", payloadType);
		paramSource.addValue("DATA", bytes, Types.BINARY);
		rcintJdbcTemplate.update(RC_PUBLISH_PAYLOAD, paramSource);
		return payloadId;
	}
	
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.RCPublishPayloadDAO#updatePayloadStatus(long, java.lang.String, java.lang.String)
     */
	@Override
    public void updatePayloadStatus(long payloadId, String status, String response){
		logger.info("updating rc publish payload");
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("PAYLOAD_ID", payloadId);
		paramSource.addValue("STATUS", status);
		paramSource.addValue("RESPONSE", response);
		rcintJdbcTemplate.update(RC_PUBLISH_PAYLOAD_STATUS_UPDATE, paramSource);
	}
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.RCPublishPayloadDAO#updatePayloadResfresh(long, byte[])
     */
	@Override
	@Deprecated
    public void updatePayloadResfresh(long payloadId, byte[] bytes){
		logger.info("updating rc publish payload");
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("PAYLOAD_ID", payloadId);
		paramSource.addValue("DATA", bytes, Types.BINARY);
		rcintJdbcTemplate.update(RC_PUBLISH_PAYLOAD_REFRESH, paramSource);
	}
	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.RCPublishPayloadDAO#retrievePayload(long)
     */
	@Override
    public byte[] retrievePayload(long payloadId){
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("PAYLOAD_ID", payloadId);
		return rcintJdbcTemplate.query(SELECT_COS_PAYLOAD, paramSource, new ResultSetExtractor<byte[]>() {
			@Override
			public byte[] extractData(ResultSet rs) throws SQLException, DataAccessException {
				while(rs.next()){
					return rs.getBytes(1);
				}
				return null;
			}
		});
	}

	/* (non-Javadoc)
     * @see com.caiso.rcint.dao.RCPublishPayloadDAO#updateAsIgnored()
     */
	@Override
	@Deprecated
    public void updateAsIgnored() {
	    
	}

	private long getNextSequenceValue(){
		return rcintJdbcTemplate.query(RC_PUBLISH_PAYLOAD_SEQ, new ResultSetExtractor<Long>() {
			@Override
			public Long extractData(ResultSet rs) throws SQLException, DataAccessException {
				while(rs.next()){
					return rs.getLong(1);
				}
				return null;
			}
		});
	}
	
	@Override
    public byte[] retrievePayloadForMRID(String payloadType, String mrid, String version){
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("OMS_OUTAGE_ID", mrid);
		paramSource.addValue("OMS_OUTAGE_TYPE", payloadType);
		paramSource.addValue("OMS_OUTAGE_VERSION", version);
		
		return rcintJdbcTemplate.query(SELECT_COS_PAYLOAD_FOR_MRID, paramSource, new ResultSetExtractor<byte[]>() {
			@Override
			public byte[] extractData(ResultSet rs) throws SQLException, DataAccessException {
				while(rs.next()){
					return rs.getBytes(1);
				}
				return null;
			}
		});
	}
}

