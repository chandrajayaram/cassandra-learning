package com.caiso.rcint.outage.oms.endpoint;

import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.server.endpoint.annotation.SoapAction;

import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.outage.oms.availability.AvailabilityResultsProcessor;
import com.caiso.rcint.outage.oms.payload.ReceiveAvailabilityResultsCaisoV1;
import com.caiso.rcint.outage.oms.payload.ReceiveResourceOutageResultsCaisoV2;
import com.caiso.rcint.outage.oms.payload.ReceiveTransmissionOutageResultsCaisoV2;
import com.caiso.rcint.outage.oms.resource.ResourceOutageProcessor;
import com.caiso.rcint.outage.oms.transmission.TransmissionOutageProcessor;



@Endpoint
public class ServiceEndpoint {
	public static final Logger logger = LoggerFactory.getLogger(ServiceEndpoint.class);
	
    @Autowired
	private TransmissionOutageProcessor transmissionOutageService;
	
    @Autowired
	private ResourceOutageProcessor resourceOutageService;
    
    @Autowired
	private AvailabilityResultsProcessor availabilityResultsService;

    @Autowired
    private ExecutorService transmisiionOutageExecutorService;
    
    @Autowired
    private ExecutorService resourceOutageExecutorService;
    
	@SoapAction("http://www.caiso.com/soa/receiveTransmissionOutageResultsCaiso_v2")
    @ResponsePayload
    public Boolean receiveTransmissionOutageResultsCaisoV2(@RequestPayload ReceiveTransmissionOutageResultsCaisoV2 payload) throws RCINTApplicationException {
		transmisiionOutageExecutorService.submit(() -> {
			try {
				logger.info("received transmission outage -> " + payload.getDomainObject().getMessagePayload().getTransmissionOutages().get(0).getMRID() +" ");
				transmissionOutageService.process(payload.getDomainObject());
			} catch (Exception e) {
				logger.error("Error occoured processing the transmission outage -> " + payload.getDomainObject().getMessagePayload().getTransmissionOutages().get(0).getMRID() +" ", e);
			}
		});
		return true;
    }
    @SoapAction("http://www.caiso.com/soa/receiveResourceOutageResultsCaiso_v2")
    @ResponsePayload
    public Boolean  receiveResourceOutageResultsCaisoV2(@RequestPayload ReceiveResourceOutageResultsCaisoV2 payload) throws RCINTApplicationException {
    	resourceOutageExecutorService.submit( () ->{
    		try {
				logger.info("received resourse outage -> " + payload.getDomainObject().getMessagePayload().getRegisteredResourceOutages().get(0).getMRID() +" ");
				resourceOutageService.processAsync(payload.getDomainObject());
    		} catch (Exception e) {
				logger.error("Error occoured processing the resourse outage -> " + payload.getDomainObject().getMessagePayload().getRegisteredResourceOutages().get(0).getMRID() +" ", e);
			}	
    	});
    	return true;
    }
    
    @SoapAction("http://www.caiso.com/soa/receiveAvailabilityResultsCaiso_v1")
    @ResponsePayload
    public Boolean  receiveAvailabilityResultsCaisoV1(@RequestPayload ReceiveAvailabilityResultsCaisoV1 payload) throws RCINTApplicationException {
    	resourceOutageExecutorService.submit(()->{
    	String mrids =""; 
    		try {
    			mrids = payload.getDomainObject().getMessagePayload().getRegisteredGenerators().stream().map(e ->e.getMRID()).collect(Collectors.joining(", "));
    			logger.info("received availability outage -> " + mrids);
				availabilityResultsService.processAsync(payload.getDomainObject());
    	}catch (Exception e) {
			logger.error("Error occoured processing availability outage -> " + mrids, e);
		}	
    	
    	});
    	return true;
    }
    
}
