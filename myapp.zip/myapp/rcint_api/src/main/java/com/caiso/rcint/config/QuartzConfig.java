/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: sgautam $
 */
package com.caiso.rcint.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.caiso.soa.framework.configuration.CAISOServiceConfiguration;

/**
 * This configuration defines JMS related settings.
 *
 * @author gselvara
 *
 */
@Configuration
public class QuartzConfig extends CAISOServiceConfiguration{

    @Value("${rcint.quartz.autostart:true}")
    private boolean autoStart;

    /**
     * <p>
     * If quartz job is initialized by the plugin, by default, it will auto
     * start. This bean indicate whether the quartz job should be auto started.
     * </p>
     * <p>
     * This is optional. Default to be true.
     * </p>
     * 
     * @return
     */
    @Bean(name = "quartzAutoStart")
    public Boolean autoStartQuartz() {
        return autoStart;
    }

    /**
     * <p>
     * Defines the data source for quartz which is mapped from the attribute
     * spring.rcint.datasource in the property file.
     * </p>
     * <p>
     * This is optional. If defined, the quartz will be initialized by the
     * plugin.
     * </p>
     * 
     * @return
     */
    @Bean(name = "quartzDS")
    @ConfigurationProperties(prefix = "spring.rcint.datasource")
    public DataSource quartzDS() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean(name="quartzProperty")
    public Resource qtzProperty() {
        return new ClassPathResource("quartz.properties");
    }

}
