/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Dec 14, 2016 2:29:59 PM
 * Project: caiso-rcint_api
 * File: RcIntApiException.java
 */
package com.caiso.rcint.exception;

/**
 * This is the top level exception that will be thrown out of RCINT Api. All other exceptions should be a subclass of this.
 * @author gselvaratnam
 *
 */
public class RCINTApplicationException extends Exception {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = 2904895807734715869L;

    /**
     * 
     */
    public RCINTApplicationException() {
        super();
    }

    /**
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public RCINTApplicationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * @param message
     * @param cause
     */
    public RCINTApplicationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message
     */
    public RCINTApplicationException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public RCINTApplicationException(Throwable cause) {
        super(cause);
    }
}
