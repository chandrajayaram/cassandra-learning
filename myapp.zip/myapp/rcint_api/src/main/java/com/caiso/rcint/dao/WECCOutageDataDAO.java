/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 17, 2017 10:00:46 AM
 * Project: caiso-rcint_api
 * File: WECCOutageDataDAO.java
 */
package com.caiso.rcint.dao;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

/**
 * @author gselvaratnam
 *
 */
public interface WECCOutageDataDAO {

    void saveWECCOutageData(Map<String, Object> params);

    void updateWECCOutageData(String outageId, long payloadId, String outageType, String outageStatus);

    void updateAuthPayloadIdForWECCOutageData(long payloadId, long ackPayloadId);

    List<WECCOutageData> findWECCOutageDataByWeccOutageId(String weccOutageId);

    String findWeccOutageId(String mrid, int version);

    void updateWECCOutageData(String weccOutageStatus, String weccOutageType, Long   oid);

	String findWECCOutageType(String omsId, BigInteger omsVersion, String outageType);
    
}