/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
@Entity
@Table(name = "RC_PROCESS_LOG")
public class RCProcessLog implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    @Id
    @SequenceGenerator(name = "RC_PROCESS_LOG_ID_GENERATOR", sequenceName = "RC_PROCESS_LOG_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RC_PROCESS_LOG_ID_GENERATOR")
    @Column(name = "ID", nullable = false)
    private Long            id;

    @Column(name = "EVENT_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date              eventTime;

    @Column(name = "EVENT_TYPE")
    private String            eventType;

    @Column(name = "REF_ID")
    private String            refId;

    @Column(name = "SOURCE_HOST")
    private String            sourceHost;

    @Column(name = "SERVICE_NAME")
    private String            serviceName;

    @Column(name = "PROCESS_NAME")
    private String            processName;

    @Column(name = "DESCRIPTION")
    private String            description;

    @Column(name = "EXCEPTION")
    private String            exceptionMessage;

    @Column(name = "STACK_TRACE")
    private String            stackTrace;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the eventTime
     */
    public Date getEventTime() {
        return eventTime;
    }

    /**
     * @param eventTime the eventTime to set
     */
    public void setEventTime(Date eventTime) {
        this.eventTime = eventTime;
    }

    /**
     * @return the eventType
     */
    public String getEventType() {
        return eventType;
    }

    /**
     * @param eventType the eventType to set
     */
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    /**
     * @return the refId
     */
    public String getRefId() {
        return refId;
    }

    /**
     * @param refId the refId to set
     */
    public void setRefId(String refId) {
        this.refId = refId;
    }

    /**
     * @return the sourceHost
     */
    public String getSourceHost() {
        return sourceHost;
    }

    /**
     * @param sourceHost the sourceHost to set
     */
    public void setSourceHost(String sourceHost) {
        this.sourceHost = sourceHost;
    }

    /**
     * @return the serviceName
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * @param serviceName the serviceName to set
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    /**
     * @return the processName
     */
    public String getProcessName() {
        return processName;
    }

    /**
     * @param processName the processName to set
     */
    public void setProcessName(String processName) {
        this.processName = processName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the exceptionMessage
     */
    public String getExceptionMessage() {
        return exceptionMessage;
    }

    /**
     * @param exceptionMessage the exceptionMessage to set
     */
    public void setExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    /**
     * @return the stackTrace
     */
    public String getStackTrace() {
        return stackTrace;
    }

    /**
     * @param stackTrace the stackTrace to set
     */
    public void setStackTrace(String stackTrace) {
        this.stackTrace = stackTrace;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final RCProcessLog other = (RCProcessLog) obj;
        return Objects.equals(this.id, other.id) && Objects.equals(this.eventTime, other.eventTime) && Objects.equals(this.eventType, other.eventType)
                && Objects.equals(this.refId, other.refId) && Objects.equals(this.sourceHost, other.sourceHost)
                && Objects.equals(this.serviceName, other.serviceName) && Objects.equals(this.processName, other.processName)
                && Objects.equals(this.description, other.description) && Objects.equals(this.exceptionMessage, other.exceptionMessage)
                && Objects.equals(this.stackTrace, other.stackTrace);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.description, this.eventTime, this.eventType, this.exceptionMessage, this.processName, this.refId, this.serviceName,
                this.sourceHost, this.stackTrace);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
