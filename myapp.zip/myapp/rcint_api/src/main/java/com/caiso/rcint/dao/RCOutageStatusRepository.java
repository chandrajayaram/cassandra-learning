/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 20, 2017 2:26:30 PM
 * Project: caiso-rcint_api
 * File: RCOutageStatusRepository.java
 */
package com.caiso.rcint.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.entity.RCOutageStatus;

/**
 * @author gselvaratnam
 *
 */
@Repository
public interface RCOutageStatusRepository extends JpaRepository<RCOutageStatus, Long> {

    @Query(value = "SELECT * FROM RCINT_MSTR.RC_OUTAGE_STATUS WHERE ENABLED='Y' ORDER BY STATUS", nativeQuery = true)
    public List<RCOutageStatus> findAllRCOutageStatuses();
}
