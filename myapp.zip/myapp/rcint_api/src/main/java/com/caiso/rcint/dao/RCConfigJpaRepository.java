/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 13, 2017 3:11:01 PM
 * Project: caiso-rcint_api
 * File: RCConfigDao.java
 */
package com.caiso.rcint.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.entity.RCConfig;


/**
 * @author gselvaratnam
 *
 */
@Repository
public interface RCConfigJpaRepository extends JpaRepository<RCConfig, Long> {

    public RCConfig findByProperty(String property);
}
