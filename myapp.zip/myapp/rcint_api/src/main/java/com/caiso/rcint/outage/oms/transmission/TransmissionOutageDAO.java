package com.caiso.rcint.outage.oms.transmission;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.rcint.dao.MessagePayloadDAOImpl;
import com.caiso.rcint.domain.TransmissionOutageWrapper;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.soa.framework.utils.CAISOUtils;
import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.transmissionoutageresultscaiso_v2.MessageHeader;
import com.caiso.soa.transmissionoutageresultscaiso_v2.MessagePayload;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutage;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

@Repository
public class TransmissionOutageDAO {

	public static final Logger logger = LoggerFactory.getLogger(TransmissionOutageDAO.class);

	private TransmissionOutageResultSetExtractor resultSetExtractor = new TransmissionOutageResultSetExtractor();

	@Autowired
	private MessagePayloadDAOImpl messagePayloadDAO;
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public Map<Long, TransmissionOutage> createTORTransmissionOutage(TransmissionOutageResultsCaiso transOutageResults)
			throws RCINTApplicationException {
		logger.info("Creating tranmission outage");
		MessageHeader header = transOutageResults.getMessageHeader();
		long messageId = messagePayloadDAO.createMessageHeader(header.getTimeDate(), header.getSource(),
				header.getVersion(), "TRANSMISSION");
		Map<Long, TransmissionOutage> outageMap = new HashMap<>();
		TransmissionOutageWrapper wrapper;
		for (TransmissionOutage outage : transOutageResults.getMessagePayload().getTransmissionOutages()) {
			wrapper = new TransmissionOutageWrapper();
			wrapper.setTransmissionOutage(outage);
			long id = messagePayloadDAO.createMessagePayload(wrapper, messageId, outage.getMRID(),
					outage.getVersionID().longValue(), null, null);
			outageMap.put(id, outage);
		}
		return outageMap;
	}

	public TransmissionOutageResultsCaiso getTransmissionOutagePayload(long oid) {
		return messagePayloadDAO.getOutagePayload(oid, resultSetExtractor);
	}

	private class TransmissionOutageResultSetExtractor implements ResultSetExtractor<TransmissionOutageResultsCaiso> {
		@Override
		public TransmissionOutageResultsCaiso extractData(ResultSet rs) throws SQLException  {
			while (rs.next()) {
				TransmissionOutageResultsCaiso transmissionOutage = new TransmissionOutageResultsCaiso();
				MessageHeader header = new MessageHeader();
				transmissionOutage.setMessageHeader(header);
				MessagePayload payload = new MessagePayload();
				transmissionOutage.setMessagePayload(payload);
				GregorianCalendar c = new GregorianCalendar();
				c.setTime(new Date(rs.getTimestamp("TIME_DATE").getTime()));
				XMLGregorianCalendar date2;
				try {
					date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
					header.setTimeDate(date2);
					header.setSource(rs.getString("SOURCE"));
					header.setVersion(rs.getString("VERSION"));
					byte[] compressedData = rs.getBytes("PAYLOAD");
					ByteArrayOutputStream bytes = CAISOUtils.decompressBase64(compressedData);
					TransmissionOutageWrapper outageWrapper = (TransmissionOutageWrapper) SOAPUtils
							.unmarshal(TransmissionOutageWrapper.class.getPackage().getName(), bytes.toString());
					payload.getTransmissionOutages().add(outageWrapper.getTransmissionOutage());
				} catch (DatatypeConfigurationException | JAXBException | IOException e) {
					logger.error("Error occoured while retrieving transmission outage payload");
					throw new RCINTRuntimeException(e);
				}

				return transmissionOutage;
			}
			return null;
		}

	}
}
