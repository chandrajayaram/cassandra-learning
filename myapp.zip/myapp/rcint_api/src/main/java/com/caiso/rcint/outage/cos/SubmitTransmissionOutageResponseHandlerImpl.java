/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 7, 2017 11:45:17 AM
 * Project: rcint-app
 * File: SubmitTransmissionOutageResponseHandlerImpl.java
 */
package com.caiso.rcint.outage.cos;

import java.util.Date;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.caiso.rcint.dao.RCPublishPayloadRepository;
import com.caiso.rcint.domain.RCPublishInfoType;
import com.caiso.rcint.domain.RCPublishPayloadType;
import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.exception.RCINTContinueProcessingException;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.service.RCProcessLogService;
import com.caiso.rcint.service.SaveInNewTransactionService;
import com.caiso.rcint.service.WebServiceCallOutService;
import com.caiso.rcint.util.Utils;
import com.caiso.soa.outagestandardoutput_v1.OutageStandardOutput;
import com.caiso.soa.outagestandardoutput_v1.OutageSubmitStatusKind;
import com.caiso.soa.transmissionoutagedata_v1.TransmissionOutageData;

/**
 * @author gselvaratnam
 *
 */
@Service
public class SubmitTransmissionOutageResponseHandlerImpl extends BaseCosSubmitTransmissionOutageProcessor implements SubmitTransmissionOutageResponseHandler {
    private static final Logger           logger                        = LoggerFactory.getLogger(SubmitTransmissionOutageResponseHandlerImpl.class);

    public static final String            LOG_EVT_TYPE_PROCESS_CONTINUE = "PROCESS_CONTINUE";

    @Autowired
    protected WebServiceCallOutService    webServiceCallOutService;

    @Autowired
    protected SaveInNewTransactionService saveInNewTransactionService;

    @Autowired
    protected RCProcessLogService         rcProcessLogService;

    @Autowired
    private RCPublishPayloadRepository    rcPublishPayloadRepository;

    /*
     * (non-Javadoc)
     * 
     * @see com.caiso.rcint.outage.oms.service.
     * SubmitTransmissionOutageResponseHandler#handleResponse(com.caiso.soa.
     * transmissionoutagedata_v2.TransmissionOutageData, java.lang.String,
     * java.lang.Long)
     */
    @Override
    public String handleResponse(TransmissionOutageData omsOutageDataObject, String logRefId, Long payloadId) throws JAXBException {
        String response = null;
        try {
            String omsOutagePayload = Utils.marshallToString(omsOutageDataObject, omsOutageDataObject);

            if (omsOutagePayload != null && !(omsOutagePayload.trim().equals("error"))) {

                rcProcessLogService.createLogEntry(LOG_EVT_TYPE_PROCESS_CONTINUE, logRefId, "SubmitTransmissionOutageResponseHandlerImpl", "handleResponse",
                        "Calling OMS SubmitTransmissionOutage_v1");

                String omsTransId = getTransmisionOutageId(omsOutageDataObject);
                String soapRequestXml = webServiceCallOutService.getOmsSubmitTransmissionOutage_v1SoapXMLString();
                String submitTransOutResponse = null;
                if (StringUtils.isEmpty(omsTransId)) {
                    submitTransOutResponse = webServiceCallOutService.callOmsWebService_soap_11(soapRequestXml, omsOutagePayload, RCPublishInfoType.OMS_TRANS_OUTAGE);
                } else {
                    submitTransOutResponse = webServiceCallOutService.callOmsWebService_soap_11(soapRequestXml, omsOutagePayload,
                            RCPublishInfoType.OMS_TRANS_OUTAGE_CHANGE_REQUEST);
                }

                OutageStandardOutput outageStandardOutput = null;
                outageStandardOutput = getOutageStandardOutput(submitTransOutResponse);
                String result = findEventResult(outageStandardOutput);
                if ("Failure".equalsIgnoreCase(result)) {
                    OutageSubmitStatusKind submitStatus = findOutageSubmitStatusKind(outageStandardOutput);
                    if (OutageSubmitStatusKind.REJECTED.equals(submitStatus)) {
                        handleSubmitTransmissionOutageRejection(outageStandardOutput);
                    } else {
                        throw new RCINTContinueProcessingException(Utils.marshallToString(outageStandardOutput, outageStandardOutput));
                    }
                } else {
                    OutageSubmitStatusKind submitStatus = findOutageSubmitStatusKind(outageStandardOutput);
                    if (OutageSubmitStatusKind.ACCEPTED.equals(submitStatus)) {

                        String mRID = findEventLogOutageMRID(outageStandardOutput);
                        response = mRID;
                        String mktOrgOutageID = findEventLogOutageMktOrgOutageID(outageStandardOutput);

                        saveInNewTransactionService.updateRCOutageDataOmsOutageId(mRID, payloadId);
                        String acceptedStr = "ACCEPTED: Published WECC outage[" + mktOrgOutageID + "] as OMS outage [" + mRID + "]";
                        saveInNewTransactionService.updateStatusAndResponseByPayloadId(RCPublishPayloadType.SUCCESS.name(), acceptedStr, payloadId);

                    } else if (OutageSubmitStatusKind.REJECTED.equals(submitStatus)) {
                        handleSubmitTransmissionOutageRejection(outageStandardOutput);
                    } else {
                        throw new RCINTContinueProcessingException("Unhandled SubmitTransmissionOutage_v1 : " + submitTransOutResponse);
                    }
                }
            }
        } catch (RCINTRuntimeException rcintRuntimeException) {
            handleException(rcintRuntimeException, payloadId);
            throw rcintRuntimeException;
        } catch (Exception exception) {
            handleException(exception, payloadId);
            throw new RCINTRuntimeException(exception);
        }
        return response;
    }

    private void handleException(Exception exception, Long payloadId) {

        RCPublishPayload rcPublishPayload = rcPublishPayloadRepository.findOne(payloadId);

        if (rcPublishPayload != null) {

            String response = Utils.substring(getExceptionMessage(exception), 1000);
            if (response.contains(RCPublishPayloadType.REJECTED.name())) {
                rcPublishPayload.setStatus(RCPublishPayloadType.REJECTED.name());
                rcPublishPayload.setUpdatedDate(new Date());
            } else {
                rcPublishPayload.setStatus(RCPublishPayloadType.ERROR.name());
                response = Utils.substring(getExceptionMessage(exception), 1000);
                if (StringUtils.isEmpty(response)) {
                    response = Utils.substring(Utils.parseStackTrace(exception), 1000);
                }
                rcPublishPayload.setUpdatedDate(new Date());
            }

            rcPublishPayload.setResponse(response);

            saveInNewTransactionService.createOrUpdateRCPublishPayload(rcPublishPayload);
        }
    }

    private String getExceptionMessage(Exception exception) {
        String response = exception.getMessage();
        if (StringUtils.isEmpty(response)) {
            response = "Unexpected Error";
        }

        if(response.length() > 1000) {
            response = response.substring(0, 1000);
        }

        return response;
    }
}
