/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 10, 2017 11:49:06 AM
 * Project: caiso-rcint_api
 * File: SOAPMessageTemplate.java
 */
package com.caiso.rcint.util;

import java.util.Map;

import javax.xml.soap.SOAPMessage;

import org.apache.http.client.HttpClient;

import com.caiso.rcint.exception.RCINTApplicationException;

/**
 * @author gselvaratnam
 *
 */
public interface SOAPMessageTemplate {

    SOAPMessage sendMessage(String endPointUrl, String soapAction, SOAPMessage soapRequest, HttpClient httpClient, int retryCount)
            throws RCINTApplicationException;

    String sendMessage(String endPointUrl, String requestXML, Map<String, String> httpHeaders, HttpClient httpClient, int retryCount) throws RCINTApplicationException;

}