package com.caiso.rcint.outage.oms.availability;

import static com.caiso.rcint.util.Utils.xmlGregorianCalendarToSqlTimeStampFn;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.dao.MessagePayloadDAO;
import com.caiso.rcint.domain.AvailabilityResultsWrapper;
import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.soa.availabilityresultscaiso_v1.Availability;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;
import com.caiso.soa.availabilityresultscaiso_v1.MessageHeader;
import com.caiso.soa.availabilityresultscaiso_v1.MessagePayload;
import com.caiso.soa.availabilityresultscaiso_v1.RegisteredGenerator;
import com.caiso.soa.framework.utils.CAISOUtils;
import com.caiso.soa.framework.utils.SOAPUtils;

@Repository
public class AvailabilityResultsDAO {
	public static final Logger logger = LoggerFactory.getLogger(AvailabilityResultsDAO.class);

	private static final String INSERT_RC_OMS_AVAILABILITY_DATA = "INSERT INTO RC_OMS_AVAILABILITY_PERIOD(OID, MRID, PERIOD_START, PERIOD_END) VALUES(:OID, :MRID, :PERIOD_START, :PERIOD_END)";
	private static final String SELECT_RC_OMS_OID = "SELECT DISTINCT OID FROM RC_OMS_AVAILABILITY_PERIOD WHERE MRID= :MRID AND PERIOD_START >= :PERIOD_START AND PERIOD_END <= :PERIOD_END";
	private ResultSetExtractor<AvailabilityResultsCaiso> resultSetExtractor = new AvailabilityResultsCaisoResultSetExtractor();
	@Autowired
	private MessagePayloadDAO messagePayloadDAO;

	@Autowired
	private NamedParameterJdbcTemplate rcintJdbcTemplate;
	
	public Set<String> createAvailabilityResults(AvailabilityResultsCaiso availabilityResultsCaiso, Map<String, AvailabilityResultsWrapper> outageAvailabilityMap) throws RCINTApplicationException {
		logger.info("Creating resource outage");
		MessageHeader header = availabilityResultsCaiso.getMessageHeader();
		long messageId = messagePayloadDAO.createMessageHeader(header.getTimeDate(), header.getSource(), header.getVersion(),"AVAILABILITY");
		
		for(Entry<String,AvailabilityResultsWrapper> entry: outageAvailabilityMap.entrySet()){
			long id = messagePayloadDAO.createMessagePayload(entry.getValue(), messageId,entry.getKey(), 0l,null,null);
			List<MapSqlParameterSource> paramSourceList = new ArrayList<>();

			for (RegisteredGenerator registeredGen : entry.getValue().getRegisteredGenerators()) {
				for (Availability availability : registeredGen.getOutagedRegisteredResource().getAvailabilities()) {
					MapSqlParameterSource paramSource = new MapSqlParameterSource();
					paramSource.addValue("OID", id);
					paramSource.addValue("MRID", entry.getKey());
					paramSource.addValue("PERIOD_START", xmlGregorianCalendarToSqlTimeStampFn.apply(availability.getPeriod().getStart()));
					paramSource.addValue("PERIOD_END", xmlGregorianCalendarToSqlTimeStampFn.apply(availability.getPeriod().getEnd()));
					paramSourceList.add(paramSource);
				}
			}			
			MapSqlParameterSource [] paramSourceArray = new MapSqlParameterSource[paramSourceList.size()];
			paramSourceList.toArray(paramSourceArray);
			rcintJdbcTemplate.batchUpdate(INSERT_RC_OMS_AVAILABILITY_DATA, paramSourceArray);
		}
		return outageAvailabilityMap.keySet();
	}

	public AvailabilityResultsCaiso getAvailabilityResults(long oid){
		return messagePayloadDAO.getOutagePayload(oid,resultSetExtractor);
	}
	public AvailabilityResultsCaiso getAvailabilityResults(String mrid, XMLGregorianCalendar start, XMLGregorianCalendar end) throws RCINTApplicationException{
		String payloadXML = messagePayloadDAO.getOutagePayload(mrid, start, end, "AVAILABILITY");
		if(payloadXML!=null){
			AvailabilityResultsCaiso resourceOutage = new AvailabilityResultsCaiso();
			MessagePayload payload = new MessagePayload();
			resourceOutage.setMessagePayload(payload);
			AvailabilityResultsWrapper outageWrapper;
			try {
				outageWrapper = (AvailabilityResultsWrapper) SOAPUtils.unmarshal(AvailabilityResultsWrapper.class.getPackage().getName(), payloadXML);
				payload.getRegisteredGenerators().addAll(outageWrapper.getRegisteredGenerators());
				return resourceOutage;
			} catch (JAXBException e) {
				logger.error("error accoured with retrieving the availability results payload",e);
				throw new RCINTRuntimeException(e);
			}
		}
		return null;
	}	
	
	public List<RegisteredGenerator> getAvailabilityRegisteredResource(String mrid, XMLGregorianCalendar start, XMLGregorianCalendar end) throws RCINTApplicationException{

		
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("MRID", mrid);
		paramSource.addValue("PERIOD_START", xmlGregorianCalendarToSqlTimeStampFn.apply(start));
		paramSource.addValue("PERIOD_END", xmlGregorianCalendarToSqlTimeStampFn.apply(end));

		
		Set<Long> dataSet = rcintJdbcTemplate.query(SELECT_RC_OMS_OID, paramSource, new ResultSetExtractor<Set<Long>>() {
			@Override
			public Set<Long> extractData(ResultSet rs) {
				Set<Long> oids = new HashSet<>();
				try {
					while (rs.next()) {
						oids.add(rs.getLong("OID"));
					} 
				} catch (SQLException e) {
						throw new RCINTRuntimeException(e);
				}
				return oids;
			}
		});
		
		if(!dataSet.isEmpty()){
			List<String> payloadXMLs = messagePayloadDAO.getOutagePayloadList(dataSet);
			if (payloadXMLs != null && !payloadXMLs.isEmpty()) {
				MessagePayload payload = new MessagePayload();
				try {
					for (String payloadXML : payloadXMLs) {
						AvailabilityResultsWrapper outageWrapper = (AvailabilityResultsWrapper) SOAPUtils
								.unmarshal(AvailabilityResultsWrapper.class.getPackage().getName(), payloadXML);
						payload.getRegisteredGenerators().addAll(outageWrapper.getRegisteredGenerators());
					}
					return payload.getRegisteredGenerators();
				} catch (JAXBException e) {
					logger.error("error accoured with retrieving the availability results payload",e);
					throw new RCINTRuntimeException(e);
				}
			}
		}
		return new ArrayList<>();
	}	
	
	private class  AvailabilityResultsCaisoResultSetExtractor implements ResultSetExtractor<AvailabilityResultsCaiso>{

		@Override
		public AvailabilityResultsCaiso extractData(ResultSet rs) throws SQLException {
			while (rs.next()) {
				AvailabilityResultsCaiso resourceOutage = new AvailabilityResultsCaiso();
				MessageHeader header = new MessageHeader();
				resourceOutage.setMessageHeader(header);
				MessagePayload payload = new MessagePayload();
				resourceOutage.setMessagePayload(payload);
				GregorianCalendar c = new GregorianCalendar();
				c.setTime(new Date(rs.getTimestamp("TIME_DATE").getTime()));
				XMLGregorianCalendar date2;
				try {
					date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
					header.setTimeDate(date2);
					header.setSource(rs.getString("SOURCE"));
					header.setVersion(rs.getString("VERSION"));
					byte [] compressedData = rs.getBytes("PAYLOAD");
					ByteArrayOutputStream bytes = CAISOUtils.decompressBase64(compressedData);
					AvailabilityResultsWrapper outageWrapper = (AvailabilityResultsWrapper) SOAPUtils.unmarshal(AvailabilityResultsWrapper.class.getPackage().getName(), bytes.toString());
					payload.getRegisteredGenerators().addAll(outageWrapper.getRegisteredGenerators());
				} catch (DatatypeConfigurationException | JAXBException  | IOException e) {
					logger.error("error accoured with retrieving the result set",e);
					throw new RCINTRuntimeException(e);
				}
				return resourceOutage;
			}
			return null;
		}
		
	}
	
	
	
}
