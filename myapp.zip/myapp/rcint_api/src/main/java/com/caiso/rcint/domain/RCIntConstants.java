/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 6, 2017 3:47:19 PM
 * Project: caiso-rcint_api
 * File: RCIntConstants.java
 */
package com.caiso.rcint.domain;

import java.util.TimeZone;

/**
 * @author gselvaratnam
 *
 */
public final class RCIntConstants {

    public static final TimeZone DEFAULT_TIME_ZONE = TimeZone.getTimeZone("America/Los_Angeles");
    public static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");

    public static final String CONTROL_CENTER = "ControlCenter";
    public static final String CONTROL_CENTER_NAME = "CONTROL_CENTER_NAME";

    public static final String TCC = "TCC";
    public static final String WILDCARD_CC = "?CC";

    public static final String SWITCHING_START = "SWITCHING_START";

    public static final String SQL_CONTROL_AREA_QUERY = "controlAreasQuery";
    public static final String SQL_OUTAGE_STATUS_QUERY = "outageStatusQuery";

    public static final String ASC = "ASC";
    public static final String DESC = "DESC";

    public static final String SORT_BY = "SWITCHING_START";

    public static final String STATUS = "STATUS";

    public static final String UNKNOWN = "UNKNOWN";
    public static final String DURATION = "DURATION";
    public static final String OMS_SOURCE = "RCINT";
    public static final String OMS_VERSION = "1.0";
    public static final String YES = "YES";
    public static final String NO = "NO";
    public static final String OPEN = "open";
    public static final String PRIMARY_CAUSE_CODE = "UNKNOWN_P";
    public static final String SECONDARY_CAUSE_CODE = "OTHER_S";
    public static final String OTHER = "OTHER";
    
}
