package com.caiso.rcint.outage.oms.payload;

import com.caiso.soa.framework.payload.DomainPayload;
import com.caiso.soa.transmissionoutageresultscaiso_v2.TransmissionOutageResultsCaiso;

public class ReceiveTransmissionOutageResultsCaisoV2 extends DomainPayload<TransmissionOutageResultsCaiso> {

}
