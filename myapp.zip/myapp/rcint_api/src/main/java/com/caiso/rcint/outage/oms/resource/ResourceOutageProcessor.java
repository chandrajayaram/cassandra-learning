package com.caiso.rcint.outage.oms.resource;

import com.caiso.rcint.exception.RCINTApplicationException;
import com.caiso.soa.resourceoutageresultscaiso_v2.ResourceOutageResultsCaiso;

public interface ResourceOutageProcessor {
	public void processAsync(ResourceOutageResultsCaiso resourceOutageResults) throws RCINTApplicationException;
}
