/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 6, 2017 3:36:31 PM
 * Project: rcint-app
 * File: SubmitPayloadControllerImpl.java
 */
package com.caiso.rcint.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.caiso.rcint.dao.RCPublishPayloadDAO;
import com.caiso.rcint.util.Utils;

/**
 * @author gselvaratnam
 *
 */
@RestController
public class GetCOSPayload {
    private static final Logger logger = LoggerFactory.getLogger(GetCOSPayload.class);

	@Autowired
	private RCPublishPayloadDAO rcPublishPayloadDAO;
	

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.caiso.rcint.controller.SubmitPayloadController#resendPayload(java.
     * lang.String)
     */
    
    @RequestMapping(path = "/cosPayload/{payloadType}/{mrid}/{version}", method = RequestMethod.GET)
    public String retrieveCosPayload(@PathVariable(value = "payloadType")String payloadType, @PathVariable(value = "mrid")String mrid, @PathVariable(value = "version")String version) {
        try {
        	byte[] data = rcPublishPayloadDAO.retrievePayloadForMRID(payloadType, mrid, version);
            String xmlStr = Utils.decompress(data);
            return xmlStr;
            
        } catch (Exception e) {
            logger.error("Unexpected Error", e);
            return "Exception occured : " + e.getMessage();
        } finally {
            logger.info("End::GetCOSPayload.retrieveCosPayload");
        }
    }
}
