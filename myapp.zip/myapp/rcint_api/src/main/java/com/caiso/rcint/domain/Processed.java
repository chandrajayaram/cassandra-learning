package com.caiso.rcint.domain;

public enum Processed {
	NO('N'), YES('Y'),FAILED('F');
	private char value;
	
	private Processed(char value){
		this.value= value;
	}
	public String value() {
		return String.valueOf(value);
	}
	public static Processed fromValue(String v) {
		for(Processed processed:Processed.values()){
			if(processed.value == v.charAt(0)){
				return processed;
			}
		}
		return null;
	}
}
