package com.caiso.rcint;

import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.web.SpringBootServletInitializer;

import com.caiso.rcint.domain.RCIntConstants;

@SpringBootApplication
public class Application  extends SpringBootServletInitializer {
    private static final Logger logger = LoggerFactory.getLogger(Application.class);
	
	public static void main(String[] args) {
	    logger.info("BEGIN::Application.main");
		
	    System.setProperty("javax.xml.soap.MessageFactory","com.sun.xml.internal.messaging.saaj.soap.ver1_2.SOAPMessageFactory1_2Impl");

	    TimeZone zone = RCIntConstants.UTC_TIME_ZONE;

        logger.info("JVM user time zone is defined: {}", TimeZone.getDefault().getID());

        SpringApplication.run(Application.class, args);

        logger.info("END::Application.main");
    }
}
