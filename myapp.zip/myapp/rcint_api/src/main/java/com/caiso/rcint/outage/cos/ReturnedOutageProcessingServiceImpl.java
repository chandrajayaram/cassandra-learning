/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 27, 2017 12:06:58 PM
 * Project: rcint-app
 * File: ReturnedOutageProcessingServiceImpl.java
 */
package com.caiso.rcint.outage.cos;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.caiso.rcint.dao.RCOutageDataRepository;
import com.caiso.rcint.dao.WECCOutageData;
import com.caiso.rcint.dao.WECCOutageDataDAO;
import com.caiso.rcint.domain.CosOutageStatusType;
import com.caiso.rcint.domain.RCPublishInfoType;
import com.caiso.rcint.domain.RCPublishPayloadType;
import com.caiso.rcint.entity.RCOutage;
import com.caiso.rcint.entity.RCOutageData;
import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.entity.WeccOutageRegAuthUpdate;
import com.caiso.rcint.exception.RCINTContinueProcessingException;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.service.RCProcessLogService;
import com.caiso.rcint.service.SaveInNewTransactionService;
import com.caiso.rcint.service.WebServiceCallOutService;
import com.caiso.rcint.util.DateUtil;

import ca.equinox.crow.ReturnedOutage;

/**
 * @author gselvaratnam
 *
 */
@Service
public class ReturnedOutageProcessingServiceImpl extends BaseCosCaisoOutageProcessor implements ReturnedOutageProcessingService {

    private static final Logger         logger = LoggerFactory.getLogger(ReturnedOutageProcessingServiceImpl.class);

    public static final String          LOG_EVT_TYPE_PROCESS_CONTINUE = "PROCESS_CONTINUE";

    @Autowired
    private RCOutageDataRepository      rcOutageDataRepository;

    @Autowired
    private WebServiceCallOutService    webServiceCallOutService;

    @Autowired
    private WECCOutageDataDAO           weccOutageDataDAO;

    @Autowired
    private SaveInNewTransactionService saveInNewTransactionService;

    @Autowired
    private RCProcessLogService         rcProcessLogService;

    @Autowired
    private CosSubmitTransmissionOutageService omsSubmitTransmissionOutageService;

    @Autowired
    private ReceiveRegulatoryAuthorityOutageStatusService receiveRegulatoryAuthorityOutageStatusService;

    /*
     * (non-Javadoc)
     * 
     * @see com.caiso.rcint.outage.oms.service.ReturnedOutageProcessingService#
     * processReturnedOutage(java.util.Map, ca.equinox.crow.ReturnedOutage)
     */
    @Override
    public void processReturnedOutage(ReturnedOutage returnedOutage, String logRefId) {
        logger.debug("Begin::ReturnedOutageProcessingServiceImpl::processReturnedOutage");

        rcProcessLogService.createLogEntry(LOG_EVT_TYPE_PROCESS_CONTINUE, logRefId, "ReturnedOutageProcessingServiceImpl", "processReturnedOutage",
                "starting the process");

        try {
            Map<String, String> outageProcessedMap = new HashMap<>();

            String weccOutageNumber = returnedOutage.getOutageNumber();
            String controlArea = parseControlArea(returnedOutage.getOperatedByControlCenters());

            String outageStatus = returnedOutage.getOutageStatus();
            String revisionNumber = String.valueOf(returnedOutage.getRevisionNumber());
            String remotesystemName = returnedOutage.getRemoteSystemName();
            String outageType = returnedOutage.getContinuousDaily();
            String outageStart = returnedOutage.getSwitchingStart();
            String outageEnd = returnedOutage.getRestorationComplete();
            String outageDuration = String.valueOf(returnedOutage.getDuration());
            String outageDurationUnit = returnedOutage.getDurationUnits();

            boolean alreadyProcessed = false;
            if (outageProcessedMap.containsKey(weccOutageNumber)) {
                if (outageProcessedMap.get(weccOutageNumber) != null && outageProcessedMap.get(weccOutageNumber).equalsIgnoreCase(revisionNumber)) {
                    alreadyProcessed = true;
                }
            }
            outageProcessedMap.put(weccOutageNumber, revisionNumber);

            boolean isPacWebOmsOutage = false;
            boolean isCaisoWebOmsOutage = false;
            if (remotesystemName != null && remotesystemName.contains("CAISO") || controlArea.contains("CISO")) {
                isCaisoWebOmsOutage = true;
            } else if (remotesystemName != null && remotesystemName.contains("PAC-COMPASS")) {
                isPacWebOmsOutage = true;
            }

            // RETREIVE RC_OUTAGE_ID FOR THE WECC OUTAGE NUMBER IF EXIST,
            // OTHERWISE CREATE NEW RC_OUTAGE RECORD
            List<WECCOutageData> weccOutageDataList = weccOutageDataDAO.findWECCOutageDataByWeccOutageId(weccOutageNumber);
            boolean bWeccOutageExist = false;
            if (!CollectionUtils.isEmpty(weccOutageDataList)) {
                bWeccOutageExist = true;
            }

            boolean bWeccOutagePublishedToOMS = isWeccOutagePublishedToOMS(weccOutageDataList);

            if (!bWeccOutagePublishedToOMS
                    && (CosOutageStatusType.CANCELLED.name().equalsIgnoreCase(outageStatus) || CosOutageStatusType.DENIED.name().equalsIgnoreCase(outageStatus)
                            || CosOutageStatusType.RECALLED.name().equalsIgnoreCase(outageStatus))) {
                /**
                 * IGNORE CANCELLED OUTAGES IF NOT PREVIOUSLY PUBLISHED TO OMS.
                 * IF THE PREVIOUS VERSION WAS CAPTURED, BUT NOT PUBLISHED, WE
                 * WANT TO IGNORE THE CANCELLATION FOR NOW AND PROCESS IT AT A
                 * LATER TIME WHEN THE PRIOR PAYLOAD PUBLICATION HAS BEEN
                 * RESOLVED.
                 */
                saveInNewTransactionService.updateRCOutageDataAndRCPublishPayloadforCancellation(CosOutageStatusType.CANCELLED, weccOutageNumber,
                        Long.valueOf(revisionNumber));
                throw new RCINTContinueProcessingException("WECC outage has been cancelled." + returnedOutage);

            } else if (!bWeccOutageExist && !StringUtils.isEmpty(controlArea) && !StringUtils.isEmpty(weccOutageNumber)) {
                // CREATE NEW RC_OUTAGE RECORD FOR WECC OUTAGE ID
                RCOutage newRcOutage = new RCOutage();
                newRcOutage.setControlArea(controlArea);
                newRcOutage.setCreatedDate(new Date());
                newRcOutage.setDuration(outageDuration);
                newRcOutage.setDurationUnit(outageDurationUnit);
                newRcOutage.setOutageEnd(outageEnd);
                newRcOutage.setOutageStart(outageStart);
                newRcOutage.setOutageType(outageType);
                newRcOutage.setUpdatedDate(new Date());
                newRcOutage.setWeccOutageId(weccOutageNumber);

                saveInNewTransactionService.saveNewRCOutage(newRcOutage);
            }

            // CHECK IF WECC OUTAGE WITH CHANGE REQUEST NUMBER ALREADY EXIST IN
            // THE DATABASE
            boolean bOutageNewerVersionExist = false;
            List<RCOutageData> rcOutageDataList = rcOutageDataRepository.findByWeccOutageIdAndWeccRevisionNumber(weccOutageNumber,
                    Long.valueOf(revisionNumber));
            if (!CollectionUtils.isEmpty(rcOutageDataList)) {
                bOutageNewerVersionExist = true;
            }

            if (!alreadyProcessed && !bOutageNewerVersionExist && !isCaisoWebOmsOutage && !isPacWebOmsOutage) {
                omsSubmitTransmissionOutageService.processSubmitTransmissionOutage(returnedOutage, weccOutageDataList, bWeccOutagePublishedToOMS, logRefId);
            } else {
                if (bWeccOutageExist) {
                    WECCOutageData weccOutageData = weccOutageDataList.get(0);
                    
                    String weccOutageStatus = weccOutageData.getWeccOutageStatus();
                    String weccOutageType = weccOutageData.getWeccOutageType();

                    if(isEqualStrings(weccOutageStatus, outageStatus) && isEqualStrings(weccOutageType, outageType)) {
                        //Do nothing
                    } else {
                        weccOutageData.setWeccOutageType(outageType);
                        weccOutageData.setWeccOutageStatus(outageStatus);
                        saveInNewTransactionService.updateWECCOutageData(weccOutageStatus, weccOutageType, weccOutageData.getOid());
                        
                        String attachmentXml = webServiceCallOutService.getOmsAttachementRegulatoryAuthorityOutageStatusXMLString(
                                DateUtil.convertToXmlGregorianCalendar(new Date()).toString(), weccOutageData.getOmsOutageId(), revisionNumber, "SOME ERROR", weccOutageNumber, "PENDING");

                        Map<String, Object> response = receiveRegulatoryAuthorityOutageStatusService.executeService(attachmentXml, null);

                        WeccOutageRegAuthUpdate weccOutageRegAuthUpdate = new WeccOutageRegAuthUpdate();
                        weccOutageRegAuthUpdate.setCreatedDate(new Date());
                        weccOutageRegAuthUpdate.setOmsOutageId(weccOutageData.getOmsOutageId());
                        weccOutageRegAuthUpdate.setOmsOutageVersion(weccOutageData.getOmsOutageVersion());
                        weccOutageRegAuthUpdate.setPayloadId((Long) response.get(ReceiveRegulatoryAuthorityOutageStatusService.EXECUTE_SERVICE_PAYLOAD_ID));
                        weccOutageRegAuthUpdate.setUpdatedDate(new Date());
                        weccOutageRegAuthUpdate.setWeccOutageId(weccOutageData.getWeccOutageId());
                        saveInNewTransactionService.createOrUpdateWeccOutageRegAuthUpdate(weccOutageRegAuthUpdate);
                    }
                }
            }
        } catch (RCINTRuntimeException rcintRuntimeException) {
            throw rcintRuntimeException;
        } catch (Exception exception) {
            throw new RCINTRuntimeException(exception);
        }

        rcProcessLogService.createLogEntry(LOG_EVT_TYPE_PROCESS_CONTINUE, logRefId, "ReturnedOutageProcessingServiceImpl", "processReturnedOutage",
                "ending the process");

        logger.debug("End::ReturnedOutageProcessingServiceImpl::processReturnedOutage");
    }

    private boolean isEqualStrings(String firstStr, String secondStr) {
        boolean response = false;
        if(!StringUtils.isEmpty(firstStr) && !StringUtils.isEmpty(secondStr)) {
            if(firstStr.equalsIgnoreCase(secondStr)) {
                response = true;
            }
        }
        return response;
    }
}
