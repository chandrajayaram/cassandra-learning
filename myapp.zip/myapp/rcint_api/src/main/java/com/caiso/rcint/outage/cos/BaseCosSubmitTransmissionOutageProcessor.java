/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 3, 2017 12:45:43 PM
 * Project: rcint-app
 * File: BaseCosSubmitTransmissionOutageProcessor.java
 */
package com.caiso.rcint.outage.cos;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.caiso.rcint.dao.WECCOutageData;
import com.caiso.rcint.domain.EquipmentSwitchType;
import com.caiso.rcint.domain.OutageStatusType;
import com.caiso.rcint.domain.PayloadType;
import com.caiso.rcint.domain.RCIntConstants;
import com.caiso.rcint.domain.RCRdfIdMap;
import com.caiso.rcint.exception.RCINTContinueProcessingException;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.service.CosToRdfIdService;
import com.caiso.rcint.service.RCProcessLogService;
import com.caiso.rcint.util.DateUtil;
import com.caiso.soa.outagestandardoutput_v1.OutageResultKind;
import com.caiso.soa.outagestandardoutput_v1.OutageStandardOutput;
import com.caiso.soa.outagestandardoutput_v1.OutageSubmitStatusKind;
import com.caiso.soa.transmissionoutagedata_v1.EmergencyReturnTimeKind;
import com.caiso.soa.transmissionoutagedata_v1.EquipmentOutage;
import com.caiso.soa.transmissionoutagedata_v1.OperatingParticipant;
import com.caiso.soa.transmissionoutagedata_v1.Outage;
import com.caiso.soa.transmissionoutagedata_v1.OutageCause;
import com.caiso.soa.transmissionoutagedata_v1.OutageChangeRequest;
import com.caiso.soa.transmissionoutagedata_v1.OutageChangeRequestAction;
import com.caiso.soa.transmissionoutagedata_v1.OutageChangeRequestActionReason;
import com.caiso.soa.transmissionoutagedata_v1.OutagedEquipment;
import com.caiso.soa.transmissionoutagedata_v1.Switch;
import com.caiso.soa.transmissionoutagedata_v1.SwitchState;
import com.caiso.soa.transmissionoutagedata_v1.SwitchingOperation;
import com.caiso.soa.transmissionoutagedata_v1.SwitchingOperation.NewStatePeriod;
import com.caiso.soa.transmissionoutagedata_v1.TransmissionOutage;
import com.caiso.soa.transmissionoutagedata_v1.TransmissionOutageData;
import com.caiso.soa.transmissionoutagedata_v1.Work;
import com.caiso.soa.transmissionoutagedata_v1.WorkKind;
import com.caiso.soa.transmissionoutagedata_v1.YesNo;

import ca.equinox.crow.ArrayOfErrorCode;
import ca.equinox.crow.ArrayOfRequestedEquipment;
import ca.equinox.crow.ErrorCode;
import ca.equinox.crow.OutageSchedule;
import ca.equinox.crow.OutageScheduleLoadItemResponse;
import ca.equinox.crow.RequestedEquipment;
import ca.equinox.crow.ReturnedOutage;

/**
 * @author gselvaratnam
 *
 */
public class BaseCosSubmitTransmissionOutageProcessor {

    private static final String                        LOG_EVT_TYPE_PROCESS_CONTINUE = "PROCESS_CONTINUE";

    @Autowired
    private CosToRdfIdService cosToRdfIdService;

    @Autowired
    protected RCProcessLogService                     rcProcessLogService;

    protected TransmissionOutageData createTransmissionOutageData(ReturnedOutage returnedOutageNode, OutageSchedule outageEquipInfo,
            List<WECCOutageData> weccOutageDataList, StringBuffer equipmentMap, String logRefId) throws Exception {

        boolean isConstraintTypeOOS = false;
        String requestedEquipmentStr = outageEquipInfo.getRequestedEquipmentStr();
        if (outageEquipInfo != null && requestedEquipmentStr != null && requestedEquipmentStr.endsWith("OOS")) {
            isConstraintTypeOOS = true;
            requestedEquipmentStr = outageEquipInfo.getRequestedEquipmentStr();
        }

        if (!isConstraintTypeOOS) {
            String errMsg = "Outage constraint type [" + requestedEquipmentStr + "] is not OOS.  Outage will not be submitted to OMS.";
            throw new RCINTContinueProcessingException(errMsg);
        }

        com.caiso.soa.transmissionoutagedata_v1.ObjectFactory jaxbfactory = new com.caiso.soa.transmissionoutagedata_v1.ObjectFactory();
        TransmissionOutageData transmissionOutageData = jaxbfactory.createTransmissionOutageData();
        TransmissionOutage transmissionOutage = jaxbfactory.createTransmissionOutage();

        com.caiso.soa.transmissionoutagedata_v1.MessagePayload messagePayLoad = jaxbfactory.createMessagePayload();
        List<TransmissionOutage> transmissionOutages = new ArrayList<TransmissionOutage>();

        Outage.EstimatedPeriod estimatedPeriod = jaxbfactory.createOutageEstimatedPeriod();
        estimatedPeriod.setStart(DateUtil.getXMLGregorianCalendarDate(outageEquipInfo.getSwitchingStart()));
        estimatedPeriod.setEnd(DateUtil.getXMLGregorianCalendarDate(outageEquipInfo.getRestorationComplete()));

        transmissionOutage.setEstimatedPeriod(estimatedPeriod);

        String controlArea = parseControlArea(returnedOutageNode.getOperatedByControlCenters()) + ": ";

        String description = RCIntConstants.UNKNOWN;
        if (!StringUtils.isEmpty(outageEquipInfo.getReasonForChange())) {
            description = outageEquipInfo.getReasonForChange();
        }
        description = controlArea + description;

        String omsOutageNumber = (!weccOutageDataList.isEmpty()) ? weccOutageDataList.get(0).getOmsOutageId() : null;

        transmissionOutage.setDescription(description);
        transmissionOutage.setEmergencyReturnTimeType(EmergencyReturnTimeKind.DURATION);
        transmissionOutage.setMktOrgOutageID(returnedOutageNode.getOutageNumber());
        transmissionOutage.setDiscoveryDateTime(DateUtil.getXMLGregorianCalendarDate(returnedOutageNode.getRecCreateDate()));
        transmissionOutage.setComment("External COS ID: " + returnedOutageNode.getOutageNumber());

        if (omsOutageNumber != null) {
            // SET OMS_OUTAGE_ID IF EXISTS TO IDENTIFY CHANGE REQUEST

            transmissionOutage.setMRID(omsOutageNumber);

            String outageStatus = returnedOutageNode.getOutageStatus();

            OutageChangeRequest outageChangeRequest = jaxbfactory.createOutageChangeRequest();
            if (outageStatus != null && !(outageStatus.equalsIgnoreCase(OutageStatusType.CANCELLED.name())
                    || outageStatus.equalsIgnoreCase(OutageStatusType.DENIED.name()) || outageStatus.equalsIgnoreCase(OutageStatusType.RECALLED.name()))) {
                outageChangeRequest.setAction(OutageChangeRequestAction.UPDATE);
            } else {
                outageChangeRequest.setAction(OutageChangeRequestAction.CANCEL);
                outageChangeRequest.setActionReason(OutageChangeRequestActionReason.OTHER);
            }
            transmissionOutage.setOutageChangeRequest(outageChangeRequest);

        }

        String outageNumber = outageEquipInfo.getOutageNumber();
        String newControlArea = outageEquipInfo.getRemoteSystemName();

        int equipmentCount = 0;
        ArrayOfRequestedEquipment arrayOfRequestedEquipment = outageEquipInfo.getRequestedEquipment();

        for (RequestedEquipment requestedEquipment : arrayOfRequestedEquipment.getRequestedEquipments()) {
            try {
                String equipmentName = getSystemElementLabel(requestedEquipment);

                if (StringUtils.isEmpty(equipmentName)) {
                    equipmentName = getSystemElementName(requestedEquipment);
                }

                boolean isEquipDescriptionEmpty = StringUtils.isEmpty(requestedEquipment.getDescription());
                if (!isEquipDescriptionEmpty) {
                    equipmentMap.append("X[" + equipmentName + "] ");

                    // RLAM: DEFECT 33370- WECC: When Outages with constraint
                    // type OOS ,description not null and equipment type name
                    // can be any are retrieved,the outage should not be
                    // submitted to OMS
                    throw new RCINTContinueProcessingException(
                            "Equipment [" + equipmentName + "] description is not null and will be excluded from outage payload.");
                }

                Double voltageClass = getSystemElementVoltageClass(requestedEquipment);

                if (StringUtils.isEmpty(equipmentName)) {
                    equipmentMap.append("?[" + equipmentName + "] ");

                    throw new RCINTContinueProcessingException(
                            "RDFID is not found for control area[" + newControlArea + "] outageId[" + outageNumber + "] equipment name[" + equipmentName + "]");
                } else {
                    List<RCRdfIdMap> rcRdfIdMapList = cosToRdfIdService.findAllRCRdfIdMaps(equipmentName);

                    if (CollectionUtils.isEmpty(rcRdfIdMapList)) {
                        // String stationName =
                        // requestedEquipment.systemElementSubstationName;
                        String stationName = getSubstationName(requestedEquipment);
                        equipmentMap.append("?[" + equipmentName + "] ");

                        cosToRdfIdService.addNewRCRdfIdMap(newControlArea, stationName, voltageClass, equipmentName);
                        throw new RCINTContinueProcessingException("RDFID is not found for control area[" + newControlArea + "] outageId[" + outageNumber
                                + "] station[" + stationName + "] equipment name[" + equipmentName + "] voltageClass[" + voltageClass + "]");
                    }
                    equipmentCount++;

                    String commaSeperatedRdfIds = findListOfRdfIdsAsCommaSeperatedString(rcRdfIdMapList);
                    equipmentMap.append("*[" + equipmentName + " (" + commaSeperatedRdfIds + ")] ");

                    // FOR EACH RDFID MAPPING, CREATE AN EQUIPMENTOUTAGE ELEMENT
                    // FOR THE RDFID
                    for (RCRdfIdMap rcRdfIdMap : rcRdfIdMapList) {
                        EquipmentOutage equipmentOutage = jaxbfactory.createEquipmentOutage();
                        equipmentOutage.setMRID(rcRdfIdMap.getRdfId());

                        OutagedEquipment outageEquipment = jaxbfactory.createOutagedEquipment();

                        String typeName = getSystemElementTypeName(requestedEquipment);

                        if (typeName != null) {

                            // RLAM: DEFECT 33333 - CHECKING TO SEE IF EQUIPMENT
                            // OUTAGE IS A SWITCH OOS OUTAGE IN ORDER TO MAP THE
                            // PAYLOAD CORRECTLY.
                            boolean isEquipmentTypeOfSwitch = (typeName.equalsIgnoreCase(EquipmentSwitchType.DISCONNECT.name())
                                    || typeName.equalsIgnoreCase(EquipmentSwitchType.BREAKER.name())
                                    || typeName.equalsIgnoreCase(EquipmentSwitchType.SWITCH.name()));

                            if (isEquipmentTypeOfSwitch) {
                                outageEquipment.setUseFacilityOutageDefinition(YesNo.NO);
                                List<Switch> switchList = outageEquipment.getSwitches();
                                Switch switchEquipment = jaxbfactory.createSwitch();
                                switchList.add(switchEquipment);

                                switchEquipment.setMRID(rcRdfIdMap.getRdfId());

                                SwitchingOperation switchOperation = jaxbfactory.createSwitchingOperation();
                                switchOperation.setNewState(SwitchState.OPEN);

                                NewStatePeriod statePeriod = jaxbfactory.createSwitchingOperationNewStatePeriod();
                                statePeriod.setStart(transmissionOutage.getEstimatedPeriod().getStart());
                                statePeriod.setEnd(transmissionOutage.getEstimatedPeriod().getEnd());
                                switchOperation.setNewStatePeriod(statePeriod);

                                switchEquipment.getSwitchingOperations().add(switchOperation);
                            } else {
                                outageEquipment.setUseFacilityOutageDefinition(YesNo.YES);
                            }
                        }

                        equipmentOutage.setOutagedEquipment(outageEquipment);
                        transmissionOutage.getEquipments().add(equipmentOutage);
                    }
                }

                OutageCause outageCause1 = jaxbfactory.createOutageCause();
                outageCause1.setCode(RCIntConstants.PRIMARY_CAUSE_CODE);
                OutageCause outageCause2 = jaxbfactory.createOutageCause();
                outageCause2.setCode(RCIntConstants.SECONDARY_CAUSE_CODE);
                List<OutageCause> outageCauseCodeList = new ArrayList<OutageCause>();
                outageCauseCodeList.add(outageCause1);
                outageCauseCodeList.add(outageCause2);
                transmissionOutage.getOutageCauses().addAll(outageCauseCodeList);
            } catch (RCINTContinueProcessingException ex) {
                rcProcessLogService.createExceptionLogEntry(LOG_EVT_TYPE_PROCESS_CONTINUE, logRefId, "BaseCosSubmitTransmissionOutageProcessor", "createTransmissionOutageData",
                        "Unexpected Error" ,ex);
            }
        }

        if (equipmentCount == 0) {
            throw new RCINTContinueProcessingException(
                    "No valid equipments were found for outageId[" + outageNumber + "]. Outage will not be submitted to OMS.");
        }

        Work work = jaxbfactory.createWork();
        work.setKind(WorkKind.OUT_OF_SERVICE);
        transmissionOutage.setWork(work);

        OperatingParticipant operatingParticipant = jaxbfactory.createOperatingParticipant();
        operatingParticipant.setMRID("WECC");
        transmissionOutage.setOperatingParticipant(operatingParticipant);

        transmissionOutages.add(transmissionOutage);

        List<TransmissionOutage> transmissionOutageList = messagePayLoad.getTransmissionOutages();
        transmissionOutageList.add(transmissionOutage);

        // set message header
        com.caiso.soa.transmissionoutagedata_v1.MessageHeader paramMessageHeader = jaxbfactory.createMessageHeader();
        paramMessageHeader.setSource(RCIntConstants.OMS_SOURCE);
        paramMessageHeader.setTimeDate(DateUtil.getXmlGregorianCalendar(Calendar.getInstance().getTime()));
        paramMessageHeader.setVersion(RCIntConstants.OMS_VERSION);

        transmissionOutageData.setMessageHeader(paramMessageHeader);
        transmissionOutageData.setMessagePayload(messagePayLoad);

        return transmissionOutageData;
    }

    /**
     * @param outageStandardOutput
     */
    protected void handleSubmitTransmissionOutageRejection(OutageStandardOutput outageStandardOutput) {
        OutageResultKind errorType = findEventLogOutagesOutageValidationOutageResultKind(outageStandardOutput);
        String errorDesc = findEventLogOutagesOutageValidationOutageResultDescription(outageStandardOutput);

        String rejectedMsg = "REJECTED: " + errorType.name() + " - " + errorDesc;

        throw new RCINTContinueProcessingException(rejectedMsg);
    }

    /**
     * @param outageStandardOutput
     * @return
     */
    protected String findEventLogOutagesOutageValidationOutageResultDescription(OutageStandardOutput outageStandardOutput) {
        String response = null;
        if (outageStandardOutput != null && outageStandardOutput.getMessagePayload() != null && outageStandardOutput.getMessagePayload().getEventLog() != null
                && !CollectionUtils.isEmpty(outageStandardOutput.getMessagePayload().getEventLog().getOutages())
                && outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getOutageValidation() != null && !CollectionUtils
                        .isEmpty(outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getOutageValidation().getOutageResults())) {
            response = outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getOutageValidation().getOutageResults().get(0)
                    .getDescription();
        }
        return response;
    }

    /**
     * @param outageStandardOutput
     * @return
     */
    protected OutageResultKind findEventLogOutagesOutageValidationOutageResultKind(OutageStandardOutput outageStandardOutput) {
        OutageResultKind response = null;
        if (outageStandardOutput != null && outageStandardOutput.getMessagePayload() != null && outageStandardOutput.getMessagePayload().getEventLog() != null
                && !CollectionUtils.isEmpty(outageStandardOutput.getMessagePayload().getEventLog().getOutages())
                && outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getOutageValidation() != null && !CollectionUtils
                        .isEmpty(outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getOutageValidation().getOutageResults())) {
            response = outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getOutageValidation().getOutageResults().get(0).getType();
        }
        return response;
    }

    /**
     * @param outageStandardOutput
     * @return
     */
    protected String findEventLogOutageMRID(OutageStandardOutput outageStandardOutput) {
        String response = null;
        if (outageStandardOutput != null && outageStandardOutput.getMessagePayload() != null && outageStandardOutput.getMessagePayload().getEventLog() != null
                && !CollectionUtils.isEmpty(outageStandardOutput.getMessagePayload().getEventLog().getOutages())) {
            response = outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getMRID();
        }
        return response;
    }

    /**
     * @param outageStandardOutput
     * @return
     */
    protected String findEventLogOutageMktOrgOutageID(OutageStandardOutput outageStandardOutput) {
        String response = null;
        if (outageStandardOutput != null && outageStandardOutput.getMessagePayload() != null && outageStandardOutput.getMessagePayload().getEventLog() != null
                && !CollectionUtils.isEmpty(outageStandardOutput.getMessagePayload().getEventLog().getOutages())) {
            response = outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getMktOrgOutageID();
        }
        return response;
    }

    /**
     * @param outageStandardOutput
     * @return
     */
    protected OutageSubmitStatusKind findOutageSubmitStatusKind(OutageStandardOutput outageStandardOutput) {
        OutageSubmitStatusKind response = null;
        if (outageStandardOutput != null && outageStandardOutput.getMessagePayload() != null && outageStandardOutput.getMessagePayload().getEventLog() != null
                && !CollectionUtils.isEmpty(outageStandardOutput.getMessagePayload().getEventLog().getOutages())
                && outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getOutageValidation() != null) {
            response = outageStandardOutput.getMessagePayload().getEventLog().getOutages().get(0).getOutageValidation().getSubmitStatus();
        }
        return response;
    }

    /**
     * @param outageStandardOutput
     * @return
     */
    protected String findEventResult(OutageStandardOutput outageStandardOutput) {
        String response = null;
        if (outageStandardOutput != null && outageStandardOutput.getMessagePayload() != null && outageStandardOutput.getMessagePayload().getEventLog() != null
                && outageStandardOutput.getMessagePayload().getEventLog().getEvent() != null) {
            response = outageStandardOutput.getMessagePayload().getEventLog().getEvent().getResult();
        }
        return response;
    }

    /**
     * @param responseSoapMessage
     * @return
     * @throws JAXBException
     */
    protected OutageStandardOutput getOutageStandardOutput(String responseSoapBody) throws JAXBException {
        OutageStandardOutput outageStandardOutput;

        JAXBContext jaxbContext = JAXBContext.newInstance("com.caiso.soa.outagestandardoutput_v1");
        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
        JAXBElement<OutageStandardOutput> root = jaxbUnmarshaller.unmarshal(new StreamSource(new StringReader(responseSoapBody)), OutageStandardOutput.class);
        outageStandardOutput = root.getValue();
        return outageStandardOutput;
    }

    /**
     * @param omsOutageDataObject
     */
    protected String getTransmisionOutageId(TransmissionOutageData omsOutageDataObject) {
        String responseId = null;

        if (omsOutageDataObject != null && omsOutageDataObject.getMessagePayload() != null
                && CollectionUtils.isEmpty(omsOutageDataObject.getMessagePayload().getTransmissionOutages())) {
            responseId = omsOutageDataObject.getMessagePayload().getTransmissionOutages().get(0).getMRID();
        }
        return responseId;
    }

    protected OutageSchedule findOutageSchedule(String outSchedule_LoadItmSoapResponse) throws JAXBException {
        OutageSchedule response = null;
        JAXBContext jaxbContext = JAXBContext.newInstance("ca.equinox.crow");
        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
        JAXBElement<OutageScheduleLoadItemResponse> root = jaxbUnmarshaller.unmarshal(new StreamSource(new StringReader(outSchedule_LoadItmSoapResponse)),
                OutageScheduleLoadItemResponse.class);
        OutageScheduleLoadItemResponse outageScheduleLoadItemResponse = root.getValue();
        if (isNoError(outageScheduleLoadItemResponse)) {
            response = outageScheduleLoadItemResponse.getOutageScheduleLoadItemResult();
        }

        return response;
    }

    protected boolean isNoError(OutageScheduleLoadItemResponse outageScheduleLoadItemResponse) {
        if (outageScheduleLoadItemResponse != null && outageScheduleLoadItemResponse.getOutageScheduleLoadItemResult() != null) {
            ArrayOfErrorCode arrayOfErrorCode = outageScheduleLoadItemResponse.getOutageScheduleLoadItemResult().getErrorCodes();
            for (ErrorCode errorCode : arrayOfErrorCode.getErrorCodes()) {
                if (errorCode.getErrorCode() == 0) {
                    return true;
                } else {
                    throw new RCINTRuntimeException(
                            "Error:OutageSchedule_LoadItem [Error Code:]" + errorCode.getErrorCode() + " [Error Message:]" + errorCode.getErrorDescription());
                }
            }
        }
        return false;
    }

    protected String parseControlArea(String controlArea) {
        String parser = "-";

        if (controlArea != null) {
            return controlArea.indexOf(parser) < 0 ? controlArea : controlArea.substring(0, controlArea.indexOf(parser));
        } else {
            return "";
        }
    }

    /**
     * 
     */
    protected String getSubstationName(RequestedEquipment requestedEquipment) {
        String response = null;
        if (requestedEquipment != null && requestedEquipment.getSystemElement() != null && requestedEquipment.getSystemElement().getSubstation() != null) {
            response = requestedEquipment.getSystemElement().getSubstation().getName();
        }
        return response;
    }

    protected String getSystemElementLabel(RequestedEquipment requestedEquipment) {
        String response = null;
        if (requestedEquipment != null && requestedEquipment.getSystemElement() != null) {
            response = requestedEquipment.getSystemElement().getLabel();
        }
        return response;
    }

    protected String getSystemElementName(RequestedEquipment requestedEquipment) {
        String response = null;
        if (requestedEquipment != null && requestedEquipment.getSystemElement() != null) {
            response = requestedEquipment.getSystemElement().getName();
        }
        return response;
    }

    protected Double getSystemElementVoltageClass(RequestedEquipment requestedEquipment) {
        Double response = null;
        if (requestedEquipment != null && requestedEquipment.getSystemElement() != null) {
            response = requestedEquipment.getSystemElement().getVoltageClass();
        }
        return response;
    }

    protected String getSystemElementTypeName(RequestedEquipment requestedEquipment) {
        String response = null;
        if (requestedEquipment != null && requestedEquipment.getSystemElement() != null) {
            response = requestedEquipment.getSystemElement().getTypeName();
        }
        return response;
    }

    /**
     * @param rcRdfIdMapList
     * @return
     */
    private String findListOfRdfIdsAsCommaSeperatedString(List<RCRdfIdMap> rcRdfIdMapList) {
        Collection<String> rdfIdArray = new ArrayList<>();
        for (RCRdfIdMap rcRdfIdMap : rcRdfIdMapList) {
            rdfIdArray.add(rcRdfIdMap.getRdfId());
        }
        String concatanatedStatusList = org.apache.commons.lang3.StringUtils.join(rdfIdArray, ',');
        return concatanatedStatusList;
    }

    protected String getPayloadType(boolean priorVersionExist) {
        boolean isGenerationOutage = false;
        String payloadType = null;

        // IS GENERATION OUTAGE
        if (isGenerationOutage) {
            if (!priorVersionExist) {
                // NEW GENERATION OUTAGE
                payloadType = PayloadType.OMS_TRANS_OUTAGE.getPayloadType();
            } else {
                // GENERATION CHANGE REQUEST
                payloadType = PayloadType.OMS_TRANS_OUTAGE_CHANGE_REQUEST.getPayloadType();
            }
        } else {
            if (!priorVersionExist) {
                // NEW TRANSMISSION OUTAGE
                payloadType = PayloadType.OMS_TRANS_OUTAGE.getPayloadType();
            } else {
                // TRANSMISSION OUTAGE CHANGE REQUEST
                payloadType = PayloadType.OMS_TRANS_OUTAGE_CHANGE_REQUEST.getPayloadType();
            }
        }
        return payloadType;
    }
}
