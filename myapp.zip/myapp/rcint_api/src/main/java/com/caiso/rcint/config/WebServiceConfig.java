package com.caiso.rcint.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.ws.WebServiceMessageFactory;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.soap.SoapVersion;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

import com.caiso.rcint.util.SOAPMessageTemplate;
import com.caiso.rcint.util.SOAPMessageTemplateImpl;

@Configuration
@EnableWs
public class WebServiceConfig {

    @Value("${http.message.sender.connectionTimeout:5000}")
    private int connectionTimeout;

    @Value("${http.message.sender.readTimeout:10000}")
    private int readTimeout;

    /**
     * <p>
     * Register servlet to map to receive message.
     * </p>
     * Using /caiso/SyncMessagingService/ so that it is minimal change to AI.
     * Ideally it should be app specific URI.
     * 
     * @param applicationContext
     * @return
     */
    @Bean
    public ServletRegistrationBean dispatcherServlet(ApplicationContext applicationContext) {
        MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        return new ServletRegistrationBean(servlet, "/caiso/SyncMessagingService/*");
    }

    /**
     * Bean for Rest controller to support invoking quartz job
     * 
     * @param applicationContext
     * @return
     */
    @Bean
    public ServletRegistrationBean dispatcherRestServlet(ApplicationContext applicationContext) {
        DispatcherServlet servlet = new DispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        return new ServletRegistrationBean(servlet, "/*");
    }

    /**
     * SOAP 11 binding.
     * 
     * @param attachmentSchema
     * @return
     */
    @Bean(name = "rcintAdapterReceiver")
    public DefaultWsdl11Definition defaultWsdl11Definition(XsdSchema attachmentSchema) {
        DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
        wsdl11Definition.setPortTypeName("RCINTAdapterReceiver");
        wsdl11Definition.setLocationUri("/caiso/SyncMessagingService/");
        wsdl11Definition.setTargetNamespace("http://www.caiso.com/soa");
        wsdl11Definition.setSchema(attachmentSchema);
        return wsdl11Definition;
    }

    /**
     * Not being used.
     * 
     * @return
     */
    @Bean
    public XsdSchema attachmentSchema() {
        return new SimpleXsdSchema(new ClassPathResource("schema/StandardOutput.xsd"));
    }

    @Bean(name = "webServiceTemplate_12")
    public WebServiceTemplate webServiceTemplate(@Qualifier("webServiceMessageFactory_12") WebServiceMessageFactory webServiceMessageFactory,
            HttpComponentsMessageSender messageSender) {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
        webServiceTemplate.setMessageFactory(webServiceMessageFactory);
        webServiceTemplate.setMessageSender(messageSender);
        return webServiceTemplate;
    }

    @Bean
    public HttpComponentsMessageSender getHttpComponentsMessageSender() {
        HttpComponentsMessageSender htMessageSender = new HttpComponentsMessageSender();
        htMessageSender.setConnectionTimeout(connectionTimeout);
        htMessageSender.setReadTimeout(readTimeout);
        return htMessageSender;
    }

    @Bean(name = "webServiceMessageFactory_12")
    public WebServiceMessageFactory getSaajSoapMessageFactory12() {
        SaajSoapMessageFactory messageFactory = new SaajSoapMessageFactory();
        messageFactory.setSoapVersion(SoapVersion.SOAP_12);
        return messageFactory;
    }

    @Bean(name = "webServiceMessageFactory_11")
    public WebServiceMessageFactory getSaajSoapMessageFactory11() {
        SaajSoapMessageFactory messageFactory = new SaajSoapMessageFactory();
        messageFactory.setSoapVersion(SoapVersion.SOAP_11);
        return messageFactory;
    }

    @Bean
    public SOAPMessageTemplate soapMessageTemplate() {
        return new SOAPMessageTemplateImpl();
    }

    @Bean(name = "webServiceTemplate_11")
    public WebServiceTemplate webServiceTemplate11(@Qualifier("webServiceMessageFactory_11") WebServiceMessageFactory webServiceMessageFactory,
            HttpComponentsMessageSender messageSender) {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
        webServiceTemplate.setMessageFactory(webServiceMessageFactory);
        webServiceTemplate.setMessageSender(messageSender);
        return webServiceTemplate;
    }
}
