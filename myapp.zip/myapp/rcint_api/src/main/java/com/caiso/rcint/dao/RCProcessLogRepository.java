/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 26, 2017 5:26:24 PM
 * Project: rcint-app
 * File: RCProcessLogRepository.java
 */
package com.caiso.rcint.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.caiso.rcint.entity.RCProcessLog;

/**
 * @author gselvaratnam
 *
 */
@Repository
public interface RCProcessLogRepository extends JpaRepository<RCProcessLog, Long> {

}
