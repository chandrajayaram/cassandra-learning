/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 31, 2017 12:09:39 PM
 * Project: rcint-app
 * File: RCProcessLogService.java
 */
package com.caiso.rcint.service;

/**
 * @author gselvaratnam
 *
 */
public interface RCProcessLogService {

    void createLogEntry(String eventType, String refId, String serviceName, String processName, String description);

    void createExceptionLogEntry(String eventType, String refId, String serviceName, String processName, String description, Exception exception);

}