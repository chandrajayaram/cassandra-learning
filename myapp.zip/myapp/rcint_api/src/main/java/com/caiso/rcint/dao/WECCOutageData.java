/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 17, 2017 9:04:09 AM
 * Project: caiso-rcint_api
 * File: WECCOutageData.java
 */
package com.caiso.rcint.dao;

import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
public class WECCOutageData {

    private Long   oid;

    private String weccOutageId;

    private String omsOutageId;

    private int    omsOutageVersion;

    private String omsOutageStatus;

    private String omsOutageType;

    private String equipmentName;

    private Date   outageStartDts;

    private Date   outageEndDts;

    private String ignore;

    private String regen;

    private int    payloadId;

    private Date   createdDts;

    private Date   updatedDts;

    private String updatedBy;

    private int    regAuthPayloadId;

    private String submitToRegAuth;

    private String weccOutageType;

    private String weccOutageStatus;

    /**
     * @return the oid
     */
    public Long getOid() {
        return oid;
    }

    /**
     * @param oid
     *            the oid to set
     */
    public void setOid(Long oid) {
        this.oid = oid;
    }

    /**
     * @return the weccOutageId
     */
    public String getWeccOutageId() {
        return weccOutageId;
    }

    /**
     * @param weccOutageId
     *            the weccOutageId to set
     */
    public void setWeccOutageId(String weccOutageId) {
        this.weccOutageId = weccOutageId;
    }

    /**
     * @return the omsOutageId
     */
    public String getOmsOutageId() {
        return omsOutageId;
    }

    /**
     * @param omsOutageId
     *            the omsOutageId to set
     */
    public void setOmsOutageId(String omsOutageId) {
        this.omsOutageId = omsOutageId;
    }

    /**
     * @return the omsOutageVersion
     */
    public int getOmsOutageVersion() {
        return omsOutageVersion;
    }

    /**
     * @param omsOutageVersion
     *            the omsOutageVersion to set
     */
    public void setOmsOutageVersion(int omsOutageVersion) {
        this.omsOutageVersion = omsOutageVersion;
    }

    /**
     * @return the omsOutageStatus
     */
    public String getOmsOutageStatus() {
        return omsOutageStatus;
    }

    /**
     * @param omsOutageStatus
     *            the omsOutageStatus to set
     */
    public void setOmsOutageStatus(String omsOutageStatus) {
        this.omsOutageStatus = omsOutageStatus;
    }

    /**
     * @return the omsOutageType
     */
    public String getOmsOutageType() {
        return omsOutageType;
    }

    /**
     * @param omsOutageType
     *            the omsOutageType to set
     */
    public void setOmsOutageType(String omsOutageType) {
        this.omsOutageType = omsOutageType;
    }

    /**
     * @return the equipmentName
     */
    public String getEquipmentName() {
        return equipmentName;
    }

    /**
     * @param equipmentName
     *            the equipmentName to set
     */
    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }

    /**
     * @return the outageStartDts
     */
    public Date getOutageStartDts() {
        return outageStartDts;
    }

    /**
     * @param outageStartDts
     *            the outageStartDts to set
     */
    public void setOutageStartDts(Date outageStartDts) {
        this.outageStartDts = outageStartDts;
    }

    /**
     * @return the outageEndDts
     */
    public Date getOutageEndDts() {
        return outageEndDts;
    }

    /**
     * @param outageEndDts
     *            the outageEndDts to set
     */
    public void setOutageEndDts(Date outageEndDts) {
        this.outageEndDts = outageEndDts;
    }

    /**
     * @return the ignore
     */
    public String getIgnore() {
        return ignore;
    }

    /**
     * @param ignore
     *            the ignore to set
     */
    public void setIgnore(String ignore) {
        this.ignore = ignore;
    }

    /**
     * @return the regen
     */
    public String getRegen() {
        return regen;
    }

    /**
     * @param regen
     *            the regen to set
     */
    public void setRegen(String regen) {
        this.regen = regen;
    }

    /**
     * @return the payloadId
     */
    public int getPayloadId() {
        return payloadId;
    }

    /**
     * @param payloadId
     *            the payloadId to set
     */
    public void setPayloadId(int payloadId) {
        this.payloadId = payloadId;
    }

    /**
     * @return the createdDts
     */
    public Date getCreatedDts() {
        return createdDts;
    }

    /**
     * @param createdDts
     *            the createdDts to set
     */
    public void setCreatedDts(Date createdDts) {
        this.createdDts = createdDts;
    }

    /**
     * @return the updatedDts
     */
    public Date getUpdatedDts() {
        return updatedDts;
    }

    /**
     * @param updatedDts
     *            the updatedDts to set
     */
    public void setUpdatedDts(Date updatedDts) {
        this.updatedDts = updatedDts;
    }

    /**
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy
     *            the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the regAuthPayloadId
     */
    public int getRegAuthPayloadId() {
        return regAuthPayloadId;
    }

    /**
     * @param regAuthPayloadId
     *            the regAuthPayloadId to set
     */
    public void setRegAuthPayloadId(int regAuthPayloadId) {
        this.regAuthPayloadId = regAuthPayloadId;
    }

    /**
     * @return the submitToRegAuth
     */
    public String getSubmitToRegAuth() {
        return submitToRegAuth;
    }

    /**
     * @param submitToRegAuth
     *            the submitToRegAuth to set
     */
    public void setSubmitToRegAuth(String submitToRegAuth) {
        this.submitToRegAuth = submitToRegAuth;
    }

    /**
     * @return the weccOutageType
     */
    public String getWeccOutageType() {
        return weccOutageType;
    }

    /**
     * @param weccOutageType
     *            the weccOutageType to set
     */
    public void setWeccOutageType(String weccOutageType) {
        this.weccOutageType = weccOutageType;
    }

    /**
     * @return the weccOutageStatus
     */
    public String getWeccOutageStatus() {
        return weccOutageStatus;
    }

    /**
     * @param weccOutageStatus
     *            the weccOutageStatus to set
     */
    public void setWeccOutageStatus(String weccOutageStatus) {
        this.weccOutageStatus = weccOutageStatus;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final WECCOutageData other = (WECCOutageData) obj;
        return Objects.equals(this.oid, other.oid) && Objects.equals(this.createdDts, other.createdDts)
                && Objects.equals(this.equipmentName, other.equipmentName) && Objects.equals(this.ignore, other.ignore)
                && Objects.equals(this.omsOutageId, other.omsOutageId) && Objects.equals(this.omsOutageStatus, other.omsOutageStatus)
                && Objects.equals(this.omsOutageType, other.omsOutageType) && Objects.equals(this.omsOutageVersion, other.omsOutageVersion)
                && Objects.equals(this.outageEndDts, other.outageEndDts) && Objects.equals(this.outageStartDts, other.outageStartDts)
                && Objects.equals(this.payloadId, other.payloadId) && Objects.equals(this.regAuthPayloadId, other.regAuthPayloadId)
                && Objects.equals(this.regen, other.regen) && Objects.equals(this.submitToRegAuth, other.submitToRegAuth)
                && Objects.equals(this.updatedBy, other.updatedBy) && Objects.equals(this.updatedDts, other.updatedDts)
                && Objects.equals(this.weccOutageId, other.weccOutageId) && Objects.equals(this.weccOutageType, other.weccOutageType)
                && Objects.equals(this.weccOutageStatus, other.weccOutageStatus);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.oid, this.createdDts, this.equipmentName, this.ignore, this.omsOutageId, this.omsOutageStatus, this.omsOutageType,
                this.omsOutageVersion, this.outageStartDts, this.payloadId, this.regAuthPayloadId, this.regen, this.submitToRegAuth, this.updatedBy,
                this.updatedDts, this.weccOutageId, this.weccOutageType, this.weccOutageStatus);
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}