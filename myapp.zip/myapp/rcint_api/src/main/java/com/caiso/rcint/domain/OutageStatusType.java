/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Jan 30, 2017 11:09:13 AM
 * Project: rcint-app
 * File: OutageStatusType.java
 */
package com.caiso.rcint.domain;

/**
 * @author gselvaratnam
 *
 */
public enum OutageStatusType {
    CANCELLED, DENIED, RECALLED;
}
