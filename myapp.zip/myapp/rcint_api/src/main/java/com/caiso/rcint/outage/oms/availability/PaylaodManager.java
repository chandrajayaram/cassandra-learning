package com.caiso.rcint.outage.oms.availability;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.caiso.rcint.domain.AvailabilityResultsWrapper;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.soa.availabilityresultscaiso_v1.Availability;
import com.caiso.soa.availabilityresultscaiso_v1.AvailabilityResultsCaiso;
import com.caiso.soa.availabilityresultscaiso_v1.RegisteredGenerator;


@Service
public class PaylaodManager {
	public static final Logger logger = LoggerFactory.getLogger(PaylaodManager.class);

	public Map<String,AvailabilityResultsWrapper> preparePayload(AvailabilityResultsCaiso availabilityResultsCaiso) {
		List<RegisteredGenerator> registeredGenrators = availabilityResultsCaiso.getMessagePayload().getRegisteredGenerators();
		
		List<RegisteredGenerator> registeredGenWithNoLogicalConfig = registeredGenrators.stream().filter(registerdRegerator -> registerdRegerator.getLogicalConfiguration() == null).collect(Collectors.toList());
		
		registeredGenrators.clear();
		registeredGenrators.addAll(registeredGenWithNoLogicalConfig);
		
		Set<String> outageIDs = new HashSet<>();
		
		for(RegisteredGenerator generator : registeredGenrators){
			List<Availability> availabilityWithOutagedResource = generator.getOutagedRegisteredResource().getAvailabilities().stream().filter(availability -> availability.getOutagedRegisteredResource() != null).collect(Collectors.toList());
			generator.getOutagedRegisteredResource().getAvailabilities().clear();
			generator.getOutagedRegisteredResource().getAvailabilities().addAll(availabilityWithOutagedResource);
			availabilityWithOutagedResource.forEach(availabity -> availabity.getOutagedRegisteredResource().getRegisteredResource().getRegisteredResourceOutages().forEach(resource -> outageIDs.add(resource.getMRID())));	
		}
		
		Map<String,AvailabilityResultsWrapper>  reArrageResource = new HashMap<>();
		
		for(String outageId : outageIDs){
			Set<RegisteredGenerator> registeredGenerators= new HashSet<>();
			for(RegisteredGenerator generator : registeredGenrators)
				generator.getOutagedRegisteredResource().getAvailabilities().forEach(availability -> availability.getOutagedRegisteredResource().getRegisteredResource().getRegisteredResourceOutages().forEach(resource -> 
				{
					if(resource.getMRID().equals(outageId)){
						registeredGenerators.add(generator);
					}
				}));
			
			if(!registeredGenerators.isEmpty()){
				AvailabilityResultsWrapper wrapper = new AvailabilityResultsWrapper();
				for(RegisteredGenerator genarator : registeredGenerators){
					RegisteredGenerator newGenerator = copyRegisteredGenerator(genarator);
					List<Availability> availabilitiesForOutageId = newGenerator.getOutagedRegisteredResource().getAvailabilities().stream().filter(availability -> 
							availability.getOutagedRegisteredResource().getRegisteredResource().getRegisteredResourceOutages().stream().filter(resource-> resource.getMRID().equals(outageId)).findFirst().isPresent()
					).collect(Collectors.toList());
					newGenerator.getOutagedRegisteredResource().getAvailabilities().clear();
					newGenerator.getOutagedRegisteredResource().getAvailabilities().addAll(availabilitiesForOutageId);
					wrapper.getRegisteredGenerators().add(newGenerator);
				}
				reArrageResource.put(outageId, wrapper);
			}
		}
		return reArrageResource;
	}
	private RegisteredGenerator copyRegisteredGenerator(RegisteredGenerator registeredGenerator){
        try {
			JAXBContext jc = JAXBContext.newInstance(RegisteredGenerator.class);
			JAXBElement<RegisteredGenerator> jaxbElement = new JAXBElement<RegisteredGenerator>(new QName("RegisteredGenerator"), RegisteredGenerator.class, registeredGenerator);
			Marshaller marshaller = jc.createMarshaller();
			ByteArrayOutputStream oStream = new ByteArrayOutputStream();
			marshaller.marshal(jaxbElement, oStream);
			InputStream is = new ByteArrayInputStream(oStream.toByteArray());
			Unmarshaller unmarshaller = jc.createUnmarshaller();
			JAXBElement<RegisteredGenerator> newGenerator = (JAXBElement<RegisteredGenerator>) unmarshaller.unmarshal(new StreamSource(is),RegisteredGenerator.class);
			return newGenerator.getValue();
        } catch (JAXBException e) {
        	logger.error("error accoured while copying the registered generator",e);
			throw new RCINTRuntimeException(e);
		}
        
	}
}
