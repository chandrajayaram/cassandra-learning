/**
 * Copyright © 2005-2016 California Independent System Operator
 * Date: Feb 7, 2017 4:38:34 PM
 * Project: rcint-app
 * File: SubmitOutageScheduleSubmitRequestPayloadControllerImpl.java
 */
package com.caiso.rcint.service;

import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caiso.rcint.entity.RCPublishPayload;
import com.caiso.rcint.exception.RCINTRuntimeException;
import com.caiso.rcint.outage.oms.common.OutagePublisher;
import com.caiso.rcint.outage.oms.common.WECCPayload;
import com.caiso.rcint.util.Utils;

/**
 * @author gselvaratnam
 *
 */
@Service
public class PostOutageScheduleSubmitRequestServiceImpl implements PostOutageScheduleSubmitRequestService {
    private static final Logger      logger = LoggerFactory.getLogger(PostOutageScheduleSubmitRequestServiceImpl.class);

    @Autowired
    private OutagePublisher outagePublisher;

    @Override
    public String resendPayload(RCPublishPayload rcPublishPayload) {
        logger.info("Begin::SubmitPayloadControllerImpl.resendPayload");

        String response = "OK";

        validate(rcPublishPayload);

        try {
            logger.debug("RCPublishPayload : {}", rcPublishPayload);
            String soapRequestXml = Utils.decompress(rcPublishPayload.getData());
            
            WECCPayload weccPayload = new WECCPayload();
            MessageFactory factory = MessageFactory.newInstance();
            SOAPMessage message = factory.createMessage(new MimeHeaders(), new ByteArrayInputStream(soapRequestXml.getBytes(Charset.forName("UTF-8"))));
            weccPayload.setWeccPayload(message);

            outagePublisher.process(rcPublishPayload.getPayloadId(), weccPayload);

            return response;
        } catch (Exception exception) {
            throw new RCINTRuntimeException(exception);
        } finally {
            logger.info("End::SubmitPayloadControllerImpl.resendPayload");
        }
    }

    private void validate(RCPublishPayload rcPublishPayload) {
        if (rcPublishPayload == null) {
            throw new RCINTRuntimeException("RCPublishPayload cannot be null");
        }
    }
}
