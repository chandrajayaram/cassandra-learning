package com.caiso.rcint.domain;

public enum PayloadStatus {
	RECEIVED,IGNORED, PROCESSED, ERROR; 
	
}
