/**
 * 
 */
package com.caiso.rcint.jms;

import javax.jms.Message;

/**
 * @author gselvaratnam
 *
 */
public interface MessageReciever {

	void recieveTransmissionOutage(Message theMessage);
}
