/**
 * Copyright © 2005-2016 California Independent System Operator
 * $Revision: #1 $
 * $Date: Mar 11, 2016 $
 * $Author: gselvaratnam $
 */
package com.caiso.rcint.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * @author gselvaratnam
 *
 */
public class RCRdfIdMap implements Serializable {

    /**
     * The serial version id.
     */
    private static final long serialVersionUID = -7088246649206105462L;

    private String            controlArea;

    private String            station;

    private String            voltageClass;

    private String            cosName;

    private String            rdfId;

    private Date              createdDate;

    private Date              updatedDate;

    private String            updatedBy;

    private String            batchId;

    /**
     * @return the controlArea
     */
    public String getControlArea() {
        return controlArea;
    }

    /**
     * @param controlArea
     *            the controlArea to set
     */
    public void setControlArea(String controlArea) {
        this.controlArea = controlArea;
    }

    /**
     * @return the voltageClass
     */
    public String getVoltageClass() {
        return voltageClass;
    }

    /**
     * @param voltageClass
     *            the voltageClass to set
     */
    public void setVoltageClass(String voltageClass) {
        this.voltageClass = voltageClass;
    }

    /**
     * @return the cosName
     */
    public String getCosName() {
        return cosName;
    }

    /**
     * @param cosName
     *            the cosName to set
     */
    public void setCosName(String cosName) {
        this.cosName = cosName;
    }

    /**
     * @return the rdfId
     */
    public String getRdfId() {
        return rdfId;
    }

    /**
     * @param rdfId
     *            the rdfId to set
     */
    public void setRdfId(String rdfId) {
        this.rdfId = rdfId;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy
     *            the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the batchId
     */
    public String getBatchId() {
        return batchId;
    }

    /**
     * @param batchId
     *            the batchId to set
     */
    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    /**
     * @return the station
     */
    public String getStation() {
        return station;
    }

    /**
     * @param station the station to set
     */
    public void setStation(String station) {
        this.station = station;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final RCRdfIdMap other = (RCRdfIdMap) obj;
        
        boolean check_1 = Objects.equals(this.batchId, other.batchId);
        boolean check_2 = Objects.equals(this.controlArea, other.controlArea);
        boolean check_3 = Objects.equals(this.cosName, other.cosName);
        boolean check_4 = Objects.equals(this.rdfId, other.rdfId);
        boolean check_5 = Objects.equals(this.station, other.station);
        boolean check_6 = Objects.equals(this.voltageClass, other.voltageClass);
        
        return  check_1
                && check_2
                && check_3
                && check_4
                && check_5
                && check_6;
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.batchId, this.controlArea, this.cosName, this.createdDate, this.rdfId, this.station, this.updatedBy, this.updatedDate,
                this.voltageClass);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}