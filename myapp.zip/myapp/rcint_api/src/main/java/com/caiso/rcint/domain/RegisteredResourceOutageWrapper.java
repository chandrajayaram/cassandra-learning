package com.caiso.rcint.domain;

import javax.xml.bind.annotation.XmlRootElement;

import com.caiso.soa.resourceoutageresultscaiso_v2.RegisteredResourceOutage;

@XmlRootElement(name="RegisteredResourceOutageWrapper")
public class RegisteredResourceOutageWrapper {
	
	private RegisteredResourceOutage registeredResourceOutage;

	public RegisteredResourceOutage getRegisteredResourceOutage() {
		return registeredResourceOutage;
	}

	public void setRegisteredResourceOutage(RegisteredResourceOutage registeredResourceOutage) {
		this.registeredResourceOutage = registeredResourceOutage;
	}
	
}
