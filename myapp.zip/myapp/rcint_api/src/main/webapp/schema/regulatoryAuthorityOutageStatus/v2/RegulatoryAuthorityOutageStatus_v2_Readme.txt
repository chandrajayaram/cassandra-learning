RegulatoryAuthorityOutageStatus_v2.xsd

    1/17/2017  - Early Release 2017 [Project: TOP-IRO]
	RegisteredResourceOutage/RegulatoryAuthorityOutageStatus/regulatoryAuthorityOutageState - add, optional
	RegisteredResourceOutage/RegulatoryAuthorityOutageStatus/regulatoryAuthorityOutageType  - add, optional
	RegisteredResourceOutage/versionID                                                      - changed to optional
	TransmissionOutage/RegulatoryAuthorityOutageStatus/regulatoryAuthorityOutageState       - add, optional
	TransmissionOutage/RegulatoryAuthorityOutageStatus/regulatoryAuthorityOutageType        - add, optional
	TransmissionOutage/versionID                                                            - changed to optional


RegulatoryAuthorityOutageStatus_v1.xsd

    1/27/2016  - Spring Release 2016 [Project: OMS for EIM]
	Initial Release