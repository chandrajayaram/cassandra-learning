TransmissionOutageData_v1.xsd
    1/16/2014  - Fall Release 2014
        Initial Release

    1/21/2014  - Fall Release 2014
	PSRKind                                                                           - add enumeration
	TransmissionOutage/Equipments/OutagedEquipment/Switch/VoltageLevel/name           - remove
	TransmissionOutage/Equipments/OutagedEquipment/Switch/BaseVoltage/nominalVoltage  - add
	TransmissionOutage/Equipments/OutagedEquipment/Switch/SwitchingOperations         - 1 to many

    1/31/2014  - Fall Release 2014
	PSRKind                       - add enumeration BREAKER, DISCONNECT, SWITCH

    3/31/2014  - Fall Release 2014
	WorkKind                                                                          - update enumeration
	TransmissionOutage/CauseCode                                                      - rename from GADSCause
        TransmissionOutage/emergencyReturnTimeType                                        - change, required
	TransmissionOutage/Equipments/aliasName                                           - remove
	TransmissionOutage/Equipments/PSRType                                             - remove
	TransmissionOutage/Equipments/Names                                               - add, 0 to 2
	TransmissionOutage/Equipments/Names/name                                          - add
	TransmissionOutage/Equipments/Names/NameType/name                                 - add
	TransmissionOutage/Equipments/OutagedEquipment/Switch/aliasName                   - remove
	TransmissionOutage/Equipments/OutagedEquipment/Switch/Names                       - add, 0 to 2
	TransmissionOutage/Equipments/OutagedEquipment/Switch/Names/name                  - add
	TransmissionOutage/Equipments/OutagedEquipment/Switch/Names/NameType/name         - add
	TransmissionOutage/MktOrganisation/MarketPerson                                   - remove
	TransmissionOutage/MktOrganisation                                                - remove
	TransmissionOutage/OperatingParticipant                                           - add
	TransmissionOutage/OperatingParticipant/mRID                                      - add
	TransmissionOutage/OperatingParticipant/Person                                    - add, 1 to many
	TransmissionOutage/OperatingParticipant/Person/firstName                          - add
	TransmissionOutage/OperatingParticipant/Person/lastName                           - add
	TransmissionOutage/OperatingParticipant/Person/landlinePhone/localNumber          - add
	TransmissionOutage/trumpFlag                                                      - add, optional
	TransmissionOutage/Work                                                           - moved from OutagedEquipment

    4/2/2014  - Fall Release 2014
	TransmissionOutage/Equipments/name                                                - remove
	TransmissionOutage/Equipments/Names                                               - change cardinality, 0 to 1
	TransmissionOutage/Equipments/OutagedEquipment/Switch/name                        - remove
	TransmissionOutage/Equipments/OutagedEquipment/Switch/Names                       - change cardinality, 0 to 1

    5/14/2014  - Fall Release 2014
	WorkKind                                                                           - add enumeration OUT_OF_SERVICE_WITH_SPECIAL_SETUP                            - add
	TransmissionOutage/congestionRevenueRightsDesignation                              - add, optional
        TransmissionOutage/Equipments/EquipmentContainer                                   - add, optional
        TransmissionOutage/Equipments/EquipmentContainer/BaseVoltage/nominalVoltage/value  - add
	TransmissionOutage/outageCoordinationLongTermPlanning                              - add, optional
	TransmissionOutage/OperatingParticipant/Person                                     - 0 to many
	TransmissionOutage/OutageChangeRequest/actionReason                                - add, optional
	TransmissionOutage/OutageChangeRequest/actionSubType                               - add, optional

    5/15/2014  - Fall Release 2014
        TransmissionOutage/Equipments/VoltageLevel                                         - rename from EquipmentContainer

    08/18/2014 - Fall Release 2014
	TransmissionOutage/Equipments/mrid                                                  - Changed restriction to 40 Char
	TransmissionOutage/Equipments/OutagedEquipment/Switch/mrid                          - Changed restriction to 40 Char

    08/25/2014 - Fall Release 2014
	TransmissionOutage/Equipments/Names/NameType/name                                   - Added enumerations (PARTICIPANTID and PARTICIPANTNAME)
	TransmissionOutage/Equipments/OutagedEquipment/Switch/Names/NameType/name           - Added enumerations (PARTICIPANTID and PARTICIPANTNAME)


