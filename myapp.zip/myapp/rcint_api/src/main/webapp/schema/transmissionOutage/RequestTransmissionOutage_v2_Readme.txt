RequestTransmissionOutage_v2.xsd    


11/24/2015  - Early Release 2016 {Project: OMS Enhancements/RSI]

	Bumped up the major version to match with the response {Response: TransmissionOutageResults and TransmissionOutageResultsCaiso}

----------------------------------------------------------------------------------------------------------------------------------------------

RequestTransmissionOutage_v1.xsd    


12/23/2014  - Fall Release 2014

	OutageRange/rangePeriodType         -  add, optional


	
