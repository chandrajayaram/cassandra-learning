TransmissionOutageResultsCaiso_v1.xsd
    4/7/2014  - Fall Release 2014
	Initial Release

    6/2/2014  - Fall Release 2014
	MessageHeader/IncPayloadFlag                                          - add, optional
	MessageHeader/lastBroadcasted                                         - add, optional
	MessageHeader/BroadcastSequenceNum                                    - add, optional
	TransmissionOutage/congestionRevenueRightsDesignation                 - add, optional
	TransmissionOutage/outageStatusReason                                 - optional
	TransmissionOutage/RIMSProjectCommissionDate                          - add, optional
	TransmissionOutage/RIMSProjectCompletion                              - add, optional
	TransmissionOutage/RIMSProjectID                                      - add, optional
	TransmissionOutage/RIMSProjectPhase                                   - add, optional
	TransmissionOutage/ContingencyOverride/applicableMarketPass           - remove
	TransmissionOutage/ContingencyOverride/applicableMarket               - add
	TransmissionOutage/FlowgateOverride/applicableMarketPass              - remove
	TransmissionOutage/FlowgateOverride/applicableMarket                  - add, optional
	TransmissionOutage/FlowgateOverride/percent                           - add 

     6/26/14 Changed mandatory to Optional for following

	1. Flowgate Override
	2. Nomogram Override
	3. Contingency Override

     08/11/2014 - Fall Release 2014
	TransmissionOutage/Eqipments/mrid                                                  - Removed restriction
        TransmissionOutage/Eqipments/name                                                  - Removed restriction

     09/04/2014 - Fall Release 2014
	TransmissionOutage/actualPeriod/start                                              - Changed to optional
	TransmissionOutage/actualPeriod/end                                                - Changed to optional

     09/08/2014 - Fall Release 2014
        Removed restriction for mrid and name simpleType

    10/23/2014 - Fall Release 2014
	TransmissionOutage/Equipments/PSRType/type                                          - Added enumerations (CONFORMLOAD, NONCONFORMLOAD and STATICVARCOMPENSATOR)

    2/18/2015 - Fall Release 2014
	enumeration OUT_OF_SERVICE_WITH_SPECIAL_SETUP 	-add enumeration

    03/24/2015  - Fall Release 2014
        TransmissionOutage/Equipments/PSRType/type                                          - Added "COMMUNICATIONS"

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------

TransmissionOutageResultsCaiso_v2.xsd

    08/20/2015  - Early Release 2016 (Converted from Manual to CIMTool XSD)
	TransmissionOutage/Equipments/PSRType/type                                          - Added "SYNCHRONOUSMACHINE"
	TransmissionOutage/Work/kind                                                        - Added RIMS_OUTAGE, RIMS_TESTING
	TransmissionOutage/FlowgateOverride/percent                                         - changed to optional
	TransmissionOutage/FlowgateOverride/baseLimitPercent                                - Add, optional
	TransmissionOutage/FlowgateOverride/contingencyLimitPercent                         - Add, optional

    01/21/2016  - Early Release 2016 [Project: OMS Enhancements]
	TransmissionOutage/Equipments/AdjustedOperationRating                               - Change the cardinality from 0..1 to 0..N

    01/25/2016  - Spring Release 2016 [Project: OMS for EIM]
	TransmissionOutage/RegulatoryAuthorityOutage/submitOutageToRegulatoryAuthority      - Add, optional



	
	