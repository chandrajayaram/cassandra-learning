
/* ###################################################################################### 
    RC_OUTAGE_DATA_V - Added additional columns for mapping COS outage state and type
###################################################################################### */

CREATE OR REPLACE FORCE VIEW RCINT_MSTR.RC_OUTAGE_DATA_V
AS
   SELECT R.CONTROL_AREA,
          RD.ID RC_OUTAGE_DATA_ID,
          R.WECC_OUTAGE_ID,
          RD.OMS_OUTAGE_ID,
          RD.EQUIPMENT_MAP,
          RD.WECC_REVISION_NUMBER,
          RD.WECC_OUTAGE_TYPE,
          RD.WECC_OUTAGE_STATUS,
          RD.WECC_OUTAGE_DATA,
          RD.WECC_EQUIPMENT_DATA,
          RD.OMS_OUTAGE_DATA,
          RD.PAYLOAD_ID,
          P.STATUS PUBLISH_STATUS,
          P.RESPONSE,
          P.PAYLOAD_TYPE,
          RD.REGEN,
          RD.IGNORE,
          RD.CREATED_DTS,
          RD.UPDATED_DTS
     FROM RC_OUTAGE R, RC_OUTAGE_DATA RD, RC_PUBLISH_PAYLOAD P
    WHERE     R.WECC_OUTAGE_ID = RD.WECC_OUTAGE_ID
          AND RD.PAYLOAD_ID = P.PAYLOAD_ID(+);


CREATE OR REPLACE SYNONYM RCINT_APP.RC_OUTAGE_DATA_V FOR RCINT_MSTR.RC_OUTAGE_DATA_V;

GRANT SELECT ON RCINT_MSTR.RC_OUTAGE_DATA_V TO ISO_SLIC_READ_ONLY;

GRANT SELECT ON RCINT_MSTR.RC_OUTAGE_DATA_V TO RCINT_APP WITH GRANT OPTION;
