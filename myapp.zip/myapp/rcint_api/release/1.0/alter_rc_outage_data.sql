
/* ###################################################################################### 
    RC_OUTAGE_DATA - Added additional columns for mapping COS outage state and type
###################################################################################### */

ALTER TABLE RCINT_MSTR.RC_OUTAGE_DATA ADD    WECC_OUTAGE_TYPE   VARCHAR2(100);
ALTER TABLE RCINT_MSTR.RC_OUTAGE_DATA MODIFY WECC_OUTAGE_STATUS  VARCHAR2(100);

ALTER TABLE RCINT_MSTR.RC_OUTAGE_DATA ADD (REG_AUTH_PAYLOAD_ID  NUMBER);

ALTER TABLE RCINT_MSTR.RC_OUTAGE_DATA DROP COLUMN OUTAGE_PRIORITY;