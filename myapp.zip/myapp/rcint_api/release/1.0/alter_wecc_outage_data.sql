
/* ###################################################################################### 
    WECC_OUTAGE_DATA - Added additional columns for mapping COS outage state and type
###################################################################################### */

ALTER TABLE RCINT_MSTR.WECC_OUTAGE_DATA ADD (WECC_OUTAGE_TYPE   VARCHAR2(100));
ALTER TABLE RCINT_MSTR.WECC_OUTAGE_DATA ADD (WECC_OUTAGE_STATUS  VARCHAR2(100));