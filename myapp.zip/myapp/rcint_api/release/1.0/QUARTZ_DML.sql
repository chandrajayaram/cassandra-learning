delete from QRTZ2_SIMPROP_TRIGGERS;
delete from QRTZ2_SIMPLE_TRIGGERS;
delete from QRTZ2_CRON_TRIGGERS;
delete from QRTZ2_TRIGGERS;
delete from QRTZ2_JOB_DETAILS;
delete from QRTZ2_SCHEDULER_STATE;
delete from QRTZ2_PAUSED_TRIGGER_GRPS;
delete from QRTZ2_LOCKS;
delete from QRTZ2_FIRED_TRIGGERS;
delete from QRTZ2_CALENDARS;
delete from QRTZ2_BLOB_TRIGGERS;

Insert into QRTZ2_JOB_DETAILS (SCHED_NAME, JOB_NAME, JOB_GROUP, DESCRIPTION, JOB_CLASS_NAME, IS_DURABLE, IS_NONCONCURRENT, IS_UPDATE_DATA, REQUESTS_RECOVERY) Values ('quartzScheduler', 'omsOutageProcessorJob', 'RCINT', 'This job will broadcast OMS outage details', 'com.caiso.rcint.job.OmsOutageProcessorJob', '1', '0', '1', '0');
Insert into QRTZ2_TRIGGERS (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP, JOB_NAME, JOB_GROUP, DESCRIPTION, NEXT_FIRE_TIME, PREV_FIRE_TIME, PRIORITY, TRIGGER_STATE, TRIGGER_TYPE, START_TIME, END_TIME, CALENDAR_NAME, MISFIRE_INSTR) Values ('quartzScheduler', 'omsOutageProcessorJob_trigger', 'RCINT', 'omsOutageProcessorJob', 'RCINT', 'This is the trigger', null, null, 5, 'WAITING',  'CRON', 0, 0, NULL, 0);
Insert into QRTZ2_CRON_TRIGGERS (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP, CRON_EXPRESSION, TIME_ZONE_ID) Values ('quartzScheduler', 'omsOutageProcessorJob_trigger', 'RCINT', '0 0/15 * * * ?', 'UTC');

Insert into QRTZ2_JOB_DETAILS (SCHED_NAME, JOB_NAME, JOB_GROUP, DESCRIPTION, JOB_CLASS_NAME, IS_DURABLE, IS_NONCONCURRENT, IS_UPDATE_DATA, REQUESTS_RECOVERY) Values ('quartzScheduler', 'omsCaisoOutageProcessorJob', 'RCINT', 'This job will broadcast Caiso OMS outage details', 'com.caiso.rcint.job.OmsCaisoOutageProcessorJob', '1', '0', '1', '0');
Insert into QRTZ2_TRIGGERS (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP, JOB_NAME, JOB_GROUP, DESCRIPTION, NEXT_FIRE_TIME, PREV_FIRE_TIME, PRIORITY, TRIGGER_STATE, TRIGGER_TYPE, START_TIME, END_TIME, CALENDAR_NAME, MISFIRE_INSTR) Values ('quartzScheduler', 'omsCaisoOutageProcessorJob_trigger', 'RCINT', 'omsCaisoOutageProcessorJob', 'RCINT', 'This is the trigger', null, null, 5, 'WAITING',  'CRON', 0, 0, NULL, 0);
Insert into QRTZ2_CRON_TRIGGERS (SCHED_NAME, TRIGGER_NAME, TRIGGER_GROUP, CRON_EXPRESSION, TIME_ZONE_ID) Values ('quartzScheduler', 'omsCaisoOutageProcessorJob_trigger', 'RCINT', '0 0/15 * * * ?', 'UTC');