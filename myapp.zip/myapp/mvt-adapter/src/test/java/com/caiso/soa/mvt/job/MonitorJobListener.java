package com.caiso.soa.mvt.job;


import java.util.concurrent.BlockingQueue;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;

public class MonitorJobListener implements JobListener {
    private BlockingQueue<Object> blockingQueue;

    public MonitorJobListener(BlockingQueue<Object> blockingQueue) {
        this.blockingQueue = blockingQueue;
    }

    @Override
    public String getName() {
        return "Status-Monitor";
    }

    @Override
    public void jobToBeExecuted(JobExecutionContext context) {

    }

    @Override
    public void jobExecutionVetoed(JobExecutionContext context) {

    }

    @Override
    public void jobWasExecuted(JobExecutionContext context, JobExecutionException jobException) {
        try {
            if (jobException != null) {
                this.blockingQueue.put(jobException);
            } else {
                this.blockingQueue.put(Boolean.TRUE);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
