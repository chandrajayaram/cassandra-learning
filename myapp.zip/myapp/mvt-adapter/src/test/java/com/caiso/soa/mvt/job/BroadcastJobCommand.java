package com.caiso.soa.mvt.job;

public interface BroadcastJobCommand {
	public void executeJob();
}
