package com.caiso.soa.mvt.job;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.mockito.Mockito;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.springframework.context.ApplicationContext;

import com.caiso.soa.commitment_v1.Commitment;
import com.caiso.soa.framework.quartz.QuartzProperty;
import com.caiso.soa.marketclearingoutcome_v4.MarketClearingOutcome;
import com.caiso.soa.mitigatedbidset_v1.MitigatedBidSet;
import com.caiso.soa.mvt.broadcast.job.BroadcastMarketPriceCorrection;
import com.caiso.soa.nodalconstraints_v1.NodalConstraints;
import com.caiso.soa.pnodeclearingoutcome_v2.PnodeClearingOutcome;
import com.caiso.soa.resourceawards_v4.ResourceAwards;
import com.caiso.soa.rucresourceawards_v1.RUCResourceAwards;

public class BroadcastJobCommandFactory {

	
	private static ApplicationContext context;

	static Map<String, BroadcastJobCommand> jobRespository = new HashMap<>();

	static {
		jobRespository.put("broadcastMarketClearingOutcomeV4", getBroadcastMarketClearingOutcomeV4());
		jobRespository.put("broadcastResourceAwardClearingV4", getBroadcastResourceAwardsClearing());
		jobRespository.put("broadcastPnodeClearingOutcomeV2", getBroadcastPnodeClearingOutcome());
		jobRespository.put("broadcastNodalContraintsV1", getBroadcastNodalContraint());
		jobRespository.put("broadcastRUCResourceAwardClearingV1", getBroadcastRUCResourceAwardsClearing());
		jobRespository.put("broadcastMitigatedBidSetV1", getBroadcastMitigatedBidSet());
		jobRespository.put("broadcastCommitmentV1", getBroadcastCommitment());
	}

	public static BroadcastJobCommand getJobInstance(String jobName) {
		return jobRespository.get(jobName);
	}

	private static BroadcastJobCommand getBroadcastMarketClearingOutcomeV4() {
		return new BroadcastJobCommand() {

			@Override
			public void executeJob() {
				JobDataMap jobDataMap = new JobDataMap();

				jobDataMap.put(QuartzProperty.URI.getVal(),
						"http://fqapjbos191.ete.wepex.net:4400/sst/runtime.asvc/BroadcastMVTMarketClearing_MVTv4_AP");
				jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), "MIME_ATTACHMENT");
				jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(),
						"http://www.caiso.com/soa/broadcastMVTMarketClearing_v4");
				jobDataMap.put(QuartzProperty.ATTACHMENT_NAME.getVal(), "dABindingMarketClearing_attachment");
				jobDataMap.put(QuartzProperty.SERVICE_NAME.getVal(), "broadcastMarketClearingOutcomeV4");
				jobDataMap.put(QuartzProperty.VALIDTA_AGAINST_SCHEMA.getVal(), "true");
				jobDataMap.put(QuartzProperty.SCHEMA_FILE.getVal(),
						"schema/MarketClearing/MarketClearingOutcome_v4/20161001/MarketClearingOutcome_v4.xsd");

				JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
				JobDetail jobDetail = Mockito.mock(JobDetail.class);

				Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
				Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
				Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("broadcastMarketClearingOutcomeV4"));

				BroadcastMarketPriceCorrection<MarketClearingOutcome> marketClearingJob = new BroadcastMarketPriceCorrection<>();
				context.getAutowireCapableBeanFactory().autowireBean(marketClearingJob);

				try {
					marketClearingJob.executeInternal(jobContext);
				} catch (JobExecutionException e) {
					e.printStackTrace();
				}
				Assert.assertTrue(true);

			}
		};
	}

	private static BroadcastJobCommand getBroadcastResourceAwardsClearing() {
		return new BroadcastJobCommand() {

			@Override
			public void executeJob() {
				JobDataMap jobDataMap = new JobDataMap();

				jobDataMap.put(QuartzProperty.URI.getVal(),
						"http://fqapjbos191.ete.wepex.net:4400/sst/runtime.asvc/BroadcastMVTResourceAwards_MVTv4_AP");
				jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), "MIME_ATTACHMENT");
				jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(),
						"http://www.caiso.com/soa/broadcastMVTResourceAwards_v4");
				jobDataMap.put(QuartzProperty.ATTACHMENT_NAME.getVal(), "MVTResourceAwards_attachment");
				jobDataMap.put(QuartzProperty.SERVICE_NAME.getVal(), "broadcastResourceAwardClearingV4");
				jobDataMap.put(QuartzProperty.VALIDTA_AGAINST_SCHEMA.getVal(), "true");
				jobDataMap.put(QuartzProperty.SCHEMA_FILE.getVal(),
						"schema/ResourceAwards/ResourceAwards_v4/20161001/ResourceAwards_v4.xsd");

				JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
				JobDetail jobDetail = Mockito.mock(JobDetail.class);

				Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
				Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
				Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("broadcastResourceAwardClearingV4"));

				BroadcastMarketPriceCorrection<ResourceAwards> resourceAwardJob = new BroadcastMarketPriceCorrection<>();
				context.getAutowireCapableBeanFactory().autowireBean(resourceAwardJob);

				try {
					resourceAwardJob.executeInternal(jobContext);
				} catch (JobExecutionException e) {
					e.printStackTrace();
				}
				Assert.assertTrue(true);

			}
		};
	}

	private static BroadcastJobCommand getBroadcastPnodeClearingOutcome() {
		return new BroadcastJobCommand() {

			@Override
			public void executeJob() {
				JobDataMap jobDataMap = new JobDataMap();

				jobDataMap.put(QuartzProperty.URI.getVal(),
						"http://fqapjbos191.ete.wepex.net:4400/sst/runtime.asvc/BroadcastMVTPnodeClearing_MVTv2_AP");
				jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), "MIME_ATTACHMENT");
				jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(),
						"http://www.caiso.com/soa/broadcastMVTPnodeClearing_v2");
				jobDataMap.put(QuartzProperty.ATTACHMENT_NAME.getVal(), "MVTPnodeClearing_attachment");
				jobDataMap.put(QuartzProperty.SERVICE_NAME.getVal(), "broadcastPnodeClearingOutcomeV2");
				jobDataMap.put(QuartzProperty.VALIDTA_AGAINST_SCHEMA.getVal(), "true");
				jobDataMap.put(QuartzProperty.SCHEMA_FILE.getVal(),
						"schema/PnodeClearing/PnodeClearingOutcome_v2/20161001/PnodeClearingOutcome_v2.xsd");

				JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
				JobDetail jobDetail = Mockito.mock(JobDetail.class);

				Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
				Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
				Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("broadcastPnodeClearingOutcomeV2"));

				BroadcastMarketPriceCorrection<PnodeClearingOutcome> pnodeClearningJob = new BroadcastMarketPriceCorrection<>();
				context.getAutowireCapableBeanFactory().autowireBean(pnodeClearningJob);

				try {
					pnodeClearningJob.executeInternal(jobContext);
				} catch (JobExecutionException e) {
					e.printStackTrace();
				}
				Assert.assertTrue(true);

			}

		};
	}

	private static BroadcastJobCommand getBroadcastNodalContraint() {
		return new BroadcastJobCommand() {

			@Override
			public void executeJob() {
				JobDataMap jobDataMap = new JobDataMap();

				jobDataMap.put(QuartzProperty.URI.getVal(),
						"http://fqapjbos191.ete.wepex.net:4400/sst/runtime.asvc/BroadcastMVTNodalConstraints_MVTv1_AP");
				jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), "MIME_ATTACHMENT");
				jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(),
						"http://www.caiso.com/soa/broadcastMVTNodalConstraints_v1");
				jobDataMap.put(QuartzProperty.ATTACHMENT_NAME.getVal(), "MVTNodalConstraints_attachment");
				jobDataMap.put(QuartzProperty.SERVICE_NAME.getVal(), "broadcastNodalContraintsV1");
				jobDataMap.put(QuartzProperty.VALIDTA_AGAINST_SCHEMA.getVal(), "true");
				jobDataMap.put(QuartzProperty.SCHEMA_FILE.getVal(),
						"schema/NodalConstraints/NodalConstraints_v1/20161001/NodalConstraints_v1.xsd");

				JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
				JobDetail jobDetail = Mockito.mock(JobDetail.class);

				Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
				Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
				Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("broadcastNodalContraintsV1"));

				BroadcastMarketPriceCorrection<NodalConstraints> broadcastNodalContraintJob = new BroadcastMarketPriceCorrection<>();
				context.getAutowireCapableBeanFactory().autowireBean(broadcastNodalContraintJob);

				try {
					broadcastNodalContraintJob.executeInternal(jobContext);
				} catch (JobExecutionException e) {
					e.printStackTrace();
				}
				Assert.assertTrue(true);

			}
		};
	}
	private static BroadcastJobCommand getBroadcastRUCResourceAwardsClearing(){
		return new BroadcastJobCommand() {
			
			@Override
			public void executeJob() {
				JobDataMap jobDataMap = new JobDataMap();

				jobDataMap.put(QuartzProperty.URI.getVal(),
						"http://fqapjbos191.ete.wepex.net:4400/sst/runtime.asvc/BroadcastMVTRucAwards_MVTv1_AP");
				jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), "MIME_ATTACHMENT");
				jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "http://www.caiso.com/soa/broadcastMVTRucAwards_v1");
				jobDataMap.put(QuartzProperty.ATTACHMENT_NAME.getVal(), "MVTRucAwards_attachment");
				jobDataMap.put(QuartzProperty.SERVICE_NAME.getVal(), "broadcastRUCResourceAwardClearingV1");
				jobDataMap.put(QuartzProperty.VALIDTA_AGAINST_SCHEMA.getVal(), "true");
				jobDataMap.put(QuartzProperty.SCHEMA_FILE.getVal(),
						"schema/RUCAwards/RUCResourceAwards_v1/20161001/RUCResourceAwards_v1.xsd");

				JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
				JobDetail jobDetail = Mockito.mock(JobDetail.class);

				Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
				Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
				Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("broadcastRUCResourceAwardClearingV1"));

				BroadcastMarketPriceCorrection<RUCResourceAwards> broadcastRUCResourceAwardJob = new BroadcastMarketPriceCorrection<>();
				context.getAutowireCapableBeanFactory().autowireBean(broadcastRUCResourceAwardJob);

				try {
					broadcastRUCResourceAwardJob.executeInternal(jobContext);
				} catch (JobExecutionException e) {
					e.printStackTrace();
				}
				Assert.assertTrue(true);

				
			}
		};
	}
	private static BroadcastJobCommand getBroadcastMitigatedBidSet(){
		return new BroadcastJobCommand(){
			@Override
			public void executeJob() {
				JobDataMap jobDataMap =  new JobDataMap();
		        
		    	jobDataMap.put(QuartzProperty.URI.getVal(), "http://fqapjbos191.ete.wepex.net:4400/sst/runtime.asvc/BroadcastMVTMitigatedBidSet_MVTv1_AP");
		    	jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), "MIME_ATTACHMENT");
		    	jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "http://www.caiso.com/soa/broadcastMVTMitigatedBidSet_v1");
		    	jobDataMap.put(QuartzProperty.ATTACHMENT_NAME.getVal(), "MVTBidSet_attachment");
		    	jobDataMap.put(QuartzProperty.SERVICE_NAME.getVal(), "broadcastMitigatedBidSetV1");
		    	jobDataMap.put(QuartzProperty.VALIDTA_AGAINST_SCHEMA.getVal(), "true");
		    	jobDataMap.put(QuartzProperty.SCHEMA_FILE.getVal(), "schema/MitigatedBidSet/MitigatedBidSet_v1/20161001/MitigatedBidSet_v1.xsd");
		        
		    	JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
		        JobDetail jobDetail = Mockito.mock(JobDetail.class);
		        
		                       
		        
		        Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
		        Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
		        Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("broadcastMitigatedBidSetV1"));
		          
		    	BroadcastMarketPriceCorrection<MitigatedBidSet> resourceAwardJob = new BroadcastMarketPriceCorrection<>();
		    	context.getAutowireCapableBeanFactory().autowireBean(resourceAwardJob);
		    	
		    	try {
					resourceAwardJob.executeInternal(jobContext);
				} catch (JobExecutionException e) {
					e.printStackTrace();
				}
		    	Assert.assertTrue(true);

				
			}
		};
	}
	private static BroadcastJobCommand getBroadcastCommitment(){
		return new BroadcastJobCommand(){
			@Override
			public void executeJob() {
				JobDataMap jobDataMap =  new JobDataMap();
		        
		    	jobDataMap.put(QuartzProperty.URI.getVal(), "http://fqapjbos191.ete.wepex.net:4400/sst/runtime.asvc/BroadcastMVTCommitment_MVTv1_AP");
		    	jobDataMap.put(QuartzProperty.BROADCAST_TYPE.getVal(), "MIME_ATTACHMENT");
		    	jobDataMap.put(QuartzProperty.SOAP_ACTION.getVal(), "http://www.caiso.com/soa/broadcastMVTCommitment_v1");
		    	jobDataMap.put(QuartzProperty.ATTACHMENT_NAME.getVal(), "MVTCommitment_attachment");
		    	jobDataMap.put(QuartzProperty.SERVICE_NAME.getVal(), "broadcastCommitmentV1");
		    	jobDataMap.put(QuartzProperty.VALIDTA_AGAINST_SCHEMA.getVal(), "true");
		    	jobDataMap.put(QuartzProperty.SCHEMA_FILE.getVal(), "schema/InstructionCommitment/Commitment_v1/20161001/Commitment_v1.xsd");
		        
		    	JobExecutionContext jobContext = Mockito.mock(JobExecutionContext.class);
		        JobDetail jobDetail = Mockito.mock(JobDetail.class);
		        
		                       
		        
		        Mockito.when(jobContext.getJobDetail()).thenReturn(jobDetail);
		        Mockito.when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);
		        Mockito.when(jobDetail.getKey()).thenReturn(new JobKey("broadcastCommitmentV1"));
		          
		    	BroadcastMarketPriceCorrection<Commitment> broadcastCommitmentJob = new BroadcastMarketPriceCorrection<>();
		    	context.getAutowireCapableBeanFactory().autowireBean(broadcastCommitmentJob);
		    	
		    	try {
		    		broadcastCommitmentJob.executeInternal(jobContext);
				} catch (JobExecutionException e) {
					e.printStackTrace();
				}
		    	Assert.assertTrue(true);

				
			}
		};
	}

	public static void setAppicationContext(ApplicationContext context2) {
		 context= context2;
	}
}
