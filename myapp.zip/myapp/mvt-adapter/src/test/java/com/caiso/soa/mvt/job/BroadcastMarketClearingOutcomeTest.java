package com.caiso.soa.mvt.job;

public class BroadcastMarketClearingOutcomeTest extends BroadcastMarketPriceCorrectionTest{
		
	public String getJobName() {
		return "broadcastMarketClearingOutcomeV4";
	}	
	
}
