package com.caiso.soa.mvt.job;

public class BroadcastMitigatedBidSetTest extends BroadcastMarketPriceCorrectionTest{

	@Override
	public String getJobName() {
		return "broadcastMitigatedBidSetV1";
	}
   
}
