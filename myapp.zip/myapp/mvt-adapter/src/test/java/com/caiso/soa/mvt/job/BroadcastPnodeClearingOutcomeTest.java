package com.caiso.soa.mvt.job;

public class BroadcastPnodeClearingOutcomeTest extends BroadcastMarketPriceCorrectionTest{

	@Override
	public String getJobName() {
		return "broadcastPnodeClearingOutcomeV2";
	}

}
