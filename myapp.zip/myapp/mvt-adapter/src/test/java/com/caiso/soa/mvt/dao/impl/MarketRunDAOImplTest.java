package com.caiso.soa.mvt.dao.impl;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.soa.mvt.config.MvtApplicationConfig;
import com.caiso.soa.mvt.dao.MarketRunDAO;
import com.caiso.soa.mvt.domain.MvtPriceCorrectionDTO;



@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(MvtApplicationConfig.class)
@WebIntegrationTest()
@Rollback
@Transactional
public class MarketRunDAOImplTest {
	
	@Autowired
    public MarketRunDAO markertRunDAO;
	
    @PostConstruct
    public void init() {
        System.getProperties().put("spring.config.location", MarketRunDAO.class.getResource("/application.properties").getFile());
    }


    @Before
    public void setUp() {
        
    }

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void testGetData() throws IOException, DatatypeConfigurationException {
    	List<MvtPriceCorrectionDTO> result = markertRunDAO.getPendingMarketRunInputData("NEW", "broadcastResourceAwardClearingV4");
    	System.out.println(result.isEmpty());	
    	
    	Assert.assertTrue(true);
    }

}
