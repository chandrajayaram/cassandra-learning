package com.caiso.soa.mvt.job;

import java.io.IOException;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.soa.mvt.config.MvtApplicationConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(MvtApplicationConfig.class)
@WebIntegrationTest()
@Rollback
@Transactional
public class BroadcastMarketPriceCorrectionTest {
	@Autowired
	public ApplicationContext context;

	@PostConstruct
	public void init() {
		System.getProperties().put("spring.config.location",
				BroadcastMarketPriceCorrectionTest.class.getResource("/application.properties").getFile());
		BroadcastJobCommandFactory.setAppicationContext(context);
	}

	@Before
	public void setUp() {
		TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
	}
	@Test
	public void testBroadcast() throws IOException, DatatypeConfigurationException {
		String jobName= getJobName();
		if(jobName!=null){
			BroadcastJobCommand command = BroadcastJobCommandFactory.getJobInstance(jobName);
			command.executeJob();	
		}
	}

	public String getJobName() {
		return null;
	}	

}
