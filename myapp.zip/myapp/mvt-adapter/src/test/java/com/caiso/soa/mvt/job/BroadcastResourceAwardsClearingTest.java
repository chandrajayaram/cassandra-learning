package com.caiso.soa.mvt.job;

public class BroadcastResourceAwardsClearingTest extends BroadcastMarketPriceCorrectionTest {

	@Override
	public String getJobName() {
		return "broadcastResourceAwardClearingV4";
	}

}
