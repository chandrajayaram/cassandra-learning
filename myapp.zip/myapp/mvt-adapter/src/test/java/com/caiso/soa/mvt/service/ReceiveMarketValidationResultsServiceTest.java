package com.caiso.soa.mvt.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.soa.marketvalidationresults_v1.MarketValidation;
import com.caiso.soa.marketvalidationresults_v1.PassIndicatorType;
import com.caiso.soa.marketvalidationresults_v1.RuleViolation;
import com.caiso.soa.marketvalidationresults_v1.ViolationData;
import com.caiso.soa.mvt.config.MvtApplicationConfig;
import com.caiso.soa.mvt.dao.MarketValidationsDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(MvtApplicationConfig.class)
@WebIntegrationTest()
@Configuration
public class ReceiveMarketValidationResultsServiceTest {

	@Autowired
	private MarketValidationsDAO marketValidationsDAO;
	
	/**
	 * <?xml version="1.0" encoding="UTF-8"?>
	<MarketValidationResults>
		<MessageHeader>
			<TimeDate>2001-12-17T09:30:47Z</TimeDate>
			<Source>String</Source>
			<Version>v20131001</Version>
		</MessageHeader>
		<MessagePayload>
			<MarketRun>
				<contingencyActive>YES</contingencyActive>
				<contingencyType>String</contingencyType>
				<executionType>RTPD</executionType>
				<marketEndTime>2001-12-17T09:30:47Z</marketEndTime>
				<marketID>String</marketID>
				<marketRunID>String</marketRunID>
				<marketStartTime>2001-12-17T09:30:47Z</marketStartTime>
				<marketType>RTM</marketType>
				<masterFileRepositoryVersion>String</masterFileRepositoryVersion>
				<pathExclusions>String</pathExclusions>
			</MarketRun>
			<MarketValidation>
				<intervalStartTime>2001-12-17T09:30:47Z</intervalStartTime>
				<passIndicator>RUC</passIndicator>
				<rulesValidated>0</rulesValidated>
				<rulesViolated>0</rulesViolated>
				<RuleViolation>
					<validationRule>0</validationRule>
					<violationObject>String</violationObject>
					<ViolationData>
						<elementName>String</elementName>
						<elementValue>String</elementValue>
					</ViolationData>
				</RuleViolation>
			</MarketValidation>
		</MessagePayload>
	</MarketValidationResults>
	 * @throws DatatypeConfigurationException 

	 */
	
	@Test
	public void testMarketValidations() throws DatatypeConfigurationException {
		
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(new Date());
		XMLGregorianCalendar date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		
		List<MarketValidation> marketValidations = new ArrayList<MarketValidation>(1);
		MarketValidation mktValidation = new MarketValidation();
		RuleViolation ruleViolation = new RuleViolation();
		ViolationData violationData = new ViolationData();
		
		mktValidation.setIntervalStartTime(date);
		mktValidation.setPassIndicator(PassIndicatorType.HA_SCUC);
		mktValidation.setRulesValidated(BigInteger.valueOf(10));
		mktValidation.setRulesViolated(BigInteger.valueOf(2));
		
		ruleViolation.setValidationRule(BigInteger.valueOf(1));
		ruleViolation.setViolationObject("TEST");
		
		violationData = new ViolationData();
		violationData.setElementName("TEST1");
		violationData.setElementValue("TEST2");
		ruleViolation.getViolationDatas().add(violationData);
		
		violationData = new ViolationData();
		violationData.setElementName("TEST1");
		violationData.setElementValue("TEST2");
		ruleViolation.getViolationDatas().add(violationData);
		mktValidation.getRuleViolations().add(ruleViolation);
		
		//2nd rule violation
		ruleViolation = new RuleViolation();
		ruleViolation.setValidationRule(BigInteger.valueOf(1));
		ruleViolation.setViolationObject("TEST");
		violationData = new ViolationData();
		violationData.setElementName("TEST1");
		violationData.setElementValue("TEST2");
		ruleViolation.getViolationDatas().add(violationData);
		
		violationData = new ViolationData();
		violationData.setElementName("TEST1");
		violationData.setElementValue("TEST2");
		ruleViolation.getViolationDatas().add(violationData);
		mktValidation.getRuleViolations().add(ruleViolation);
		
		marketValidations.add(mktValidation);
		
		marketValidationsDAO.saveMarketValidations(marketValidations, 123L, Calendar.getInstance());
	}

}
