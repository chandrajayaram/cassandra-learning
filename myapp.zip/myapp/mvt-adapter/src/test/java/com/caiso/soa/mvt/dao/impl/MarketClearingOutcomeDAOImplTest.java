package com.caiso.soa.mvt.dao.impl;

import static com.caiso.soa.mvt.util.MarshallingUtil.toXml;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.caiso.soa.marketclearingoutcome_v4.MarketClearingOutcome;
import com.caiso.soa.mvt.config.MvtApplicationConfig;
import com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(MvtApplicationConfig.class)
@WebIntegrationTest()
@Rollback
@Transactional
public class MarketClearingOutcomeDAOImplTest {
	
	@Autowired
	@Qualifier("broadcastMarketClearingOutcomeV4")
	MarketPriceCorrectionDAO<MarketClearingOutcome> marketClearingOutcomeDAO;

	
	
    @PostConstruct
    public void init() {
        System.getProperties().put("spring.config.location", MarketPriceCorrectionDAO.class.getResource("/application.properties").getFile());
    }


    @Before
    public void setUp() {
    	 TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
    }

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void testBroadcastMarketClearingOutcomeV4() throws IOException, DatatypeConfigurationException {
    	Calendar cal = Calendar.getInstance();
    	cal.setTimeInMillis(0);
    	cal.set(2016, 01, 20, 0, 0, 0);
    	Date date = cal.getTime(); // get back a Date object
    	cal.add(Calendar.DAY_OF_MONTH,1);
    	Date endDate =  cal.getTime(); 
    	List<MarketClearingOutcome>  marketList = marketClearingOutcomeDAO.getPayload(date,endDate, "RTPD");
  		toXml(marketList,"marketClearing");
    	Assert.assertTrue(true);
    }

    
}
