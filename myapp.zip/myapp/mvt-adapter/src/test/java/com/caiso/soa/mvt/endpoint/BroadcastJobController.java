package com.caiso.soa.mvt.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.caiso.soa.mvt.job.BroadcastJobCommandFactory;

@Controller
@RequestMapping("/broadcast")
public class BroadcastJobController {
	private static final String template = "Job %s! was triggered for testing";
    
	@Autowired
	public ApplicationContext context;
	
    @RequestMapping(method=RequestMethod.GET)
    
    public @ResponseBody String testJob(@RequestParam(value="name", required=true) String name) {
    	BroadcastJobCommandFactory.setAppicationContext(context);
    	BroadcastJobCommandFactory.getJobInstance(name).executeJob();
        return String.format(template, name);
    }

}
