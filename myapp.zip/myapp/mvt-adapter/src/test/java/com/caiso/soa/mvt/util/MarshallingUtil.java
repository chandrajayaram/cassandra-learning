package com.caiso.soa.mvt.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.util.JAXBSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.SAXException;

import com.caiso.soa.commitment_v1.Commitment;
import com.caiso.soa.nodalconstraints_v1.NodalConstraints;
import com.caiso.soa.pnodeclearingoutcome_v2.PnodeClearingOutcome;
import com.caiso.soa.resourceawards_v4.ResourceAwards;
import com.caiso.soa.rucresourceawards_v1.RUCResourceAwards;


public class MarshallingUtil {

	private static JAXBContext ctx;
	private static Marshaller marshaller;
	private static Unmarshaller unMarshaller;
	
	static{
		try {
			ctx = JAXBContext.newInstance(com.caiso.soa.resourceawards_v4.ResourceAwards.class, com.caiso.soa.marketclearingoutcome_v4.MarketClearingOutcome.class,PnodeClearingOutcome.class, NodalConstraints.class,RUCResourceAwards.class,com.caiso.soa.mitigatedbidset_v1.MitigatedBidSet.class,Commitment.class );
			marshaller = ctx.createMarshaller();
			unMarshaller = ctx.createUnmarshaller(); 
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}
	
	public static <T> void toXml(List<T> payloads,String serviceName){
		    try {
	        	
	        	marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	            int i=0;
	        	for(T payload: payloads){
	        		FileOutputStream fout = new FileOutputStream(new File("E:\\app\\oasis_data\\"+ serviceName+"_"+ ++i +".xml"));  
	                marshaller.marshal(payload, fout);	
	        	}
	        	
	        }
	        catch (Exception e) {
	        	e.printStackTrace();
	        }
	}
	public static Object getObject(String message, Date startDate, String marketType){
	    try {
        	SimpleDateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy");
        	String date = fmt.format(startDate);
        	String fileName = message +"_"+date+"_"+marketType+".xml";
        	InputStream inStream = MarshallingUtil.class.getClassLoader().getResourceAsStream("testdata/"+fileName);
        	return unMarshaller.unmarshal(inStream);
        }
        catch (Exception e) {
        	e.printStackTrace();
        }
	    return null;
}
	
	
	public void test() throws SAXException, JAXBException, IOException {
		SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		URL fileURL = this.getClass().getResource("/schema/ResourceAwards/ResourceAwards_v4/20161001/ResourceAwards_v4.xsd");
			
		Schema schema = sf
				.newSchema(fileURL);
		
		ResourceAwards data = new ResourceAwards();
		JAXBSource source = null;
		Validator validator = schema.newValidator();
		source = new JAXBSource(ctx, data);
			try {
				validator.validate(source);
			} catch (SAXException ex) {
				System.out.println("Validation Exception");
			}
	}
	public static void main(String[] args) throws SAXException, JAXBException, IOException {
		new MarshallingUtil().test();
	}
	
}
