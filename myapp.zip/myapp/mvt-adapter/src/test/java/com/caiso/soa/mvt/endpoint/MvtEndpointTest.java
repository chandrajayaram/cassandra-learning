package com.caiso.soa.mvt.endpoint;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.caiso.soa.mvt.config.MvtApplicationConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(MvtApplicationConfig.class)
@WebIntegrationTest()
@Rollback
@Transactional
public class MvtEndpointTest {

    @PostConstruct
    public void init() {
        System.getProperties().put("spring.config.location",
                MvtEndpointTest.class.getResource("/application.properties").getFile());
    }

    private WebServiceTemplate webServiceTemplate = new WebServiceTemplate();

    @Value("${server.port}")
    private int serverPort;

    @Before
    public void setUp() {
        this.webServiceTemplate.setDefaultUri("http://localhost:" + this.serverPort + "/caiso/SyncMessagingService/");
    }

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void testReceiveMarketValidationResults_v1() throws IOException {
        boolean status = this.webServiceTemplate.sendAndReceive(new WebServiceMessageCallback() {

            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                setMessageWithMimeAttachment(message, "http://www.caiso.com/soa/receiveMarketValidationResults_v1", "receiveMarketValidationResults_v1");
            }
        }, new WebServiceMessageCallback() {

            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                checkResponseStatus(message);
            }
        });
        Assert.assertTrue(status);
    }

    @Ignore
    public void testReceiveMarketValidationResults_huge_v1() throws IOException {
        boolean status = this.webServiceTemplate.sendAndReceive(new WebServiceMessageCallback() {

            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                setMessageWithMimeAttachment(message, "http://www.caiso.com/soa/receiveMarketValidationResults_v1", "receiveMarketValidationResults_huge_v1");
            }
        }, new WebServiceMessageCallback() {

            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
                checkResponseStatus(message);
            }
        });
        Assert.assertTrue(status);
    }

    /**
     * Helper method to validate that response is success.
     * 
     * @param message
     */
    private void checkResponseStatus(WebServiceMessage message) {
        SoapMessage soapMessage = (SoapMessage) message;
        QName faultCode = soapMessage.getFaultCode();
        Assert.assertNull("Response has fault code.", faultCode);
    }

    /**
     * Helper method to configure the outgoing soap message.
     * 
     * @param message
     * @param soapAction
     * @param serviceName
     */
    private void setMessageWithMimeAttachment(WebServiceMessage message, String soapAction, String serviceName) {
        try {
            SoapMessage soapMessage = (SoapMessage) message;
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(new ClassPathResource("receives/" + serviceName + "_header.xml").getFile());

            soapMessage.setSoapAction(soapAction);

            NodeList childNodes = doc.getChildNodes().item(0).getChildNodes();
            for (int i = 0; i < childNodes.getLength(); i++) {
                Node node = childNodes.item(i);
                TransformerFactory.newInstance().newTransformer().transform(new DOMSource(node),
                        soapMessage.getSoapHeader().getResult());

            }

            StreamSource bodySource = new StreamSource(
                    new ClassPathResource("receives/" + serviceName + "_body.xml").getInputStream());
            TransformerFactory.newInstance().newTransformer().transform(bodySource, soapMessage.getPayloadResult());

            soapMessage.addAttachment("test",
                    new ClassPathResource("receives/attachment/" + serviceName + ".uue").getFile());
        } catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

    /**
     * Helper method to configure the outgoing soap message.
     * 
     * @param message
     * @param soapAction
     * @param serviceName
     */
    private void setMessageWithDocAttachment(WebServiceMessage message, String soapAction, String serviceName) {
        try {
            SoapMessage soapMessage = (SoapMessage) message;
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(new ClassPathResource("receives/" + serviceName + "_header.xml").getFile());

            soapMessage.setSoapAction(soapAction);

            NodeList childNodes = doc.getChildNodes().item(0).getChildNodes();
            for (int i = 0; i < childNodes.getLength(); i++) {
                Node node = childNodes.item(i);
                TransformerFactory.newInstance().newTransformer().transform(new DOMSource(node),
                        soapMessage.getSoapHeader().getResult());

            }
            StreamSource bodySource = new StreamSource(
                    new ClassPathResource("receives/" + serviceName + "_body.xml").getInputStream());
            TransformerFactory.newInstance().newTransformer().transform(bodySource, soapMessage.getPayloadResult());
        } catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

}
