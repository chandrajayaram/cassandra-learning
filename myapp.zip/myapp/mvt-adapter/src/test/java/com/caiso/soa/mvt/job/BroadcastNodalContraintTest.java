package com.caiso.soa.mvt.job;


public class BroadcastNodalContraintTest extends BroadcastMarketPriceCorrectionTest{

	@Override
	public String getJobName() {
		return "broadcastNodalContraintsV1";
	}

}
