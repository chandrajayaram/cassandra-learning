package com.caiso.soa.mvt.job;


public class BroadcastRUCResourceAwardsClearingTest extends BroadcastMarketPriceCorrectionTest{

	@Override
	public String getJobName() {
		return "broadcastRUCResourceAwardClearingV1";
	}

}
