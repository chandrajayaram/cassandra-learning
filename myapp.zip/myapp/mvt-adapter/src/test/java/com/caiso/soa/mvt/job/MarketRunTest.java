package com.caiso.soa.mvt.job;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

public class MarketRunTest {

	public static void main(String[] args) {
		DataSource ds = DataSourceBuilder.create().driverClassName("oracle.jdbc.OracleDriver")
				.url("jdbc:oracle:thin:@fqdb113.ete.wepex.net:1524:MRTQ4").username("MKT_NOTES_MSTR")
				.password("b0l0gna").build();
		
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("SERVICE_NAME", "broadcastResourceAwardClearingv4");
		paramSource.addValue("STATUS", "NEW");
		
		
		NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate  (ds);
		
		SqlRowSet mktInputRs = template.queryForRowSet("SELECT  ID, START_DATE, END_DATE, STATUS FROM MVT_PUB_PRICE_CORRECTION WHERE SERVICE_NAME = :SERVICE_NAME AND STATUS=:STATUS", paramSource);
		while(mktInputRs.next()){
			System.out.println(mktInputRs.getLong("ID"));
		}
	}

}
