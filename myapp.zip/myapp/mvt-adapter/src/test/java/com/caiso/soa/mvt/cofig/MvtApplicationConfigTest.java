package com.caiso.soa.mvt.cofig;

import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.web.SpringBootServletInitializer;

import com.caiso.soa.mvt.config.MvtApplicationConfig;

@SpringBootApplication
public class MvtApplicationConfigTest extends SpringBootServletInitializer {
    public static final Logger logger = LoggerFactory.getLogger(MvtApplicationConfig.class);

    public static void main(String[] args) {
    	// set default timezone if not already specified
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        logger.info("JVM user time zone is defined: {}", TimeZone.getDefault().getID());
        SpringApplication.run(MvtApplicationConfig.class, args);
    }
}
