package com.caiso.soa.mvt.util;

import java.sql.Timestamp;
import java.util.Calendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;

import com.caiso.soa.framework.utils.SOAPUtils;

/**
 * The Class MvtUtil is the application scope util class.
 */
public class MvtUtil {
	
	private MvtUtil(){
		
	}
	/**
	 * Gets the calendar.
	 *
	 * @param ts the ts
	 * @return the calendar
	 * @throws DatatypeConfigurationException the datatype configuration exception
	 */
	public static XMLGregorianCalendar getCalendar(Timestamp ts) throws DatatypeConfigurationException {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(ts);
		return SOAPUtils.convert(calendar);
	}
	
}
