/**
 * 
 */
package com.caiso.soa.mvt.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Repository;

import com.caiso.soa.marketvalidationresults_v1.MarketRun;
import com.caiso.soa.marketvalidationresults_v1.MarketValidation;
import com.caiso.soa.marketvalidationresults_v1.RuleViolation;
import com.caiso.soa.marketvalidationresults_v1.ViolationData;
import com.caiso.soa.mvt.dao.MarketValidationsDAO;

/**
 * @author kchitturi
 *
 */
@Repository
public class MaketValidationsDAOImpl implements MarketValidationsDAO {

	public static final String MSG_PAYLOAD_INSERT_SQL = "Insert into MVT_INT.R_MVR_MESSAGEPAYLOAD (MESSAGEPAYLOAD_ID, STG_LOAD_TS, STG_SERVICE_NAME) Values (?, ?, ? )";
	
	public static final String MVR_MARKETRUN_INSERT_SQL = "Insert into MVT_INT.R_MVR_MARKETRUN (MARKETRUN_ID, MESSAGEPAYLOAD_ID, CONTINGENCYACTIVE, CONTINGENCYTYPE, EXECUTIONTYPE, MARKETENDTIME, MARKETID, MARKETRUNID, MARKETSTARTTIME, MARKETTYPE, MASTERFILEREPOSITORYVERSION, PATHEXCLUSIONS, STG_LOAD_TS) Values (R_MVR_SEQ.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
	
	public static final String MVR_MARKETVAL_INSERT_SQL = "Insert into MVT_INT.R_MVR_MARKETVALIDATION (MESSAGEPAYLOAD_ID, INTERVALSTARTTIME, PASSINDICATOR, RULESVALIDATED, RULESVIOLATED, STG_LOAD_TS,MARKETVALIDATION_ID) Values (?,?,?,?,?,?,?)";
	
	public static final String MVR_RULEVIOLATION_INSERT_SQL = "Insert into MVT_INT.R_MVR_RULEVIOLATION (MARKETVALIDATION_ID, VALIDATIONRULE, VIOLATIONOBJECT, STG_LOAD_TS, RULEVIOLATION_ID)Values(?,?,?,?,?)";
	
	public static final String MVR_VIOLATIONDATA_INSERT_SQL = "Insert into MVT_INT.R_MVR_VIOLATIONDATA (RULEVIOLATION_ID, ELEMENTNAME, ELEMENTVALUE, STG_LOAD_TS, VIOLATIONDATA_ID) Values (?, ?, ?, ?, ?)";
	
	@Autowired
    @Qualifier("mvtJdbcTemplate")
    private JdbcTemplate template;

    private Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public Long saveMessage(final String serviceName, final Calendar cal) {
		log.info("saveMessage: " + serviceName + " BEGIN ");
		
		final Long messagePayLoadId = getNextValueForSequence();
		
		template.execute(MSG_PAYLOAD_INSERT_SQL,new PreparedStatementCallback<Boolean>(){  
			    @Override  
			    public Boolean doInPreparedStatement(PreparedStatement ps)   throws SQLException, DataAccessException {  
			        ps.setLong(1,messagePayLoadId);  
			        ps.setTimestamp(2, new Timestamp(cal.getTimeInMillis()));  
			        ps.setString(3,serviceName);  
			        return ps.execute();  
			    }  
		});  
	
		log.info("saveMessage: " + serviceName + "Message PayLoadID :" + messagePayLoadId + " END ");
		return messagePayLoadId;
	}

	@Override
	public Long saveMarketRun(final MarketRun marketRun, final Long payLoadId, final Calendar cal) {
		log.info("saveMarketRun: BEGIN ");
		
		template.execute(MVR_MARKETRUN_INSERT_SQL,new PreparedStatementCallback<Boolean>(){  
			    @Override  
			    public Boolean doInPreparedStatement(PreparedStatement ps)   throws SQLException, DataAccessException {  
			        ps.setLong(1,payLoadId);
			        ps.setString(2, marketRun.getContingencyActive().value());
			        ps.setString(3, marketRun.getContingencyType());
			        ps.setString(4, marketRun.getExecutionType().value());
			        ps.setTimestamp(5, new Timestamp(marketRun.getMarketEndTime().toGregorianCalendar().getTimeInMillis()));
			        ps.setString(6, marketRun.getMarketID());
			        ps.setString(7, marketRun.getMarketRunID());
			        ps.setTimestamp(8, new Timestamp(marketRun.getMarketStartTime().toGregorianCalendar().getTimeInMillis()));
			        ps.setString(9, marketRun.getMarketType().value());
			        ps.setString(10, marketRun.getMasterFileRepositoryVersion());
			        ps.setString(11, marketRun.getPathExclusions());
			        ps.setTimestamp(12, new Timestamp(cal.getTimeInMillis()));  
			        return ps.execute();  
			    }  
		});  
	
		log.info("saveMarketRun: END ");
		return null;
	}

//	@Override
//	public void saveMarketValidations(final List<MarketValidation> marketValidations, final Long messagePayloadId,final Calendar cal) {
//		log.info("saveMarketValidations: BEGIN ");
//		
//		 template.batchUpdate(MVR_MARKETVAL_INSERT_SQL, new BatchPreparedStatementSetter() {
//			 	MarketValidation marketValidation;
//	            @Override
//	            public void setValues(PreparedStatement ps, int i) throws SQLException {
//	                marketValidation = marketValidations.get(i);
//	                ps.setLong(1, messagePayloadId);
//	                ps.setTimestamp(2, new Timestamp(marketValidation.getIntervalStartTime().toGregorianCalendar().getTimeInMillis()));
//	                ps.setString(3, marketValidation.getPassIndicator().value());
//	                ps.setInt(4, marketValidation.getRulesValidated().intValue());
//	                ps.setInt(5, marketValidation.getRulesViolated().intValue());
//	                ps.setTimestamp(6, new Timestamp(cal.getTimeInMillis()));
//	                
//	                final List<RuleViolation> ruleViolations = marketValidation.getRuleViolations();
//	                
//	                template.batchUpdate(MVR_RULEVIOLATION_INSERT_SQL, new BatchPreparedStatementSetter() {
//	                	RuleViolation ruleViolation;
//	    	            @Override
//	    	            public void setValues(PreparedStatement ps, int i) throws SQLException {
//	    	                
//	    	            	ruleViolation = ruleViolations.get(i);
//	    	                
//	    	                ps.setInt(1, ruleViolation.getValidationRule().intValue());
//	    	                ps.setString(2, ruleViolation.getViolationObject());
//	    	                ps.setTimestamp(3, new Timestamp(cal.getTimeInMillis()));
//	    	                
//	    	                final List<ViolationData> violationData = ruleViolation.getViolationDatas();
//	    	                
//	    	                template.batchUpdate(MVR_VIOLATIONDATA_INSERT_SQL, new BatchPreparedStatementSetter() {
//	    	                	ViolationData violationRec;
//	    	    	            @Override
//	    	    	            public void setValues(PreparedStatement ps, int i) throws SQLException {
//	    	    	                
//	    	    	            	violationRec = violationData.get(i);
//	    	    	                
//	    	    	                ps.setString(1, violationRec.getElementName());
//	    	    	                ps.setString(2, violationRec.getElementValue());
//	    	    	                ps.setTimestamp(3, new Timestamp(cal.getTimeInMillis()));
//	    	    	            }
//
//	    	    	            @Override
//	    	    	            public int getBatchSize() {
//	    	    	                return violationData.size();
//	    	    	            }
//	    	    	        });
//	    	                
//	    	            }
//
//	    	            @Override
//	    	            public int getBatchSize() {
//	    	                return ruleViolations.size();
//	    	            }
//	    	        });
//	            }
//
//	            @Override
//	            public int getBatchSize() {
//	                return marketValidations.size();
//	            }
//	        });
//		
//		log.info("saveMarketValidations: END ");
//	}
	
	@Override
	public void saveMarketValidations(final List<MarketValidation> marketValidations, final Long messagePayloadId,final Calendar cal) {
		log.info("saveMarketValidations: BEGIN ");
		DataSource ds = template.getDataSource();
		
		PreparedStatement ps= null;
		PreparedStatement ps2= null;
		PreparedStatement ps3= null;
		try{
			Connection connection = ds.getConnection();
			connection.setAutoCommit(false);
			
			ps = connection.prepareStatement(MVR_MARKETVAL_INSERT_SQL);
			ps2 = connection.prepareStatement(MVR_RULEVIOLATION_INSERT_SQL);
			ps3 = connection.prepareStatement(MVR_VIOLATIONDATA_INSERT_SQL);
			
			for (MarketValidation marketValidation: marketValidations){
				Long mktValidationId = getNextValueForSequence();
				ps.setLong(1, messagePayloadId);
				ps.setTimestamp(2, new Timestamp(marketValidation.getIntervalStartTime().toGregorianCalendar().getTimeInMillis()));
	            ps.setString(3, marketValidation.getPassIndicator().value());
	            ps.setInt(4, marketValidation.getRulesValidated().intValue());
	            ps.setInt(5, marketValidation.getRulesViolated().intValue());
	            ps.setTimestamp(6, new Timestamp(cal.getTimeInMillis()));
	            ps.setLong(7, mktValidationId);
	            ps.addBatch();
	            
	            List<RuleViolation> ruleViolations = marketValidation.getRuleViolations();
	            for(RuleViolation ruleViolation: ruleViolations){
	            	Long ruleViolationId = getNextValueForSequence();
	            	ps2.setLong(1, mktValidationId);
	            	ps2.setInt(2, ruleViolation.getValidationRule().intValue());
	                ps2.setString(3, ruleViolation.getViolationObject());
	                ps2.setTimestamp(4, new Timestamp(cal.getTimeInMillis()));
	                ps2.setLong(5, ruleViolationId);
	                ps2.addBatch();
	                
	                List<ViolationData> violationData = ruleViolation.getViolationDatas();
	                for(ViolationData violationRec: violationData){
	                	Long violationDataId = getNextValueForSequence();
	                	ps3.setLong(1, ruleViolationId);
	                	ps3.setString(2, violationRec.getElementName());
		                ps3.setString(3, violationRec.getElementValue().trim());
		                ps3.setTimestamp(4, new Timestamp(cal.getTimeInMillis()));
		                ps3.setLong(5, violationDataId);
		                ps3.addBatch();
	                }//End ViolationData
	            }//End RuleViolation
	        }//End MarketValidations
			
			ps.executeBatch();
			ps2.executeBatch();
			ps3.executeBatch();
			connection.commit();
		}catch(SQLException e){
			log.error("Error while inserting Market Validaton Data");
			e.printStackTrace();
		}finally{
			if(null!= ps){
				try {ps.close();} catch (SQLException e){ e.printStackTrace();}
		    }
			if(null!= ps2){
				try {ps2.close();} catch (SQLException e){ e.printStackTrace();}
		    }
			if(null!= ps3){
				try {ps3.close();} catch (SQLException e){ e.printStackTrace();}
		    }
		}
		
		log.info("saveMarketValidations: END ");
	}
	

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Long getNextValueForSequence() {

		return (Long) template.execute(
		new PreparedStatementCreator() {
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				return connection.prepareStatement("SELECT R_MVR_SEQ.nextval FROM DUAL");
			}
		},
		new PreparedStatementCallback() {
			public Object doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				ResultSet rs = ps.executeQuery();
				Long value = null;
				while(rs.next()) {
					value = rs.getLong(1);
				}
				return value;
			}
		});
	}
		
}
