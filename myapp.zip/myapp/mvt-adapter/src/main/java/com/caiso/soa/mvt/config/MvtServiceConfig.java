package com.caiso.soa.mvt.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

import com.caiso.soa.framework.configuration.CAISOServiceConfiguration;

/**
 * The Class MvtServiceConfig contains bean definition of the configuration 
 */
@Configuration
@EnableWs
@ComponentScan({ "com.caiso.soa.mvt.endpoint", 
				 "com.caiso.soa.mvt.service", 
				 "com.caiso.soa.mvt.dao.impl",
				 "com.caiso.soa.framework.quartz", 
				 "com.caiso.soa.framework.dao",
				 "com.caiso.soa.mvt.broadcast.job"})
public class MvtServiceConfig extends CAISOServiceConfiguration {

    @Value("${mvt.quartz.autostart:true}")
    private boolean autoStart;

    /**
     * <p>
     * Register servlet to map to receive message.
     * </p>
     * Using /caiso/SyncMessagingService/ so that it is minimal change to AI.
     * Ideally it should be app specific URI.
     * 
     * @param applicationContext
     * @return
     */
    @Bean
    public ServletRegistrationBean dispatcherServlet(ApplicationContext applicationContext) {
        MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        return new ServletRegistrationBean(servlet, "/caiso/SyncMessagingService/*");
    }

    /**
     * Bean for Rest controller to support invoking quartz job
     * 
     * @param applicationContext
     * @return
     */
    @Bean
    public ServletRegistrationBean dispatcherRestServlet(ApplicationContext applicationContext) {
        DispatcherServlet servlet = new DispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        return new ServletRegistrationBean(servlet, "/*");
    }

    /**
     * SOAP 11 binding.
     * 
     * @param attachmentSchema
     * @return
     */
    @Bean(name = "MvtAdapterReceiver")
    public DefaultWsdl11Definition defaultWsdl11Definition(XsdSchema attachmentSchema) {
        DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
        wsdl11Definition.setPortTypeName("MvtAdapterReceiver");
        wsdl11Definition.setLocationUri("/caiso/SyncMessagingService/");
        wsdl11Definition.setTargetNamespace("http://www.caiso.com/soa");
        wsdl11Definition.setSchema(attachmentSchema);
        return wsdl11Definition;
    }

    /**
     * Not being used.
     * 
     * @return
     */
    @Bean
    public XsdSchema attachmentSchema() {
        return new SimpleXsdSchema(new ClassPathResource("schema/StandardOutput.xsd"));
    }

    /**
     * <p>
     * Defines the data source for mvt which is mapped from the attribute
     * spring.mvt.datasource in the property file.
     * </p>
     * <p>
     * This is app specific ds. The plugin does not use this.
     * </p>
     * 
     * @return
     */
    @Bean(name = "mvtDatasource")
    @Primary
    @ConfigurationProperties(prefix = "spring.mvt.datasource")
    public DataSource masterDataSource() {
        return DataSourceBuilder.create().build();
    }

    /**
     * <p>
     * Defines JDBC Template to be use the mvt.
     * </p>
     * <p>
     * This is app specific jdbc tempalte. The plugin does not use this.
     * </p>
     * 
     * @param mvtDatasource
     * @return
     */
    @Bean(name = "mvtJdbcTemplate")
    @Autowired
    public JdbcTemplate mvtJdbcTemplate(@Qualifier("mvtDatasource") DataSource mvtDatasource) {
        return new JdbcTemplate(mvtDatasource);
    }

    /**
     * <p>
     * Defines the data source for mvt which is mapped from the attribute
     * spring.mvt.datasource in the property file.
     * </p>
     * <p>
     * This is app specific ds. The plugin does not use this.
     * </p>
     * 
     * @return
     */
    @Bean(name = "mvtLmpDatasource")
    @ConfigurationProperties(prefix = "spring.mvt.lmp.datasource")
    public DataSource lmpDataSource() {
        return DataSourceBuilder.create().build();
    }

    /**
     * <p>
     * Defines JDBC Template to be use the mvt.
     * </p>
     * <p>
     * This is app specific jdbc tempalte. The plugin does not use this.
     * </p>
     * 
     * @param mvtLmpDatasource
     * @return
     */
    @Bean(name = "mvtLmpJdbcTemplate")
    @Autowired
    public NamedParameterJdbcTemplate mvtLmpJdbcTemplate(@Qualifier("mvtLmpDatasource") DataSource mvtLmpDatasource) {
        return new NamedParameterJdbcTemplate (mvtLmpDatasource);
    }
   
    /**
     * <p>
     * Defines the data source for mvt which is mapped from the attribute
     * spring.mvt.datasource in the property file.
     * </p>
     * <p>
     * This is app specific ds. The plugin does not use this.
     * </p>
     * 
     * @return
     */ 
    @Bean(name = "mktNotesDatasource")
    @ConfigurationProperties(prefix = "spring.mvt.mktnotes.datasource")
    public DataSource mktNotesDataSource() {
        return DataSourceBuilder.create().build();
    }
    
    /**
     * <p>
     * Defines JDBC Template to be use the mvt.
     * </p>
     * <p>
     * This is app specific jdbc tempalte. The plugin does not use this.
     * </p>
     * 
     * @param mktNotesDatasource
     * @return
     */
    @Bean(name = "mktNotesJdbcTemplate")
    @Autowired
    public NamedParameterJdbcTemplate marketNotesJdbcTemplate(@Qualifier("mktNotesDatasource") DataSource mktNotesDatasource) {
        return new NamedParameterJdbcTemplate (mktNotesDatasource);
    }
    
    /**
     * <p>
     * Defines the data source for quartz which is mapped from the attribute
     * spring.mvt.datasource in the property file.
     * </p>
     * <p>
     * This is optional. If defined, the quartz will be initialized by the
     * plugin.
     * </p>
     * 
     * @return
     */
    @Bean(name = "quartzDS")
    @ConfigurationProperties(prefix = "spring.mvt.datasource")
    public DataSource quartzDS() {
        return DataSourceBuilder.create().build();
    }

    /**
     * 
     * <p>
     * Define the jdbc template to allow the plugin to write log event into the
     * table (SOA_PROCESS_EVENT).
     * </p>
     * <p>
     * This is optional. If defined, the plugin in will write log event into the
     * table above.
     * </p>
     * 
     * @param mvtDatasource
     * @return
     */
    @Bean(name = "logEventJdbcTemplate")
    @Autowired
    public JdbcTemplate logEventJdbcTemplate(@Qualifier("mvtDatasource") DataSource mvtDatasource) {
        return new JdbcTemplate(mvtDatasource);
    }

    /**
     * <p>
     * If quartz job is initialized by the plugin, by default, it will auto
     * start. This bean indicate whether the quartz job should be auto started.
     * </p>
     * <p>
     * This is optional. Default to be true.
     * </p>
     * 
     * @return
     */
    @Bean(name = "quartzAutoStart")
    public Boolean autoStartQuartz() {
        return autoStart;
    }

}