package com.caiso.soa.mvt.dao.impl;

import static com.caiso.soa.mvt.util.MvtUtil.getCalendar;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.marketclearingoutcome_v4.AncillaryServiceClearing;
import com.caiso.soa.marketclearingoutcome_v4.ConstraintClearing;
import com.caiso.soa.marketclearingoutcome_v4.ConstraintResults;
import com.caiso.soa.marketclearingoutcome_v4.EnergyImbalanceMarketBalancingAuthorityAreaResults;
import com.caiso.soa.marketclearingoutcome_v4.ExecutionType;
import com.caiso.soa.marketclearingoutcome_v4.GeneralClearing;
import com.caiso.soa.marketclearingoutcome_v4.HostControlAreaGroup;
import com.caiso.soa.marketclearingoutcome_v4.MQSUpdateKind;
import com.caiso.soa.marketclearingoutcome_v4.MarketClearingOutcome;
import com.caiso.soa.marketclearingoutcome_v4.MarketProduct;
import com.caiso.soa.marketclearingoutcome_v4.MarketProductType;
import com.caiso.soa.marketclearingoutcome_v4.MarketRegion;
import com.caiso.soa.marketclearingoutcome_v4.MarketRegionResults;
import com.caiso.soa.marketclearingoutcome_v4.MarketRun;
import com.caiso.soa.marketclearingoutcome_v4.MessageHeader;
import com.caiso.soa.marketclearingoutcome_v4.MessagePayload;
import com.caiso.soa.marketclearingoutcome_v4.Nomogram;
import com.caiso.soa.marketclearingoutcome_v4.PassIndicatorType;
import com.caiso.soa.marketclearingoutcome_v4.SystemRampingResults;
import com.caiso.soa.marketclearingoutcome_v4.Update;
import com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO;
import com.caiso.soa.mvt.domain.Published;
import com.caiso.soa.mvt.exception.MvtRuntimeException;

/**
 * The Class MarketClearingOutcomeDAOImpl generates payload for Market clearing outcome 
 */
@Repository("broadcastMarketClearingOutcomeV4")
public class MarketClearingOutcomeDAOImpl implements MarketPriceCorrectionDAO<MarketClearingOutcome> {

	/** The template. */
	@Autowired
	@Qualifier("mvtLmpJdbcTemplate")
	private NamedParameterJdbcTemplate template;

	/** The log. */
	private Logger log = LoggerFactory.getLogger(this.getClass());

	/** The Constant MKT_CLEARING_REGIONAL_PRICE. */
	private static final String MKT_CLEARING_REGIONAL_PRICE = "select market_start_time, mkt_type, time_interval, commodity_type, region_id, region_name, calc_cleared_price,correction_reason from market_output_prc_correction "
			+ "where CORRECTION_FLAG = 'Y' AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE  AND MARKET_START_TIME=:MARKET_START_TIME AND PUBLISHED_YN IS NULL ORDER BY TIME_INTERVAL";

	/** The Constant MKT_CLEARING_CONSTRAINT_PRICE. */
	private static final String MKT_CLEARING_CONSTRAINT_PRICE = "select market_start_time, mkt_type, time_interval, flowgate_id, flowgate_name, constr_class, na_case_id, na_case_name, curve_id, segment_id, calc_shadow_price, correction_reason "
			+ " from shadow_price_correction where CORRECTION_FLAG = 'Y' and constr_class not in ('NDGROUP') AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND MARKET_START_TIME=:MARKET_START_TIME AND PUBLISHED_YN IS NULL ORDER BY TIME_INTERVAL";
	
	/** The Constant FLEX_RAMP_BAA_CORRECTION. */
	private static final String FLEX_RAMP_BAA_CORRECTION = "select time_interval, mkt_type, correction_reason, calc_shadow_price from flex_ramp_baa_correction "
				+ "where CORRECTION_FLAG = 'Y' AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND MARKET_START_TIME=:MARKET_START_TIME AND PUBLISHED_YN IS NULL ORDER BY TIME_INTERVAL";
	
	/** The Constant MARKET_RUN_DATES. */
	private static final String MARKET_RUN_DATES="select distinct market_start_time from market_output_prc_correction where CORRECTION_FLAG = 'Y' AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL" 
										+" union select distinct market_start_time from shadow_price_correction where CORRECTION_FLAG = 'Y' and constr_class not in ('NDGROUP') AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL"
										+" union select distinct market_start_time from flex_ramp_baa_correction where CORRECTION_FLAG = 'Y' AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL";	

	
	/** The Constant MKT_CLEARING_REGIONAL_PRICE_UPDATE. */
	private static final String MKT_CLEARING_REGIONAL_PRICE_UPDATE = "update market_output_prc_correction set PUBLISHED_YN = :PUBLISHED_YN "
			+ "where CORRECTION_FLAG = 'Y' AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE  AND PUBLISHED_YN IS NULL";

	/** The Constant MKT_CLEARING_CONSTRAINT_PRICE_UPDATE. */
	private static final String MKT_CLEARING_CONSTRAINT_PRICE_UPDATE = "update shadow_price_correction set PUBLISHED_YN = :PUBLISHED_YN "
			+ " where CORRECTION_FLAG = 'Y' and constr_class not in ('NDGROUP') AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL";
	
	/** The Constant FLEX_RAMP_BAA_CORRECTION_UPDATE. */
	private static final String FLEX_RAMP_BAA_CORRECTION_UPDATE = "update flex_ramp_baa_correction set  PUBLISHED_YN = :PUBLISHED_YN "
				+ "where CORRECTION_FLAG = 'Y' AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL";
	
	/** The mkt mapping. */
	private final Map<String, String> mktMapping = new HashMap<>();
	
	/** The commodity mapping. */
	private final Map<String, String> commodityMapping = new HashMap<>();
	
	/**
	 * Instantiates a new market clearing outcome DAO impl.
	 */
	public MarketClearingOutcomeDAOImpl(){
		mktMapping.put("DA","RTPD");
		mktMapping.put("RTD","RTPD");
		mktMapping.put("RTPD","RTPD");
		mktMapping.put("RUC","RUC");
		mktMapping.put("HASP","HA-SCUC");
		
		commodityMapping.put("Nr", "NR");
		commodityMapping.put("Sr", "SR");
		commodityMapping.put("Ru", "RU");
		commodityMapping.put("Rd", "RD");
		commodityMapping.put("Md", "RMD");
		commodityMapping.put("Mu", "RMU");
		commodityMapping.put("En", "EN");
		commodityMapping.put("Ur", "FRU");
		commodityMapping.put("Dr", "FRD");
		commodityMapping.put("Ld", "LFD");
		commodityMapping.put("Lu", "LFU");
		
	}
	
	
	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#getPayload(java.util.Date, java.util.Date, java.lang.String)
	 */
	@Override
	public List<MarketClearingOutcome> getPayload(Date startDate, Date endDate, String marketType) {
		
		log.info(" getMarketClearingData Begin...");
		
		List<MarketClearingOutcome> marketClearingOutcomeList = new ArrayList<>();
		
		XMLGregorianCalendar now = null;
		try {
			now = getCalendar(new Timestamp(new Date().getTime()));
		
		} catch (DatatypeConfigurationException e) {
		
			log.debug("error accoured while processing the correction payload market clearing", e);
			throw new MvtRuntimeException(e) ;
		}
		
		MarketClearingOutcome outcome = null;
		MessagePayload payload = null;		
		try {
			
			MapSqlParameterSource paramSource = new MapSqlParameterSource();
			
			paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
			paramSource.addValue("MKT_TYPE",marketType);
			paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
			
			
			SqlRowSet marketRunRs = template.queryForRowSet(MARKET_RUN_DATES, paramSource);
			while(marketRunRs.next()){
				
				payload = new MessagePayload();
				paramSource.addValue("MARKET_START_TIME", marketRunRs.getTimestamp("market_start_time"));
				
				populateAncillaryServiceClearing(payload, marketType,paramSource, now);
				
				populateConstraintClearings(payload,marketType,paramSource, now);
				
				populateSystemRampingResults(payload,paramSource, now);
				
				outcome = new MarketClearingOutcome();
				outcome.setMessageHeader(new MessageHeader());
				outcome.getMessageHeader().setVersion("v20161001");
				outcome.getMessageHeader().setSource("MVT");
				outcome.getMessageHeader().setTimeDate(SOAPUtils.currentTime());
				outcome.setMessagePayload(payload);

				payload.setMarketRun(getMarketRunData(marketType, getCalendar(marketRunRs.getTimestamp("market_start_time"))));
				
				marketClearingOutcomeList.add(outcome);
			}
			
		} catch (Exception ex) {
			log.debug("error accoured while processing the correction payload resource awards", ex);
			throw new MvtRuntimeException(ex) ;
		}
		return marketClearingOutcomeList;
	}

	/**
	 * Gets the market run data.
	 *
	 * @param marketType the market type
	 * @param marketStartTime the market start time
	 * @return the market run data
	 */
	private MarketRun getMarketRunData(String marketType, XMLGregorianCalendar marketStartTime) {
		MarketRun marketRun = new MarketRun();
		marketRun.setCorrectionPayloadFlag(true);
		marketRun.setExecutionType(ExecutionType.valueOf(marketType));
		marketRun.setMarketStartTime(marketStartTime);
		marketRun.setMarketRunID("0");
		marketRun.setMarketID("0");
		return marketRun;
	}
	
	/**
	 * Populate ancillary service clearing.
	 *
	 * @param payload the payload
	 * @param marketType the market type
	 * @param paramSource the param source
	 * @param now the now
	 * @throws InvalidResultSetAccessException the invalid result set access exception
	 * @throws DatatypeConfigurationException the datatype configuration exception
	 */
	private void  populateAncillaryServiceClearing(MessagePayload payload,String marketType, MapSqlParameterSource paramSource, XMLGregorianCalendar now) throws  DatatypeConfigurationException{
		
		SqlRowSet rowset = template.queryForRowSet(MKT_CLEARING_REGIONAL_PRICE, paramSource);
		List<AncillaryServiceClearing> ancillaryServiceClearings = payload.getAncillaryServiceClearings();
		XMLGregorianCalendar prevIntervalStartTime = null;
		XMLGregorianCalendar currIntervalStartTime;
		AncillaryServiceClearing ancillaryServiceClearing;
		List<MarketRegionResults> mktRegionResults = null;
		MarketRegionResults mktRegionResult;
		MarketProduct mktProduct;
		MarketRegion mktRegion;
		
		Update update =new Update();
		update.setUpdateTimeStamp(now);
		update.setUpdateType(MQSUpdateKind.CHG);
		update.setUpdateUser("MVT");
		
		List<GeneralClearing> generalClearings = payload.getGeneralClearings();
		GeneralClearing generalClearing;
		EnergyImbalanceMarketBalancingAuthorityAreaResults energyImbalance;
		
		while(rowset.next()){
			currIntervalStartTime = getCalendar(rowset.getTimestamp("TIME_INTERVAL"));
			if(prevIntervalStartTime == null || !prevIntervalStartTime.equals(currIntervalStartTime)){
				prevIntervalStartTime = currIntervalStartTime;
				ancillaryServiceClearing = new AncillaryServiceClearing();
				ancillaryServiceClearing.setIntervalStartTime(currIntervalStartTime);
				ancillaryServiceClearing.setPassIndicator(PassIndicatorType.valueOf(mktMapping.get(marketType)));
				mktRegionResults = ancillaryServiceClearing.getMarketRegionResults();
				ancillaryServiceClearings.add(ancillaryServiceClearing);
				
				generalClearing = new GeneralClearing();
				generalClearing.setIntervalStartTime(currIntervalStartTime);
				generalClearing.setPassIndicator(PassIndicatorType.valueOf(mktMapping.get(marketType)));
				energyImbalance = new EnergyImbalanceMarketBalancingAuthorityAreaResults();
				energyImbalance.setGreenHouseGasShadowPrice(rowset.getFloat("calc_cleared_price"));
				energyImbalance.setUpdate(update);
				generalClearing.setEnergyImbalanceMarketBalancingAuthorityAreaResults(energyImbalance);
				generalClearings.add(generalClearing);
			}	
			mktRegionResult = new MarketRegionResults();
			mktRegionResult.setClearedPrice(rowset.getFloat("calc_cleared_price"));
			mktRegionResult.setPriceCorrectionReason(rowset.getString("correction_reason"));
			mktProduct = new MarketProduct();
			mktProduct.setMarketProductType(MarketProductType.valueOf(commodityMapping.get(rowset.getString("commodity_type"))));
			mktRegionResult.setMarketProduct(mktProduct);
			mktRegion =new MarketRegion();
			mktRegion.setMrid(rowset.getString("region_name"));
			mktRegionResult.setMarketRegion(mktRegion);
			mktRegionResult.setUpdate(update);
			mktRegionResults.add(mktRegionResult);
		}
	}
	
	/**
	 * Populate constraint clearings.
	 *
	 * @param payload the payload
	 * @param marketType the market type
	 * @param paramSource the param source
	 * @param now the now
	 * @throws InvalidResultSetAccessException the invalid result set access exception
	 * @throws DatatypeConfigurationException the datatype configuration exception
	 */
	private void populateConstraintClearings(MessagePayload payload, String marketType,	MapSqlParameterSource paramSource, XMLGregorianCalendar now) throws  DatatypeConfigurationException{
		SqlRowSet rowset = template.queryForRowSet(MKT_CLEARING_CONSTRAINT_PRICE, paramSource);
		List<ConstraintClearing> constraintClearings = payload.getConstraintClearings();
		
		XMLGregorianCalendar prevIntervalStartTime = null;
		XMLGregorianCalendar currIntervalStartTime;
		ConstraintClearing constraintClearing; 
		List<ConstraintResults> constraintResults = null;
		ConstraintResults constraintResult;
		
		
		
		
		Update update = new Update();
		update.setUpdateTimeStamp(now);
		update.setUpdateType(MQSUpdateKind.CHG);
		update.setUpdateUser("MVT");
		
		while (rowset.next()) {
			currIntervalStartTime = getCalendar(rowset.getTimestamp("TIME_INTERVAL"));
			if (prevIntervalStartTime == null || !prevIntervalStartTime.equals(currIntervalStartTime)) {
				prevIntervalStartTime = currIntervalStartTime;
				constraintClearing = new ConstraintClearing();
				constraintClearing.setIntervalStartTime(currIntervalStartTime);
				constraintClearing.setPassIndicator(PassIndicatorType.valueOf(mktMapping.get(marketType)));
				constraintResults = constraintClearing.getConstraintResults();
				constraintClearings.add(constraintClearing);
				
				
			}

			constraintResult = new ConstraintResults();
			constraintResult.setPriceCorrectionReason(rowset.getString("correction_reason"));
			constraintResult.setShadowPrice(rowset.getFloat("calc_shadow_price"));
			Nomogram nomogram = new Nomogram();
			nomogram.setMrid(rowset.getString("flowgate_name"));
			if(rowset.getBigDecimal("curve_id")!=null){
				nomogram.setCurveID(rowset.getBigDecimal("curve_id").toBigInteger());
			}
			if(rowset.getBigDecimal("segment_id")!=null){
				nomogram.setSegmentID(rowset.getBigDecimal("segment_id").toBigInteger());
			}
				
			
			constraintResult.setNomogram(nomogram);
			constraintResult.setUpdate(update);
			constraintResults.add(constraintResult);

		}
		
	}

	/**
	 * Populate system ramping results.
	 *
	 * @param payload the payload
	 * @param marketType the market type
	 * @param paramSource the param source
	 * @param now the now
	 * @throws InvalidResultSetAccessException the invalid result set access exception
	 * @throws DatatypeConfigurationException the datatype configuration exception
	 */
	private void populateSystemRampingResults(MessagePayload payload, MapSqlParameterSource paramSource, XMLGregorianCalendar now) throws  DatatypeConfigurationException{
		SqlRowSet rowset = template.queryForRowSet(FLEX_RAMP_BAA_CORRECTION, paramSource);
		List<SystemRampingResults> systemRampingResults = payload.getSystemRampingResults();
		SystemRampingResults systemRampingResult;
		Update update =new Update();
		update.setUpdateTimeStamp(now);
		update.setUpdateType(MQSUpdateKind.CHG);
		update.setUpdateUser("MVT");

		while(rowset.next()){
			systemRampingResult = new SystemRampingResults();
			systemRampingResult.setIntervalStartTime(getCalendar(rowset.getTimestamp("time_interval")));
			systemRampingResult.setPassIndicator(PassIndicatorType.valueOf(rowset.getString("mkt_type")));
			systemRampingResult.setPriceCorrectionReason(rowset.getString("correction_reason"));
			systemRampingResult.setRampDownShadowPrice(rowset.getFloat("calc_shadow_price"));
			systemRampingResult.setRampUpShadowPrice(rowset.getFloat("calc_shadow_price"));
			HostControlAreaGroup hostControlAreaGroup = new HostControlAreaGroup();
			//hostControlAreaGroup.setMrid(rowset.getString("baa_id"));
			systemRampingResult.setHostControlAreaGroup(hostControlAreaGroup);
			systemRampingResult.setUpdate(update);
			systemRampingResults.add(systemRampingResult);
		}
	}


	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#updateStatus(java.util.Date, java.util.Date, java.lang.String, com.caiso.soa.mvt.domain.Published)
	 */
	@Override
	public void updateStatus(Date startDate, Date endDate, String marketType,Published status) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("MKT_TYPE",marketType);
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("PUBLISHED_YN", status.toString()); 
		
		template.update(MKT_CLEARING_REGIONAL_PRICE_UPDATE, paramSource);
		template.update(MKT_CLEARING_CONSTRAINT_PRICE_UPDATE, paramSource);
		template.update(FLEX_RAMP_BAA_CORRECTION_UPDATE, paramSource);
		
		
		
	}

	

	
}
