package com.caiso.soa.mvt.dao;

import java.util.Date;
import java.util.List;

import com.caiso.soa.mvt.domain.Published;


/**
 * The Interface MarketPriceCorrectionDAO is an interface for generating pay loads for  
 * market price correction messages and updating the published status of the messages   
 * @param <T> the generic type for JAXB classes 
 */
public interface MarketPriceCorrectionDAO<T> {
	
	/**
	 * Generates the payload for the given market price correction message.
	 *
	 * @param startDate is the interval start date  
	 * @param endDate is the interval end date
	 * @param marketType the market type
	 * @return the jaxb class representing the payload
	 */
	public List<T> getPayload(Date startDate, Date endDate, String marketType);
	
	/**
	 * Update status of the price correction message.
	 * @param startDate is the interval start date
	 * @param endDate is the interval end date
	 * @param marketType the market type
	 * @param status the Y if successful, N is case of error  
	 */
	public void updateStatus(Date startDate, Date endDate, String marketType, Published status);
}
