package com.caiso.soa.mvt.dao.impl;
import static com.caiso.soa.mvt.util.MvtUtil.getCalendar;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO;
import com.caiso.soa.mvt.domain.Published;
import com.caiso.soa.mvt.exception.MvtRuntimeException;
import com.caiso.soa.resourceawards_v4.ClearingResourceAward;
import com.caiso.soa.resourceawards_v4.Configuration;
import com.caiso.soa.resourceawards_v4.ExecutionType;
import com.caiso.soa.resourceawards_v4.FlexibleRampingPriceBreakdown;
import com.caiso.soa.resourceawards_v4.HostControlAreaGroup;
import com.caiso.soa.resourceawards_v4.MQSUpdateKind;
import com.caiso.soa.resourceawards_v4.MarketProduct;
import com.caiso.soa.resourceawards_v4.MarketProductType;
import com.caiso.soa.resourceawards_v4.MarketRun;
import com.caiso.soa.resourceawards_v4.MessageHeader;
import com.caiso.soa.resourceawards_v4.MessagePayload;
import com.caiso.soa.resourceawards_v4.PassIndicatorType;
import com.caiso.soa.resourceawards_v4.RegisteredGenerator;
import com.caiso.soa.resourceawards_v4.RegisteredInterTie;
import com.caiso.soa.resourceawards_v4.ResourceAwardInstruction;
import com.caiso.soa.resourceawards_v4.ResourceAwards;
import com.caiso.soa.resourceawards_v4.Update;
import com.caiso.soa.resourceawards_v4.YesNo;


/**
 * The Class ResourceAwardsClearingDAOImpl generated payload for Resource awards.
 */
@Repository("broadcastResourceAwardClearingV4")
public class ResourceAwardsClearingDAOImpl implements MarketPriceCorrectionDAO<ResourceAwards> {

	/** The template. */
	@Autowired
	@Qualifier("mvtLmpJdbcTemplate")
	private NamedParameterJdbcTemplate template;

	/** The log. */
	private Logger log = LoggerFactory.getLogger(this.getClass());
	
	
	/** The Constant RESOURCE_AWARD_CLEARING. */
	private static final String RESOURCE_AWARD_CLEARING="SELECT T1.MARKET_START_TIME, T1.MKT_TYPE, T1.TIME_INTERVAL, T1.RESOURCE_ID, T1.RESOURCE_NAME, T1.MSG_PLANT,T1.COMMODITY_TYPE, T1.RESOURCE_TYPE,"
										   +"T1.CALC_RES_LMP,T1.CALC_RES_COST,T1.CALC_RES_LOSS, T1.CALC_RES_CONG, T1.CALC_GHG_LMP,T1.CALC_TIE_CONGESTION_LMP,"
										   +"T2.BAA_ID, T2.BAA_NAME,T2.CALC_MARGINAL_PRICE, t1.correction_reason, T1.MSG_PLANT "
										   +"from (SELECT * FROM RESOURCE_LMP_CORRECTION " 
										   +"WHERE CORRECTION_FLAG = 'Y' AND MKT_TYPE NOT IN ('RUC') AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL) T1 "
										   +"LEFT JOIN (SELECT * FROM RESOURCE_FLEX_CORRECTION WHERE  MKT_TYPE = :MKT_TYPE AND CORRECTION_FLAG = 'Y' AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL) T2 " 
										   +"ON  T1.MKT_TYPE = T2.MKT_TYPE AND T1.TIME_INTERVAL = T2.TIME_INTERVAL AND T1.RESOURCE_ID = T2.RESOURCE_ID AND T1.COMMODITY_TYPE = T2.COMMODITY_TYPE "
										   +"ORDER BY T1.MARKET_START_TIME, t1.MKT_TYPE, T1.TIME_INTERVAL, t1.RESOURCE_NAME";
	
	/** The Constant RESOURCE_LMP_CORRECTION_UPDATE. */
	private static final String RESOURCE_LMP_CORRECTION_UPDATE="UPDATE RESOURCE_LMP_CORRECTION SET PUBLISHED_YN =:PUBLISHED_YN " 
			   +"WHERE CORRECTION_FLAG = 'Y' AND MKT_TYPE NOT IN ('RUC') AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL ";
	
	
	/** The Constant RESOURCE_FLEX_CORRECTION_UPDATE. */
	private static final String RESOURCE_FLEX_CORRECTION_UPDATE="UPDATE RESOURCE_FLEX_CORRECTION SET PUBLISHED_YN = :PUBLISHED_YN WHERE  MKT_TYPE = :MKT_TYPE AND CORRECTION_FLAG = 'Y' AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL"; 
			   
	
	
	
	/** The Constant mktMapping. */
	private static final Map<String, String> mktMapping = new HashMap<>();
	
	/** The Constant commodityMapping. */
	private static final Map<String, String> commodityMapping = new HashMap<>();
	
	
	static{
		
		mktMapping.put("DA","IFM");
		mktMapping.put("RTD","RTED");
		mktMapping.put("RTPD","RTPD");
		mktMapping.put("RUC","RUC");
		mktMapping.put("HASP","HA-SCUC");	
				
		commodityMapping.put("Nr", "NR");
		commodityMapping.put("Sr", "SR");
		commodityMapping.put("Ru", "RU");
		commodityMapping.put("Rd", "RD");
		commodityMapping.put("Md", "RMD");
		commodityMapping.put("Mu", "RMU");
		commodityMapping.put("En", "EN");
		commodityMapping.put("Ur", "FRU");
		commodityMapping.put("Dr", "FRD");
		commodityMapping.put("Ld", "LFD");
		commodityMapping.put("Lu", "LFU");
		
	}
	
	
	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#getPayload(java.util.Date, java.util.Date, java.lang.String)
	 */
	@Override
	public List<ResourceAwards> getPayload(Date startDate, Date endDate, String marketType) {
		log.info(" getResourceAwardsClearingData Begin...");
		List<ResourceAwards> payloadList = new ArrayList<>();

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);

		try {
			SqlRowSet resourceAwardRs = template.queryForRowSet(RESOURCE_AWARD_CLEARING, paramSource);
			XMLGregorianCalendar currMarketStartTime;
			XMLGregorianCalendar prevMarketStartTime = null;

			MessagePayload payload;
			ResourceAwards outcome;
			MessageHeader messageHeader;

			List<ClearingResourceAward> clearingResourceAwards = null;
			XMLGregorianCalendar now = getCalendar(new Timestamp(new Date().getTime()));
			XMLGregorianCalendar prevIntervalStartTime = null;
			XMLGregorianCalendar currIntervalStartTime;
			List<ResourceAwardInstruction> resourceAwardInstructions = null;
			ClearingResourceAward clearingResourceAward;
			ResourceAwardInstruction resourceAwardInstruction;
			while (resourceAwardRs.next()) {
				currMarketStartTime = getCalendar(resourceAwardRs.getTimestamp("MARKET_START_TIME"));
				if (prevMarketStartTime == null || !prevMarketStartTime.equals(currMarketStartTime)) {
					prevMarketStartTime = currMarketStartTime;
					outcome = new ResourceAwards();
					messageHeader = new MessageHeader();
					messageHeader.setVersion("v20161001");
					messageHeader.setSource("MVT");
					messageHeader.setTimeDate(SOAPUtils.currentTime());
					payload = new MessagePayload();
					outcome.setMessageHeader(messageHeader);
					outcome.setMessagePayload(payload);
					payload.setMarketRun(getMarketRunData(marketType, currMarketStartTime));
					payloadList.add(outcome);
					clearingResourceAwards = payload.getClearingResourceAwards();
					prevIntervalStartTime = null;
				}
				currIntervalStartTime = getCalendar(resourceAwardRs.getTimestamp("TIME_INTERVAL"));
				if(prevIntervalStartTime == null || !prevIntervalStartTime.equals(currIntervalStartTime)){
					prevIntervalStartTime = currIntervalStartTime;
					clearingResourceAward = new ClearingResourceAward();
					clearingResourceAward.setIntervalStartTime(currIntervalStartTime);
					clearingResourceAward.setPassIndicator(PassIndicatorType.valueOf(mktMapping.get(marketType)));
					clearingResourceAwards.add(clearingResourceAward);
					resourceAwardInstructions = clearingResourceAward.getResourceAwardInstructions();
				}
				resourceAwardInstruction = new ResourceAwardInstruction();
				resourceAwardInstruction.setClearedPrice(resourceAwardRs.getFloat("CALC_RES_LMP"));
				resourceAwardInstruction.setCongestLMP(resourceAwardRs.getFloat("CALC_RES_CONG"));
				resourceAwardInstruction.setCostLMP(resourceAwardRs.getFloat("CALC_RES_COST"));
				resourceAwardInstruction.setGreenHouseGasLMP(resourceAwardRs.getFloat("CALC_GHG_LMP"));
				resourceAwardInstruction.setITCShadowPrice(resourceAwardRs.getFloat("CALC_TIE_CONGESTION_LMP"));
				resourceAwardInstruction.setLossLMP(resourceAwardRs.getFloat("CALC_RES_LOSS"));
				resourceAwardInstruction.setPriceCorrectionReason(resourceAwardRs.getString("CORRECTION_REASON"));
				List<Object> flexRampPriceBreakdowns = resourceAwardInstruction.getFlexibleRampingPriceBreakdownsAndMarginalCongestionCostBreakdowns();
				FlexibleRampingPriceBreakdown flexRampPriceBreakdown = new FlexibleRampingPriceBreakdown(); 
				HostControlAreaGroup hostCtrlAreaGrp = new HostControlAreaGroup();
				hostCtrlAreaGrp.setMrid(resourceAwardRs.getString("BAA_NAME"));
				flexRampPriceBreakdown.setHostControlAreaGroup(hostCtrlAreaGrp);
				flexRampPriceBreakdown.setFlexibleRampingPrice(resourceAwardRs.getFloat("CALC_MARGINAL_PRICE"));
				flexRampPriceBreakdown.setPriceCorrectionReason(resourceAwardRs.getString("CORRECTION_REASON"));
				flexRampPriceBreakdowns.add(flexRampPriceBreakdown);
				MarketProduct mktProductType = new MarketProduct();
				mktProductType.setMarketProductType(MarketProductType.valueOf(commodityMapping.get(resourceAwardRs.getString("COMMODITY_TYPE"))));
				resourceAwardInstruction.setMarketProduct(mktProductType);
				
				String resoureType =  resourceAwardRs.getString("RESOURCE_TYPE");
				if(resoureType!= null){
					if(resoureType.equals("SR")){
						RegisteredInterTie regInterTie = new RegisteredInterTie();
						regInterTie.setMrid(resourceAwardRs.getString("RESOURCE_NAME"));
						regInterTie.setRegisteredFlag(YesNo.YES);
						resourceAwardInstruction.setRegisteredInterTie(regInterTie);		
					}else if(resoureType.equals("PS") || resoureType.equals("G")){
						RegisteredGenerator registeredGen = new RegisteredGenerator();
						String msgPlant = resourceAwardRs.getString("MSG_PLANT");
						if(msgPlant == null){
							registeredGen.setMrid(resourceAwardRs.getString("RESOURCE_NAME"));	
						}else{
							registeredGen.setMrid(msgPlant);
							Configuration config = new Configuration();
							config.setMrid(resourceAwardRs.getString("RESOURCE_NAME"));
							registeredGen.setConfiguration(config);
						}
						resourceAwardInstruction.setRegisteredGenerator(registeredGen);
					}
				}

				Update update = new Update();
				update.setUpdateTimeStamp(now);
				update.setUpdateUser("MVT");
				update.setUpdateType(MQSUpdateKind.CHG);
				resourceAwardInstruction.setUpdate(update);
				resourceAwardInstructions.add(resourceAwardInstruction);
						
			}

		} catch (Exception ex) {
			log.debug("error accoured while processing the correction payload resource awards", ex);
			throw new MvtRuntimeException(ex);
		}
		return payloadList;
	}

	/**
	 * Gets the market run data.
	 *
	 * @param marketType the market type
	 * @param marketStartTime the market start time
	 * @return the market run data
	 */
	private MarketRun getMarketRunData(String marketType, XMLGregorianCalendar marketStartTime) {
		MarketRun marketRun = new MarketRun();
		marketRun.setCorrectionPayloadFlag(true);
		marketRun.setExecutionType(ExecutionType.valueOf(marketType));
		marketRun.setMarketStartTime(marketStartTime);
		marketRun.setMarketRunID("0");
		marketRun.setMarketID("0");
		return marketRun;
	}
	
	
	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#updateStatus(java.util.Date, java.util.Date, java.lang.String, com.caiso.soa.mvt.domain.Published)
	 */
	@Override
	public void updateStatus(Date startDate, Date endDate, String marketType, Published status) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);
		paramSource.addValue("PUBLISHED_YN", status.toString());
		
		template.update(RESOURCE_LMP_CORRECTION_UPDATE, paramSource);
		template.update(RESOURCE_FLEX_CORRECTION_UPDATE, paramSource);
	}

}
