package com.caiso.soa.mvt.dao.impl;

import static com.caiso.soa.mvt.util.MvtUtil.getCalendar;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.caiso.soa.commitment_v1.ADSInstTypeCommitment;
import com.caiso.soa.commitment_v1.Commitment;
import com.caiso.soa.commitment_v1.CommitmentClearing;
import com.caiso.soa.commitment_v1.CommitmentType;
import com.caiso.soa.commitment_v1.Commitments;
import com.caiso.soa.commitment_v1.Configuration;
import com.caiso.soa.commitment_v1.ExecutionType;
import com.caiso.soa.commitment_v1.InstructionClearing;
import com.caiso.soa.commitment_v1.Instructions;
import com.caiso.soa.commitment_v1.MarketRun;
import com.caiso.soa.commitment_v1.MessageHeader;
import com.caiso.soa.commitment_v1.MessageHeaderYesNo;
import com.caiso.soa.commitment_v1.MessagePayload;
import com.caiso.soa.commitment_v1.PassIndicatorType;
import com.caiso.soa.commitment_v1.RegisteredGenerator;
import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO;
import com.caiso.soa.mvt.domain.Published;
import com.caiso.soa.mvt.exception.MvtRuntimeException;


/**
 * The Class CommitmentDAOImpl generates payload for CommitmentDAO.
 */
@Repository("broadcastCommitmentV1")
public class CommitmentDAOImpl implements MarketPriceCorrectionDAO<Commitment> {

	/** The template. */
	@Autowired
	@Qualifier("mvtLmpJdbcTemplate")
	private NamedParameterJdbcTemplate template;

	/** The log. */
	private Logger log = LoggerFactory.getLogger(this.getClass());

	/** The Constant COMMITMENT. */
	private static final String COMMITMENT = "SELECT MKT_START_TIME, MKT_TYPE, TIME_INTERVAL_S, RESOURCE_ID, RESOURCE_NAME,COMMITMENT_TYPE, INSTRUCTION_TYPE, CALC_INSTRUCTION_COST, CALC_NO_LOAD_COST, CORRECTION_REASON, "
			+ " dense_rank() over(order by MKT_START_TIME,TIME_INTERVAL_S,RESOURCE_NAME,INSTRUCTION_TYPE) as \"INSTRUCTIONS\""
			+ " From COMMITMENT_COST_CORRECTION WHERE CORRECTION_FLAG = 'Y' AND MKT_TYPE IN (:MKT_TYPE) AND TIME_INTERVAL_S>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL_E<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND PUBLISHED_YN IS NULL ORDER BY MKT_START_TIME, TIME_INTERVAL_S";

	/** The Constant COMMITMENT_UPDATE. */
	private static final String COMMITMENT_UPDATE = "UPDATE COMMITMENT_COST_CORRECTION set PUBLISHED_YN = :PUBLISHED_YN  "
			+ "WHERE CORRECTION_FLAG = 'Y' AND MKT_TYPE IN (:MKT_TYPE) AND TIME_INTERVAL_S>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL_E<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND PUBLISHED_YN IS NULL";

	/** The mkt mapping. */
	private final Map<String, String> mktMapping = new HashMap<>();

	/**
	 * Instantiates a new commitment DAO impl.
	 */
	public CommitmentDAOImpl() {
		mktMapping.put("DA", "IFM");
		mktMapping.put("RTD", "RTPD");
		mktMapping.put("RTPD", "RTPD");
		mktMapping.put("RUC", "RUC");
		mktMapping.put("HASP", "HA-SCUC");

	}

	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#getPayload(java.util.Date, java.util.Date, java.lang.String)
	 */
	@Override
	public List<Commitment> getPayload(Date startDate, Date endDate, String marketType) {

		log.info(" getNodalClearingData Begin...");

		List<Commitment> payloadList = new ArrayList<>();

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);

		try {
			SqlRowSet rowSet = template.queryForRowSet(COMMITMENT, paramSource);
			XMLGregorianCalendar currMarketStartTime;
			XMLGregorianCalendar prevMarketStartTime = null;

			MessagePayload payload;
			Commitment commitment;
			MessageHeader messageHeader;

			CommitmentClearing commitmentClearing;
			List<Commitments> commitments = null;
			Commitments lcommitments;

			InstructionClearing instructionClearing ;
			List<InstructionClearing> instructionClearings = null;
			List<Instructions> instructions;
			Instructions instruction;

			String prevInstruction = null;
			String currInstruction;
			XMLGregorianCalendar currIntervalStartTime;

			while (rowSet.next()) {
				currMarketStartTime = getCalendar(rowSet.getTimestamp("MKT_START_TIME"));
				if (prevMarketStartTime == null || !prevMarketStartTime.equals(currMarketStartTime)) {
					prevMarketStartTime = currMarketStartTime;
					commitment = new Commitment();
					messageHeader = new MessageHeader();
					messageHeader.setVersion("v20161001");
					messageHeader.setSource("MVT");
					messageHeader.setIncPayloadFlag(MessageHeaderYesNo.YES);
					messageHeader.setTimeDate(SOAPUtils.currentTime());
					payload = new MessagePayload();
					commitment.setMessageHeader(messageHeader);
					commitment.setMessagePayload(payload);
					payload.setMarketRun(getMarketRunData(marketType, currMarketStartTime));
					payloadList.add(commitment);
					commitmentClearing = new CommitmentClearing();
					commitmentClearing.setPassIndicator(PassIndicatorType.valueOf(mktMapping.get(marketType)));
					commitments = commitmentClearing.getCommitments();
					payload.getCommitmentClearings().add(commitmentClearing);
					instructionClearings = payload.getInstructionClearings();
					prevInstruction = null;
				}
				currIntervalStartTime = getCalendar(rowSet.getTimestamp("TIME_INTERVAL_S"));
				lcommitments = new Commitments();
				lcommitments.setCommitmentType(CommitmentType.valueOf(rowSet.getString("COMMITMENT_TYPE")));
				lcommitments.setInstructionType(ADSInstTypeCommitment.valueOf(rowSet.getString("INSTRUCTION_TYPE")));
				BigDecimal intructionCost = rowSet.getBigDecimal("CALC_INSTRUCTION_COST");
				if(intructionCost!=null)
					lcommitments.setInstructionCost(intructionCost.floatValue());
				lcommitments.setIntervalStartTime(currIntervalStartTime);
				lcommitments.setNoLoadCost(rowSet.getBigDecimal("CALC_NO_LOAD_COST").floatValue());
				if(intructionCost!=null)
					lcommitments.setTransitionCost(rowSet.getBigDecimal("CALC_INSTRUCTION_COST").floatValue());
				lcommitments.setPriceCorrectionReason(rowSet.getString("CORRECTION_REASON"));
				RegisteredGenerator regGenerator = new RegisteredGenerator();
				regGenerator.setMrid(rowSet.getString("RESOURCE_NAME"));
				Configuration config = new Configuration();
				config.setMrid(rowSet.getString("RESOURCE_NAME"));
				regGenerator.setConfiguration(config);
				lcommitments.setRegisteredGenerator(regGenerator);
				commitments.add(lcommitments);

				currInstruction = rowSet.getString("INSTRUCTIONS");
				if (prevInstruction == null || !prevInstruction.equals(currInstruction)) {
					prevInstruction = currInstruction;
					instructionClearing = new InstructionClearing();
					instructionClearing.setIntervalStartTime(currIntervalStartTime);
					instructionClearing.setPassIndicator(PassIndicatorType.valueOf(mktMapping.get(marketType)));
					instructionClearings.add(instructionClearing);
					instructions = instructionClearing.getInstructions();
					instruction = new Instructions();
					instruction.setInstructionStartTime(currIntervalStartTime);
					instruction.setInstructionType(ADSInstTypeCommitment.valueOf(rowSet.getString("INSTRUCTION_TYPE")));
					if(intructionCost!=null){
						instruction.setInstructionCost(rowSet.getBigDecimal("CALC_INSTRUCTION_COST").floatValue());
					}	
					regGenerator = new RegisteredGenerator();
					regGenerator.setMrid(rowSet.getString("RESOURCE_NAME"));
					config = new Configuration();
					config.setMrid(rowSet.getString("RESOURCE_NAME"));
					regGenerator.setConfiguration(config);
					instruction.setRegisteredGenerator(regGenerator);
					instruction.setPriceCorrectionReason(rowSet.getString("CORRECTION_REASON"));
					instructions.add(instruction);
				}
			}

		} catch (Exception ex) {
			log.debug("error accoured while processing the correction payload resource awards", ex);
			throw new MvtRuntimeException(ex);
		}
		return payloadList;
	}

	/**
	 * Gets the market run data.
	 *
	 * @param marketType the market type
	 * @param marketStartTime the market start time
	 * @return the market run data
	 */
	private MarketRun getMarketRunData(String marketType, XMLGregorianCalendar marketStartTime) {
		MarketRun marketRun = new MarketRun();
		marketRun.setCorrectionPayloadFlag(true);
		marketRun.setExecutionType(ExecutionType.valueOf(marketType));
		marketRun.setMarketID("0");
		marketRun.setMarketRunID("0");
		marketRun.setMarketStartTime(marketStartTime);
		return marketRun;
	}

	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#updateStatus(java.util.Date, java.util.Date, java.lang.String, com.caiso.soa.mvt.domain.Published)
	 */
	@Override
	public void updateStatus(Date startDate, Date endDate, String marketType, Published status) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);
		paramSource.addValue("PUBLISHED_YN", status.toString());

		template.update(COMMITMENT_UPDATE, paramSource);

	}

}
