package com.caiso.soa.mvt.entity;

import java.util.Calendar;

public class RMvrMarketValidation {

	private Long id;
	private Long messagePayloadId;
	private Calendar intervalStartTime;
	private String passIndicator;
	private Long rulesValidated;
	private Long rulesViolated;
	private Calendar stgLoadTs;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getMessagePayloadId() {
		return messagePayloadId;
	}
	public void setMessagePayloadId(Long messagePayloadId) {
		this.messagePayloadId = messagePayloadId;
	}
	public Calendar getIntervalStartTime() {
		return intervalStartTime;
	}
	public void setIntervalStartTime(Calendar intervalStartTime) {
		this.intervalStartTime = intervalStartTime;
	}
	public String getPassIndicator() {
		return passIndicator;
	}
	public void setPassIndicator(String passIndicator) {
		this.passIndicator = passIndicator;
	}
	public Long getRulesValidated() {
		return rulesValidated;
	}
	public void setRulesValidated(Long rulesValidated) {
		this.rulesValidated = rulesValidated;
	}
	public Long getRulesViolated() {
		return rulesViolated;
	}
	public void setRulesViolated(Long rulesViolated) {
		this.rulesViolated = rulesViolated;
	}
	public Calendar getStgLoadTs() {
		return stgLoadTs;
	}
	public void setStgLoadTs(Calendar stgLoadTs) {
		this.stgLoadTs = stgLoadTs;
	}
	
}
