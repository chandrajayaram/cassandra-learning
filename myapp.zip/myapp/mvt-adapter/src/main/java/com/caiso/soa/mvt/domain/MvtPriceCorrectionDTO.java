package com.caiso.soa.mvt.domain;

import java.util.Date;

/**
 * The Class MvtPriceCorrectionDTO represents market price correction data.
 */
public class MvtPriceCorrectionDTO {

	/** The id. */
	Long id;
	
	/** The start date. */
	Date startDate;
	
	/** The end date. */
	Date endDate;
	
	/** The mkt type. */
	String mktType;
	
	/** The service name. */
	String serviceName;
	
	/** The status. */
	String status;
	
	/** The records processed. */
	Long recordsProcessed;
	
	
	public MvtPriceCorrectionDTO(){
		//public default contructor
	}
	
	/**
	 * Instantiates a new mvt price correction DTO.
	 *
	 * @param id the id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param mktType the mkt type
	 * @param serviceName the service name
	 * @param status the status
	 * @param recordsProcessed the records processed
	 */
	
	
	
	public MvtPriceCorrectionDTO(Long id, Date startDate, Date endDate, String mktType, String serviceName, String status, Long recordsProcessed){
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.mktType = mktType;
		this.serviceName = serviceName;
		this.status = status;
		this.recordsProcessed = recordsProcessed;
	}
	

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return startDate;
	}
	
	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}
	
	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	/**
	 * Gets the mkt type.
	 *
	 * @return the mkt type
	 */
	public String getMktType() {
		return mktType;
	}
	
	/**
	 * Sets the mkt type.
	 *
	 * @param mktType the new mkt type
	 */
	public void setMktType(String mktType) {
		this.mktType = mktType;
	}
	
	/**
	 * Gets the service name.
	 *
	 * @return the service name
	 */
	public String getServiceName() {
		return serviceName;
	}
	
	/**
	 * Sets the service name.
	 *
	 * @param serviceName the new service name
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the records processed.
	 *
	 * @return the records processed
	 */
	public Long getRecordsProcessed() {
		return recordsProcessed;
	}
	
	/**
	 * Sets the records processed.
	 *
	 * @param recordsProcessed the new records processed
	 */
	public void setRecordsProcessed(Long recordsProcessed) {
		this.recordsProcessed = recordsProcessed;
	}
	
}
