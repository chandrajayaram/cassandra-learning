package com.caiso.soa.mvt.dao.impl;
import static com.caiso.soa.mvt.util.MvtUtil.getCalendar;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO;
import com.caiso.soa.mvt.domain.Published;
import com.caiso.soa.mvt.exception.MvtRuntimeException;
import com.caiso.soa.rucresourceawards_v1.ClearingResourceAward;
import com.caiso.soa.rucresourceawards_v1.Configuration;
import com.caiso.soa.rucresourceawards_v1.ExecutionType;
import com.caiso.soa.rucresourceawards_v1.MQSUpdateKind;
import com.caiso.soa.rucresourceawards_v1.MarketProductType;
import com.caiso.soa.rucresourceawards_v1.MarketRun;
import com.caiso.soa.rucresourceawards_v1.MarketType;
import com.caiso.soa.rucresourceawards_v1.MessageHeader;
import com.caiso.soa.rucresourceawards_v1.MessageHeaderYesNo;
import com.caiso.soa.rucresourceawards_v1.MessagePayload;
import com.caiso.soa.rucresourceawards_v1.PassIndicatorType;
import com.caiso.soa.rucresourceawards_v1.RUCAwardInstruction;
import com.caiso.soa.rucresourceawards_v1.RUCResourceAwards;
import com.caiso.soa.rucresourceawards_v1.RegisteredGenerator;
import com.caiso.soa.rucresourceawards_v1.Update;

/**
 * The Class RUCResourceAwardClearingDAOImpl generates payload for RUC Resource awards message.
 */
@Repository("broadcastRUCResourceAwardClearingV1")
public class RUCResourceAwardClearingDAOImpl implements MarketPriceCorrectionDAO<RUCResourceAwards> {

	/** The template. */
	@Autowired
	@Qualifier("mvtLmpJdbcTemplate")
	private NamedParameterJdbcTemplate template;

	/** The log. */
	private Logger log = LoggerFactory.getLogger(this.getClass());
	

	
	/** The Constant RUC_RESOURCE_AWARD_CLEARING. */
	private static final String RUC_RESOURCE_AWARD_CLEARING = "SELECT MARKET_START_TIME, MKT_TYPE, TIME_INTERVAL, RESOURCE_ID, RESOURCE_NAME, COMMODITY_TYPE,RESOURCE_TYPE,MSG_PLANT, CALC_RES_LMP,CALC_RES_COST,CALC_RES_LOSS, CALC_RES_CONG, CALC_GHG_LMP,CALC_TIE_CONGESTION_LMP, CORRECTION_REASON "
	+" from RESOURCE_LMP_CORRECTION WHERE CORRECTION_FLAG = 'Y' AND MKT_TYPE IN ('RUC') AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL ORDER BY MARKET_START_TIME, TIME_INTERVAL";
	
	
	/** The Constant RUC_RESOURCE_AWARD_CLEARING_UPDATE. */
	private static final String RUC_RESOURCE_AWARD_CLEARING_UPDATE = "UPDATE RESOURCE_LMP_CORRECTION set PUBLISHED_YN= :PUBLISHED_YN "
			+" WHERE CORRECTION_FLAG = 'Y' AND MKT_TYPE IN ('RUC') AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL";
			
	
	/** The Constant mktMapping. */
	private static final Map<String, String> mktMapping = new HashMap<>();
	
	/** The Constant commodityMapping. */
	private static final Map<String, String> commodityMapping = new HashMap<>();
	
	
	static{
		
		mktMapping.put("DA","IFM");
		mktMapping.put("RTD","RTED");
		mktMapping.put("RTPD","RTPD");
		mktMapping.put("RUC","RC");
		mktMapping.put("HASP","HA-SCUC");	
				
		commodityMapping.put("Nr", "NR");
		commodityMapping.put("Sr", "SR");
		commodityMapping.put("Ru", "RU");
		commodityMapping.put("Rd", "RD");
		commodityMapping.put("Md", "RMD");
		commodityMapping.put("Mu", "RMU");
		commodityMapping.put("En", "EN");
		commodityMapping.put("Ur", "FRU");
		commodityMapping.put("Dr", "FRD");
		commodityMapping.put("Ld", "LFD");
		commodityMapping.put("Lu", "LFU");
		
	}
	
	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#getPayload(java.util.Date, java.util.Date, java.lang.String)
	 */
	@Override
	public List<RUCResourceAwards> getPayload(Date startDate, Date endDate, String marketType) {
		log.info(" getResourceAwardsClearingData Begin...");
		List<RUCResourceAwards> payloadList = new ArrayList<>();

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);

		try {
			SqlRowSet resourceAwardRs = template.queryForRowSet(RUC_RESOURCE_AWARD_CLEARING, paramSource);
			XMLGregorianCalendar currMarketStartTime;
			XMLGregorianCalendar prevMarketStartTime = null;

			MessagePayload payload;
			RUCResourceAwards outcome;
			MessageHeader messageHeader;
			
			
			List<ClearingResourceAward> clearingResourceAwards = null;
			XMLGregorianCalendar now = getCalendar(new Timestamp(new Date().getTime()));
			XMLGregorianCalendar prevIntervalStartTime = null;
			XMLGregorianCalendar currIntervalStartTime;
			List<RUCAwardInstruction> resourceAwardInstructions = null;
			ClearingResourceAward clearingResourceAward;
			RUCAwardInstruction resourceAwardInstruction;
			while (resourceAwardRs.next()) {
				currMarketStartTime = getCalendar(resourceAwardRs.getTimestamp("MARKET_START_TIME"));
				if (prevMarketStartTime == null || prevMarketStartTime.equals(currMarketStartTime) == false) {
					prevMarketStartTime = currMarketStartTime;
					outcome = new RUCResourceAwards();
					messageHeader = new MessageHeader();
					messageHeader.setVersion("v20161001");
					messageHeader.setSource("MVT");
					messageHeader.setTimeDate(SOAPUtils.currentTime());
					messageHeader.setIncPayloadFlag(MessageHeaderYesNo.YES);
					payload = new MessagePayload();
					outcome.setMessageHeader(messageHeader);
					outcome.setMessagePayload(payload);
					payload.setMarketRun(getMarketRunData(marketType, currMarketStartTime));
					payloadList.add(outcome);
					clearingResourceAwards = payload.getClearingResourceAwards();
					prevIntervalStartTime = null;
				}
				currIntervalStartTime = getCalendar(resourceAwardRs.getTimestamp("TIME_INTERVAL"));
				if(prevIntervalStartTime == null || prevIntervalStartTime.equals(currIntervalStartTime)==false){
					prevIntervalStartTime = currIntervalStartTime;
					clearingResourceAward = new ClearingResourceAward();
					clearingResourceAward.setIntervalStartTime(currIntervalStartTime);
					marketType= resourceAwardRs.getString("MKT_TYPE");
					clearingResourceAward.setPassIndicator(PassIndicatorType.valueOf(marketType));
					clearingResourceAwards.add(clearingResourceAward);
					resourceAwardInstructions = clearingResourceAward.getRUCAwardInstructions();
				}
				resourceAwardInstruction = new RUCAwardInstruction();
				resourceAwardInstruction.setClearedPrice(resourceAwardRs.getFloat("CALC_RES_LMP"));
				resourceAwardInstruction.setMarketProductType(MarketProductType.valueOf(commodityMapping.get(resourceAwardRs.getString("COMMODITY_TYPE"))));
				resourceAwardInstruction.setPriceCorrectionReason(resourceAwardRs.getString("CORRECTION_REASON"));
				
				RegisteredGenerator registeredGen = new RegisteredGenerator();
				registeredGen.setMrid(resourceAwardRs.getString("RESOURCE_NAME"));
				Configuration config = new Configuration();
				config.setMrid(resourceAwardRs.getString("RESOURCE_NAME"));
				registeredGen.setConfiguration(config);
				resourceAwardInstruction.setRegisteredGenerator(registeredGen);
				
				Update update = new Update();
				update.setUpdateTimeStamp(now);
				update.setUpdateUser("MVT");
				update.setUpdateType(MQSUpdateKind.CHG);
				resourceAwardInstruction.setUpdate(update);
				resourceAwardInstructions.add(resourceAwardInstruction);
						
			}

		} catch (Exception ex) {
			log.debug("error accoured while processing the correction payload resource awards", ex);
			throw new MvtRuntimeException(ex);
		}
		return payloadList;
	}

	/**
	 * Gets the market run data.
	 *
	 * @param marketType the market type
	 * @param marketStartTime the market start time
	 * @return the market run data
	 */
	private MarketRun getMarketRunData(String marketType, XMLGregorianCalendar marketStartTime) {
		MarketRun marketRun = new MarketRun();
		marketRun.setCorrectionPayloadFlag(true);
		marketRun.setExecutionType(ExecutionType.valueOf("DA"));
		marketRun.setMarketStartTime(marketStartTime);
		marketRun.setMarketRunID("0");
		marketRun.setMarketID("0");
		marketRun.setMarketType(MarketType.valueOf("DAM"));
		return marketRun;
	}
	
	
	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#updateStatus(java.util.Date, java.util.Date, java.lang.String, com.caiso.soa.mvt.domain.Published)
	 */
	@Override
	public void updateStatus(Date startDate, Date endDate, String marketType, Published status) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);
		paramSource.addValue("PUBLISHED_YN", status.toString());
		template.update(RUC_RESOURCE_AWARD_CLEARING_UPDATE, paramSource);
	}

}

