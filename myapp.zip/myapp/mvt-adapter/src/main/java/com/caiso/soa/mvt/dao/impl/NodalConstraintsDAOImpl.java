package com.caiso.soa.mvt.dao.impl;

import static com.caiso.soa.mvt.util.MvtUtil.getCalendar;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO;
import com.caiso.soa.mvt.domain.Published;
import com.caiso.soa.mvt.exception.MvtRuntimeException;
import com.caiso.soa.nodalconstraints_v1.BindingLimitTypeCode;
import com.caiso.soa.nodalconstraints_v1.ConstraintClearing;
import com.caiso.soa.nodalconstraints_v1.ConstraintResults;
import com.caiso.soa.nodalconstraints_v1.ExecutionType;
import com.caiso.soa.nodalconstraints_v1.IndividualPnodeNmReq;
import com.caiso.soa.nodalconstraints_v1.MarketRunMsg;
import com.caiso.soa.nodalconstraints_v1.MessageHeader;
import com.caiso.soa.nodalconstraints_v1.MessagePayload;
import com.caiso.soa.nodalconstraints_v1.NodalConstraints;
import com.caiso.soa.nodalconstraints_v1.NodeGroup;
import com.caiso.soa.nodalconstraints_v1.PassIndicatorType;

 
/**
 * The Class NodalConstraintsDAOImpl generates payload for nodal constraint message.
 */
@Repository("broadcastNodalContraintsV1")
public class NodalConstraintsDAOImpl implements MarketPriceCorrectionDAO<NodalConstraints> {

	/** The template. */
	@Autowired
	@Qualifier("mvtLmpJdbcTemplate")
	private NamedParameterJdbcTemplate template;

	/** The log. */
	private Logger log = LoggerFactory.getLogger(this.getClass());

	/** The Constant NODAL_CONSTRAINT_PRICE. */
	private static final String NODAL_CONSTRAINT_PRICE = "SELECT MARKET_START_TIME, MKT_TYPE, TIME_INTERVAL, FLOWGATE_ID, FLOWGATE_NAME, NA_CASE_ID, CALC_SHADOW_PRICE , NA_CASE_NAME, CORRECTION_REASON "
			+ " FROM SHADOW_PRICE_CORRECTION WHERE CORRECTION_FLAG = 'Y' AND MKT_TYPE IN ('DA') AND CONSTR_CLASS IN ('NDGROUP') AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL ORDER BY MARKET_START_TIME, TIME_INTERVAL";


	/** The Constant NODAL_CONSTRAINT_PRICE_UPDATE. */
	private static final String NODAL_CONSTRAINT_PRICE_UPDATE = "UPDATE  SHADOW_PRICE_CORRECTION SET PUBLISHED_YN= :PUBLISHED_YN "
			+ " WHERE CORRECTION_FLAG = 'Y' AND MKT_TYPE IN ('DA') AND CONSTR_CLASS IN ('NDGROUP') AND TIME_INTERVAL>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')  AND TIME_INTERVAL<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL";

	
	/** The mkt mapping. */
	private final Map<String, String> mktMapping = new HashMap<>();

	/**
	 * Instantiates a new nodal constraints DAO impl.
	 */
	public NodalConstraintsDAOImpl() {
		mktMapping.put("DA", "RTPD");
		mktMapping.put("RTD", "RTPD");
		mktMapping.put("RTPD", "RTPD");
		mktMapping.put("RUC", "RUC");
		mktMapping.put("HASP", "HA-SCUC");

	}

	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#getPayload(java.util.Date, java.util.Date, java.lang.String)
	 */
	@Override
	public List<NodalConstraints> getPayload(Date startDate, Date endDate, String marketType) {

		log.info(" getNodalClearingData Begin...");

		List<NodalConstraints> payloadList = new ArrayList<>();

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);

		try {
			SqlRowSet rowSet = template.queryForRowSet(NODAL_CONSTRAINT_PRICE, paramSource);
			XMLGregorianCalendar currMarketStartTime;
			XMLGregorianCalendar prevMarketStartTime = null;

			MessagePayload payload;
			NodalConstraints nodalContraint;
			MessageHeader messageHeader;

			ConstraintClearing contraintClearing;
			List<ConstraintResults> contraintClearingResults = null;
			List<ConstraintClearing> contraintClearings = null;
			ConstraintResults constraintResult;
			NodeGroup nodeGroup;

			XMLGregorianCalendar prevIntervalStartTime = null;
			XMLGregorianCalendar currIntervalStartTime;

			while (rowSet.next()) {
				currMarketStartTime = getCalendar(rowSet.getTimestamp("MARKET_START_TIME"));
				if (prevMarketStartTime == null || !prevMarketStartTime.equals(currMarketStartTime)) {
					prevMarketStartTime = currMarketStartTime;
					nodalContraint = new NodalConstraints();
					messageHeader = new MessageHeader();
					messageHeader.setVersion("v20161001");
					messageHeader.setSource("MVT");
					messageHeader.setTimeDate(SOAPUtils.currentTime());
					payload = new MessagePayload();
					nodalContraint.setMessageHeader(messageHeader);
					nodalContraint.setMessagePayload(payload);
					payload.setMarketRun(getMarketRunData(marketType, currMarketStartTime));
					payloadList.add(nodalContraint);
					contraintClearings = payload.getConstraintClearings();
					prevIntervalStartTime = null;
				}
				currIntervalStartTime = getCalendar(rowSet.getTimestamp("TIME_INTERVAL"));
				if (prevIntervalStartTime == null || !prevIntervalStartTime.equals(currIntervalStartTime)) {
					prevIntervalStartTime = currIntervalStartTime;
					contraintClearing = new ConstraintClearing();
					contraintClearing.setIntervalStartTime(currIntervalStartTime);
					contraintClearing.setPassIndicator(PassIndicatorType.valueOf(mktMapping.get(marketType)));
					contraintClearings.add(contraintClearing);
					contraintClearingResults = contraintClearing.getConstraintResults();
				}
				constraintResult = new ConstraintResults();
				constraintResult.setBindingLimitType(BindingLimitTypeCode.U);
				constraintResult.setShadowPrice(rowSet.getFloat("calc_shadow_price"));
				nodeGroup = new NodeGroup();
				nodeGroup.setName(rowSet.getString("flowgate_name"));
				IndividualPnodeNmReq e = new IndividualPnodeNmReq();
				e.setMrid("null");
				nodeGroup.getIndividualPnodes().add(e);
				constraintResult.setNodeGroup(nodeGroup);
				constraintResult.setPriceCorrectionReason(rowSet.getString("CORRECTION_REASON"));
				contraintClearingResults.add(constraintResult);
			}

		} catch (Exception ex) {
			log.debug("error accoured while processing the correction payload resource awards", ex);
			throw new MvtRuntimeException(ex);
		}
		return payloadList;
	}

	/**
	 * Gets the market run data.
	 *
	 * @param marketType the market type
	 * @param marketStartTime the market start time
	 * @return the market run data
	 */
	private MarketRunMsg getMarketRunData(String marketType, XMLGregorianCalendar marketStartTime) {
		MarketRunMsg marketRun = new MarketRunMsg();
		marketRun.setCorrectionPayloadFlag(true);
		marketRun.setExecutionType(ExecutionType.valueOf(marketType));
		marketRun.setMarketID("0");
		marketRun.setMarketRunID("0");
		marketRun.setMarketStartTime(marketStartTime);
		
		return marketRun;
	}

	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#updateStatus(java.util.Date, java.util.Date, java.lang.String, com.caiso.soa.mvt.domain.Published)
	 */
	@Override
	public void updateStatus(Date startDate, Date endDate, String marketType, Published status) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);
		paramSource.addValue("PUBLISHED_YN", status.toString()); 

		template.update(NODAL_CONSTRAINT_PRICE_UPDATE, paramSource);
		
	}

}
