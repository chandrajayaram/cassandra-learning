package com.caiso.soa.mvt.config;

import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.web.SpringBootServletInitializer;

/**
 * The Class MvtApplicationConfig starts the spring boot application.
 */
@SpringBootApplication
public class MvtApplicationConfig extends SpringBootServletInitializer {
    
    /** The Constant log. */
    public static final Logger log = LoggerFactory.getLogger(MvtApplicationConfig.class);

    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        log.info("JVM user time zone is defined: {}", TimeZone.getDefault().getID());
        SpringApplication.run(MvtApplicationConfig.class, args);
    }
}
