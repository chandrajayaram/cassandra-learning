package com.caiso.soa.mvt.broadcast.job;

import java.util.ArrayList;
import java.util.List;

import org.quartz.JobDataMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.caiso.soa.framework.quartz.BroadcastJob;
import com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO;
import com.caiso.soa.mvt.dao.MarketRunDAO;
import com.caiso.soa.mvt.domain.MvtPriceCorrectionDTO;
import com.caiso.soa.mvt.domain.Published;


/**
 * Generic job for Broadcasting market price correction pay-loads.
 * extends broadcast job class from the framework class.
 * @param <T> the generic type JAXB class the represent the pay-load
 */
public class BroadcastMarketPriceCorrection<T> extends BroadcastJob<T> {

	
	private Logger log = LoggerFactory.getLogger(this.getClass());
	private static final String  MARKET_RUN_LIST = "MARKET_RUN_LIST"; 
	private static final String  LOGMARKETINFO = "Jobname %s Market StartDate: %s market EndDate: %s MarketType: %s";
	
	@Autowired
	private MarketRunDAO marketRunDAO;

	@Autowired
	private ApplicationContext context;

	/* (non-Javadoc)
	 * @see com.caiso.soa.framework.quartz.BroadcastJob#getDataAsList(org.quartz.JobDataMap, java.lang.String)
	 */
	@Override
	public List<T> getDataAsList(JobDataMap dataMap, String jobName) {
		log.info("getData: BEGIN:");

		List<T> allpayloads = new ArrayList<>();

		List<T> payloads;
		List<MvtPriceCorrectionDTO> marketRunList = marketRunDAO.getPendingMarketRunInputData("NEW", jobName);
		if (marketRunList == null || marketRunList.isEmpty()) {
			return allpayloads;
		}

		dataMap.put(MARKET_RUN_LIST, marketRunList);

		marketRunDAO.updateMarketRunInputData(marketRunList, "PENDING", jobName);

		@SuppressWarnings("unchecked")
		MarketPriceCorrectionDAO<T> marketPriceCorrection = context.getBean(jobName, MarketPriceCorrectionDAO.class);

		try {
			for (MvtPriceCorrectionDTO marketRun : marketRunList) {
				log.info(String.format(LOGMARKETINFO, jobName, marketRun.getStartDate() , marketRun.getEndDate(), marketRun.getMktType()));

				payloads = marketPriceCorrection.getPayload(marketRun.getStartDate(), marketRun.getEndDate(),
						marketRun.getMktType());
				if (payloads != null && !payloads.isEmpty()) {
					allpayloads.addAll(payloads);
				}
			}
		} catch (Exception ex) {
			log.error("Exception while processing the data.", ex);
			marketRunDAO.updateMarketRunInputData(marketRunList, "ERROR", jobName);
		}
		log.info("getData: END:");

		return allpayloads;
	}

	/* (non-Javadoc)
	 * @see com.caiso.soa.framework.quartz.BroadcastJob#onSuccess(org.quartz.JobDataMap, java.lang.String, java.util.List)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void onSuccess(JobDataMap jobData, String jobName, List<T> data) {

		List<MvtPriceCorrectionDTO> marketRunList = (List<MvtPriceCorrectionDTO>) jobData.get(MARKET_RUN_LIST);
		if (marketRunList != null && !marketRunList.isEmpty()) {
			MarketPriceCorrectionDAO<T> marketPriceCorrection = context.getBean(jobName,
					MarketPriceCorrectionDAO.class);
			marketRunDAO.updateMarketRunInputData(marketRunList, "COMPLETE", jobName);
			for (MvtPriceCorrectionDTO marketRun : marketRunList) {
				log.info("Onsuccess " +  String.format(LOGMARKETINFO,jobName, marketRun.getStartDate() , marketRun.getEndDate(), marketRun.getMktType()));
				marketPriceCorrection.updateStatus(marketRun.getStartDate(), marketRun.getEndDate(),
						marketRun.getMktType(), Published.Y);
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.caiso.soa.framework.quartz.BroadcastJob#onError(org.quartz.JobDataMap, java.lang.String, java.util.List)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void onError(JobDataMap jobData, String jobName, List<T> data) {
		List<MvtPriceCorrectionDTO> marketRunList = (List<MvtPriceCorrectionDTO>) jobData.get(MARKET_RUN_LIST);
		if (marketRunList != null && !marketRunList.isEmpty()) {
			MarketPriceCorrectionDAO<T> marketPriceCorrection = context.getBean(jobName,
					MarketPriceCorrectionDAO.class);
			marketRunDAO.updateMarketRunInputData(marketRunList, "ERROR", jobName);
			for (MvtPriceCorrectionDTO marketRun : marketRunList) {
				log.info("OnError " +  String.format(LOGMARKETINFO, jobName, marketRun.getStartDate() , marketRun.getEndDate(), marketRun.getMktType()));

				marketPriceCorrection.updateStatus(marketRun.getStartDate(), marketRun.getEndDate(),
						marketRun.getMktType(), Published.N);
			}
		}

	}

	/* (non-Javadoc)
	 * @see com.caiso.soa.framework.quartz.BroadcastJob#getData(org.quartz.JobDataMap, java.lang.String)
	 */
	@Override
	public T getData(JobDataMap jobData, String jobName) {
		return null;
	}

}
