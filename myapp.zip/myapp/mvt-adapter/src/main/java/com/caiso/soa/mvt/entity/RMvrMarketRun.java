package com.caiso.soa.mvt.entity;

import java.util.Calendar;

public class RMvrMarketRun {
	private Long id;
	private Long messagePayloadId;
	private String contingencyActive;
	private String contingencyType;
	private String executionType;
	private Calendar marketEndTime;
	private Long marketId;
	private Long marketRunId;
	private Calendar marketStartTime;
	private String marketType;
	private String masterfileRepositoryVersion;
	private String pathExclusions;
	private Calendar stgLoadTs;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getMessagePayloadId() {
		return messagePayloadId;
	}
	public void setMessagePayloadId(Long messagePayloadId) {
		this.messagePayloadId = messagePayloadId;
	}
	public String getContingencyActive() {
		return contingencyActive;
	}
	public void setContingencyActive(String contingencyActive) {
		this.contingencyActive = contingencyActive;
	}
	public String getContingencyType() {
		return contingencyType;
	}
	public void setContingencyType(String contingencyType) {
		this.contingencyType = contingencyType;
	}
	public String getExecutionType() {
		return executionType;
	}
	public void setExecutionType(String executionType) {
		this.executionType = executionType;
	}
	public Calendar getMarketEndTime() {
		return marketEndTime;
	}
	public void setMarketEndTime(Calendar marketEndTime) {
		this.marketEndTime = marketEndTime;
	}
	public Long getMarketId() {
		return marketId;
	}
	public void setMarketId(Long marketId) {
		this.marketId = marketId;
	}
	public Long getMarketRunId() {
		return marketRunId;
	}
	public void setMarketRunId(Long marketRunId) {
		this.marketRunId = marketRunId;
	}
	public Calendar getMarketStartTime() {
		return marketStartTime;
	}
	public void setMarketStartTime(Calendar marketStartTime) {
		this.marketStartTime = marketStartTime;
	}
	public String getMarketType() {
		return marketType;
	}
	public void setMarketType(String marketType) {
		this.marketType = marketType;
	}
	public String getMasterfileRepositoryVersion() {
		return masterfileRepositoryVersion;
	}
	public void setMasterfileRepositoryVersion(String masterfileRepositoryVersion) {
		this.masterfileRepositoryVersion = masterfileRepositoryVersion;
	}
	public String getPathExclusions() {
		return pathExclusions;
	}
	public void setPathExclusions(String pathExclusions) {
		this.pathExclusions = pathExclusions;
	}
	public Calendar getStgLoadTs() {
		return stgLoadTs;
	}
	public void setStgLoadTs(Calendar stgLoadTs) {
		this.stgLoadTs = stgLoadTs;
	}
	
	
}
