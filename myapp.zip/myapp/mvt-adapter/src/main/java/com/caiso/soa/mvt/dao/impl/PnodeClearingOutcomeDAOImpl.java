package com.caiso.soa.mvt.dao.impl;
import static com.caiso.soa.mvt.util.MvtUtil.getCalendar;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO;
import com.caiso.soa.mvt.domain.Published;
import com.caiso.soa.mvt.exception.MvtRuntimeException;
import com.caiso.soa.pnodeclearingoutcome_v2.AggregatedPnode;
import com.caiso.soa.pnodeclearingoutcome_v2.ExecutionType;
import com.caiso.soa.pnodeclearingoutcome_v2.Flowgate;
import com.caiso.soa.pnodeclearingoutcome_v2.HostControlArea;
import com.caiso.soa.pnodeclearingoutcome_v2.IndividualPnode;
import com.caiso.soa.pnodeclearingoutcome_v2.MQSUpdateKind;
import com.caiso.soa.pnodeclearingoutcome_v2.MarginalCongestionCostBreakdown;
import com.caiso.soa.pnodeclearingoutcome_v2.MarketRun;
import com.caiso.soa.pnodeclearingoutcome_v2.MessageHeader;
import com.caiso.soa.pnodeclearingoutcome_v2.MessagePayload;
import com.caiso.soa.pnodeclearingoutcome_v2.PassIndicatorType;
import com.caiso.soa.pnodeclearingoutcome_v2.PnodeClearing;
import com.caiso.soa.pnodeclearingoutcome_v2.PnodeClearingOutcome;
import com.caiso.soa.pnodeclearingoutcome_v2.PnodeResults;
import com.caiso.soa.pnodeclearingoutcome_v2.Update;
import com.caiso.soa.pnodeclearingoutcome_v2.YesNo;


/**
 * The Class PnodeClearingOutcomeDAOImpl returns the payload for pnode clearing message.
 */
@Repository("broadcastPnodeClearingOutcomeV2")
public class PnodeClearingOutcomeDAOImpl implements  MarketPriceCorrectionDAO<PnodeClearingOutcome>{

	/** The template. */
	@Autowired
    @Qualifier("mvtLmpJdbcTemplate")
    private NamedParameterJdbcTemplate template;
	
	/** The mkt notes jdbc template. */
	@Autowired
    @Qualifier("mktNotesJdbcTemplate")
    private NamedParameterJdbcTemplate mktNotesJdbcTemplate;

    /** The log. */
    private Logger log = LoggerFactory.getLogger(this.getClass());

    /** The Constant MKT_TIME_SQL. */
    private static final String MKT_TIME_SQL = "select distinct MARKET_START_TIME, MKT_TYPE"
											+"	from PNODE_LMP_CORRECTION T1"
											+"	WHERE T1.TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
											+"	AND T1.TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')" 
											+"	AND T1.CORRECTION_FLAG = 'Y' AND MKT_TYPE = :MKT_TYPE "
											+"UNION "
											+ "select distinct MARKET_START_TIME, MKT_TYPE"
											+"	from APNODE_LMP_CORRECTION T1"
											+"	WHERE T1.TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
											+"	AND T1.TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')" 
											+"	AND T1.CORRECTION_FLAG = 'Y'  AND MKT_TYPE = :MKT_TYPE";
    
    /** The Constant APNODE_CLEARING_SQL. */
    private static final String APNODE_CLEARING_SQL = "select T1.MARKET_START_TIME, T1.MKT_TYPE, T1.TIME_INTERVAL,T1.APNODE_ID AS ID, T1.APNODE_NAME AS MRID, "
										 +"T1.CALC_LMP, T1.CALC_COST_LMP,T1.CALC_LOSS_LMP,T1.CALC_CONG_LMP, T1.CALC_GHG_LMP, T1.CORRECTION_REASON "
										 +" from APNODE_LMP_CORRECTION T1 "
										 +" WHERE T1.TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') "
										 +" AND T1.TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') "
										 +" AND T1.CORRECTION_FLAG = 'Y' AND MKT_TYPE=:MKT_TYPE "
										 + " AND PUBLISHED_YN IS NULL "
    									 + "ORDER BY T1.TIME_INTERVAL ";
										 
    
	
    /** The Constant APNODE_CLEARING_SP_MCC_CORRECTION. */
    private static final String APNODE_CLEARING_SP_MCC_CORRECTION = "select T2.SP_NAME, T2.BAA_ID,T2.BAA_NAME, T2.CALC_MCC, T2.CORRECTION_REASON, T2.TIME_INTERVAL, T2.MKT_TYPE, T2.MARKET_START_TIME"
													    +" from APNODE_LMP_CORRECTION T1, SP_MCC_CORRECTION T2 "
													    +" WHERE T1.TIME_INTERVAL = T2.TIME_INTERVAL "
														+" AND T1.MKT_TYPE = T2.MKT_TYPE "
														+" AND T1.APNODE_NAME = T2.SP_NAME" 
														+" AND T1.MARKET_START_TIME = T2.MARKET_START_TIME" 
														+" AND T2.CORRECTION_FLAG = 'Y'"
														+" AND T1.TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') "
														+" AND T1.TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') "
														+" AND T1.CORRECTION_FLAG = 'Y' AND T1.MKT_TYPE=:MKT_TYPE AND T2.MKT_TYPE=:MKT_TYPE "
														+ " AND T1.PUBLISHED_YN IS NULL AND T2.PUBLISHED_YN IS NULL "
														+ " ORDER BY T2.TIME_INTERVAL";
   
	/** The Constant APNODE_CLEARING_SP_TIE_MCC_CORRECTION. */
	private static final String APNODE_CLEARING_SP_TIE_MCC_CORRECTION = "select T3.SP_NAME,"
															+" T3.INTER_TIE_NAME, T3.BAA_NAME AS SP_TIE_BAA, T3.CALC_MCC AS SP_TIE_MCC,  T3.CALC_LMP AS SP_TIE_LMP"
															+" ,t3.CALC_GHG_LMP AS SP_TIE_GHG,T3.CALC_COST_LMP AS SP_TIE_COST, T3.CALC_LOSS_LMP AS SP_TIE_LOSS , T3.TIME_INTERVAL, T3.MKT_TYPE, T3.MARKET_START_TIME"
															+" FROM APNODE_LMP_CORRECTION T1, SP_TIE_MCC_CORRECTION T3"
															+" WHERE "
															+"  T1.TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') "
															+" AND T1.TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') "
															+" AND T1.CORRECTION_FLAG = 'Y'"                              
															+" AND T1.TIME_INTERVAL = T3.TIME_INTERVAL" 
															+" AND T1.MKT_TYPE = T3.MKT_TYPE "
															+" AND T1.APNODE_NAME = T3.SP_NAME" 
															+" AND T1.MARKET_START_TIME = T3.MARKET_START_TIME" 
															+" AND T3.CORRECTION_FLAG = 'Y' AND T1.MKT_TYPE=:MKT_TYPE AND T3.MKT_TYPE=:MKT_TYPE "
															+ " AND T1.PUBLISHED_YN IS NULL AND T3.PUBLISHED_YN IS NULL "
															+ "  ORDER BY T3.TIME_INTERVAL";
	
	/** The Constant PNODE_CLEARING_SQL. */
	private static final String PNODE_CLEARING_SQL = "select T1.MARKET_START_TIME, T1.MKT_TYPE, T1.TIME_INTERVAL,T1.PNODE_ID AS ID, T1.PNODE_NAME AS MRID, "
										 +"			T1.CALC_LMP, T1.CALC_COST_LMP,T1.CALC_LOSS_LMP,T1.CALC_CONG_LMP, T1.CALC_GHG_LMP, T1.CORRECTION_REASON "
										 +"			from PNODE_LMP_CORRECTION T1 "
										 +"			WHERE T1.TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') "
										 +"			AND T1.TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') "
										 +"			AND T1.CORRECTION_FLAG = 'Y' AND T1.MKT_TYPE=:MKT_TYPE " 
										 +" 	    AND T1.PUBLISHED_YN IS NULL"
										 +"			ORDER BY T1.TIME_INTERVAL";		


	/** The Constant PNODE_CLEARING_SP_MCC_CORRECTION. */
	private static final String PNODE_CLEARING_SP_MCC_CORRECTION = "select T2.SP_NAME, T2.BAA_ID,T2.BAA_NAME, T2.CALC_MCC, T2.CORRECTION_REASON , T2.TIME_INTERVAL, T2.MKT_TYPE, T2.MARKET_START_TIME"
													    +" from PNODE_LMP_CORRECTION T1, SP_MCC_CORRECTION T2 "
													    +"	        WHERE T1.TIME_INTERVAL = T2.TIME_INTERVAL "
														+"             AND T1.MKT_TYPE = T2.MKT_TYPE "
														+"             AND T1.PNODE_NAME = T2.SP_NAME" 
														+"             AND T1.MARKET_START_TIME = T2.MARKET_START_TIME" 
														+"             AND T2.CORRECTION_FLAG = 'Y'"
														+"             AND T1.TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
														+"             AND T1.TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
														+"             AND T1.CORRECTION_FLAG = 'Y'  AND T1.MKT_TYPE=:MKT_TYPE  AND T2.MKT_TYPE=:MKT_TYPE"
														+" 			   AND T1.PUBLISHED_YN IS NULL AND T2.PUBLISHED_YN IS NULL "
														+"			    ORDER BY T2.TIME_INTERVAL";		
	
	/** The Constant PNODE_CLEARING_SP_TIE_MCC_CORRECTION. */
	private static final String PNODE_CLEARING_SP_TIE_MCC_CORRECTION = "select T3.SP_NAME,"
															+" T3.INTER_TIE_NAME, T3.BAA_NAME AS SP_TIE_BAA, T3.CALC_MCC AS SP_TIE_MCC,  T3.CALC_LMP AS SP_TIE_LMP"
															+" ,t3.CALC_GHG_LMP AS SP_TIE_GHG,T3.CALC_COST_LMP AS SP_TIE_COST, T3.CALC_LOSS_LMP AS SP_TIE_LOSS, T3.TIME_INTERVAL, T3.MKT_TYPE, T3.MARKET_START_TIME"
															+" FROM PNODE_LMP_CORRECTION T1, SP_TIE_MCC_CORRECTION T3"
															+" WHERE "
															+"  T1.TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
															+" AND T1.TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
															+" AND T1.CORRECTION_FLAG = 'Y'"                              
															+" AND T1.TIME_INTERVAL = T3.TIME_INTERVAL" 
															+"      AND T1.MKT_TYPE = T3.MKT_TYPE "
															+"      AND T1.PNODE_NAME = T3.SP_NAME" 
															+"      AND T1.MARKET_START_TIME = T3.MARKET_START_TIME" 
															+"      AND T3.CORRECTION_FLAG = 'Y' AND T1.MKT_TYPE=:MKT_TYPE  AND T3.MKT_TYPE=:MKT_TYPE"
															+" 		AND T1.PUBLISHED_YN IS NULL AND T3.PUBLISHED_YN IS NULL "
															+" 		ORDER BY T3.TIME_INTERVAL "	;
	
	
	
	/** The Constant APNODE_LMP_CORRECTION_UPDATE. */
	private static final String APNODE_LMP_CORRECTION_UPDATE = "update APNODE_LMP_CORRECTION set PUBLISHED_YN= :PUBLISHED_YN where  "
			+"  TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
			+" AND TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
			+" AND CORRECTION_FLAG = 'Y' AND PUBLISHED_YN IS NULL AND MKT_TYPE=:MKT_TYPE ";
	
	
	/** The Constant SP_MCC_CORRECTION_UPDATE. */
	private static final String SP_MCC_CORRECTION_UPDATE = "update SP_MCC_CORRECTION set PUBLISHED_YN= :PUBLISHED_YN where  "
			+"  TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
			+" AND TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
			+" AND CORRECTION_FLAG = 'Y' AND PUBLISHED_YN IS NULL AND MKT_TYPE=:MKT_TYPE ";
	
	/** The Constant PNODE_LMP_CORRECTION_UPDATE. */
	private static final String PNODE_LMP_CORRECTION_UPDATE = "update PNODE_LMP_CORRECTION set PUBLISHED_YN= :PUBLISHED_YN where  "
															+"  TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
															+" AND TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
															+" AND CORRECTION_FLAG = 'Y' AND PUBLISHED_YN IS NULL AND MKT_TYPE=:MKT_TYPE ";
	
	
	/** The Constant SP_TIE_MCC_CORRECTION_UPDATE. */
	private static final String SP_TIE_MCC_CORRECTION_UPDATE = "update SP_TIE_MCC_CORRECTION set PUBLISHED_YN= :PUBLISHED_YN where  "
			+"  TIME_INTERVAL >=(FROM_TZ(CAST(:START_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
			+" AND TIME_INTERVAL<(FROM_TZ(CAST(:END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT')"
			+" AND CORRECTION_FLAG = 'Y' AND PUBLISHED_YN IS NULL AND MKT_TYPE=:MKT_TYPE ";

	
	/** The mkt mapping. */
	private final Map<String, String> mktMapping = new HashMap<>();
	
	/** The commodity mapping. */
	private final Map<String, String> commodityMapping = new HashMap<>();
	
	/**
	 * Instantiates a new pnode clearing outcome DAO impl.
	 */
	public PnodeClearingOutcomeDAOImpl(){
		mktMapping.put("DA","RTPD");
		mktMapping.put("RTD","RTPD");
		mktMapping.put("RTPD","RTPD");
		mktMapping.put("RUC","RUC");
		mktMapping.put("HASP","HA-SCUC");
		
		commodityMapping.put("Nr", "NR");
		commodityMapping.put("Sr", "SR");
		commodityMapping.put("Ru", "RU");
		commodityMapping.put("Rd", "RD");
		commodityMapping.put("Md", "RMD");
		commodityMapping.put("Mu", "RMU");
		commodityMapping.put("En", "EN");
		commodityMapping.put("Ur", "FRU");
		commodityMapping.put("Dr", "FRD");
		commodityMapping.put("Ld", "LFD");
		commodityMapping.put("Lu", "LFU");
		
	}
	
	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#getPayload(java.util.Date, java.util.Date, java.lang.String)
	 */
	@Override
	public List<PnodeClearingOutcome> getPayload(Date startDate, Date endDate, String marketType) {
		log.info(" getPnodeClearingData Begin...");
		List<PnodeClearingOutcome> pnodeList = new ArrayList<>();
	
		try{
			List<MessagePayload> payloadList = preparePayLoad(startDate, endDate, marketType);
			
			for(MessagePayload payload: payloadList){
				PnodeClearingOutcome outcome = new PnodeClearingOutcome();
				outcome.setMessageHeader(new MessageHeader());
				outcome.getMessageHeader().setVersion("v20161001");
				outcome.getMessageHeader().setSource("MVT");
				outcome.getMessageHeader().setTimeDate(SOAPUtils.currentTime());
				outcome.setMessagePayload(payload);
				pnodeList.add(outcome);
			}	
		}catch(Exception ex){
			log.error("error accoured while processing the correction payload pnode clearing", ex);
			throw new MvtRuntimeException(ex) ;
		}
		log.info(" getPnodeClearingData END.");
		return pnodeList;
	}

	/**
	 * Gets the market run data.
	 *
	 * @param startDate the start date
	 * @param marketType the market type
	 * @param marketStartTime the market start time
	 * @return the market run data
	 */
	private MarketRun getMarketRunData(String marketType, XMLGregorianCalendar marketStartTime) {
		log.info(" getMarketRunData Begin...");
		MarketRun marketRun = new MarketRun();
		marketRun.setCorrectionPayloadFlag(true);
		marketRun.setExecutionType(ExecutionType.valueOf(marketType));
		marketRun.setMarketStartTime(marketStartTime);
		marketRun.setMarketRunID("0");
		marketRun.setMarketID("0");
		log.info(" getMarketRunData End...");
		return marketRun;
	}

	/**
	 * Prepare pay load.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param marketType the market type
	 * @return the list
	 * @throws InvalidResultSetAccessException the invalid result set access exception
	 * @throws DatatypeConfigurationException the datatype configuration exception
	 */
	private List<MessagePayload> preparePayLoad(Date startDate, Date endDate, String marketType) throws DatatypeConfigurationException{
		log.info(" preparePayLoad Begin..." + startDate );
		
		XMLGregorianCalendar now = getCalendar(new Timestamp(new Date().getTime()));
		
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("START_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);
		
		SqlRowSet rs = null;
		SqlRowSet rs2 = null;
		SqlRowSet rs3 = null;
		SqlRowSet mktRs = template.queryForRowSet(MKT_TIME_SQL, paramSource);
		
		
		PnodeResults result;
		List<MessagePayload> payloadList = new ArrayList<>(10);
		
		MessagePayload payload;
		
		while(mktRs.next()){//For each time interval
			
			payload = new MessagePayload();
			 
			payload.setMarketRun(getMarketRunData(mktRs.getString("MKT_TYPE"), getCalendar(mktRs.getTimestamp("MARKET_START_TIME"))));	
			
			for(String nodeType:new String[] {"APNODE", "PNODE"}){
				
				if(nodeType.equals("APNODE")){
					rs = template.queryForRowSet(APNODE_CLEARING_SQL, paramSource);
					rs2 = template.queryForRowSet(APNODE_CLEARING_SP_MCC_CORRECTION, paramSource);
					rs3 = template.queryForRowSet(APNODE_CLEARING_SP_TIE_MCC_CORRECTION, paramSource);
				}else if(nodeType.equals("PNODE")){
					rs = template.queryForRowSet(PNODE_CLEARING_SQL, paramSource);
					rs2 = template.queryForRowSet(PNODE_CLEARING_SP_MCC_CORRECTION, paramSource);
					rs3 = template.queryForRowSet(PNODE_CLEARING_SP_TIE_MCC_CORRECTION, paramSource);
				}
				
				
				while (rs.next()) {
					 if(mktRs.getTimestamp("MARKET_START_TIME").getTime() == rs.getTimestamp("MARKET_START_TIME").getTime() && 
							 //mktRs.getTimestamp("TIME_INTERVAL").getTime() == rs.getTimestamp("TIME_INTERVAL").getTime() && 
							 mktRs.getString("MKT_TYPE").equals(rs.getString("MKT_TYPE"))){
						 
							 PnodeClearing pnode = new PnodeClearing();
									
							 pnode.setIntervalStartTime(getCalendar(rs.getTimestamp("TIME_INTERVAL")));
							 pnode.setPassIndicator(PassIndicatorType.valueOf(mktMapping.get(rs.getString("MKT_TYPE"))));
							 
							 result = new PnodeResults();
							 
							 //Populate from APNODE or PNODE_LMP_CORRECTION
							 String pnodeName = constructPnodeData(rs, result, nodeType);
							 
							 //Populate SP_MCC_CORRECTION DATA
							 constructSpMccData(now, rs, rs2, result, pnodeName);
							 
							 //Add to pnode clearing
							 pnode.getPnodeResults().add(result);
							 
							 //Populate SP_TIE_MCC_CORRECTION_DATA
							 constructSPTieMccData(now, rs, rs3, pnode, pnodeName, nodeType);
							 
							 payload.getPnodeClearings().add(pnode);
					}//End if
				}//End RS
			}	
			rs.beforeFirst();
			
			payloadList.add(payload);
		}
		log.info("Payload size:" + payloadList.size());
		
		log.info(" preparePayLoad END...");
		return payloadList;
	}

	/**
	 * Construct pnode data.
	 *
	 * @param rs the rs
	 * @param result the result
	 * @param nodeType the node type
	 * @return the string
	 */
	private String constructPnodeData(SqlRowSet rs, PnodeResults result, String nodeType) {
		float congestLMP = rs.getFloat("CALC_CONG_LMP");
		 if(!rs.wasNull()){
			 result.setCongestLMP(congestLMP);
		 }	 
		 
		 float costLmp = rs.getFloat("CALC_COST_LMP"); 
		 if(!rs.wasNull()){
			 result.setCostLMP(costLmp);
		 }	 
		 
		 float ghgLmp = rs.getFloat("CALC_GHG_LMP");
		 if(!rs.wasNull()){
			 result.setGreenHouseGasLMP(ghgLmp);
		 }
		 
		 float lossLmp = rs.getFloat("CALC_LOSS_LMP");
		 if(!rs.wasNull()){
			 result.setLossLMP(lossLmp);
		 }	 
		 
		 float marginalClearingPrice = rs.getFloat("CALC_LMP");
		 if(!rs.wasNull()){
			 result.setMarginalClearingPrice(marginalClearingPrice);
		 }
		 
		 
		 result.setOriginalPrice(YesNo.YES);//Default to YES
		 
		 result.setPriceCorrectionReason(rs.getString("CORRECTION_REASON"));
		 
		 String pnodeName = rs.getString("MRID");
		 if(nodeType.equals("APNODE")){
			 AggregatedPnode apNode = new AggregatedPnode();
			 apNode.setMrid(pnodeName);
			 result.setAggregatedPnode(apNode);
		 }else{
			 IndividualPnode ipNode = new IndividualPnode();
			 ipNode.setMrid(pnodeName);
			 result.setIndividualPnode(ipNode);
		 }
		return pnodeName;
	}

	/**
	 * Construct sp mcc data.
	 *
	 * @param now the now
	 * @param rs the rs
	 * @param rs2 the rs 2
	 * @param result the result
	 * @param pnodeName the pnode name
	 */
	private void constructSpMccData(XMLGregorianCalendar now,SqlRowSet rs, SqlRowSet rs2, PnodeResults result, String pnodeName) {
		MarginalCongestionCostBreakdown costBreakDown;
		HostControlArea controlArea;
		while (rs2.next()){
			 
			 if(pnodeName.equals(rs2.getString("SP_NAME"))
				&&  rs.getString("MKT_TYPE").equals(rs2.getString("MKT_TYPE"))	 
				&& 	rs.getTimestamp("TIME_INTERVAL").getTime() == rs2.getTimestamp("TIME_INTERVAL").getTime()
				&& 	rs.getTimestamp("MARKET_START_TIME").getTime() == rs2.getTimestamp("MARKET_START_TIME").getTime()
				){
				 
				 costBreakDown = new MarginalCongestionCostBreakdown();
				 controlArea = new HostControlArea();
				 
				 controlArea.setMrid(rs2.getString("BAA_NAME"));
				 
				 costBreakDown.setHostControlArea(controlArea);
				 
				 costBreakDown.setCongestLMP(rs2.getFloat("CALC_MCC"));
				 
				 costBreakDown.setPriceCorrectionReason(rs2.getString("CORRECTION_REASON"));
				 
				 result.getMarginalCongestionCostBreakdowns().add(costBreakDown);
			 }
		 }
		 rs2.beforeFirst();
		 
		 Update update = new Update();
		 update.setUpdateTimeStamp(now);
		 update.setUpdateType(MQSUpdateKind.CHG);
		 update.setUpdateUser("MVT");
		 result.setUpdate(update);
	}

	/**
	 * Construct SP tie mcc data.
	 *
	 * @param now the now
	 * @param rs the rs
	 * @param rs3 the rs 3
	 * @param pnode the pnode
	 * @param pnodeName the pnode name
	 * @param nodeType the node type
	 */
	private void constructSPTieMccData(XMLGregorianCalendar now, SqlRowSet rs, SqlRowSet rs3, PnodeClearing pnode, String pnodeName, String nodeType) {
		PnodeResults result;
		float costLmp;
		float ghgLmp;
		float lossLmp;
		float marginalClearingPrice;
		float calcMcc;
		Update update;
		MarginalCongestionCostBreakdown costBreakDown;
		HostControlArea controlArea;
		
		while(rs3.next()){
			 if(pnodeName.equals(rs3.getString("SP_NAME"))
				&&  rs.getString("MKT_TYPE").equals(rs3.getString("MKT_TYPE"))	 
				&& 	rs.getTimestamp("TIME_INTERVAL").getTime() == rs3.getTimestamp("TIME_INTERVAL").getTime()
				&& 	rs.getTimestamp("MARKET_START_TIME").getTime() == rs3.getTimestamp("MARKET_START_TIME").getTime()	 
			   ){
				 result = new PnodeResults();					//Create new Pnode for SP_TIE_MCC_CORRECTION.
				 
				 calcMcc = rs3.getFloat("SP_TIE_MCC"); 
				 if(!rs3.wasNull()){
					 result.setCongestLMP(calcMcc);
				 }
				 
				 costLmp = rs3.getFloat("SP_TIE_COST"); 
				 if(!rs3.wasNull()){
					 result.setCostLMP(costLmp);
				 }	 
				 
				 ghgLmp = rs3.getFloat("SP_TIE_GHG");
				 if(!rs3.wasNull()){
					 result.setGreenHouseGasLMP(ghgLmp);
				 }
				 
				 lossLmp = rs3.getFloat("SP_TIE_LOSS");
				 if(!rs3.wasNull()){
					 result.setLossLMP(lossLmp);
				 }	 
				 
				 marginalClearingPrice = rs3.getFloat("SP_TIE_LMP");
				 if(!rs3.wasNull()){
					 result.setMarginalClearingPrice(marginalClearingPrice);
				 }
				 
				 Flowgate fg = new Flowgate();
				 fg.setMrid(rs3.getString("INTER_TIE_NAME"));
				 result.setFlowgate(fg);
				 
				 costBreakDown = new MarginalCongestionCostBreakdown();
				 controlArea = new HostControlArea();
				 controlArea.setMrid(rs3.getString("SP_TIE_BAA"));
				 costBreakDown.setHostControlArea(controlArea);
				 calcMcc = rs3.getFloat("SP_TIE_MCC"); 
				 if(!rs3.wasNull()){
					 costBreakDown.setCongestLMP(calcMcc);
				 }
				 result.getMarginalCongestionCostBreakdowns().add(costBreakDown);
				 
				 if(nodeType.equals("APNODE")){
					 AggregatedPnode apNode = new AggregatedPnode();
					 apNode.setMrid(pnodeName);
					 result.setAggregatedPnode(apNode);
				 }else{
					 IndividualPnode ipNode = new IndividualPnode();
					 ipNode.setMrid(pnodeName);
					 result.setIndividualPnode(ipNode);
				 }
				 update = new Update();
				 update.setUpdateTimeStamp(now);
				 update.setUpdateType(MQSUpdateKind.CHG);
				 update.setUpdateUser("MVT");
				 result.setUpdate(update);
				 
				 pnode.getPnodeResults().add(result);
			 }//End IF
		 }//End RS2
		 rs3.beforeFirst();
	}

	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#updateStatus(java.util.Date, java.util.Date, java.lang.String, com.caiso.soa.mvt.domain.Published)
	 */
	@Override
	public void updateStatus(Date startDate, Date endDate, String marketType, Published status) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("START_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);
		paramSource.addValue("PUBLISHED_YN", status.toString());
		template.update(APNODE_LMP_CORRECTION_UPDATE, paramSource);
		template.update(SP_MCC_CORRECTION_UPDATE, paramSource);
		template.update(PNODE_LMP_CORRECTION_UPDATE, paramSource);
		template.update(SP_TIE_MCC_CORRECTION_UPDATE, paramSource);
		
	}
 }
