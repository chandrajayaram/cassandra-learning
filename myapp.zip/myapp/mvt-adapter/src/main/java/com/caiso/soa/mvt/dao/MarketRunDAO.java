package com.caiso.soa.mvt.dao;

import java.util.List;

import com.caiso.soa.mvt.domain.MvtPriceCorrectionDTO;

/**
 * The Interface MarketRunDAO for managing the market correction interval dates for 
 * message payloads.
 */
public interface MarketRunDAO {
	
	/**
	 * Gets the pending market run input data.
	 *
	 * @param status the status
	 * @param serviceName the service name
	 * @return the pending market run input data
	 */
	public List<MvtPriceCorrectionDTO> getPendingMarketRunInputData(String status, String serviceName);

	/**
	 * Update market run input data.
	 *
	 * @param marketRunList the market run list
	 * @param status the status
	 * @param serviceName the service name
	 */
	public void updateMarketRunInputData(List<MvtPriceCorrectionDTO> marketRunList, String status, String serviceName);
}
