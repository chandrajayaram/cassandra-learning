package com.caiso.soa.mvt.dao.impl;
import static com.caiso.soa.mvt.util.MvtUtil.getCalendar;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.caiso.soa.framework.utils.SOAPUtils;
import com.caiso.soa.mitigatedbidset_v1.BidMitigationStatus;
import com.caiso.soa.mitigatedbidset_v1.BidMitigationType;
import com.caiso.soa.mitigatedbidset_v1.BidPriceCurve;
import com.caiso.soa.mitigatedbidset_v1.BidSchedule;
import com.caiso.soa.mitigatedbidset_v1.BidSetCurveSchedData;
import com.caiso.soa.mitigatedbidset_v1.ConfigurationNmReq;
import com.caiso.soa.mitigatedbidset_v1.ExecutionType;
import com.caiso.soa.mitigatedbidset_v1.GeneratingBidMB;
import com.caiso.soa.mitigatedbidset_v1.MarketRunMsg;
import com.caiso.soa.mitigatedbidset_v1.MessageHeader;
import com.caiso.soa.mitigatedbidset_v1.MessagePayload;
import com.caiso.soa.mitigatedbidset_v1.MitigatedBid;
import com.caiso.soa.mitigatedbidset_v1.MitigatedBidClearing;
import com.caiso.soa.mitigatedbidset_v1.MitigatedBidSet;
import com.caiso.soa.mitigatedbidset_v1.PassIndicatorType;
import com.caiso.soa.mitigatedbidset_v1.ProductBidMB;
import com.caiso.soa.mitigatedbidset_v1.RegisteredGenerator;
import com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO;
import com.caiso.soa.mvt.domain.Published;
import com.caiso.soa.mvt.exception.MvtRuntimeException;



/**
 * The Class MitigatedBidSetDAOImpl generates payload for mitigated bid set message.
 */
@Repository("broadcastMitigatedBidSetV1")
public class MitigatedBidSetDAOImpl implements MarketPriceCorrectionDAO<MitigatedBidSet> {

	/** The template. */
	@Autowired
	@Qualifier("mvtLmpJdbcTemplate")
	private NamedParameterJdbcTemplate template;

	/** The log. */
	private Logger log = LoggerFactory.getLogger(this.getClass());
	
	
	/** The Constant MITIGATED_BIDSET. */
	private static final String MITIGATED_BIDSET = "SELECT MKT_START_TIME,MKT_TYPE, TIME_INTERVAL_S, TIME_INTERVAL_E, RESOURCE_ID, RESOURCE_NAME, MITIGATION_STATUS, BID_TYPE, COMMODITY_TYPE, BID_CURVE_ID, BID_SEG_MW, CALC_BID_PRICE, CORRECTION_REASON, " 
													+"	dense_rank() over(order by MKT_START_TIME,TIME_INTERVAL_S,RESOURCE_NAME) as \"MITIGATED_BID\", "
													+"	dense_rank() over(order by MKT_START_TIME,TIME_INTERVAL_S,RESOURCE_NAME,BID_TYPE) as \"BID_SCHEDULE\" FROM BID_CORRECTION "
													+ "  WHERE CORRECTION_FLAG = 'Y' AND TIME_INTERVAL_S>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND TIME_INTERVAL_E<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL "
													+" ORDER BY MKT_START_TIME, TIME_INTERVAL_S, RESOURCE_NAME,BID_TYPE";	
			   

	/** The Constant MITIGATED_BIDSET_UPDATE. */
	private static final String MITIGATED_BIDSET_UPDATE = "UPDATE BID_CORRECTION SET PUBLISHED_YN= :PUBLISHED_YN"
			+ "  WHERE CORRECTION_FLAG = 'Y' AND TIME_INTERVAL_S>=(FROM_TZ(CAST(:TRADE_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND TIME_INTERVAL_E<(FROM_TZ(CAST(:TRADE_END_DATE AS TIMESTAMP), 'PST') AT TIME ZONE 'GMT') AND MKT_TYPE=:MKT_TYPE AND PUBLISHED_YN IS NULL";
				
	
	
	
	/** The Constant mktMapping. */
	private static final Map<String, String> mktMapping = new HashMap<>();
	
	/** The Constant commodityMapping. */
	private static final Map<String, String> commodityMapping = new HashMap<>();
	
	
	static{
		
		mktMapping.put("DA","IFM");
		mktMapping.put("RTD","RTED");
		mktMapping.put("RTPD","RTPD");
		mktMapping.put("RUC","RC");
		mktMapping.put("HASP","HA-SCUC");	
				
		commodityMapping.put("Nr", "NR");
		commodityMapping.put("Sr", "SR");
		commodityMapping.put("Ru", "RU");
		commodityMapping.put("Rd", "RD");
		commodityMapping.put("Md", "RMD");
		commodityMapping.put("Mu", "RMU");
		commodityMapping.put("En", "EN");
		commodityMapping.put("Ur", "FRU");
		commodityMapping.put("Dr", "FRD");
		commodityMapping.put("Ld", "LFD");
		commodityMapping.put("Lu", "LFU");
		
	}
	
	

	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#getPayload(java.util.Date, java.util.Date, java.lang.String)
	 */
	@Override
	public List<MitigatedBidSet> getPayload(Date startDate, Date endDate, String marketType) {
		log.info(" getPayload MITIGATED BIDSET Begin...");
		List<MitigatedBidSet> payloadList = new ArrayList<>();

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);

		try {
			SqlRowSet rowSet = template.queryForRowSet(MITIGATED_BIDSET, paramSource);
			XMLGregorianCalendar currMarketStartTime;
			XMLGregorianCalendar prevMarketStartTime = null;

			MessagePayload payload;
			MitigatedBidSet bidSet;
			MessageHeader messageHeader;
			
			List<MitigatedBidClearing> mitigatedBidClearings;
			MitigatedBidClearing mitigatedBidClearing;
			List<MitigatedBid> mitigatedBids = null;
			MitigatedBid mitigatedBid;
			GeneratingBidMB generatingBid;
			List<ProductBidMB> productBids = null;
			ProductBidMB productBid;
			List<BidSchedule> bidSchedules;
			BidSchedule bidSchedule;
			BidPriceCurve bidCurvePrice = null;
			List<BidSetCurveSchedData> cureSchedDatas;
			BidSetCurveSchedData bidSetCurveSchedData;
			XMLGregorianCalendar currIntervalStartTime;
			String prevBidScheduleId = null;
			String curBidScheduleId;
			
			String prevMitigatedBidId = null;
			String curMitigatedBidId;
			
			
			while (rowSet.next()) {
				currMarketStartTime = getCalendar(rowSet.getTimestamp("MKT_START_TIME"));
				if (prevMarketStartTime == null || !prevMarketStartTime.equals(currMarketStartTime)) {
					prevMarketStartTime = currMarketStartTime;
					bidSet = new MitigatedBidSet();
					messageHeader = new MessageHeader();
					messageHeader.setVersion("v20161001");
					messageHeader.setSource("MVT");
					messageHeader.setTimeDate(SOAPUtils.currentTime());
					payload = new MessagePayload();
					bidSet.setMessageHeader(messageHeader);
					bidSet.setMessagePayload(payload);
					payload.setMarketRun(getMarketRunData(marketType, currMarketStartTime));
					payloadList.add(bidSet);
					mitigatedBidClearings = payload.getMitigatedBidClearings();
					mitigatedBidClearing = new MitigatedBidClearing();
					mitigatedBidClearing.setPassIndicator(PassIndicatorType.valueOf(mktMapping.get(marketType)));
					mitigatedBids = mitigatedBidClearing.getMitigatedBids();
					mitigatedBidClearings.add(mitigatedBidClearing);
					
					prevMitigatedBidId = null;
					prevBidScheduleId = null;
				}
				
				curMitigatedBidId = rowSet.getString("MITIGATED_BID");
				if(prevMitigatedBidId == null || !curMitigatedBidId.equals(prevMitigatedBidId)){
					prevMitigatedBidId = curMitigatedBidId;
					mitigatedBid = new MitigatedBid();
					mitigatedBids.add(mitigatedBid);
					generatingBid = new GeneratingBidMB();
					generatingBid.setMrid(rowSet.getString("RESOURCE_NAME"));
					RegisteredGenerator registedRenerator = new RegisteredGenerator();
					registedRenerator.setMrid(rowSet.getString("RESOURCE_NAME"));
					ConfigurationNmReq config = new ConfigurationNmReq();
					config.setMrid(rowSet.getString("RESOURCE_NAME"));
					registedRenerator.setConfiguration(config );
					generatingBid.setRegisteredGenerator(registedRenerator);
					productBids = generatingBid.getProductBids();
					mitigatedBid.setGeneratingBid(generatingBid);
					prevBidScheduleId = null;
				}
				
				
				curBidScheduleId = rowSet.getString("BID_SCHEDULE");
				currIntervalStartTime= getCalendar(rowSet.getTimestamp("TIME_INTERVAL_S"));
				if(prevBidScheduleId == null || !curBidScheduleId.equals(prevBidScheduleId)){
					prevBidScheduleId = curBidScheduleId;
					productBid = new ProductBidMB();
					bidSchedules = productBid.getBidSchedules();
					bidSchedule = new BidSchedule();
					bidSchedule.setTimeIntervalEnd(currIntervalStartTime);
					bidSchedule.setTimeIntervalEnd(getCalendar(rowSet.getTimestamp("TIME_INTERVAL_E")));
					bidSchedule.setBidType(BidMitigationType.valueOf(rowSet.getString("BID_TYPE")));
					bidSchedule.setMitigationStatus(BidMitigationStatus.valueOf(rowSet.getString("MITIGATION_STATUS")));
					bidSchedule.setPriceCorrectionReason(rowSet.getString("CORRECTION_REASON"));
					bidCurvePrice = new BidPriceCurve();
					bidSchedule.setBidPriceCurve(bidCurvePrice);
					bidSchedules.add(bidSchedule);
					productBids.add(productBid);
				}
				cureSchedDatas = bidCurvePrice.getCurveSchedDatas();
				bidSetCurveSchedData = new BidSetCurveSchedData();
				bidSetCurveSchedData.setXAxisData(rowSet.getFloat("BID_SEG_MW"));
				bidSetCurveSchedData.setY1AxisData(rowSet.getFloat("CALC_BID_PRICE"));
				cureSchedDatas.add(bidSetCurveSchedData);
			}

		} catch (Exception ex) {
			log.debug("error accoured while processing the correction payload resource awards", ex);
			throw new MvtRuntimeException(ex);
		}
		return payloadList;
	}

	/**
	 * Gets the market run data.
	 *
	 * @param marketType the market type
	 * @param marketStartTime the market start time
	 * @return the market run data
	 */
	private MarketRunMsg getMarketRunData(String marketType, XMLGregorianCalendar marketStartTime) {
		MarketRunMsg marketRun = new MarketRunMsg();
		marketRun.setCorrectionPayloadFlag(true);
		marketRun.setExecutionType(ExecutionType.valueOf(marketType));
		marketRun.setDataStartTime(marketStartTime);
		marketRun.setMarketRunID("0");
		marketRun.setMarketID("0");
		return marketRun;
	}
	
	
	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketPriceCorrectionDAO#updateStatus(java.util.Date, java.util.Date, java.lang.String, com.caiso.soa.mvt.domain.Published)
	 */
	@Override
	public void updateStatus(Date startDate, Date endDate, String marketType, Published status) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("TRADE_DATE", new Timestamp(startDate.getTime()));
		paramSource.addValue("TRADE_END_DATE", new Timestamp(endDate.getTime()));
		paramSource.addValue("MKT_TYPE", marketType);
		paramSource.addValue("PUBLISHED_YN", status.toString());
		template.update(MITIGATED_BIDSET_UPDATE, paramSource);
	}

}
