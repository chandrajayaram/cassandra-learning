package com.caiso.soa.mvt.entity;

import java.util.Calendar;

public class RMvrRuleViolation {

	private Long id;
	private Long marketValidationId;
	private Long validationRule;
	private String violationObject;
	private Calendar stgLoadTs;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getMarketValidationId() {
		return marketValidationId;
	}
	public void setMarketValidationId(Long marketValidationId) {
		this.marketValidationId = marketValidationId;
	}
	public Long getValidationRule() {
		return validationRule;
	}
	public void setValidationRule(Long validationRule) {
		this.validationRule = validationRule;
	}
	public String getViolationObject() {
		return violationObject;
	}
	public void setViolationObject(String violationObject) {
		this.violationObject = violationObject;
	}
	public Calendar getStgLoadTs() {
		return stgLoadTs;
	}
	public void setStgLoadTs(Calendar stgLoadTs) {
		this.stgLoadTs = stgLoadTs;
	}
}
