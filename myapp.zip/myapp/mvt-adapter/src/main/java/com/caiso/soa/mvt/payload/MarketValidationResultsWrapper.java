package com.caiso.soa.mvt.payload;

import com.caiso.soa.framework.payload.DomainPayload;
import com.caiso.soa.marketvalidationresults_v1.MarketValidationResults;

public class MarketValidationResultsWrapper extends DomainPayload<MarketValidationResults> {

}
