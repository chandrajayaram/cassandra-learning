package com.caiso.soa.mvt.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.caiso.soa.mvt.dao.MarketRunDAO;
import com.caiso.soa.mvt.domain.MvtPriceCorrectionDTO;


/**
 * The Class MarketRunDAOImpl.
 */
@Repository
public class MarketRunDAOImpl implements MarketRunDAO {
    
    /** The log. */
    private Logger log = LoggerFactory.getLogger(this.getClass());

    
	/** The mkt notes jdbc template. */
	@Autowired
    @Qualifier("mktNotesJdbcTemplate")
    private NamedParameterJdbcTemplate mktNotesJdbcTemplate;
	
	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketRunDAO#getPendingMarketRunInputData(java.lang.String, java.lang.String)
	 */
	@Override
	public List<MvtPriceCorrectionDTO> getPendingMarketRunInputData(String status, String serviceName) {
	log.info(" getPendingMarketRunInputData Begin...");
		
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("STATUS", status);
		paramSource.addValue("SERVICE_NAME", serviceName);
		
		SqlRowSet mktInputRs = mktNotesJdbcTemplate.queryForRowSet("select id, start_date, end_date, status, mkt_type from MVT_PUB_PRICE_CORRECTION where status=:STATUS and service_name=:SERVICE_NAME and rownum=1", paramSource);
		
		List<MvtPriceCorrectionDTO> marketRunInputList = new ArrayList<>(10);
		MvtPriceCorrectionDTO marketRunDTO;
		while(mktInputRs.next()){
			marketRunDTO = new MvtPriceCorrectionDTO();
			marketRunDTO.setId(mktInputRs.getLong("ID")); 
			marketRunDTO.setStartDate(new java.util.Date(mktInputRs.getTimestamp("START_DATE").getTime()));
			marketRunDTO.setEndDate(new java.util.Date(mktInputRs.getTimestamp("END_DATE").getTime()));
			marketRunDTO.setStatus(mktInputRs.getString("STATUS"));
			marketRunDTO.setMktType(mktInputRs.getString("MKT_TYPE"));
			marketRunInputList.add(marketRunDTO);
		}
		log.info(" getPendingMarketRunInputData END...");
		
		return marketRunInputList;

	}

	/* (non-Javadoc)
	 * @see com.caiso.soa.mvt.dao.MarketRunDAO#updateMarketRunInputData(java.util.List, java.lang.String, java.lang.String)
	 */
	@Override
	public void updateMarketRunInputData(List<MvtPriceCorrectionDTO> marketRunList, String status, String serviceName) {
		log.info(" updateMarketRunInputData Begin...");
		
		log.info ("Setting status to :" + status);
		
		List<Long> idList = new ArrayList<>(10);
		for(MvtPriceCorrectionDTO marketRun : marketRunList){
			idList.add(marketRun.getId());
		}
		
		
		if(!idList.isEmpty()){
			MapSqlParameterSource paramSource = new MapSqlParameterSource();
			paramSource.addValue("STATUS", status);
			paramSource.addValue("SERVICE_NAME", serviceName);
			paramSource.addValue("IDLIST", idList);
			mktNotesJdbcTemplate.update("UPDATE MVT_PUB_PRICE_CORRECTION set status = :STATUS, updated_date =sysdate, updated_by='mvt_adapter' where service_name = :SERVICE_NAME and id in (:IDLIST)", paramSource);
		}	
		
		log.info(" updateMarketRunInputData END...");
	}

}
