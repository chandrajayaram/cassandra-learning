package com.caiso.soa.mvt.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.soap.server.endpoint.annotation.SoapAction;

import com.caiso.soa.mvt.payload.MarketValidationResultsWrapper;
import com.caiso.soa.mvt.service.ReceiveMarketValidationResultsService;

@Endpoint
public class MvtEndpoint {

    @Autowired
    private ReceiveMarketValidationResultsService receiveResourceAwardsService;
   

    @SoapAction("http://www.caiso.com/soa/receiveMarketValidationResults_v1")
    @ResponseBody
    public Boolean receiveMarketValidationResults_v1(@RequestPayload MarketValidationResultsWrapper elem) {
    	receiveResourceAwardsService.process(elem);
        return true;
    }

}
