package com.caiso.soa.mvt.service;

import java.util.Calendar;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caiso.soa.marketvalidationresults_v1.MessagePayload;
import com.caiso.soa.mvt.dao.MarketValidationsDAO;
import com.caiso.soa.mvt.payload.MarketValidationResultsWrapper;

@Service
public class ReceiveMarketValidationResultsService {

	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	//@Autowired
    //private AutowireCapableBeanFactory factory;
	
	@Autowired
	private MarketValidationsDAO marketValidationsDAO;
	
	@Transactional
    public void process(MarketValidationResultsWrapper marketValidationResults) {
		log.info("Started processing payload:: "+ marketValidationResults.getServiceName());
		
		//MessageHeader messageHeader = marketValidationResults.getDomainObject().getMessageHeader();
		
		MessagePayload messagePayLoad = marketValidationResults.getDomainObject().getMessagePayload();
		
		Calendar cal = Calendar.getInstance();
		
		Long messagePayloadId = marketValidationsDAO.saveMessage(marketValidationResults.getServiceName(), cal);//save data into R_MVR_MESSAGEPAYLOAD
		
		marketValidationsDAO.saveMarketRun(messagePayLoad.getMarketRun(), messagePayloadId, cal);//Save data into R_MVR_MARKET_RUN
		
		marketValidationsDAO.saveMarketValidations(messagePayLoad.getMarketValidations(), messagePayloadId, cal);//Save data to R_MVR_MARKETVALIDATION, R_MVR_RULEVIOLATION, R_MVR_VIOLATIONDATA
		
		
		//ProcessLogEventDAO eventDAO = factory.createBean(ProcessLogEventDAO.class);
        //eventDAO.insert(new LogEvent(EventType.PROCESS_INFO, "Done processing payload"));
	    log.info("Complete processing the {} payload", marketValidationResults.getServiceName());
	}
	
}
