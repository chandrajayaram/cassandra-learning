package com.caiso.soa.mvt.entity;

import java.util.Calendar;

public class RMvrViolationData {

	private Long id;
	private Long ruleViolationId;
	private String elementName;
	private String elementValue;
	private Calendar stgLoadTs;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getRuleViolationId() {
		return ruleViolationId;
	}
	public void setRuleViolationId(Long ruleViolationId) {
		this.ruleViolationId = ruleViolationId;
	}
	public String getElementName() {
		return elementName;
	}
	public void setElementName(String elementName) {
		this.elementName = elementName;
	}
	public String getElementValue() {
		return elementValue;
	}
	public void setElementValue(String elementValue) {
		this.elementValue = elementValue;
	}
	public Calendar getStgLoadTs() {
		return stgLoadTs;
	}
	public void setStgLoadTs(Calendar stgLoadTs) {
		this.stgLoadTs = stgLoadTs;
	}
}
