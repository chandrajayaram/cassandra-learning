package com.caiso.soa.mvt.dao;

import java.util.Calendar;
import java.util.List;

import com.caiso.soa.marketvalidationresults_v1.MarketRun;
import com.caiso.soa.marketvalidationresults_v1.MarketValidation;



/**
 * The Interface MarketValidationsDAO.
 */
public interface MarketValidationsDAO {

	/**
	 * Save message.
	 *
	 * @param serviceName the service name
	 * @param cal the cal
	 * @return the long
	 */
	Long saveMessage(String serviceName, Calendar cal);
	
	/**
	 * Save market run.
	 *
	 * @param marketRun the market run
	 * @param payLoadId the pay load id
	 * @param cal the cal
	 * @return the long
	 */
	Long saveMarketRun(MarketRun marketRun, Long payLoadId, Calendar cal);
	
	/**
	 * Save market validations.
	 *
	 * @param marketValidations the market validations
	 * @param messagePayloadId the message payload id
	 * @param cal the cal
	 */
	void saveMarketValidations(List<MarketValidation> marketValidations, Long messagePayloadId, Calendar cal);
}
