package com.caiso.soa.mvt.domain;

/**
 * The Enum Published represents status of the message.
 */
public enum Published {
	
	/** The y. */
	Y,
	/** The n. */
	N;
}
